"""
EDIForge AI — RAG Retriever v2
Finds most similar XSL maps using deep pattern matching.
Also injects knowledge base patterns into prompts.
"""
import re, json
from pathlib import Path
from training.xsl_indexer import load_index, read_xsl_file, MAPS_DIR
from training.xsl_pattern_extractor import get_patterns_for_ts, load_knowledge_base


def score_map(meta: dict, query: dict) -> float:
    score = 0.0
    # Transaction set match
    if query.get("transaction_set") and meta.get("transaction_set"):
        if query["transaction_set"] == meta["transaction_set"]:
            score += 40.0
    # Namespace match
    if query.get("source_namespace") and meta.get("source_namespace"):
        qns = query["source_namespace"].lower()
        mns = meta["source_namespace"].lower()
        if qns in mns or mns in qns:
            score += 20.0
    # Segment overlap
    q_segs = set(query.get("segments", []))
    m_segs = set(meta.get("segments", []))
    if q_segs and m_segs:
        score += len(q_segs & m_segs) * 3.0
    # Feature flags
    if query.get("has_date_convert") and meta.get("has_date_convert"):   score += 5.0
    if query.get("has_safe_if_check") and meta.get("has_safe_if_check"): score += 5.0
    if query.get("has_number_format") and meta.get("has_number_format"): score += 3.0
    # Loop count similarity
    diff = abs(query.get("foreach_count",0) - meta.get("foreach_count",0))
    score += max(0, 10 - diff * 2)
    # Keyword match
    q_text = query.get("raw_text","").lower()
    fname  = meta.get("filename","").lower()
    for word in ["invoice","status","tender","response","shipment","freight","carrier"]:
        if word in q_text and word in fname:
            score += 8.0
    return score


def retrieve_similar_maps(query: dict, top_k: int = 5) -> list:
    index = load_index()
    if not index:
        return []
    scored = sorted(
        [(score_map(meta, query), meta) for meta in index if score_map(meta, query) > 0],
        key=lambda x: x[0], reverse=True
    )[:top_k]

    results = []
    for score, meta in scored:
        fpath = Path(meta["full_path"])
        try:
            content = read_xsl_file(fpath)
        except Exception:
            content = ""
        results.append({
            "filename": meta["filename"],
            "score": round(score, 1),
            "transaction_set": meta.get("transaction_set",""),
            "segments": meta.get("segments",[]),
            "loops": meta.get("loops",[]),
            "foreach_count": meta.get("foreach_count",0),
            "has_safe_if_check": meta.get("has_safe_if_check", False),
            "has_date_convert": meta.get("has_date_convert", False),
            "line_count": meta.get("line_count", 0),
            "content": content
        })
    return results


def build_rag_context(similar_maps: list, max_chars: int = 12000) -> str:
    if not similar_maps:
        return ""

    lines = [
        "=== YOUR EXISTING XSL MAPS — learn these exact patterns ===",
        f"Using {len(similar_maps)} most similar map(s) from your library.",
        "CRITICAL: Follow the same patterns — namespaces, safe if-checks, segment names, loop structures.",
        ""
    ]
    chars_used = 0
    for i, m in enumerate(similar_maps, 1):
        header = (f"--- MAP {i}: {m['filename']} "
                  f"(match:{m['score']}, TS:{m['transaction_set']}, "
                  f"loops:{m['foreach_count']}) ---")
        lines.append(header)
        if m.get("segments"):
            lines.append(f"EDI segments: {', '.join(m['segments'][:15])}")
        if m.get("has_safe_if_check"):
            lines.append("Uses safe if-checks: YES (wrap every element in xsl:if test != '')")
        if m.get("has_date_convert"):
            lines.append("Uses date conversion: substring(@date,1,4)+substring(@date,6,2)+...")
        lines.append("")

        remaining = max_chars - chars_used
        if remaining > 500:
            chunk = m["content"][:remaining]
            lines.append(chunk)
            chars_used += len(chunk)
        lines.append("")
        lines.append(f"--- END MAP {i} ---")
        lines.append("")
        if chars_used >= max_chars:
            break

    lines.append("=== END EXAMPLE MAPS ===")
    return "\n".join(lines)


def build_knowledge_context(transaction_set: str, max_patterns: int = 30) -> str:
    """Build context from extracted mapping knowledge base."""
    patterns = get_patterns_for_ts(transaction_set)
    if not patterns:
        return ""

    lines = [
        f"=== LEARNED MAPPING PATTERNS FROM YOUR XSL LIBRARY (X12 {transaction_set}) ===",
        "These are exact source→target mappings extracted from your existing maps:",
        ""
    ]

    # Group by safe_check
    safe    = [p for p in patterns if p.get("safe_check")]
    unsafe  = [p for p in patterns if not p.get("safe_check")]

    lines.append(f"Patterns with safe if-check ({len(safe)}):")
    for p in safe[:max_patterns//2]:
        cond = f" [IF: {p['condition'][:60]}]" if p.get("condition") else ""
        lines.append(f"  {p['source']} → {p['target']}{cond}")

    if unsafe:
        lines.append(f"\nDirect mappings ({len(unsafe)}):")
        for p in unsafe[:max_patterns//2]:
            lines.append(f"  {p['source']} → {p['target']}")

    lines.append("")
    lines.append("=== END LEARNED PATTERNS ===")
    return "\n".join(lines)


def infer_query_features(mapping_rows: list, raw_text: str, transaction_set: str = "") -> dict:
    text = raw_text.lower()
    segs = []
    for row in mapping_rows:
        tgt = row.get("target","")
        seg = tgt.split("/")[0].strip() if "/" in tgt else tgt[:4].strip()
        if seg and len(seg) <= 4 and seg.isupper():
            segs.append(seg)
    return {
        "transaction_set": transaction_set,
        "segments": list(dict.fromkeys(segs))[:20],
        "source_namespace": "",
        "has_date_convert": any(k in text for k in ["date","time","yyyymmdd","datetime"]),
        "has_safe_if_check": True,  # Always encourage safe checks
        "has_number_format": any(k in text for k in ["weight","amount","qty","quantity","total"]),
        "foreach_count": sum(1 for r in mapping_rows if r.get("target","").count("/") > 1),
        "raw_text": raw_text[:500]
    }
