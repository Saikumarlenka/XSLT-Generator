"""
EDIForge AI — XSL Map Indexer v2
Supports UTF-8 and UTF-16 files (BizTalk exports are UTF-16)
Extracts deep patterns: mappings, loops, conditions, templates, segments
"""
import os, json, re, hashlib
from pathlib import Path
from lxml import etree

MAPS_DIR   = Path(__file__).parent / "xsl_maps"
STORE_FILE = Path(__file__).parent / "vector_store" / "index.json"

XSL_NS  = "http://www.w3.org/1999/XSL/Transform"
MSXSL_NS = "urn:schemas-microsoft-com:xslt"


# ── Encoding-safe reader ───────────────────────────────────────────────────

def read_xsl_file(path: Path) -> str:
    """Read XSL file supporting UTF-8, UTF-16 LE/BE and ANSI."""
    with open(path, "rb") as f:
        raw = f.read()

    # Detect UTF-16 BOM
    if raw.startswith(b'\xff\xfe') or raw.startswith(b'\xfe\xff'):
        content = raw.decode("utf-16")
    else:
        try:
            content = raw.decode("utf-8")
        except UnicodeDecodeError:
            content = raw.decode("latin-1")

    # Remove null bytes that appear in badly-decoded UTF-16
    content = content.replace("\x00", "")
    return content


# ── Deep XSL Pattern Extractor ────────────────────────────────────────────

def extract_deep_patterns(content: str, filename: str) -> dict:
    """
    Parse XSL with lxml and extract all semantic patterns:
    - source→target mappings with conditions
    - loops (xsl:for-each selects)
    - conditions (xsl:if tests)
    - choose/when value translations
    - reusable templates
    - BizTalk functoids
    - EDI segments created
    """
    patterns = {
        "filename": filename,
        "transaction_set": "",
        "source_namespace": "",
        "target_root": "",
        "mappings": [],
        "loops": [],
        "conditions": [],
        "value_translations": [],
        "templates_defined": [],
        "templates_called": [],
        "biztalk_functoids": [],
        "segments": [],
        "has_date_convert": False,
        "has_number_format": False,
        "has_normalize_space": False,
        "has_safe_if_check": False,
        "foreach_count": 0,
        "template_count": 0,
        "line_count": len(content.splitlines()),
        "valid": True
    }

    # Strip XML declaration — lxml handles encoding itself
    import re as _re
    content_for_parse = _re.sub(r"<\?xml[^?]*\?>", "", content, count=1).strip()
    try:
        root = etree.fromstring(content_for_parse.encode("utf-8"))
    except etree.XMLSyntaxError as e:
        patterns["valid"] = False
        patterns["parse_error"] = str(e)
        return patterns

    ns  = {"xsl": XSL_NS}
    nsm = {"msxsl": MSXSL_NS}

    # Transaction set & namespace detection
    for ts in ["210","214","204","990","850","856","810","997"]:
        if ts in filename or f'X12_00401_{ts}' in content:
            patterns["transaction_set"] = ts
            break
    ns_match = re.search(r'xmlns:s0="([^"]+)"', content)
    if ns_match:
        patterns["source_namespace"] = ns_match.group(1)

    # 1. Extract source→target mappings with their conditions
    for val in root.xpath("//xsl:value-of", namespaces=ns):
        source = val.get("select", "")
        parent = val.getparent()
        if parent is None:
            continue
        target = etree.QName(parent.tag).localname if parent.tag else ""

        # Walk ancestors to find the nearest xsl:if condition
        condition = ""
        for anc in val.iterancestors():
            tag = etree.QName(anc.tag).localname if anc.tag else ""
            if tag == "if":
                condition = anc.get("test", "")
                break
            if tag in ["for-each", "template"]:
                break

        if source and target and target not in ("stylesheet","template","when","if","choose","otherwise"):
            patterns["mappings"].append({
                "source": source,
                "target": target,
                "condition": condition
            })

    # 2. Extract loops
    for fe in root.xpath("//xsl:for-each", namespaces=ns):
        sel = fe.get("select", "")
        if sel:
            patterns["loops"].append(sel)
    patterns["foreach_count"] = len(patterns["loops"])

    # 3. Extract all xsl:if conditions
    for cond in root.xpath("//xsl:if", namespaces=ns):
        test = cond.get("test", "")
        if test:
            patterns["conditions"].append(test)

    # 4. Extract choose/when value translation tables
    for choose in root.xpath("//xsl:choose", namespaces=ns):
        translations = []
        for when in choose.xpath("xsl:when", namespaces=ns):
            test = when.get("test", "")
            # Get text content of the when
            text = "".join(when.itertext()).strip()
            translations.append({"test": test, "value": text[:80]})
        otherwise = choose.find(f"{{{XSL_NS}}}otherwise")
        if otherwise is not None:
            translations.append({"test": "otherwise", "value": "".join(otherwise.itertext()).strip()[:80]})
        if translations:
            patterns["value_translations"].append(translations)

    # 5. Template names defined
    for tmpl in root.xpath("//xsl:template[@name]", namespaces=ns):
        name = tmpl.get("name", "")
        if name:
            patterns["templates_defined"].append(name)
    patterns["template_count"] = len(root.xpath("//xsl:template", namespaces=ns))

    # 6. Templates called
    for call in root.xpath("//xsl:call-template", namespaces=ns):
        name = call.get("name", "")
        if name and name not in patterns["templates_called"]:
            patterns["templates_called"].append(name)

    # 7. BizTalk functoids
    try:
        for script in root.xpath("//msxsl:script", namespaces={"msxsl": MSXSL_NS}):
            patterns["biztalk_functoids"].append("msxsl:script")
    except Exception:
        pass
    if "userCSharp" in content:
        patterns["biztalk_functoids"].append("userCSharp")

    # 8. EDI segments created (non-XSL namespace elements)
    for elem in root.iter():
        # Skip comment/PI nodes (their .tag is a callable in lxml)
        if callable(elem.tag) or not elem.tag:
            continue
        if "{" in elem.tag:
            local  = etree.QName(elem.tag).localname
            ns_uri = etree.QName(elem.tag).namespace
        else:
            local  = elem.tag
            ns_uri = ""
        # Skip XSL/MSXSL elements; include ns0 namespace (EDI output)
        if ns_uri in (XSL_NS, MSXSL_NS, None):
            continue
        if re.match(r'^[A-Z][A-Z0-9]{1,3}$', local) or re.match(r'^[A-Z][A-Z0-9]+Loop', local):
            if local not in patterns["segments"]:
                patterns["segments"].append(local)

    # Feature flags
    patterns["has_date_convert"]     = "substring(@" in content and "concat(" in content
    patterns["has_number_format"]    = "format-number(" in content
    patterns["has_normalize_space"]  = "normalize-space(" in content
    patterns["has_safe_if_check"]    = ("!= ''" in content or "!= \"\"" in content or
                                        "string-length(" in content)

    # Target root element
    root_match = re.search(r'<(ns0:[A-Za-z0-9_]+)', content)
    if root_match:
        patterns["target_root"] = root_match.group(1)

    return patterns


# ── Index Builder ─────────────────────────────────────────────────────────

def build_index() -> dict:
    """Scan xsl_maps/ and build full semantic index."""
    STORE_FILE.parent.mkdir(exist_ok=True, parents=True)
    index = {"maps": [], "total": 0, "last_updated": ""}

    xsl_files = list(MAPS_DIR.glob("**/*.xsl")) + list(MAPS_DIR.glob("**/*.xslt"))

    if not xsl_files:
        print(f"No XSL files found in {MAPS_DIR}")
        print("Add your .xsl/.xslt files to training/xsl_maps/ and run again.")
        return index

    print(f"Indexing {len(xsl_files)} XSL file(s)...")

    for fpath in xsl_files:
        print(f"  → {fpath.name}")
        try:
            content = read_xsl_file(fpath)

            # Validate it's actually XSLT
            if "<xsl:stylesheet" not in content and "<xsl:transform" not in content:
                print(f"  ⚠ Skipping {fpath.name} — not a valid XSLT file")
                continue

            meta = extract_deep_patterns(content, fpath.name)
            if not meta["valid"]:
                print(f"  ⚠ Skipping {fpath.name} — XML parse error: {meta.get('parse_error','')[:80]}")
                continue

            meta["full_path"] = str(fpath)
            meta["hash"] = hashlib.md5(content.encode()).hexdigest()[:8]
            meta["full_content"] = content  # keep in memory only

            index["maps"].append(meta)
            print(f"  ✔ {fpath.name} — TS:{meta['transaction_set']} "
                  f"mappings:{len(meta['mappings'])} loops:{meta['foreach_count']} "
                  f"segs:{len(meta['segments'])}")

        except Exception as e:
            print(f"  ✗ {fpath.name}: {e}")

    index["total"] = len(index["maps"])

    import datetime
    index["last_updated"] = datetime.datetime.now().isoformat()

    # Save index (without full_content)
    index_for_file = {"maps": [], "total": index["total"], "last_updated": index["last_updated"]}
    for m in index["maps"]:
        m_copy = {k: v for k, v in m.items() if k != "full_content"}
        index_for_file["maps"].append(m_copy)

    STORE_FILE.write_text(json.dumps(index_for_file, indent=2))
    print(f"\n✅ Index saved: {index['total']} maps")
    return index


def load_index() -> list:
    if not STORE_FILE.exists():
        return []
    return json.loads(STORE_FILE.read_text()).get("maps", [])


def get_index_stats() -> dict:
    if not STORE_FILE.exists():
        return {"total": 0, "indexed": False}
    data = json.loads(STORE_FILE.read_text())
    maps = data.get("maps", [])
    ts_counts = {}
    for m in maps:
        ts = m.get("transaction_set", "unknown") or "unknown"
        ts_counts[ts] = ts_counts.get(ts, 0) + 1
    return {
        "total": len(maps),
        "indexed": True,
        "last_updated": data.get("last_updated", ""),
        "transaction_sets": ts_counts
    }


if __name__ == "__main__":
    build_index()
