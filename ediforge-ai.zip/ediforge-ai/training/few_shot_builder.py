"""EDIForge AI - Few Shot Builder (stub - returns empty if no knowledge base yet)"""
from pathlib import Path
import json

KNOWLEDGE_DIR = Path(__file__).parent / "knowledge"

def build_few_shot_section(transaction_set: str = "", max_chars: int = 3000) -> str:
    try:
        ts_file = KNOWLEDGE_DIR / f"{transaction_set}_patterns.json"
        if not ts_file.exists():
            return ""
        patterns = json.loads(ts_file.read_text())
        if not patterns:
            return ""
        lines = [
            f"=== FEW-SHOT EXAMPLES FROM YOUR {transaction_set} MAPS ===",
            "Use exactly this safe if-check pattern for every element:",
            ""
        ]
        count = 0
        for p in patterns:
            if not p.get("safe_check"):
                continue
            src  = p.get("source", "")
            tgt  = p.get("target", "")
            cond = p.get("condition", f"{src} != ''")
            lines.append(f'<xsl:if test="{cond}">')
            lines.append(f'  <{tgt}>')
            lines.append(f'    <xsl:call-template name="CleanAlphaField">')
            lines.append(f'      <xsl:with-param name="inputText" select="{src}"/>')
            lines.append(f'      <xsl:with-param name="maxLength" select="30"/>')
            lines.append(f'    </xsl:call-template>')
            lines.append(f'  </{tgt}>')
            lines.append(f'</xsl:if>')
            lines.append("")
            count += 1
            if count >= 10:
                break
        lines.append("=== END FEW-SHOT EXAMPLES ===")
        result = "\n".join(lines)
        return result[:max_chars]
    except Exception:
        return ""
