<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:msxsl="urn:schemas-microsoft-com:xslt"
xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var"
exclude-result-prefixes="msxsl var s0"
version="1.0"
xmlns:s0="http://Echo.BSSR.Internal.Canonical.TendorResponse.TenderResponseOut"
xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00401.EDI990/v1.0">
<xsl:output omit-xml-declaration="yes" method="xml" version="1.0" />
<xsl:template match="/">
<xsl:apply-templates select="/s0:TenderResponse" />
</xsl:template>
<xsl:template match="/s0:TenderResponse">
<xsl:variable name="vCustomerId"    select="@CustomerId" />
<xsl:variable name="vCompanyId"     select="@CompanyId" />
<xsl:variable name="vDefaultSCAC"   select="Transaction/Header/SCAC/text()" />
<xsl:variable name="vBOL"           select="Transaction/Header/BOL/text()" />
<xsl:variable name="vRefSCAC"       select="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='7J']/RefValue/text()" />
<xsl:variable name="vRefMBOL"       select="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='MB']/RefValue/text()" />
<xsl:variable name="vMode"          select="Transaction/Header/Mode/text()" />
<xsl:variable name="vBookingDateRaw" select="Transaction/Header/BookingDate/text()" />
<xsl:variable name="vReservationCode" select="Transaction/Header/ReservationCode/text()" />
<xsl:variable name="vRemarks"       select="Transaction/Header/Remarks/text()" />

<xsl:variable name="vBookingDate"          select="substring-before($vBookingDateRaw,'T')" />
<xsl:variable name="vBookingTime"          select="substring-after($vBookingDateRaw,'T')" />
<xsl:variable name="vBookingYear"          select="substring-before($vBookingDate, '-')" />
<xsl:variable name="vBookingMonthDay"      select="substring-after($vBookingDate,'-')" />
<xsl:variable name="vBookingMonth"         select="substring-before($vBookingMonthDay,'-')" />
<xsl:variable name="vBookingDay"           select="substring-after($vBookingMonthDay,'-')" />
<xsl:variable name="vBookingHour"          select="substring-before($vBookingTime,':')" />
<xsl:variable name="vBookingMinutesSeconds" select="substring-after($vBookingTime,':')" />
<xsl:variable name="vBookingMinutes"       select="substring-before($vBookingMinutesSeconds,':')" />

<ns0:X12_00401_990>
<!-- ST: configured in BizTalk envelope -->
<ST>
<ST01>990</ST01>
<ST02>0001</ST02>
<!--<ST03></ST03>-->
</ST>

<!-- B1: Beginning Segment for Response to a Load Tender -->
<ns0:B1>
<!-- B101: SCAC code  driven from canonical source, set in BRE per customer -->
<B101>
<xsl:value-of select="Transaction/Header/SCAC/text()" />
</B101>
<!-- B102: Shipment Identification (BOL). Some customers use MBOL instead -->
<B102>
<xsl:value-of select="Transaction/Header/BOL/text()" />
</B102>
<!-- B103: Date YYYYMMDD -->
<B103>
<xsl:value-of select="$vBookingYear"/>
<xsl:value-of select="$vBookingMonth"/>
<xsl:value-of select="$vBookingDay"/>
</B103>
<!-- B104: Reservation Action Code (A=Accept, D=Decline) -->
<B104>
<xsl:value-of select="$vReservationCode"/>
</B104>
</ns0:B1>

<!-- K1: Remarks  only when B104=D (Tender Declined). Codes vary by customer -->
<xsl:if test="$vReservationCode = 'D'">
<ns0:K1>
<K101>
<xsl:value-of select="Transaction/Header/RejectReasonCode/text()" />
</K101>
<K102>
<xsl:value-of select="Transaction/Header/RejectReasonDescription/text()" />
</K102>
</ns0:K1>
</xsl:if>

<!-- N9: Reference Identification. Default qualifier CN; additional refs per customer DBconfig -->
<ns0:N9>
<N901>
<xsl:value-of select="Transaction/ReferenceNumbers/ReferenceNumber[1]/EDICode/text()"/>
</N901>
<N902>
<xsl:value-of select="Transaction/ReferenceNumbers/ReferenceNumber[1]/RefValue/text()"/>
</N902>
</ns0:N9>

<!-- N9: Additional reference (TN, CR, etc.)  conditional, only if present -->
<xsl:if test="Transaction/ReferenceNumbers/ReferenceNumber[2]/RefValue/text() != ''">
<ns0:N9>
<N901>
<xsl:value-of select="Transaction/ReferenceNumbers/ReferenceNumber[2]/EDICode/text()"/>
</N901>
<N902>
<xsl:value-of select="Transaction/ReferenceNumbers/ReferenceNumber[2]/RefValue/text()"/>
</N902>
</ns0:N9>
</xsl:if>

<!-- G62: Date/Time  EP qualifier for estimated pickup -->
<ns0:G62>
<G6201>
<xsl:value-of select="Transaction/Header/DateQualifier/text()"/>
</G6201>
<xsl:if test="$vBookingDate != ''">
<G6202>
<xsl:value-of select="$vBookingYear"/>
<xsl:value-of select="$vBookingMonth"/>
<xsl:value-of select="$vBookingDay"/>
</G6202>
</xsl:if>
<G6203>
<xsl:value-of select="Transaction/Header/TimeQualifier/text()"/>
</G6203>
<xsl:if test="$vBookingTime != ''">
<G6204>
<xsl:value-of select="$vBookingHour"/>
<xsl:value-of select="$vBookingMinutes"/>
</G6204>
</xsl:if>
</ns0:G62>

<!-- V9: Event Detail  only on Decline. Reason codes vary by customer -->
<xsl:if test="$vReservationCode = 'D'">
<ns0:V9>
<V901>
<xsl:value-of select="Transaction/Header/EventReasonCode/text()"/>
</V901>
<xsl:if test="Transaction/Header/EventReasonDescription/text() != ''">
<V902>
<xsl:value-of select="Transaction/Header/EventReasonDescription/text()"/>
</V902>
</xsl:if>
<xsl:if test="Transaction/Header/EventStatusCode/text() != ''">
<V908>
<xsl:value-of select="Transaction/Header/EventStatusCode/text()"/>
</V908>
</xsl:if>
</ns0:V9>
</xsl:if>


<SE>
<SE01>990</SE01>
<SE02>0001</SE02>
<!--<SE03></SE03>-->
</SE>

</ns0:X12_00401_990>
</xsl:template>

<!-- CleanAlphaField start -->
<xsl:template name="CleanAlphaField">
<xsl:param name="inputText" />
<xsl:param name="maxLength" />
<xsl:variable name="singleQuote" select='"&apos;"' />
<xsl:variable name="doubleQuote" select="'&quot;'" />
<xsl:variable name="vAllowedSymbolsPart1" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}\?/#'"/>
<xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
<xsl:variable name="vCleanedText" select="translate($inputText,translate($inputText, $vAllowedSymbols, ''),'')"/>
<xsl:value-of select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
</xsl:template>
<!-- CleanAlphaField end -->

</xsl:stylesheet>