"""
EDIForge AI — XSL Pattern Extractor
Reads ALL indexed XSL maps and builds a unified mapping knowledge base.
Extracts:
  - source→target XPath mappings with conditions
  - Loop structures
  - Value translation tables (choose/when)
  - Reusable template patterns
  - BizTalk functoid usage
"""
import json
from pathlib import Path
from lxml import etree
from training.xsl_indexer import read_xsl_file, extract_deep_patterns, MAPS_DIR

KNOWLEDGE_DIR = Path(__file__).parent / "knowledge"

XSL_NS = "http://www.w3.org/1999/XSL/Transform"


def extract_value_templates(content: str, root) -> list:
    """
    Extract named template value-mapping tables.
    e.g. StopTypeMapValue: Pick->SF, Drop->CN
    """
    ns = {"xsl": XSL_NS}
    tables = []
    for tmpl in root.xpath("//xsl:template[@name]", namespaces=ns):
        name = tmpl.get("name", "")
        rows = []
        for when in tmpl.xpath(".//xsl:when", namespaces=ns):
            test = when.get("test", "")
            val  = "".join(when.itertext()).strip()
            rows.append({"test": test, "value": val})
        oth = tmpl.find(f".//{{{XSL_NS}}}otherwise")
        if oth is not None:
            rows.append({"test": "otherwise", "value": "".join(oth.itertext()).strip()})
        if rows:
            tables.append({"template_name": name, "rows": rows})
    return tables


def extract_safe_mappings(content: str, root) -> list:
    """
    Extract mappings that use safe if-check pattern.
    Returns each mapping enriched with:
    - safe_check: bool (wrapped in xsl:if != '')
    - condition_type: none | not_empty | length | numeric | custom
    """
    ns = {"xsl": XSL_NS}
    mappings = []

    for val in root.xpath("//xsl:value-of", namespaces=ns):
        source = val.get("select", "")
        parent = val.getparent()
        if parent is None:
            continue
        target_tag = parent.tag or ""
        target = etree.QName(target_tag).localname if "{" in target_tag else target_tag

        if not source or target in ("stylesheet","template","when","if","choose","otherwise","for-each"):
            continue

        # Determine condition context
        condition = ""
        condition_type = "none"
        loop_context = ""
        safe_check = False

        for anc in val.iterancestors():
            anc_tag = etree.QName(anc.tag).localname if anc.tag and "{" in anc.tag else (anc.tag or "")
            if anc_tag == "if":
                condition = anc.get("test", "")
                # Classify condition type
                if "!= ''" in condition or '!= ""' in condition:
                    condition_type = "not_empty"
                    safe_check = True
                elif "string-length" in condition or "normalize-space" in condition:
                    condition_type = "length"
                    safe_check = True
                elif "> 0" in condition or "< 0" in condition:
                    condition_type = "numeric"
                    safe_check = True
                else:
                    condition_type = "custom"
                break
            elif anc_tag == "for-each":
                loop_context = anc.get("select", "")
                break

        mappings.append({
            "source": source,
            "target": target,
            "condition": condition,
            "condition_type": condition_type,
            "safe_check": safe_check,
            "loop_context": loop_context
        })

    return mappings


def build_knowledge_base() -> dict:
    """Process all XSL maps and build unified knowledge base."""
    KNOWLEDGE_DIR.mkdir(exist_ok=True)

    xsl_files = list(MAPS_DIR.glob("**/*.xsl")) + list(MAPS_DIR.glob("**/*.xslt"))
    if not xsl_files:
        print(f"No XSL files in {MAPS_DIR}")
        return {}

    print(f"Building knowledge base from {len(xsl_files)} XSL maps...")

    all_mappings    = []
    all_loops       = []
    all_conditions  = []
    all_vt_tables   = []
    all_templates   = []
    per_file        = []

    for fpath in xsl_files:
        print(f"  → {fpath.name}")
        try:
            content = read_xsl_file(fpath)
            if "<xsl:stylesheet" not in content and "<xsl:transform" not in content:
                print(f"    ⚠ Not XSLT, skipping")
                continue

            import re as _re
            content_p = _re.sub(r"<\?xml[^?]*\?>", "", content, count=1).strip()
            root = etree.fromstring(content_p.encode("utf-8"))
            ns   = {"xsl": XSL_NS}

            # Deep mappings with condition analysis
            mappings = extract_safe_mappings(content, root)

            # Loops
            loops = [fe.get("select","") for fe in root.xpath("//xsl:for-each", namespaces=ns)]

            # Conditions
            conditions = [c.get("test","") for c in root.xpath("//xsl:if", namespaces=ns)]

            # Value translation tables
            vt_tables = extract_value_templates(content, root)

            # Templates defined
            templates = [t.get("name","") for t in root.xpath("//xsl:template[@name]", namespaces=ns)]

            # Transaction set
            ts = ""
            for t in ["210","214","204","990","850","856"]:
                if t in fpath.name or f"X12_00401_{t}" in content:
                    ts = t
                    break

            file_record = {
                "file": fpath.name,
                "transaction_set": ts,
                "mapping_count": len(mappings),
                "loop_count": len(loops),
                "condition_count": len(conditions),
                "safe_check_count": sum(1 for m in mappings if m["safe_check"]),
                "mappings": mappings,
                "loops": loops,
                "conditions": conditions,
                "value_translations": vt_tables,
                "templates": templates
            }
            per_file.append(file_record)

            # Accumulate with file tag
            for m in mappings:
                m["_file"] = fpath.name
                m["_ts"]   = ts
                all_mappings.append(m)
            for l in loops:
                all_loops.append({"xpath": l, "_file": fpath.name, "_ts": ts})
            for c in conditions:
                all_conditions.append({"test": c, "_file": fpath.name, "_ts": ts})
            all_vt_tables.extend(vt_tables)
            for t in templates:
                all_templates.append({"name": t, "_file": fpath.name})

            safe_pct = int(file_record["safe_check_count"] / max(len(mappings),1) * 100)
            print(f"    ✔ mappings:{len(mappings)} loops:{len(loops)} "
                  f"safe-checks:{file_record['safe_check_count']}({safe_pct}%)")

        except Exception as e:
            print(f"    ✗ Error: {e}")

    # Save knowledge base
    kb = {
        "total_files":    len(per_file),
        "total_mappings": len(all_mappings),
        "total_loops":    len(all_loops),
        "mappings":       all_mappings,
        "loops":          all_loops,
        "conditions":     all_conditions,
        "value_translations": all_vt_tables,
        "templates":      all_templates,
        "per_file":       per_file
    }

    (KNOWLEDGE_DIR / "mapping_patterns.json").write_text(json.dumps(kb, indent=2))

    # Also save per-transaction-set files for faster lookup
    ts_data = {}
    for m in all_mappings:
        ts = m.get("_ts", "unknown") or "unknown"
        if ts not in ts_data:
            ts_data[ts] = []
        ts_data[ts].append(m)
    for ts, maps in ts_data.items():
        (KNOWLEDGE_DIR / f"{ts}_patterns.json").write_text(json.dumps(maps, indent=2))

    print(f"\n✅ Knowledge base built:")
    print(f"   Files:    {len(per_file)}")
    print(f"   Mappings: {len(all_mappings)}")
    print(f"   Loops:    {len(all_loops)}")
    print(f"   VT tables:{len(all_vt_tables)}")
    return kb


def load_knowledge_base() -> dict:
    kb_file = KNOWLEDGE_DIR / "mapping_patterns.json"
    if not kb_file.exists():
        return {}
    return json.loads(kb_file.read_text())


def get_patterns_for_ts(transaction_set: str) -> list:
    """Get all mapping patterns for a specific transaction set."""
    ts_file = KNOWLEDGE_DIR / f"{transaction_set}_patterns.json"
    if ts_file.exists():
        return json.loads(ts_file.read_text())
    kb = load_knowledge_base()
    return [m for m in kb.get("mappings", []) if m.get("_ts") == transaction_set]


if __name__ == "__main__":
    build_knowledge_base()


def auto_sync_to_learning_engine():
    """Push extracted XSL patterns into the LearningEngine after every rebuild."""
    try:
        from backend.learning.learning_engine import LearningEngine
        learner     = LearningEngine()
        all_patterns = []
        for txn in ["210", "204", "214", "850"]:
            p_file = KNOWLEDGE_DIR / f"{txn}_patterns.json"
            if p_file.exists():
                try:
                    patterns = json.loads(p_file.read_text(encoding="utf-8"))
                    if isinstance(patterns, list):
                        all_patterns.extend(patterns)
                except Exception:
                    pass
        if all_patterns:
            learner.learn_from_xsl_patterns(all_patterns)
            print(f"[Learning] Synced {len(all_patterns)} XSL patterns to learning engine")
    except Exception as e:
        print(f"[Learning] Auto-sync failed: {e}")
