﻿<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet version="1.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:msxsl="urn:schemas-microsoft-com:xslt"
                xmlns:con="http://Echo.BSSR.Internal.Canonical.Status/v1.0"
                xmlns:edi="http://Echo.BSSR.Schemas.EDI.X12_00401.EDI214/v1.0"
                xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp"
                exclude-result-prefixes="msxsl">
	<xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>
	<xsl:param name="chunkSize" select="30" />

	<xsl:template match="//con:Status/StatusList/ShipmentStatus">
		<xsl:element name="edi:X12_00401_214">
			<xsl:apply-templates select="." mode="BuildST"/>
			<xsl:apply-templates select="." mode="BuildB10"/>

			<xsl:apply-templates select="BusinessReferences/BusinessReference" mode="BuildL11" />

			<xsl:for-each select="Statuses/Status/Details/Detail[@stopType = 'Pick']/../../@assignedNumber">
				<xsl:sort data-type="number" order="ascending" />
				<xsl:if test="position()=1">
					<xsl:apply-templates select="//Statuses/Status[@assignedNumber= current()]/Details/Detail[@stopType = 'Pick']" mode="BuildN1Loop1" />
				</xsl:if>
			</xsl:for-each>

			<xsl:for-each select="Statuses/Status/Details/Detail[@stopType = 'Drop']/../../@assignedNumber">
				<xsl:sort data-type="number" order="descending" />
				<xsl:if test="position()=1">
					<xsl:apply-templates select="//Statuses/Status[@assignedNumber= current()]/Details/Detail[@stopType = 'Drop']" mode="BuildN1Loop1" />
				</xsl:if>
			</xsl:for-each>

			<xsl:apply-templates select="//Statuses/Status/Details/Detail[not(userCSharp:IsNullOrEmpty(@statusCode))]" mode="BuildLXLoop1" />

		</xsl:element>
	</xsl:template>

	<xsl:template match="BusinessReference" mode="BuildL11">
		<xsl:element name="edi:L11">

			<xsl:element name="L1101">
				<xsl:value-of select="@referenceId"/>
			</xsl:element>

			<xsl:element name="L1102">
				<xsl:choose>
					<xsl:when test="@referenceType = 'ZC' and @referenceDescription = 'Carrier Name'">
						<xsl:text>ZC</xsl:text>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="@referenceType"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:element>

			<xsl:if test="@referenceType = 'ZC' and @referenceDescription = 'Carrier Name'">
				<xsl:element name="L1103">
					<xsl:text>ZC</xsl:text>
				</xsl:element>
			</xsl:if>

		</xsl:element>
	</xsl:template>

	<xsl:template match="ShipmentStatus" mode="BuildST">
		<xsl:element name="ST">
			<xsl:element name="ST01">
				<xsl:text>214</xsl:text>
			</xsl:element>
			<xsl:element name="ST02">
				<xsl:text>1234</xsl:text>
			</xsl:element>
			<!--<xsl:element name="ST03">
        <xsl:value-of select="//con:Status/@CustomerId"/>
      </xsl:element>-->
		</xsl:element>
	</xsl:template>

	<xsl:template match="ShipmentStatus" mode="BuildB10">
		<xsl:element name="edi:B10">
			<xsl:element name="B1001">
				<xsl:value-of select="ReferenceData/LoadId" />
			</xsl:element>
			<xsl:element name="B1002">
				<xsl:value-of select="ReferenceData/Bol" />
			</xsl:element>
			<xsl:element name="B1003">
				<xsl:value-of select="userCSharp:GetSCAC(//con:Status/@CustomerId ,ReferenceData/Scac)"/>
			</xsl:element>
		</xsl:element>
	</xsl:template>

	<xsl:template match="Detail" mode="BuildN1Loop1">
		<xsl:element name="edi:N1Loop1">
			<xsl:apply-templates select="." mode="BuildN1Loop1_N1" />
			<xsl:apply-templates select="." mode="BuildN1Loop1_N3" />
			<xsl:apply-templates select="." mode="BuildN1Loop1_N4" />
		</xsl:element>
	</xsl:template>

	<xsl:template match="Detail" mode="BuildN1Loop1_N1">
		<xsl:element name="edi:N1">
			<xsl:element name="N101">
				<xsl:choose>
					<xsl:when test="@stopType = 'Pick'">
						<xsl:text>SF</xsl:text>
					</xsl:when>
					<xsl:otherwise>
						<xsl:text>ST</xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:element>

			<xsl:if test="not(userCSharp:IsNullOrEmpty(Addresses/Address/@name))">
				<xsl:element name="N102">
					<xsl:value-of select="Addresses/Address/@name"/>
				</xsl:element>
			</xsl:if>

			<xsl:choose>
				<xsl:when test="not(userCSharp:IsNullOrEmpty(Addresses/Address/@locationIdentifierCode))">
					<xsl:element name="N103">
						<xsl:choose>
							<xsl:when test="not(userCSharp:IsNullOrEmpty(Addresses/Address/@locationIdentifier))">
								<xsl:value-of select="Addresses/Address/@locationIdentifier"/>
							</xsl:when>
							<xsl:otherwise>
								<xsl:text>93</xsl:text>
							</xsl:otherwise>
						</xsl:choose>
					</xsl:element>
					<xsl:element name="N104">
						<xsl:value-of select="Addresses/Address/@locationIdentifier"/>
					</xsl:element>
				</xsl:when>

				<xsl:when test="//BusinessReferences/BusinessReference[@referenceType = 'SF' and @referenceDescription='EDIQualifier'] and @stopType = 'Pick'">
					<xsl:element name="N103">
						<xsl:choose>
							<xsl:when test="not(userCSharp:IsNullOrEmpty(Addresses/Address/@locationIdentifier))">
								<xsl:value-of select="Addresses/Address/@locationIdentifier"/>
							</xsl:when>
							<xsl:otherwise>
								<xsl:text>93</xsl:text>
							</xsl:otherwise>
						</xsl:choose>
					</xsl:element>
					<xsl:element name="N104">
						<xsl:value-of select="//BusinessReferences/BusinessReference[@referenceType = 'SF']/@referenceId"/>
					</xsl:element>
				</xsl:when>

				<xsl:when test="//BusinessReferences/BusinessReference[@referenceType = 'ST' and @referenceDescription='EDIQualifier'] and @stopType = 'Drop'">
					<xsl:element name="N103">
						<xsl:choose>
							<xsl:when test="not(userCSharp:IsNullOrEmpty(Addresses/Address/@locationIdentifier))">
								<xsl:value-of select="Addresses/Address/@locationIdentifier"/>
							</xsl:when>
							<xsl:otherwise>
								<xsl:text>93</xsl:text>
							</xsl:otherwise>
						</xsl:choose>
					</xsl:element>
					<xsl:element name="N104">
						<xsl:value-of select="//BusinessReferences/BusinessReference[@referenceType = 'ST']/@referenceId"/>
					</xsl:element>
				</xsl:when>

			</xsl:choose>

		</xsl:element>
	</xsl:template>

	<xsl:template match="Detail" mode="BuildN1Loop1_N3">
		<xsl:element name="edi:N3">
			<xsl:element name="N301">
				<xsl:value-of select="Addresses/Address/@address1"/>
			</xsl:element>

			<xsl:if test="not(userCSharp:IsNullOrEmpty(Addresses/Address/@address2))">
				<xsl:element name="N302">
					<xsl:value-of select="Addresses/Address/@address2"/>
				</xsl:element>
			</xsl:if>

		</xsl:element>
	</xsl:template>

	<xsl:template match="Detail" mode="BuildN1Loop1_N4">
		<xsl:element name="edi:N4">

			<xsl:if test="not(userCSharp:IsNullOrEmpty(Addresses/Address/@city))">
				<xsl:element name="N401">
					<xsl:value-of select="Addresses/Address/@city"/>
				</xsl:element>
			</xsl:if>


			<xsl:if test="not(userCSharp:IsNullOrEmpty(Addresses/Address/@stateProvince))">
				<xsl:element name="N402">
					<xsl:value-of select="Addresses/Address/@stateProvince"/>
				</xsl:element>
			</xsl:if>

			<xsl:if test="not(userCSharp:IsNullOrEmpty(Addresses/Address/@postalCode))">
				<xsl:element name="N403">
					<xsl:value-of select="Addresses/Address/@postalCode"/>
				</xsl:element>
			</xsl:if>

			<xsl:if test="not(userCSharp:IsNullOrEmpty(Addresses/Address/@country))">
				<xsl:element name="N404">
					<xsl:value-of select="Addresses/Address/@country"/>
				</xsl:element>
			</xsl:if>

		</xsl:element>
	</xsl:template>

	<xsl:template match="Detail" mode="BuildLXLoop1">
		<xsl:element name="edi:LXLoop1">
			<xsl:apply-templates select="." mode="BuildLXLoop1_LX" />
			<xsl:element name="edi:AT7Loop1">
				<xsl:apply-templates select="." mode="BuildAT7Loop1_AT7" />
				<xsl:apply-templates select="EquipmentLocation[not(userCSharp:IsNullOrEmpty(@cityName)) and not(userCSharp:IsNullOrEmpty(@stateOrProvince))]" mode="BuildAT7Loop1_MS1" />
				<xsl:apply-templates select="EquipmentLocation[not(userCSharp:IsNullOrEmpty(@equipmentDescriptionCode)) and not(userCSharp:IsNullOrEmpty(@equipmentNumber))]" mode="BuildAT7Loop1_MS2" />
			</xsl:element>
			<xsl:apply-templates select="//ShipmentStatus/ReferenceData[not(userCSharp:IsNullOrEmpty(StopSequenceNumber)) and not(StopSequenceNumber = '0')]" mode="BuildLXLoop1_L11_3" />
			<xsl:variable name="detailStatus" select="@statusCode" />
			<!--<xsl:apply-templates select="//Remarks/Remark[not(userCSharp:IsNullOrEmpty(@remarkMessage2)) and (@remarkMessage1 = $detailStatus)]" mode="BuildLXLoop1_K1_2" />
			<xsl:apply-templates select="//ShipmentTotals[not(userCSharp:IsNullOrEmpty(./TotalWeight)) and (./TotalWeight > 0)]" mode="BuildLXLoop1_AT8" />-->
		</xsl:element>
	</xsl:template>

	<xsl:template match="Detail" mode="BuildLXLoop1_LX">
		<xsl:element name="edi:LX">
			<xsl:element name="LX01">
				<xsl:value-of select="../../@assignedNumber"/>
			</xsl:element>
		</xsl:element>
	</xsl:template>

	<xsl:template match="Detail" mode="BuildAT7Loop1_AT7">
		<xsl:element name="edi:AT7">
			<xsl:if test="not(userCSharp:IsNullOrEmpty(@statusCode))">
				<xsl:choose>
					<xsl:when test="@statusCode != 'AA' and @statusCode != 'AB'">
						<xsl:element name="AT701">
							<xsl:value-of select="@statusCode"/>
						</xsl:element>
						<xsl:element name="AT702">
							<xsl:text>NS</xsl:text>
						</xsl:element>
					</xsl:when>
					<xsl:when test="@statusCode = 'AA' or @statusCode = 'AB'">
						<xsl:element name="AT703">
							<xsl:value-of select="@statusCode"/>
						</xsl:element>
						<xsl:element name="AT704">
							<xsl:text>NA</xsl:text>
						</xsl:element>
					</xsl:when>
				</xsl:choose>
			</xsl:if>

			<xsl:if test="not(userCSharp:IsNullOrEmpty(@statusdatetime))">
				<xsl:element name="AT705">
					<xsl:value-of select="userCSharp:GetDate(@statusdatetime)"/>
				</xsl:element>
				<xsl:element name="AT706">
					<xsl:value-of select="userCSharp:GetTime(@statusdatetime)"/>
				</xsl:element>
			</xsl:if>

			<xsl:choose>
				<xsl:when test="@statusCode = 'AB'">
					<xsl:variable name="StatusCity">
						<xsl:value-of select="EquipmentLocation/@cityName" />
					</xsl:variable>
					<xsl:variable name="StatusState">
						<xsl:value-of select="EquipmentLocation/@stateOrProvince" />
					</xsl:variable>

					<xsl:if test="//Detail[@stopType='Drop' and Addresses/Address/@city = $StatusCity and Addresses/Address/@stateProvince = $StatusState]">
						<xsl:element name="AT707">
							<xsl:value-of select="//Detail[@stopType='Drop' and Addresses/Address/@city = $StatusCity and Addresses/Address/@stateProvince = $StatusState][1]/@statusTimeZone"/>
						</xsl:element>
					</xsl:if>
				</xsl:when>
				<xsl:otherwise>
					<xsl:if test="not(userCSharp:IsNullOrEmpty(@statusTimeZone))">
						<xsl:element name="AT707">
							<xsl:value-of select="@statusTimeZone"/>
						</xsl:element>
					</xsl:if>
				</xsl:otherwise>
			</xsl:choose>

		</xsl:element>
	</xsl:template>
	<xsl:template match="EquipmentLocation" mode="BuildAT7Loop1_MS1">
		<xsl:element name="edi:MS1">
			<xsl:element name="MS101">
				<xsl:call-template name="CleanAlphaField">
					<xsl:with-param name="inputText" select="@cityName"/>
					<xsl:with-param name="maxLength" select="30"/>
				</xsl:call-template>
			</xsl:element>

			<xsl:element name="MS102">
				<xsl:call-template name="CleanAlphaField">
					<xsl:with-param name="inputText" select="@stateOrProvince"/>
					<xsl:with-param name="maxLength" select="2"/>
				</xsl:call-template>
			</xsl:element>

			<xsl:variable name="equipmentLocationCity">
				<xsl:value-of select="@cityName"/>
			</xsl:variable>

			<xsl:if test="//Detail[@stopType='Pick' and Addresses/Address/@city = $equipmentLocationCity]">
				<xsl:element name="MS103">
					<xsl:call-template name="CleanAlphaField">
						<xsl:with-param name="inputText"
							select="//Detail[@stopType='Pick' and Addresses/Address/@city = $equipmentLocationCity][1]/Addresses/Address/@country"/>
						<xsl:with-param name="maxLength" select="3"/>
					</xsl:call-template>
				</xsl:element>
			</xsl:if>
		</xsl:element>
	</xsl:template>

	<xsl:template match="EquipmentLocation" mode="BuildAT7Loop1_MS2">
		<xsl:element name="edi:MS2">
			<xsl:element name="MS201">
				<xsl:call-template name="CleanAlphaField">
					<xsl:with-param name="inputText" select="@equipmentScac"/>
					<xsl:with-param name="maxLength" select="4"/>
				</xsl:call-template>
			</xsl:element>

			<xsl:element name="MS202">
				<xsl:call-template name="CleanAlphaField">
					<xsl:with-param name="inputText" select="@equipmentNumber"/>
					<xsl:with-param name="maxLength" select="10"/>
				</xsl:call-template>
			</xsl:element>
		</xsl:element>
	</xsl:template>

	<!--<xsl:element name="MS203">
				<xsl:value-of select="@equipmentDescriptionCode"/>
			</xsl:element>-->


	<xsl:template match="ReferenceData" mode="BuildLXLoop1_L11_3">
		<xsl:element name="edi:L11_3">
			<xsl:element name="L1101">
				<xsl:value-of select="StopSequenceNumber"/>
			</xsl:element>
			<xsl:element name="L1102">
				<xsl:text>QN</xsl:text>
			</xsl:element>
		</xsl:element>
	</xsl:template>

	<xsl:template match="Remark" mode="BuildLXLoop1_K1_2">
		<xsl:call-template name="chunk">
			<xsl:with-param name="pText" select="@remarkMessage2" />
		</xsl:call-template>
	</xsl:template>

	<xsl:template name="chunk">
		<xsl:param name="pText" select="."/>
		<xsl:if test="string-length($pText) >0">
			<xsl:element name="edi:K1_2">
				<xsl:element name="K101">
					<xsl:value-of select="userCSharp:GetTrimmedString(substring($pText, 1, $chunkSize))"/>
				</xsl:element>
				<xsl:element name="K102">
					<xsl:text>Notes</xsl:text>
				</xsl:element>
			</xsl:element>
			<xsl:call-template name="chunk">
				<xsl:with-param name="pText" select="substring($pText, $chunkSize+1)"/>
			</xsl:call-template>
		</xsl:if>
	</xsl:template>

	<xsl:template match="ShipmentTotals" mode="BuildLXLoop1_AT8">
		<xsl:element name="edi:AT8">
			<xsl:element name="AT801">
				<xsl:value-of select="ShipmentTotal/@totalTypeQualifier"/>
			</xsl:element>
			<xsl:element name="AT802">
				<xsl:value-of select="ShipmentTotal/@totalUnitOfMeasure"/>
			</xsl:element>
			<xsl:element name="AT803">
				<xsl:value-of select="format-number(TotalWeight, '0.##')"/>
			</xsl:element>
			<xsl:element name="AT804">
				<xsl:value-of select="TotalHandlingQty"/>
			</xsl:element>
		</xsl:element>
	</xsl:template>
	<!-- CleanAlphaField Template -->
	<xsl:template name="CleanAlphaField">
		<xsl:param name="inputText" />
		<xsl:param name="maxLength" />
		<xsl:variable name="singleQuote" select='"&apos;"' />
		<xsl:variable name="doubleQuote" select="'&quot;'" />
		<xsl:variable name="vAllowedSymbolsPart1"
			select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}\?/#'"/>
		<xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
		<xsl:variable name="vCleanedText"
			select="translate($inputText, translate($inputText, $vAllowedSymbols, ''),'')"/>
		<xsl:value-of select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
	</xsl:template>

	<msxsl:script language="C#" implements-prefix="userCSharp">
		<![CDATA[
      public bool IsNullOrEmpty(string str)
      {
	        return System.String.IsNullOrEmpty(str);
      }
      
      public string GetDate(string str)
      {
            string retVal = String.Empty;

            if (!System.String.IsNullOrEmpty(str))
            {
                retVal = System.DateTimeOffset.Parse(str).ToString("yyyyMMdd");
            }

            return retVal;
        }

        public string GetTime(string str)
        {
            string retVal = String.Empty;

            if (!System.String.IsNullOrEmpty(str))
            {
                retVal = System.DateTimeOffset.Parse(str).ToString("HHmm");
            }

            return retVal;
        }
        
        public string GetSCAC(string str, string scac)
        {
            switch (str)
            {
                case "5665":
                case "150057":
                    return "ECHS";
                case "35281":
                  return "CMMS";
                default:
                    return scac;
            }
        }
        
        public string GetTrimmedString(string str)
        {
            return str.Trim();
        }
  ]]>
	</msxsl:script>

</xsl:stylesheet>
