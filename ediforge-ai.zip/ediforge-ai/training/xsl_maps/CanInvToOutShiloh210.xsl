<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00401.EDI210/v1.0" xmlns:s0="http://Echo.BSSR.Internal.Canonical.InvoiceV2" xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp" exclude-result-prefixes="msxsl var s0 userCSharp" version="1.0">
	<xsl:variable name="vLowercaseChars_CONST" select="'abcdefghijklmnopqrstuvwxyz'"/>
	<xsl:variable name="vUppercaseChars_CONST" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'"/>
	<xsl:output omit-xml-declaration="yes" method="xml" version="1.0"/>
	<xsl:template match="/">
		<xsl:apply-templates select="/s0:Invoice"/>
	</xsl:template>
	<xsl:template match="/s0:Invoice">
		<ns0:X12_00401_210>
			<ST>
				<ST01>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetIdentifierCode"/>
				</ST01>
				<ST02>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber"/>
				</ST02>
			</ST>
			<xsl:variable name="account" select="Header/PartyList/Party[Name/@EntityIdentifierCode='BT']/Name/@Name"/>
			<xsl:variable name="addr" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']/AddressInformation/@AddressInformationLine1"/>
			<xsl:variable name="city" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']/GeographicLocation/@CityName"/>
			<xsl:variable name="zip" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']/GeographicLocation/@PostalCode"/>
			<xsl:variable name="addr2" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']/AddressInformation/@AddressInformationLine1"/>
			<xsl:variable name="city2" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']/GeographicLocation/@CityName"/>
			<xsl:variable name="zip2" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']/GeographicLocation/@PostalCode"/>
			<xsl:variable name="PO" select="Header/ReferenceList/ReferenceInformation[@EDICode = 'PO']/@ReferenceInformation"/>
			<xsl:variable name="IO">
				<xsl:value-of select ="userCSharp:GetIO($addr, $city, $addr2, $city2)"/>
			</xsl:variable>

			<xsl:variable name="LocCode" select="userCSharp:GetLocationCode($addr, $city, $addr2, $city2)"/>
			<xsl:variable name="addrCode">
				<xsl:value-of select="userCSharp:GetAddressCode($addr, $city, $addr2, $city2)"/>
			</xsl:variable>


			<ns0:B3>
				<!--
 Segment not mapped by default
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@ShipmentQualifier != '' ">      
					<B301><xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentQualifier" /></B301>
				</xsl:if>
        
-->
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber != ''">
					<B302>
						<xsl:call-template name="CleanAlphaField">
							<xsl:with-param name="inputText" select="Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber"/>
							<xsl:with-param name="maxLength" select="22"/>
						</xsl:call-template>
					</B302>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber != ''">
					<B303>
						<xsl:choose>
							<xsl:when test="contains(Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber, '-') ">
								<xsl:call-template name="CleanAlphaField" >
									<xsl:with-param name="inputText" select="(substring-before(Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber, '-'))" />
									<xsl:with-param name="maxLength" select="22" />
								</xsl:call-template>
							</xsl:when>
							<xsl:otherwise>
								<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber" />
							</xsl:otherwise>
						</xsl:choose>
					</B303>
				</xsl:if>
				<xsl:choose>
					<xsl:when test="Header/ReferenceList/ReferenceInformation[@EDICode = 'IB']/@ReferenceInformation = 'Outbound'">
						<B304>PP</B304>
					</xsl:when>
					<xsl:when test="Header/ReferenceList/ReferenceInformation[@EDICode = 'IB']/@ReferenceInformation = 'Inbound'">
						<B304>CC</B304>
					</xsl:when>
				</xsl:choose>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@WeightUnitCode != '' ">
					<B305>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@WeightUnitCode"/>
					</B305>
				</xsl:if>
				<xsl:variable name="InvoiceDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='InvoiceDate']"/>
				<xsl:variable name="DeliveryDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='DeliveryDate']"/>
				<xsl:variable name="BillingDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='BillingDate']"/>
				<xsl:variable name="PickupDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='PickupDate']"/>
				<xsl:if test="$InvoiceDate != '' ">
					<B306>
						<xsl:value-of select="concat(substring($InvoiceDate, 1, 4), substring($InvoiceDate, 6, 2), substring($InvoiceDate, 9, 2))"/>
					</B306>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@NetAmountDue != '' ">
					<B307>
						<xsl:value-of select="translate(Header/BeginningSegmentForCarriersInvoice/@NetAmountDue,'.','')"/>
					</B307>
				</xsl:if>
				<!--

				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@CorrectionIndicator != '' ">
					<B308><xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@CorrectionIndicator" /></B308>
				</xsl:if>
        
-->
				<xsl:if test="$DeliveryDate != '' ">
					<B309>
						<xsl:value-of select="concat(substring($DeliveryDate, 1, 4), substring($DeliveryDate, 6, 2), substring($DeliveryDate, 9, 2))"/>
					</B309>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@DateTimeQualifier != '' ">
					<B310>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@DateTimeQualifier"/>
					</B310>
				</xsl:if>
				<B311>ECHS</B311>
				<xsl:if test="$PickupDate != '' ">
					<B312>
						<xsl:value-of select="concat(substring($PickupDate, 1, 4), substring($PickupDate, 6, 2), substring($PickupDate, 9, 2))"/>
					</B312>
				</xsl:if>
				<!--
  Not mapped by default
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@TariffServiceCode != '' ">
					<B313>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@TariffServiceCode" />
					</B313>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@TransportationTermsCode != '' ">
					<B314>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@TransportationTermsCode" />
					</B314>
				</xsl:if>
        
-->
			</ns0:B3>
			<!--
 Not mapped by default
      <ns0:C2>
        <C201>E</C201>
      </ns0:C2>
-->
			<xsl:if test="Header/Currency/@BillingCurrencyCode != '' ">
				<ns0:C3>
					<C301>
						<xsl:value-of select="Header/Currency/@BillingCurrencyCode"/>
					</C301>
				</ns0:C3>

			</xsl:if>

			<ns0:N9>
				<N901>4C</N901>
				<N902>
					<xsl:choose>
						<xsl:when test="$IO != ''">
							<xsl:value-of select="$IO"/>
						</xsl:when>
						<xsl:otherwise>Unknown</xsl:otherwise>
					</xsl:choose>
				</N902>
			</ns0:N9>

			<!--  Not mapped by default -->
			<xsl:variable name="DeliveryDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='DeliveryDate']"/>
			<xsl:variable name="PickupDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='PickupDate']"/>
			<ns0:G62>
				<G6201>86</G6201>
				<G6202>
					<xsl:value-of select="concat(substring($PickupDate, 1, 4), substring($PickupDate, 6, 2), substring($PickupDate, 9, 2))"/>
				</G6202>
				<xsl:if test="$account = 'Burlington Coat Factory - CORPORATE'">
					<G6203>8</G6203>
					<G6204>
						<xsl:value-of select="concat(substring($PickupDate, 12, 2), substring($PickupDate, 15, 2))"/>
					</G6204>
				</xsl:if>
			</ns0:G62>
			<ns0:G62>
				<G6201>35</G6201>
				<G6202>
					<xsl:value-of select="concat(substring($DeliveryDate, 1, 4), substring($DeliveryDate, 6, 2), substring($DeliveryDate, 9, 2))"/>
				</G6202>
				<xsl:if test="$account = 'Burlington Coat Factory - CORPORATE'">
					<G6203>9</G6203>
					<G6204>
						<xsl:value-of select="concat(substring($DeliveryDate, 12, 2), substring($DeliveryDate, 15, 2))"/>
					</G6204>
				</xsl:if>
			</ns0:G62>


			<ns0:R3>
				<R301>ECHS</R301>
				<R302>1</R302>
				<R304>M</R304>
			</ns0:R3>
			<!--
			<ns0:K1>
				<xsl:variable name="BMRefInfo" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='ReferenceList']/*[local-name()='ReferenceInformation'][@EDICode='BM']" />
				<K101>
					<xsl:choose>
						<xsl:when test="$BMRefInfo &gt; ' ' ">
							<xsl:value-of select="$BMRefInfo" /> 
						</xsl:when>
						<xsl:otherwise>
							<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentIdentificationNumber" />
						</xsl:otherwise> 
					</xsl:choose> 
				</K101>
			</ns0:K1>
-->


			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='BT']">
				<ns0:N1Loop1>
					<ns0:N1>
						<N101>BY</N101>
						<N102>
							<xsl:call-template name="CleanAlphaField">
								<xsl:with-param name="inputText" select="Name/@Name"/>
								<xsl:with-param name="maxLength" select="60"/>
							</xsl:call-template>
						</N102>
						<xsl:if test="//Header/ReferenceList/ReferenceInformation[@EDICode = 'CC']/@ReferenceInformation != ''">
							<N103>92</N103>
							<N104>
								<xsl:value-of select="//Header/ReferenceList/ReferenceInformation[@EDICode = 'CC']/@ReferenceInformation"/>
							</N104>
						</xsl:if>
					</ns0:N1>
				</ns0:N1Loop1>
			</xsl:for-each>
			<ns0:N1Loop1>
				<ns0:N1>
					<N101>SE</N101>
					<N102>ECHO LOGISTICS</N102>
					<N103>92</N103>
					<N104>ECHS</N104>
				</ns0:N1>
			</ns0:N1Loop1>

			<!--
Template not used for a code below due to expected changes to mappings from one code to another
-->
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH'][1]">
				<ns0:N1Loop1>
					<ns0:N1>
						<N101>SF</N101>
						<N102>
							<xsl:call-template name="CleanAlphaField">
								<xsl:with-param name="inputText" select="Name/@Name"/>
								<xsl:with-param name="maxLength" select="60"/>
							</xsl:call-template>
						</N102>
						<!--<xsl:if test="$addrCode != '' and $IO = 'O'">
							<N103>FA</N103>
							<N104>
								<xsl:value-of select="$addrCode"/>
							</N104>
						</xsl:if>-->
					</ns0:N1>

					<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
						<ns0:N3>
							<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
								<N301>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N301>
							</xsl:if>
							<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
								<N302>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N302>
							</xsl:if>
						</ns0:N3>
					</xsl:if>
					<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
						<ns0:N4>
							<xsl:if test="GeographicLocation/@CityName != ''">
								<N401>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@CityName"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N401>
							</xsl:if>
							<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
								<N402>
									<xsl:value-of select="GeographicLocation/@StateOrProvinceCode"/>
								</N402>
							</xsl:if>
							<xsl:if test="GeographicLocation/@PostalCode != ''">
								<N403>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N403>
							</xsl:if>
							<xsl:if test="GeographicLocation/@CountryCode != ''">
								<N404>
									<xsl:choose>
										<xsl:when test="GeographicLocation/@CountryCode = 'US'">USA</xsl:when>
										<xsl:when test="GeographicLocation/@CountryCode = 'CA'">CAN</xsl:when>
										<xsl:when test="GeographicLocation/@CountryCode = 'CN'">CAN</xsl:when>
										<xsl:otherwise>
											<xsl:value-of select="GeographicLocation/@CountryCode"/>
										</xsl:otherwise>
									</xsl:choose>
								</N404>
							</xsl:if>
						</ns0:N4>
					</xsl:if>
				</ns0:N1Loop1>
			</xsl:for-each>
			<!--
Template not used for a code below due to expected changes to mappings from one code to another
-->
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN'][1]">
				<ns0:N1Loop1>
					<ns0:N1>
						<N101>ST</N101>
						<N102>
							<xsl:call-template name="CleanAlphaField">
								<xsl:with-param name="inputText" select="Name/@Name"/>
								<xsl:with-param name="maxLength" select="60"/>
							</xsl:call-template>
						</N102>
						<!--<xsl:if test="$addrCode != '' and $IO = 'I'">
							<N103>FA</N103>
							<N104>
								<xsl:value-of select="$addrCode"/>
							</N104>
						</xsl:if>-->
					</ns0:N1>
					<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
						<ns0:N3>
							<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
								<N301>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N301>
							</xsl:if>
							<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
								<N302>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N302>
							</xsl:if>
						</ns0:N3>
					</xsl:if>
					<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
						<ns0:N4>
							<xsl:if test="GeographicLocation/@CityName != ''">
								<N401>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@CityName"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N401>
							</xsl:if>
							<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
								<N402>
									<xsl:value-of select="GeographicLocation/@StateOrProvinceCode"/>
								</N402>
							</xsl:if>
							<xsl:if test="GeographicLocation/@PostalCode != ''">
								<N403>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N403>
							</xsl:if>
							<xsl:if test="GeographicLocation/@CountryCode != ''">
								<N404>
									<xsl:choose>
										<xsl:when test="GeographicLocation/@CountryCode = 'US'">USA</xsl:when>
										<xsl:when test="GeographicLocation/@CountryCode = 'CA'">CAN</xsl:when>
										<xsl:when test="GeographicLocation/@CountryCode = 'CN'">CAN</xsl:when>
										<xsl:otherwise>
											<xsl:value-of select="GeographicLocation/@CountryCode"/>
										</xsl:otherwise>
									</xsl:choose>
								</N404>
							</xsl:if>
						</ns0:N4>
					</xsl:if>
				</ns0:N1Loop1>
			</xsl:for-each>

			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']">
				<xsl:variable name="PositionOfSH" select="position()" />
				<xsl:if test="$PositionOfSH &gt; 1">
					<ns0:S5Loop1>
						<ns0:S5>
							<S501>
								<xsl:value-of select="$PositionOfSH" />
							</S501>
							<S502>PL</S502>
							<xsl:if test="../../../Summary/TotalWeightAndCharges/@Weight">
								<S503>
									<xsl:value-of select="../../../Summary/TotalWeightAndCharges/@Weight" />
								</S503>
								<S504>L</S504>
							</xsl:if>
						</ns0:S5>
						<xsl:for-each select="../../ReferenceList/ReferenceInformation">
							<xsl:if test="@ReferenceInformation != ''">
								<ns0:N9_3>
									<xsl:if test="@EDICode != '' ">
										<N901>
											<xsl:value-of select="@EDICode" />
										</N901>
									</xsl:if>
									<N902>
										<xsl:call-template name="CleanAlphaField" >
											<xsl:with-param name="inputText" select="@ReferenceInformation" />
											<xsl:with-param name="maxLength" select="30" />
										</xsl:call-template>
									</N902>
								</ns0:N9_3>
							</xsl:if>
						</xsl:for-each>
					</ns0:S5Loop1>
				</xsl:if>
			</xsl:for-each>
			<xsl:variable name="CountofSH" select="count(Header/PartyList/Party[Name/@EntityIdentifierCode='SH'])" />
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']">
				<xsl:variable name="PositionOfCN" select="position()" />
				<xsl:if test="$PositionOfCN!=last()">
					<ns0:S5Loop1>
						<ns0:S5>
							<S501>
								<xsl:value-of select="$PositionOfCN + $CountofSH" />
							</S501>
							<S502>PU</S502>
							<xsl:if test="//Summary/TotalWeightAndCharges/@Weight">
								<S503>
									<xsl:value-of select="//Summary/TotalWeightAndCharges/@Weight" />
								</S503>
								<S504>L</S504>
							</xsl:if>
						</ns0:S5>
						<xsl:for-each select="//ReferenceList/ReferenceInformation">
							<xsl:if test="(@ReferenceInformation != '')">
								<ns0:N9_3>
									<xsl:if test="@EDICode != '' ">
										<N901>
											<xsl:value-of select="@EDICode" />
										</N901>
									</xsl:if>
									<N902>
										<xsl:call-template name="CleanAlphaField" >
											<xsl:with-param name="inputText" select="@ReferenceInformation" />
											<xsl:with-param name="maxLength" select="30" />
										</xsl:call-template>
									</N902>
								</ns0:N9_3>
							</xsl:if>
						</xsl:for-each>
					</ns0:S5Loop1>
				</xsl:if>
			</xsl:for-each>

			<!--
 Create S5Loop1 only for last recored where party Identifier Codes is 'CN', 
-->
			<!--
<xsl:variable name="NumberOfParties" select="count (Header/PartyList/Party)"/>
-->
			<!--
<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']">
      
-->
			<!-- <xsl:for-each select="Header/PartyList/Party"> -->
			<!--

        <xsl:if test="position() &lt; $NumberOfParties">
				<ns0:S5Loop1>
						<ns0:S5>
							<S501>
								<xsl:value-of select="position()" />
							</S501>
							<S502>PU</S502>
              <xsl:if test="../../../Summary/TotalWeightAndCharges/@Weight">
              <S503>
                <xsl:value-of select="../../../Summary/TotalWeightAndCharges/@Weight" />
              </S503>
              <S504>L</S504>
              </xsl:if>
						</ns0:S5>
           <xsl:for-each select="../../ReferenceList/ReferenceInformation">
            <xsl:if test="(@ReferenceInformationQualifier != '') or (@ReferenceInformation != '') ">
              <ns0:N9_3>
                <xsl:if test="@EDICode != '' ">
                  <N901>
                    <xsl:value-of select="@EDICode" />
                  </N901>
                </xsl:if>
                <xsl:if test="@ReferenceInformation != '' ">
                  <N902>
                    <xsl:call-template name="CleanAlphaField" >
                      <xsl:with-param name="inputText" select="@ReferenceInformation" />
                      <xsl:with-param name="maxLength" select="30" />
                    </xsl:call-template>
                  </N902>
                </xsl:if>
              </ns0:N9_3>
            </xsl:if>
          </xsl:for-each>
				</ns0:S5Loop1>
        </xsl:if>
			</xsl:for-each>
-->
			<!--
<xsl:variable name="CountofSH" select="count(PartyList/Party[Name/@EntityIdentifierCode='SH'][1]) - 1" />


			<xsl:for-each select="PartyList/Party[Name/@EntityIdentifierCode='CN']">
				<xsl:variable name="PositionOfCN" select="position()" />
				<ns0:S5Loop1>
					<xsl:if test="$PositionOfCN != last()">
						<ns0:S5>
							<S501>
								<xsl:value-of select="$CountofSH + position()" />
							</S501>
							<S502>PU</S502>
						</ns0:S5>
						<ns0:N1Loop2>
							<ns0:N1_2>
								<N101>
									<xsl:value-of select="Name/@EntityIdentifierCode" />
								</N101>
								<N102>
									<xsl:value-of select="Name/@Name" />
								</N102>
							</ns0:N1_2>
							<ns0:N3_2>
								<N301>
									<xsl:value-of select="AddressInformation/@AddressInformationLine1" />
								</N301>
							</ns0:N3_2>
							<ns0:N4_2>
								<xsl:if test="GeographicLocation/@CityName != '' ">
									<N401>
										<xsl:value-of select="GeographicLocation/@CityName" />
									</N401>
								</xsl:if>
								<xsl:if test="GeographicLocation/@StateOrProvinceCode != '' ">
									<N402>
										<xsl:value-of select="GeographicLocation/@StateOrProvinceCode" />
									</N402>
								</xsl:if>
								<xsl:if test="GeographicLocation/@PostalCode != '' ">
									<N403>
										<xsl:value-of select="GeographicLocation/@PostalCode" />
									</N403>
								</xsl:if>
								<xsl:if test="GeographicLocation/@CountryCode != '' ">
									<N404>
										<xsl:value-of select="GeographicLocation/@CountryCode" />
									</N404>
								</xsl:if>
							</ns0:N4_2>
						</ns0:N1Loop2>
					</xsl:if>
				</ns0:S5Loop1>
			</xsl:for-each>
-->
			<xsl:variable name="weight" select="Summary/TotalWeightAndCharges/@Weight"/>
			<xsl:variable name ="itemCount" select="Summary/TotalWeightAndCharges/@LadingQuantity"/>
			<xsl:variable name ="freightClass" select="s0:Header/Detail/LineItemList/LineItem/DescriptionMarksAndNumbers[@CommodityCode2 != '']/@CommodityCode2"/>
			<xsl:variable name ="NMFC" select="//Detail/LineItemList/LineItem/DescriptionMarksAndNumbers[@CommodityCode != '']/@CommodityCode"/>
			<xsl:for-each select="Detail/LineItemList/LineItem">
				<xsl:if test="DescriptionMarksAndNumbers/@LadingDescription = 'Line Haul'">
					<ns0:LXLoop1>
						<ns0:LX>
							<LX01>1</LX01>
						</ns0:LX>
						<xsl:if test="//Header/ReferenceList/ReferenceInformation[@EDICode = 'PO']/@ReferenceInformation != ''">
							<ns0:N9_5>
								<N901>PO</N901>
								<N902>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="//Header/ReferenceList/ReferenceInformation[@EDICode = 'PO']/@ReferenceInformation" />
										<xsl:with-param name="maxLength" select="30" />
									</xsl:call-template>
								</N902>
							</ns0:N9_5>
						</xsl:if>
						<ns0:L5>
							<L501>
								<xsl:value-of select="position()"/>
							</L501>
							<xsl:choose>
								<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'LHS'">
									<L502>LINEHAUL</L502>
								</xsl:when>
								<xsl:otherwise>
									<xsl:if test="DescriptionMarksAndNumbers/@LadingDescription != ''">
										<L502>
											<xsl:call-template name="CleanAlphaField" >
												<xsl:with-param name="inputText" select="DescriptionMarksAndNumbers/@LadingDescription" />
												<xsl:with-param name="maxLength" select="50" />
											</xsl:call-template>
										</L502>
									</xsl:if>
								</xsl:otherwise>
							</xsl:choose>
						</ns0:L5>
						<ns0:L0>
							<L001>1</L001>
							<L004>
								<xsl:value-of select="$weight"/>
							</L004>
							<L005>N</L005>
							<L008>

								<xsl:choose>
									<xsl:when test="$itemCount &lt; 1">1</xsl:when>
									<xsl:otherwise>
										<xsl:value-of select="$itemCount"/>
									</xsl:otherwise>
								</xsl:choose>


							</L008>
							<L009>PCS</L009>
						</ns0:L0>
						<xsl:if test="RateAndCharges/@FreightRate != '' or RateAndCharges/@Charge != '' or RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
							<ns0:L1>
								<L101>1</L101>
								<xsl:if test="RateAndCharges/@FreightRate != ''">
									<L102>
										<xsl:value-of select="RateAndCharges/@FreightRate"/>
									</L102>
								</xsl:if>
								<xsl:if test="RateAndCharges/@RateValueQualifier != ''">
									<L103>
										<xsl:value-of select="RateAndCharges/@RateValueQualifier"/>
									</L103>
								</xsl:if>
								<xsl:if test="RateAndCharges/@Charge != ''">
									<L104>
										<xsl:value-of select="RateAndCharges/@Charge"/>
									</L104>
								</xsl:if>
							</ns0:L1>
						</xsl:if>
					</ns0:LXLoop1>
				</xsl:if>
			</xsl:for-each>


			<xsl:for-each select="Detail/LineItemList/LineItem">
				<xsl:if test="DescriptionMarksAndNumbers/@LadingDescription != 'Line Haul' and RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
					<ns0:LXLoop1>
						<ns0:LX>
							<LX01>
								<xsl:value-of select="position() + 1"/>
							</LX01>
						</ns0:LX>
						<ns0:L5>
							<L501>
								<xsl:value-of select="position() + 1"/>
							</L501>
							<xsl:if test="DescriptionMarksAndNumbers/@LadingDescription != ''">
								<L502>
									<!-- Convert to UpperCase <xsl:value-of select="translate(DescriptionMarksAndNumbers/@LadingDescription,  $vLowercaseChars_CONST, $vUppercaseChars_CONST)" />-->
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="DescriptionMarksAndNumbers/@LadingDescription" />
										<xsl:with-param name="maxLength" select="50" />
									</xsl:call-template>
								</L502>
							</xsl:if>
						</ns0:L5>
						<ns0:L0>
							<L001>
								<xsl:value-of select="position() + 1"/>
							</L001>
							<xsl:if test="LineItemQuantityAndWeight/@BilledRatedAsQuantity != ''">
								<L002>
									<xsl:value-of select="LineItemQuantityAndWeight/@BilledRatedAsQuantity" />
								</L002>
							</xsl:if>
							<xsl:if test="LineItemQuantityAndWeight/@BilledRatedAsQualifier != ''">
								<L003>
									<xsl:value-of select="LineItemQuantityAndWeight/@BilledRatedAsQualifier" />
								</L003>
							</xsl:if>
							<xsl:choose>
								<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'LHS'">
									<xsl:if test="//Summary/TotalWeightAndCharges/@Weight!=''">
										<L004>
											<xsl:value-of select="//Summary/TotalWeightAndCharges/@Weight"/>
										</L004>
										<L005>N</L005>
									</xsl:if>
									<xsl:if test="//Summary/TotalWeightAndCharges/@LadingQuantity!=''">
										<L008>
											<xsl:value-of select="//Summary/TotalWeightAndCharges/@LadingQuantity"/>
										</L008>
									</xsl:if>
									<L009>PCS</L009>
								</xsl:when>
								<xsl:otherwise>
									<xsl:if test="LineItemQuantityAndWeight/@Weight != ''">
										<L004>
											<xsl:value-of select="LineItemQuantityAndWeight/@Weight" />
										</L004>
										<L005>
											<xsl:value-of select="LineItemQuantityAndWeight/@WeightUnitCode" />
										</L005>
									</xsl:if>
									<xsl:if test="LineItemQuantityAndWeight/@LadingQuantity!=''">
										<L008>
											<xsl:value-of select="LineItemQuantityAndWeight/@LadingQuantity" />
										</L008>
									</xsl:if>
									<xsl:if test="LineItemQuantityAndWeight/@LadingQuantityPackagingFormCode!=''">
										<L009>
											<xsl:value-of select="LineItemQuantityAndWeight/@LadingQuantityPackagingFormCode" />
										</L009>
									</xsl:if>
								</xsl:otherwise>
							</xsl:choose>
						</ns0:L0>
						<xsl:if test="RateAndCharges/@FreightRate != '' or RateAndCharges/@Charge != '' or RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
							<ns0:L1>
								<L101>
									<xsl:value-of select="position() +1"/>
								</L101>
								<xsl:if test="RateAndCharges/@FreightRate != ''">
									<L102>
										<xsl:value-of select="RateAndCharges/@FreightRate"/>
									</L102>
								</xsl:if>
								<xsl:if test="RateAndCharges/@RateValueQualifier != ''">
									<L103>
										<xsl:value-of select="RateAndCharges/@RateValueQualifier"/>
									</L103>
								</xsl:if>
								<xsl:if test="RateAndCharges/@Charge != ''">
									<L104>
										<xsl:value-of select="RateAndCharges/@Charge"/>
									</L104>
								</xsl:if>
								<xsl:if test="RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
									<L108>
										<xsl:choose>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'LYC'">LAY</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'LHS'"></xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'TDT'">DET</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'SRG'">STR</xsl:when>
											<xsl:otherwise>
												<xsl:value-of select="RateAndCharges/@SpecialChargeOrAllowanceCode"/>
											</xsl:otherwise>
										</xsl:choose>
									</L108>
								</xsl:if>
							</ns0:L1>
						</xsl:if>
						<xsl:if test="//DescriptionMarksAndNumbers/@CommodityCode2!=''">
							<ns0:L7>
								<L701>
									<xsl:value-of select="position()" />
								</L701>
								<L707>
									<xsl:value-of select="//DescriptionMarksAndNumbers/@CommodityCode2"/>
								</L707>
							</ns0:L7>
						</xsl:if>
					</ns0:LXLoop1>
				</xsl:if>
			</xsl:for-each>

			<xsl:for-each select="Summary/TotalWeightAndCharges">
				<ns0:L3>
					<xsl:if test="@Weight">
						<L301>
							<xsl:value-of select="@Weight"/>
						</L301>
					</xsl:if>
					<L302>
						<xsl:value-of select="@WeightQualifier"/>
					</L302>
					<xsl:variable name="TotalCharges" select="@TotalCharges"/>
					<xsl:variable name="TotalChargesLength" select="string-length(@TotalCharges)"/>
					<xsl:if test="$TotalChargesLength > 2">
						<L305>
							<xsl:value-of select="translate(@TotalCharges,',','')"/>
							<!--
<xsl:value-of select="concat(substring($TotalCharges, 1, $TotalChargesLength - 2), '.',  substring($TotalCharges, $TotalChargesLength - 2 , 2))" />
-->
						</L305>
					</xsl:if>
					<!--    <xsl:if test="@LadingQuantity">
            <L311>
              <xsl:value-of select="@LadingQuantity"/>
            </L311>
          </xsl:if> -->
				</ns0:L3>
			</xsl:for-each>
			<SE>
				<SE01>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetIdentifierCode"/>
				</SE01>
				<SE02>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber"/>
				</SE02>
			</SE>
		</ns0:X12_00401_210>
	</xsl:template>

	<msxsl:script language="C#" implements-prefix="userCSharp">
		<![CDATA[
    public string dateReturn()
    {
	    DateTime localDate = DateTime.Now;
	    return localDate.ToString("yyyyMMdd");
    }
    ]]>
	</msxsl:script>
	<!-- Custom Templates -->
	<!--  Created by Neal, not specific to L108 -->
	<xsl:template name="ChangeThisName">
		<xsl:param name="ValueToConvert" select="0"/>
		<xsl:param name="LadingDescriptionParm" select="1"/>
		<xsl:variable name="L108Map">
			<map>
				<entry key="LHS">400</entry>
				<entry key="LYC">LAY</entry>
				<entry key="SRG">STR</entry>
				<entry key="TDT">DET</entry>
			</map>
		</xsl:variable>
		<xsl:variable name="ValueConverted" select="msxsl:node-set($L108Map)/map/entry[@key=$ValueToConvert]"/>
		<xsl:choose>
			<xsl:when test="$ValueConverted">
				<xsl:value-of select="$ValueConverted"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:choose>
					<xsl:when test="$LadingDescriptionParm = 'Lumper'">
						<xsl:text>LAB</xsl:text>
					</xsl:when>
					<xsl:when test="$LadingDescriptionParm = 'Unloading'">
						<xsl:text>UNL</xsl:text>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="$ValueToConvert"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<!--  Created by Neal, not specific to L108 -->
	<!-- CleanAlphaField start  -->
	<xsl:template name="CleanAlphaField">
		<xsl:param name="inputText" />
		<xsl:param name="maxLength" />
		<xsl:variable name="singleQuote" select='"&apos;"' />
		<xsl:variable name="doubleQuote" select="'&quot;'" />
		<xsl:variable name="vAllowedSymbolsPart1" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}\?/#'"/>
		<xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
		<xsl:variable name="vCleanedText" select="translate($inputText,translate($inputText, $vAllowedSymbols, ''),'')"/>
		<xsl:value-of select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
	</xsl:template>
	<!-- Clean AlphaField end -->
	<!-- Value mapping template -->
	<xsl:template name="StopTypeMapValue">
		<xsl:param name="ValueToConvert" select="0"/>
		<xsl:variable name="StopTypeMap">
			<map>
				<entry key="Pick">SF</entry>
				<entry key="Drop">CN</entry>
			</map>
		</xsl:variable>
		<xsl:value-of select="msxsl:node-set($StopTypeMap)/map/entry[@key=$ValueToConvert]"/>
	</xsl:template>
	<!-- Value mapping template -->
	<!-- Set default if empty template start -->
	<xsl:template name="SetDefaultIfEmpty">
		<xsl:param name="pNode"/>
		<xsl:param name="pDefaultValue"/>
		<xsl:if test="$pNode">
			<xsl:value-of select="$pNode"/>
		</xsl:if>
		<xsl:if test="not($pNode)">
			<xsl:value-of select="$pDefaultValue"/>
		</xsl:if>
	</xsl:template>
	<msxsl:script language="C#" implements-prefix="userCSharp">
		<msxsl:using namespace="System.Text.RegularExpressions" />
		<msxsl:using namespace="System.Collections.Generic" />
		<![CDATA[
public class LoadAddress
{
	public String LocationCode;
  public String AddressCode;
	public String Addr;
	public String City;
	public String ZipCode;

	public LoadAddress (String locationCode,String addressCode, String addr, String city, String zipCode){
		LocationCode = locationCode;
    AddressCode = addressCode;
		Addr = SanitizeInput(addr);
		City = SanitizeInput(city);
		ZipCode = SanitizeInput(zipCode);
	}
	
	// Matches if either address is a match for the account
	public bool isMatch(String addr1, String city1, String addr2, String city2){
			if (SanitizeInput(city1) == City 
					&& SanitizeInput(addr1) == Addr){return true;}
			else if (SanitizeInput(city2) == City
					&& SanitizeInput(addr2) == Addr){return true;}
		return false;
	}
	
	// "In" means "inbound" not "contains"
	public bool AddressIsIn(String addr1, String city1, String addr2, String city2){
			if (SanitizeInput(city2) == City 
				&& SanitizeInput(addr2) == Addr){return true;}
		return false;
	}
	
	private String SanitizeInput(String input){
		return Regex.Replace(input, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
}

	
	// Used by xslt to get N104 value for BY line
	public String GetLocationCode(String addr1, String city1, String addr2, String city2){
		foreach(LoadAddress lad in LOAD_ADDRESSES){
			if(lad.isMatch(addr1, city1, addr2, city2)){
				return lad.LocationCode;
			}
		}
		return "Not Found";
	}
  
  	// Used by xslt to get N104 value for stops
	public String GetAddressCode(String addr1, String city1, String addr2, String city2){
		foreach(LoadAddress lad in LOAD_ADDRESSES){
			if(lad.isMatch(addr1, city1, addr2, city2)){
				return lad.AddressCode;
			}
		}
		return "Not Found";
	}
	
	// Returns I for inbound, O for outbound. I = SH address, O = CN address
	public String GetIO(string addr, string city, string addr2, string city2){
		// Iterate through the address list, if we find a match, check if it's the loads inbound address. If it is, return I, if not, return O 
		foreach(LoadAddress ldr in LOAD_ADDRESSES){
			if(ldr.isMatch(addr, city, addr2, city2)){
				if(ldr.AddressIsIn(addr, city, addr2, city2)){return "I";}
				else{return "O";}
			}
		}
		return "Not Found";
	}
  //Column 2 for Address code is required additionally on some accounts - it is an additional code associated with the address and is returned on the pick/drop. Leave NULL if not in use. 
					public List<LoadAddress> LOAD_ADDRESSES = new List<LoadAddress>(){					
					new LoadAddress("101","","880 Steel Drive","Valley City","44280"),
					new LoadAddress("101","","880 Steel Dr","Valley City","44280"), 
					new LoadAddress("106","","350 Maple Street","Wellington","44090"), 
					new LoadAddress("106","","350 Maple St","Wellington","44090"), 
					new LoadAddress("109","","5580 Wegman Drive","Valley City","44280"), 
					new LoadAddress("109","","5580 Wegman Dr","Valley City","44280"), 
					new LoadAddress("120","","5569 Innovation Drive","Valley City","44280"), 
					new LoadAddress("120","","5569 Innovation Dr","Valley City","44280"), 
					new LoadAddress("125","","7295 Haggerty Road","Canton","48187"), 
					new LoadAddress("125","","7295 Haggerty Rd","Canton","48187"), 
					new LoadAddress("130","","47632 Halyard Drive","Plymouth","48170"),
					new LoadAddress("130","","47632 Halyard Dr","Plymouth","48170"), 
					new LoadAddress("132","","880 Steel Drive","Valley City","44280"),
					new LoadAddress("132","","880 Steel Dr","Valley City","44280"),
					new LoadAddress("145","","One Shiloh Drive","Dickson","37055"), 
					new LoadAddress("145","","One Shiloh Dr","Dickson","37055"), 
					new LoadAddress("150","","310 Jody Richards Drive","Bowling Green","42101"), 
					new LoadAddress("150","","310 Jody Richards Dr","Bowling Green","42101"), 
					new LoadAddress("155","","8200 100th Street","Pleasant Prairie","53158"), 
					new LoadAddress("155","","8200 100th St","Pleasant Prairie","53158"), 
					new LoadAddress("156","","250 Adams Street","Alma","48801"), 
					new LoadAddress("156","","250 Adams St","Alma","48801"), 
					new LoadAddress("157","","1200 Power Drive","Auburn","46706"),
					new LoadAddress("157","","1200 Power Dr","Auburn","46706"), 
					new LoadAddress("158","","901 Alfred Thun Road","Clarksville","37040"), 
					new LoadAddress("158","","901 Alfred Thun Rd","Clarksville","37040"),
					new LoadAddress("159","","5 Arnolt Drive","Pierceton","46562"), 
					new LoadAddress("159","","5 Arnolt Dr","Pierceton","46562"), 
					new LoadAddress("160","","27101 Groesbeck Hwy","Warren","48089"), 
					new LoadAddress("161","","28101 Groesbeck Hwy","Roseville","48066"), 
					new LoadAddress("162","","1780 POND RUN","AUBURN HILLS","48326"), 
					new LoadAddress("CELAYA","","Carretera Celaya-Salvatierra Km 8.5","Guanajuato","38158"), 
					new LoadAddress("GOSH","","910 Eisenhower Dr S","Goshen","46526"), 
					new LoadAddress("KZOO","","9000 E. Michigan Ave","Galesburg","49053"), 
					new LoadAddress("SALTILLO","","Av. Delta 2025 Parque Industrial","Coah Saltillo","449025"),
};
]]>
	</msxsl:script>
	<!-- Set default if empty template end -->
</xsl:stylesheet>