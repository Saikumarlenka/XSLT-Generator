<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" exclude-result-prefixes="msxsl var s0 userCSharp" version="1.0" xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00401.EDIOB210V2.0" xmlns:s0="http://Echo.BSSR.Internal.Canonical.InvoiceV2" xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp">
	<xsl:variable name="vLowercaseChars_CONST" select="'abcdefghijklmnopqrstuvwxyz'"/>
	<xsl:variable name="vUppercaseChars_CONST" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'"/>
	<xsl:output omit-xml-declaration="yes" method="xml" version="1.0"/>
	<xsl:template match="/">
		<xsl:apply-templates select="/s0:Invoice"/>
	</xsl:template>
	<xsl:template match="/s0:Invoice">
		<ns0:X12_00401_210>
			<ST>
				<ST01>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetIdentifierCode"/>
				</ST01>
				<ST02>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber"/>
				</ST02>
			</ST>
			<xsl:variable name="account" select="Header/PartyList/Party[Name/@EntityIdentifierCode='BT']/Name/@Name"/>
			<xsl:variable name="addr" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']/AddressInformation/@AddressInformationLine1"/>
			<xsl:variable name="city" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']/GeographicLocation/@CityName"/>
			<xsl:variable name="zip" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']/GeographicLocation/@PostalCode"/>
			<xsl:variable name="addr2" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']/AddressInformation/@AddressInformationLine1"/>
			<xsl:variable name="city2" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']/GeographicLocation/@CityName"/>
			<xsl:variable name="zip2" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']/GeographicLocation/@PostalCode"/>
			<xsl:variable name="PO" select="Header/ReferenceList/ReferenceInformation[@EDICode = 'PO']/@ReferenceInformation"/>
			<xsl:variable name="IO">
				<xsl:value-of select ="userCSharp:GetIO($addr, $city, $addr2, $city2)"/>
			</xsl:variable>

			<xsl:variable name="LocCode" select="userCSharp:GetLocationCode($addr, $city, $addr2, $city2)"/>
			<xsl:variable name="addrCode">
				<xsl:value-of select="userCSharp:GetAddressCode($addr, $city, $addr2, $city2)"/>
			</xsl:variable>

			<ns0:B3>
				<!-- Segment not mapped by default
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@ShipmentQualifier != '' ">      
					<B301><xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentQualifier" /></B301>
				</xsl:if>
        -->
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber != ''">
					<B302>
						<xsl:call-template name="CleanAlphaField">
							<xsl:with-param name="inputText" select="Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber"/>
							<xsl:with-param name="maxLength" select="22"/>
						</xsl:call-template>
					</B302>
				</xsl:if>
				<xsl:if test="$PO != '' ">
					<B303>
						<!--<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentIdentificationNumber" />-->
						<xsl:call-template name="CleanAlphaField">
							<xsl:with-param name="inputText" select="$PO"/>
							<xsl:with-param name="maxLength" select="30"/>
						</xsl:call-template>
					</B303>
				</xsl:if>
				<B304>
					<xsl:choose>
						<xsl:when test="$IO = 'O'">PP</xsl:when>
						<xsl:when test="$IO = 'I'">CC</xsl:when>
						<xsl:otherwise>
							<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@ShipmentMethodOfPayment != ''">
								<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentMethodOfPayment"/>s
							</xsl:if>
						</xsl:otherwise>
					</xsl:choose>
				</B304>

				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@WeightUnitCode != '' ">
					<B305>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@WeightUnitCode"/>
					</B305>
				</xsl:if>
				<xsl:variable name="InvoiceDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='InvoiceDate']"/>
				<xsl:variable name="DeliveryDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='DeliveryDate']"/>
				<xsl:variable name="BillingDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='BillingDate']"/>
				<xsl:variable name="PickupDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='PickupDate']"/>
				<xsl:if test="$InvoiceDate != '' ">
					<B306>
						<xsl:value-of select="concat(substring($InvoiceDate, 1, 4), substring($InvoiceDate, 6, 2), substring($InvoiceDate, 9, 2))"/>
					</B306>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@NetAmountDue != '' ">
					<B307>
						<xsl:value-of select="translate(Header/BeginningSegmentForCarriersInvoice/@NetAmountDue,'.','')"/>
					</B307>
				</xsl:if>
				<!--
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@CorrectionIndicator != '' ">
					<B308><xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@CorrectionIndicator" /></B308>
				</xsl:if>
        -->
				<xsl:if test="$DeliveryDate != '' ">
					<B309>
						<xsl:value-of select="concat(substring($DeliveryDate, 1, 4), substring($DeliveryDate, 6, 2), substring($DeliveryDate, 9, 2))"/>
					</B309>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@DateTimeQualifier != '' ">
					<B310>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@DateTimeQualifier"/>
					</B310>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@StandardCarrierAlphaCode != '' ">
					<B311>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@StandardCarrierAlphaCode"/>
					</B311>
				</xsl:if>
				<xsl:if test="$PickupDate != '' ">
					<B312>
						<xsl:value-of select="concat(substring($PickupDate, 1, 4), substring($PickupDate, 6, 2), substring($PickupDate, 9, 2))"/>
					</B312>
				</xsl:if>
				<!--  Not mapped by default
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@TariffServiceCode != '' ">
					<B313>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@TariffServiceCode" />
					</B313>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@TransportationTermsCode != '' ">
					<B314>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@TransportationTermsCode" />
					</B314>
				</xsl:if>
        -->
			</ns0:B3>
			<!-- Not mapped by default
      <ns0:C2>
        <C201>E</C201>
      </ns0:C2>-->
			<xsl:if test="Header/Currency/@BillingCurrencyCode != '' ">
				<ns0:C3>
					<C301>
						<xsl:value-of select="Header/Currency/@BillingCurrencyCode"/>
					</C301>
				</ns0:C3>
			</xsl:if>
			<xsl:if test="$PO != ''">
				<ns0:N9>
					<N901>PO</N901>
					<N902>
						<xsl:value-of select="$PO"/>
					</N902>
				</ns0:N9>
			</xsl:if>
			<ns0:N9>
				<N901>4C</N901>
				<N902>
					<xsl:choose>
						<xsl:when test="$IO != ''">
							<xsl:value-of select="$IO"/>
						</xsl:when>
						<xsl:otherwise>Unknown</xsl:otherwise>
					</xsl:choose>
				</N902>
			</ns0:N9>
			<ns0:N9>
				<N901>QY</N901>
				<N903>
					<xsl:choose>
						<xsl:when test="Header/ReferenceList/ReferenceInformation[@EDICode = 'QY']/@ReferenceInformation = 'NO'">NO</xsl:when>
						<xsl:otherwise>YES</xsl:otherwise>
					</xsl:choose>
				</N903>
			</ns0:N9>


			<!-- Not mapped by default-->
			<xsl:variable name="DeliveryDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='DeliveryDate']"/>
			<xsl:variable name="PickupDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='PickupDate']"/>
			<ns0:G62>
				<G6201>86</G6201>
				<G6202>
					<xsl:value-of select="concat(substring($PickupDate, 1, 4), substring($PickupDate, 6, 2), substring($PickupDate, 9, 2))"/>
				</G6202>
			</ns0:G62>
			<ns0:G62>
				<G6201>35</G6201>
				<G6202>
					<xsl:value-of select="concat(substring($DeliveryDate, 1, 4), substring($DeliveryDate, 6, 2), substring($DeliveryDate, 9, 2))"/>
				</G6202>
			</ns0:G62>

			<ns0:R3>
				<R301>ECHS</R301>
				<R302>1</R302>
				<R304>M</R304>
				<R310>G2</R310>
			</ns0:R3>
			<!--
			<ns0:K1>
				<xsl:variable name="BMRefInfo" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='ReferenceList']/*[local-name()='ReferenceInformation'][@EDICode='BM']" />
				<K101>
					<xsl:choose>
						<xsl:when test="$BMRefInfo &gt; ' ' ">
							<xsl:value-of select="$BMRefInfo" /> 
						</xsl:when>
						<xsl:otherwise>
							<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentIdentificationNumber" />
						</xsl:otherwise> 
					</xsl:choose> 
				</K101>
			</ns0:K1>-->
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='BT']">
				<ns0:N1Loop1>
					<ns0:N1>
						<N101>BY</N101>
						<xsl:if test="Name/@Name != ''">
							<N102>
								<xsl:call-template name="CleanAlphaField">
									<xsl:with-param name="inputText" select="Name/@Name"/>
									<xsl:with-param name="maxLength" select="60"/>
								</xsl:call-template>
							</N102>
						</xsl:if>
						<xsl:if test="$LocCode != 'Not Found'">
							<N103>92</N103>
							<N104>
								<xsl:value-of select="$LocCode"/>
							</N104>
						</xsl:if>
					</ns0:N1>
					<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
						<ns0:N3>
							<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
								<N301>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N301>
							</xsl:if>
							<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
								<N302>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N302>
							</xsl:if>
						</ns0:N3>
					</xsl:if>
					<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
						<ns0:N4>
							<xsl:if test="GeographicLocation/@CityName != ''">
								<N401>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@CityName"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N401>
							</xsl:if>
							<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
								<N402>
									<xsl:value-of select="GeographicLocation/@StateOrProvinceCode"/>
								</N402>
							</xsl:if>
							<xsl:if test="GeographicLocation/@PostalCode != ''">
								<N403>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N403>
							</xsl:if>
							<xsl:if test="GeographicLocation/@CountryCode != ''">
								<N404>
									<xsl:value-of select="GeographicLocation/@CountryCode"/>
								</N404>
							</xsl:if>
						</ns0:N4>
					</xsl:if>
				</ns0:N1Loop1>
			</xsl:for-each>
			<ns0:N1Loop1>
				<ns0:N1>
					<N101>SE</N101>
					<N102>ECHO LOGISTICS</N102>
					<N103>92</N103>
					<N104>ECHS</N104>
				</ns0:N1>
			</ns0:N1Loop1>

			<!--Template not used for a code below due to expected changes to mappings from one code to another-->
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH'][1]">
				<ns0:N1Loop1>
					<ns0:N1>
						<N101>SF</N101>
						<xsl:if test="Name/@Name != ''">
							<N102>
								<xsl:call-template name="CleanAlphaField">
									<xsl:with-param name="inputText" select="Name/@Name"/>
									<xsl:with-param name="maxLength" select="60"/>
								</xsl:call-template>
							</N102>
						</xsl:if>
						<xsl:if test="$addrCode != '' and $IO = 'O'">
							<N103>FA</N103>
							<N104>
								<xsl:value-of select="$addrCode"/>
							</N104>
						</xsl:if>
					</ns0:N1>
					<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
						<ns0:N3>
							<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
								<N301>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N301>
							</xsl:if>
							<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
								<N302>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N302>
							</xsl:if>
						</ns0:N3>
					</xsl:if>
					<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
						<ns0:N4>
							<xsl:if test="GeographicLocation/@CityName != ''">
								<N401>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@CityName"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N401>
							</xsl:if>
							<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
								<N402>
									<xsl:value-of select="GeographicLocation/@StateOrProvinceCode"/>
								</N402>
							</xsl:if>
							<xsl:if test="GeographicLocation/@PostalCode != ''">
								<N403>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N403>
							</xsl:if>
							<xsl:if test="GeographicLocation/@CountryCode != ''">
								<N404>
									<xsl:value-of select="GeographicLocation/@CountryCode"/>
								</N404>
							</xsl:if>
						</ns0:N4>
					</xsl:if>
				</ns0:N1Loop1>
			</xsl:for-each>
			<!--Template not used for a code below due to expected changes to mappings from one code to another-->
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN'][1]">
				<ns0:N1Loop1>
					<ns0:N1>
						<N101>
							<xsl:value-of select="Name/@EntityIdentifierCode"/>
						</N101>
						<xsl:if test="Name/@Name != ''">
							<N102>
								<xsl:call-template name="CleanAlphaField">
									<xsl:with-param name="inputText" select="Name/@Name"/>
									<xsl:with-param name="maxLength" select="60"/>
								</xsl:call-template>
							</N102>
						</xsl:if>
						<xsl:if test="$addrCode != '' and $IO = 'I'">
							<N103>FA</N103>
							<N104>
								<xsl:value-of select="$addrCode"/>
							</N104>
						</xsl:if>
					</ns0:N1>
					<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
						<ns0:N3>
							<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
								<N301>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N301>
							</xsl:if>
							<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
								<N302>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N302>
							</xsl:if>
						</ns0:N3>
					</xsl:if>
					<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
						<ns0:N4>
							<xsl:if test="GeographicLocation/@CityName != ''">
								<N401>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@CityName"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N401>
							</xsl:if>
							<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
								<N402>
									<xsl:value-of select="GeographicLocation/@StateOrProvinceCode"/>
								</N402>
							</xsl:if>
							<xsl:if test="GeographicLocation/@PostalCode != ''">
								<N403>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N403>
							</xsl:if>
							<xsl:if test="GeographicLocation/@CountryCode != ''">
								<N404>
									<xsl:choose>
										<xsl:when test="GeographicLocation/@CountryCode = 'US'">USA</xsl:when>
										<xsl:when test="GeographicLocation/@CountryCode = 'CA'">CAN</xsl:when>
										<xsl:when test="GeographicLocation/@CountryCode = 'CN'">CAN</xsl:when>
										<xsl:otherwise>
											<xsl:value-of select="GeographicLocation/@CountryCode"/>
										</xsl:otherwise>
									</xsl:choose>
								</N404>
							</xsl:if>
						</ns0:N4>
					</xsl:if>
				</ns0:N1Loop1>
			</xsl:for-each>
			<xsl:variable name="NumberOfN7" select="count (Header/EquipmentList/Equipment[@EquipmentNumber != ''])"/>
			<xsl:if test="$NumberOfN7 > 0">
				<ns0:N7Loop1>
					<xsl:for-each select="Header/EquipmentList/Equipment">
						<ns0:N7>
							<xsl:if test="@EquipmentNumber != ''">
								<N702>
									<xsl:value-of select="@EquipmentNumber"/>
								</N702>
							</xsl:if>
							<xsl:if test="@EquipmentDescriptionCode != ''">
								<N711>
									<xsl:value-of select="@EquipmentDescriptionCode"/>
								</N711>
							</xsl:if>
							<xsl:if test="@EquipmentDescriptionCode != ''">
								<N715>
									<xsl:value-of select="@EquipmentLength"/>
								</N715>
							</xsl:if>
						</ns0:N7>
					</xsl:for-each>
				</ns0:N7Loop1>
			</xsl:if>

			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']">
				<xsl:variable name="PositionOfSH" select="position()" />
				<xsl:if test="$PositionOfSH &gt; 1">
					<ns0:S5Loop1>
						<ns0:S5>
							<S501>
								<xsl:value-of select="$PositionOfSH -1" />
							</S501>
							<S502>PL</S502>
							<xsl:if test="//Summary/TotalWeightAndCharges/@Weight != ''">
								<S503>
									<xsl:value-of select="//Summary/TotalWeightAndCharges/@Weight" />
								</S503>
								<S504>L</S504>
							</xsl:if>
						</ns0:S5>
						<xsl:for-each select="//ReferenceList/ReferenceInformation">
							<xsl:if test="@ReferenceInformation != '' and @EDICode != ''">
								<ns0:N9_3>
									<N901>
										<xsl:value-of select="@EDICode" />
									</N901>
									<N902>
										<xsl:call-template name="CleanAlphaField" >
											<xsl:with-param name="inputText" select="@ReferenceInformation" />
											<xsl:with-param name="maxLength" select="30" />
										</xsl:call-template>
									</N902>
								</ns0:N9_3>
							</xsl:if>
						</xsl:for-each>
					</ns0:S5Loop1>
				</xsl:if>
			</xsl:for-each>
			<xsl:variable name="CountofSH" select="count(Header/PartyList/Party[Name/@EntityIdentifierCode='SH'])" />
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']">
				<xsl:variable name="PositionOfCN" select="position()" />
				<xsl:if test="$PositionOfCN!=last()">
					<ns0:S5Loop1>
						<ns0:S5>
							<S501>
								<xsl:value-of select="$PositionOfCN + $CountofSH -1" />
							</S501>
							<S502>PU</S502>
							<xsl:if test="//Summary/TotalWeightAndCharges/@Weight != ''">
								<S503>
									<xsl:value-of select="//Summary/TotalWeightAndCharges/@Weight" />
								</S503>
								<S504>L</S504>
							</xsl:if>
						</ns0:S5>
						<xsl:for-each select="//ReferenceList/ReferenceInformation">
							<xsl:if test="@ReferenceInformation != '' and @EDICode != ''">
								<ns0:N9_3>
									<N901>
										<xsl:value-of select="@EDICode" />
									</N901>
									<N902>
										<xsl:call-template name="CleanAlphaField" >
											<xsl:with-param name="inputText" select="@ReferenceInformation" />
											<xsl:with-param name="maxLength" select="30" />
										</xsl:call-template>
									</N902>
								</ns0:N9_3>
							</xsl:if>
						</xsl:for-each>
					</ns0:S5Loop1>
				</xsl:if>
			</xsl:for-each>

			<xsl:variable name="weight" select="Summary/TotalWeightAndCharges/@Weight"/>
			<xsl:variable name ="itemCount" select="Summary/TotalWeightAndCharges/@LadingQuantity"/>

			<xsl:for-each select="Detail/LineItemList/LineItem">
				<xsl:if test="DescriptionMarksAndNumbers/@LadingDescription = 'Line Haul'">
					<ns0:LXLoop1>
						<ns0:LX>
							<LX01>1</LX01>
						</ns0:LX>
						<ns0:L5>
							<L501>1</L501>
							<L502>LINEHAUL</L502>
						</ns0:L5>
						<ns0:L0>
							<L001>1</L001>
							<L004>
								<xsl:value-of select="$weight"/>
							</L004>
							<L005>N</L005>
							<L008>
								<xsl:choose>
									<xsl:when test="$itemCount &lt; 1">1</xsl:when>
									<xsl:otherwise>
										<xsl:value-of select="$itemCount"/>
									</xsl:otherwise>
								</xsl:choose>
							</L008>
							<L009>PCS</L009>
						</ns0:L0>
						<xsl:if test="RateAndCharges/@FreightRate != '' or RateAndCharges/@Charge != '' or RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
							<ns0:L1>
								<L101>1</L101>
								<xsl:if test="RateAndCharges/@FreightRate != ''">
									<L102>
										<xsl:value-of select="RateAndCharges/@FreightRate"/>
									</L102>
								</xsl:if>
								<xsl:if test="RateAndCharges/@RateValueQualifier != ''">
									<L103>
										<xsl:value-of select="RateAndCharges/@RateValueQualifier"/>
									</L103>
								</xsl:if>
								<xsl:if test="RateAndCharges/@Charge != ''">
									<L104>
										<xsl:value-of select="RateAndCharges/@Charge"/>
									</L104>
								</xsl:if>
							</ns0:L1>
						</xsl:if>
					</ns0:LXLoop1>
				</xsl:if>
			</xsl:for-each>

			<xsl:for-each select="Detail/LineItemList/LineItem">
				<xsl:if test="DescriptionMarksAndNumbers/@LadingDescription != 'Line Haul'">
					<ns0:LXLoop1>
						<ns0:LX>
							<LX01>
								<xsl:value-of select="position() + 1"/>
							</LX01>
						</ns0:LX>
						<ns0:L5>
							<L501>
								<xsl:value-of select="position() + 1"/>
							</L501>
							<xsl:if test="DescriptionMarksAndNumbers/@LadingDescription != ''">
								<L502>
									<!-- Convert to UpperCase <xsl:value-of select="translate(DescriptionMarksAndNumbers/@LadingDescription,  $vLowercaseChars_CONST, $vUppercaseChars_CONST)" />-->
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="DescriptionMarksAndNumbers/@LadingDescription" />
										<xsl:with-param name="maxLength" select="50" />
									</xsl:call-template>
								</L502>
							</xsl:if>
						</ns0:L5>
						<ns0:L0>
							<L001>
								<xsl:value-of select="position() + 1"/>
							</L001>
							<xsl:if test="LineItemQuantityAndWeight/@BilledRatedAsQuantity != ''">
								<L002>
									<xsl:value-of select="LineItemQuantityAndWeight/@BilledRatedAsQuantity" />
								</L002>
							</xsl:if>
							<xsl:if test="LineItemQuantityAndWeight/@BilledRatedAsQualifier != ''">
								<L003>
									<xsl:value-of select="LineItemQuantityAndWeight/@BilledRatedAsQualifier" />
								</L003>
							</xsl:if>
						</ns0:L0>
						<xsl:if test="RateAndCharges/@FreightRate != '' or RateAndCharges/@Charge != '' or RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
							<ns0:L1>
								<L101>
									<xsl:value-of select="position() + 1"/>
								</L101>
								<xsl:if test="RateAndCharges/@FreightRate != ''">
									<L102>
										<xsl:value-of select="RateAndCharges/@FreightRate"/>
									</L102>
								</xsl:if>
								<xsl:if test="RateAndCharges/@RateValueQualifier != ''">
									<L103>
										<xsl:value-of select="RateAndCharges/@RateValueQualifier"/>
									</L103>
								</xsl:if>
								<xsl:if test="RateAndCharges/@Charge != ''">
									<L104>
										<xsl:value-of select="RateAndCharges/@Charge"/>
									</L104>
								</xsl:if>
								<xsl:if test="RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
									<L108>
										<xsl:choose>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'FUE' or RateAndCharges/@SpecialChargeOrAllowanceCode = '405'">FSC</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'TDT'">DTB</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'SPT'">DRO</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = '585'">245</xsl:when>
											<xsl:otherwise>
												<xsl:value-of select="RateAndCharges/@SpecialChargeOrAllowanceCode"/>
											</xsl:otherwise>
										</xsl:choose>
									</L108>
								</xsl:if>
							</ns0:L1>
						</xsl:if>
					</ns0:LXLoop1>
				</xsl:if>
			</xsl:for-each>
			<xsl:for-each select="Summary/TotalWeightAndCharges">
				<ns0:L3>
					<xsl:if test="@Weight != ''">
						<L301>
							<xsl:value-of select="@Weight"/>
						</L301>
					</xsl:if>
					<xsl:if test="@WeightQualifier != ''">
						<L302>
							<xsl:value-of select="@WeightQualifier"/>
						</L302>
					</xsl:if>
					<xsl:variable name="TotalCharges" select="@TotalCharges"/>
					<xsl:variable name="TotalChargesLength" select="string-length(@TotalCharges)"/>
					<xsl:if test="$TotalChargesLength > 2">
						<L305>
							<xsl:value-of select="translate(@TotalCharges,',','')"/>
							<!--<xsl:value-of select="concat(substring($TotalCharges, 1, $TotalChargesLength - 2), '.',  substring($TotalCharges, $TotalChargesLength - 2 , 2))" />-->
						</L305>
					</xsl:if>
					<xsl:if test="@LadingQuantity != ''">
						<L311>
							<xsl:value-of select="@LadingQuantity"/>
						</L311>
					</xsl:if>
				</ns0:L3>
			</xsl:for-each>
			<SE>
				<SE01>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetIdentifierCode"/>
				</SE01>
				<SE02>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber"/>
				</SE02>
			</SE>
		</ns0:X12_00401_210>
	</xsl:template>
	<!--Custom Templates-->
	<!-- Created by Neal, not specific to L108-->
	<xsl:template name="ChangeThisName">
		<xsl:param name="ValueToConvert" select="0"/>
		<xsl:param name="LadingDescriptionParm" select="1"/>
		<xsl:variable name="L108Map">
			<map>
				<entry key="LHS">400</entry>
				<entry key="LYC">LAY</entry>
				<entry key="SRG">STR</entry>
				<entry key="TDT">DET</entry>
			</map>
		</xsl:variable>
		<xsl:variable name="ValueConverted" select="msxsl:node-set($L108Map)/map/entry[@key=$ValueToConvert]"/>
		<xsl:choose>
			<xsl:when test="$ValueConverted">
				<xsl:value-of select="$ValueConverted"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:choose>
					<xsl:when test="$LadingDescriptionParm = 'Lumper'">
						<xsl:text>LAB</xsl:text>
					</xsl:when>
					<xsl:when test="$LadingDescriptionParm = 'Unloading'">
						<xsl:text>UNL</xsl:text>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="$ValueToConvert"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<!-- Created by Neal, not specific to L108-->
	<!-- CleanAlphaField start  -->
	<xsl:template name="CleanAlphaField">
		<xsl:param name="inputText"/>
		<xsl:param name="maxLength"/>
		<xsl:variable name="singleQuote" select='"&apos;"'/>
		<xsl:variable name="doubleQuote" select="'&quot;'"/>
		<xsl:variable name="vAllowedSymbolsPart1" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}\?/#'"/>
		<xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
		<xsl:variable name="vCleanedText" select="translate($inputText,translate($inputText, $vAllowedSymbols, ''),'')"/>
		<xsl:value-of select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
	</xsl:template>
	<!-- Clean AlphaField end -->
	<!--Value mapping template-->
	<xsl:template name="StopTypeMapValue">
		<xsl:param name="ValueToConvert" select="0"/>
		<xsl:variable name="StopTypeMap">
			<map>
				<entry key="Pick">SF</entry>
				<entry key="Drop">CN</entry>
			</map>
		</xsl:variable>
		<xsl:value-of select="msxsl:node-set($StopTypeMap)/map/entry[@key=$ValueToConvert]"/>
	</xsl:template>
	<!--Value mapping template-->
	<!--Set default if empty template start-->
	<xsl:template name="SetDefaultIfEmpty">
		<xsl:param name="pNode"/>
		<xsl:param name="pDefaultValue"/>
		<xsl:if test="$pNode">
			<xsl:value-of select="$pNode"/>
		</xsl:if>
		<xsl:if test="not($pNode)">
			<xsl:value-of select="$pDefaultValue"/>
		</xsl:if>
	</xsl:template>
	<!--Set default if empty template end-->
	<msxsl:script language="C#" implements-prefix="userCSharp">
		<msxsl:using namespace="System.Text.RegularExpressions" />
		<msxsl:using namespace="System.Collections.Generic" />
		<![CDATA[
public class LoadAddress
{
	public String LocationCode;
  public String AddressCode;
	public String Addr;
	public String City;
	public String ZipCode;

	public LoadAddress (String locationCode,String addressCode, String addr, String city, String zipCode){
		LocationCode = locationCode;
    AddressCode = addressCode;
		Addr = SanitizeInput(addr);
		City = SanitizeInput(city);
		ZipCode = SanitizeInput(zipCode);
	}
	
	// Matches if either address is a match for the account
	public bool isMatch(String addr1, String city1, String addr2, String city2){
			if (SanitizeInput(city1) == City 
					&& SanitizeInput(addr1) == Addr){return true;}
			else if (SanitizeInput(city2) == City
					&& SanitizeInput(addr2) == Addr){return true;}
		return false;
	}
	
	// "In" means "inbound" not "contains"
	public bool AddressIsIn(String addr1, String city1, String addr2, String city2){
			if (SanitizeInput(city2) == City 
				&& SanitizeInput(addr2) == Addr){return true;}
		return false;
	}
	
	private String SanitizeInput(String input){
		return Regex.Replace(input, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
}

	
	// Used by xslt to get N104 value for BY line
	public String GetLocationCode(String addr1, String city1, String addr2, String city2){
		foreach(LoadAddress lad in LOAD_ADDRESSES){
			if(lad.isMatch(addr1, city1, addr2, city2)){
				return lad.LocationCode;
			}
		}
		return "Not Found";
	}
  
  	// Used by xslt to get N104 value for stops
	public String GetAddressCode(String addr1, String city1, String addr2, String city2){
		foreach(LoadAddress lad in LOAD_ADDRESSES){
			if(lad.isMatch(addr1, city1, addr2, city2)){
				return lad.AddressCode;
			}
		}
		return "Not Found";
	}
	
	// Returns I for inbound, O for outbound. I = SH address, O = CN address
	public String GetIO(string addr, string city, string addr2, string city2){
		// Iterate through the address list, if we find a match, check if it's the loads inbound address. If it is, return I, if not, return O 
		foreach(LoadAddress ldr in LOAD_ADDRESSES){
			if(ldr.isMatch(addr, city, addr2, city2)){
				if(ldr.AddressIsIn(addr, city, addr2, city2)){return "I";}
				else{return "O";}
			}
		}
		return "Not Found";
	}
  //Column 2 for Address code is required additionally on some accounts - it is an additional code associated with the address and is returned on the pick/drop. Leave NULL if not in use. 
					public List<LoadAddress> LOAD_ADDRESSES = new List<LoadAddress>(){					
					new LoadAddress("HD3DBIRV","1209","167 Technology Drive","Irvine","92618"),
					new LoadAddress("HD3DBIRV","1209","2323 Avenida Costa Este","San Diego","92154"),
					new LoadAddress("HD3FMSLC","","2300 South 2300 West","Salt Lake City","84119"),
					new LoadAddress("HD3FMSLC","","955 South 3800 West","Salt Lake City","84104"),
					new LoadAddress("HD3FMSLC","","500 Indeneer Drive","Kernersville","27284"),
					new LoadAddress("HD3FMSLC","","4773 Colorado Ave S","Seattle","98134"),
					new LoadAddress("HDARCPOW","1140-1150-1000","12055 Tech Center Dr","Poway","92064"),
					new LoadAddress("HDARCPOW","1150","13915 Danielson St, Ste 100","Poway","92064"),
					new LoadAddress("HDARCPOW","1140-1150-1000-1060-1120-1130","2280 Enrico Fermi Dr #23","San Diego","92154"),
					new LoadAddress("HDARCPOW","1140-1150-1000-1060-1120-1130","8830 Siempre Viva Rd, Ste 100","San Diego","92154"),
					new LoadAddress("HDARCPOW","1140-1150-1000","2080 Enterprise Blvd","West Sacramento","95691"),
					new LoadAddress("HDARCPOW","1140-1150-1000","1 Hunter Douglas Dr SE","Cumberland","21502"),
					new LoadAddress("HDARCPOW","1140-1150-1000","111 Apollo Rd","Salt Lake City","84116"),
					new LoadAddress("HDARCPOW","1140-1150-1000-1100","4 Duette Way","Broomfield","80020"),
					new LoadAddress("HDARCPOW","","1610 Landmark","San Diego","92154"),
					new LoadAddress("HDAWSELM","","9900 Gidley Street","El Monte","91731"),
					new LoadAddress("HDAWSELM","","29572 Union City Blvd","Union City","94587"),
					new LoadAddress("HDCARAUG","","633 NW Frontage Rd","Augusta","30907"),
					new LoadAddress("HDCBGCAN","1060","2908 Portland Drive","Oakville","L6H5W8"),
					new LoadAddress("HDCBGCER","1140","12800 Center Court Dr S, Ste 450","Cerritos","90703"),
					new LoadAddress("HDCBGCER","1140-1150-1000-1100-1120-1130","12055 Tech Center Dr","Poway","92064"),
					new LoadAddress("HDCBGCER","1140-1150-1000-1100-1120-1130","2280 Enrico Fermi Dr #23","San Diego","92154"),
					new LoadAddress("HDCBGCER","1140-1150-1000-1100-1120-1130","8830 Siempre Viva Rd, Ste 100","San Diego","92154"),
					new LoadAddress("HDCBGCER","1140-1150-1000-1100-1120-1130","2080 Enterprise Blvd","West Sacramento","95691"),
					new LoadAddress("HDCBGCER","1140-1150-1000-1100-1120-1130","4 Duette Way","Broomfield","80020"),
					new LoadAddress("HDCBGCER","1140-1150-1000-1100-1120-1130","1 Hunter Douglas Dr SE","Cumberland","21502"),
					new LoadAddress("HDCBGCER","1140-1150-1000-1100-1120-1130","2580 Kenmore Ave","Tonawanda","14150"),
					new LoadAddress("HDCBGCER","1140-1000","2920 Brecksville Rd","Richfield","44286"),
					new LoadAddress("HDCBGCER","1140-1150-1000-1100-1120-1130","111 Apollo Rd","Salt Lake City","84116"),
					new LoadAddress("HDCBGCER","1140","Prolongacion 5 de Mayo No. 2483","Playas de Rosarito","22710"),
					new LoadAddress("HDCBGCER","1100","1610 Landmark","San Diego","92154"),
					new LoadAddress("HDCBGFXO","1020","5710 Technology Circle","Appleton","54914"),
					new LoadAddress("HDCBGTIM","1140","1400 Lavon Dr.","McKinney","75069"),
					new LoadAddress("HDCBGVIS","1140","8801 Corporate Square Ct.","Jacksonville","32216"),
					new LoadAddress("HDCBGVIS","1140","10 E.V. Hogan Drive","Hamlet","28345"),
					new LoadAddress("HDCFXMPL","1105","21 Elm Street","Maplewood","12189"),
					new LoadAddress("HDCFXMPL","1105","1801 Avenue B","Watervliet","12189"),
					new LoadAddress("HDCFXMPL","1105","601 S 65th Ave","Phoenix","85043"),
					new LoadAddress("HDCFXMPL","1105","1307 Mineral Springs Ave","North Providence","02904"),
					new LoadAddress("HDCFXMPL","1105","20 S 3rd St","Telford","18969"),
					new LoadAddress("HDCFXMPL","1105","633 NW Frontage Rd","Augusta","30907"),
					new LoadAddress("HDCFXMPL","1105","8830 Siempre Viva RD Ste 100","San Diego","92154"),
					new LoadAddress("HDCFXMPL","1105","1400 Lavor Dr","McKinney","75069"),
					new LoadAddress("HDCFXMPL","1105","21 Elm Street","Watervliet","12189"),
					new LoadAddress("HDCFXMPL","","1610 Landmark","San Diego","92154"),
					new LoadAddress("HDFABBRM","1110","1 Duette Way","Broomfield","80020"),
					new LoadAddress("HDFABBRM","1110","4 Duette Way","Broomfield","80020"),
					new LoadAddress("HDFABBRM","1110","5 Duette Way","Broomfield","80020"),
					new LoadAddress("HDFABCMB","1000","4145 Parkway Dr","Florence","35630"),
					new LoadAddress("HDFABCMB","1000","601 S 65th Ave #6","Phoenix","85043"),
					new LoadAddress("HDFABCMB","1000","3407 N Perris Blvd","Perris","92571"),
					new LoadAddress("HDFABCMB","1140-1150-1000","12055 Tech Center Dr","Poway","92064"),
					new LoadAddress("HDFABCMB","1140-1150-1000-1060-1120-1130","2280 Enrico Fermi Dr #23","San Diego","92154"),
					new LoadAddress("HDFABCMB","1140-1150-1000-1060","8830 Siempre Viva Rd, Ste 100","San Diego","92154"),
					new LoadAddress("HDFABCMB","1000","1144 N Main St","Lombard","60148"),
					new LoadAddress("HDFABCMB","1140-1150-1000","1 Hunter Douglas Dr SE","Cumberland","21502"),
					new LoadAddress("HDFABCMB","1000","2663 Patton Rd","Roseville","55113"),
					new LoadAddress("HDFABCMB","1101","222 Laney Rd","Shannon","38868"),
					new LoadAddress("HDFABCMB","1102","201 Southridge Parkway","Bessemer City","28016"),
					new LoadAddress("HDFABCMB","1116","62 Enter Lane","Islandia","11749"),
					new LoadAddress("HDFABCMB","1140-1000","2580 Kenmore Ave","Tonawanda","14150"),
					new LoadAddress("HDFABCMB","1140-1000","2920 Brecksville Rd","Richfield","44286"),
					new LoadAddress("HDFABCMB","1140-1000-1060","132 First Gulf Blvd","Brampton","L6W4T7"),
					new LoadAddress("HDFABCMB","1115","8572 Katy Freeway","Houston","77024"),
					new LoadAddress("HDFABCMB","1000","1920 Merrill Creek Pkwy","Everett","98203"),
					new LoadAddress("HDFABMNT","1000","Ave Ruiz Cortines #6021","Colonia Los Puertos","66647"),
					new LoadAddress("HDFABMNT","1000","8301 Killiam Industrial Blvd","Laredo","78045"),
					new LoadAddress("HDFABMNT","","318 Crossroads","Laredo","78045"),
					new LoadAddress("HDFABSAC","1140-1150-1000","2080 Enterprise Blvd","West Sacramento","95691"),
					new LoadAddress("HDFABSLC","1140-1150-1000","111 Apollo Rd","Salt Lake City","84116"),
					new LoadAddress("HDHOSPSD","","9927 Via de la Amistad Business Park","San Diego","92154"),
					new LoadAddress("HDHOSPSD","","12975 Brookprinter Place","Poway","92064"),
					new LoadAddress("HDLEVAGP","1120-1130","102 W 9th St","Douglas","85607"),
					new LoadAddress("HDLEVAGP","1120-1130","2350 E Riverview Dr #120","Phoenix","85034"),
					new LoadAddress("HDLEVAGP","1120-1130","3045 S 43rd Ave","Phoenix","85009"),
					new LoadAddress("HDLEVAGP","1120-1130","4110 W Gibson Ln","Phoenix","85009"),
					new LoadAddress("HDLEVAGP","1120-1130","Calle 17 Ave 67 Y 10","Agua Prieta","85714"),
					new LoadAddress("HDLEVAGP","","1610 Landmark","San Diego","92154"),
					new LoadAddress("HDLEVBUF","1120-1130","3 Glenlake Pkwy","Atlanta","30328"),
					new LoadAddress("HDLEVBUF","1120-1130","1750 Satellite Blvd, Ste 100","Buford","30518"),
					new LoadAddress("HDLEVBUF","1120-1130","5775 Glenridge Drive, Building A","Atlanta","30328"),
					new LoadAddress("HDLEVCAN","1232","435 N Service Road","Oakville","L6M4X8"),
					new LoadAddress("HDLEVOGD","1120-1130","1330 W 3300 S St","Ogden","84401"),
					new LoadAddress("HDMERCOW","","5970 N Main St","Cowpens","29330"),
					new LoadAddress("HDMERCOW","","275 Tucapau Rd","Wellford","29385"),
					new LoadAddress("HDMERCOW","","109 Plantation Drive","Spartanburg","29302"),
					new LoadAddress("HDMERCOW","","254 Franklin Street","Spartanburg","29303"),
					new LoadAddress("HDMFGOWE","1107","1600 Ragu Dr","Owensboro","42303"),
					new LoadAddress("HDMFGTUP","1101","222 Laney Rd","Shannon","38868"),
					new LoadAddress("HDSELBLD","","145 South 79th Street Suite 85","Chandler","85226"),
					new LoadAddress("HDTURBUF","","1750 Satellite Blvd","Buford","30518"),
					new LoadAddress("HDTURBUF","","950 Quality Drive","Lancaster","29720"),
					new LoadAddress("HDWDDBC","1102","201 Southridge Parkway","Bessemer City","28016"),
					new LoadAddress("HDWFDBRM","1000","1 Duette Way","Broomfield","80020"),
					new LoadAddress("HDWFDBRM","1000","2 Duette Way","Broomfield","80020"),
					new LoadAddress("HDWFDBRM","1000","3 Duette Way","Broomfield","80020"),
					new LoadAddress("HDWFDBRM","1000","4 Duette Way","Broomfield","80020"),
					new LoadAddress("HDWFDBRM","1000","5 Duette Way","Broomfield","80020"),
					new LoadAddress("HDWFDBRM","1000","2550 W. Midway Blvd.","Broomfield","80020"),
					new LoadAddress("HDWFDBRM","1000","601 Alter St","Broomfield","80020"),
};
]]>
	</msxsl:script>

</xsl:stylesheet>
