<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:msxsl="urn:schemas-microsoft-com:xslt"
                xmlns:con="http://Echo.BSSR.Internal.Canonical.Status/v1.0"
				xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00401.EDI214/v1.0"
                xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp"
                exclude-result-prefixes="msxsl  userCSharp con">
	<xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>

	<!--Variables-->
	<xsl:variable name="varNumeric" select="1234567890" />
	<xsl:variable name="vX6LoadActivityNotes" select="con:Status/StatusList/ShipmentStatus/Remarks/Remark[@remarkMessage1='X6']/@remarkMessage2" />

	<!--Main template-->
	<xsl:template match="/">
		<xsl:apply-templates select="/con:Status/StatusList/ShipmentStatus" />
	</xsl:template>
	<xsl:template match="/con:Status/StatusList/ShipmentStatus">
		<xsl:element name="ns0:X12_00401_214">
			<xsl:apply-templates select="." mode="BuildST"/>
			<xsl:apply-templates select="." mode="BuildB10"/>

			<!--Alrick changes for E148921 -->
			<xsl:variable name="ENum" select="/con:Status/@CustomerId"/>
			<xsl:for-each select="BusinessReferences">
				<xsl:for-each select="BusinessReference">
					<xsl:if test="$ENum = '148921' and (@referenceType  = 'CN')">
						<ns0:L11>
							<xsl:if test="@referenceId != ''">
								<L1101>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="@referenceId" />
										<xsl:with-param name="maxLength" select="30" />
									</xsl:call-template>
								</L1101>
							</xsl:if>
							<xsl:if test="@referenceType  != ''">
								<L1102>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="@referenceType" />
										<xsl:with-param name="maxLength" select="3" />
									</xsl:call-template>
								</L1102>
							</xsl:if>
						</ns0:L11>
					</xsl:if>
				</xsl:for-each>
			</xsl:for-each>

			<xsl:if test="((//BusinessReferences/BusinessReference/@referenceId = 'NIKE') and 
						  (//Statuses/Status/Details/Detail/@statusCode) = 'X1') ">
				<xsl:apply-templates select="//Statuses/Status/Details/Detail[not(userCSharp:IsNullOrEmpty(@statusCode))]" mode="BuildLXLoop1" >
					<xsl:with-param name="pShipmentStatusCode">X1</xsl:with-param>
				</xsl:apply-templates>
				<xsl:apply-templates select="//Statuses/Status/Details/Detail[not(userCSharp:IsNullOrEmpty(@statusCode))]" mode="BuildLXLoop1" >
					<xsl:with-param name="pShipmentStatusCode">D1</xsl:with-param>
				</xsl:apply-templates>
			</xsl:if>

			<xsl:if test="not((//BusinessReferences/BusinessReference/@referenceId = 'NIKE') and 
						  (//Statuses/Status/Details/Detail/@statusCode) = 'X1') ">
				<xsl:apply-templates select="//Statuses/Status/Details/Detail[not(userCSharp:IsNullOrEmpty(@statusCode))]" mode="BuildLXLoop1" >
					<xsl:with-param name="pShipmentStatusCode">
						<xsl:choose>
							<xsl:when test="//BusinessReferences/BusinessReference[@referenceType = '11' 
											and 
											@referenceId='DLMF']">
								<xsl:value-of select="//Statuses/Status/Details/Detail/@statusCode"/>
							</xsl:when>
							<xsl:when test="//Statuses/Status/Details/Detail/@statusCode = 'AF' 
											and 
											//BusinessReferences/BusinessReference[@referenceType = '11' and @referenceId != 'DLMF']
									  		and 
											//BusinessReferences/BusinessReference[@referenceType = '11' and @referenceId != 'SHES']
											and 
											//BusinessReferences/BusinessReference[@referenceType = '11' and @referenceId != 'LAVA']		
											and 
											//BusinessReferences/BusinessReference[@referenceType = '11' and @referenceId != 'AINS']		
											and 
											//BusinessReferences/BusinessReference[@referenceType = '11' and @referenceId != 'WNBR']		
											and 
											//BusinessReferences/BusinessReference[@referenceType = '11' and @referenceId != 'CMNA']		
											and 
											//BusinessReferences/BusinessReference[@referenceType = '11' and @referenceId != 'KEEF']		
											and 
											//BusinessReferences/BusinessReference[@referenceType = '11' and @referenceId != 'MCCK']											  
											and 
											//BusinessReferences/BusinessReference[@referenceType = '11' and @referenceId != 'ORIN']">
								<xsl:text>CP</xsl:text>
							</xsl:when>
							<xsl:when test="(//Statuses/Status/Details/Detail/@statusCode = 'D1')
											  and 
												((//BusinessReferences/BusinessReference[@referenceType = '11' and @referenceId = 'AINS'])
													or  											
												(//BusinessReferences/BusinessReference[@referenceType = '11' and @referenceId = 'WNBR']))">
								<xsl:text>CD</xsl:text>
							</xsl:when>
							<xsl:otherwise>
								<xsl:value-of select="//Statuses/Status/Details/Detail/@statusCode"/>
							</xsl:otherwise>
						</xsl:choose>
					</xsl:with-param>
				</xsl:apply-templates>
			</xsl:if>
		</xsl:element>
	</xsl:template>

	<!--Referred templates-->
	<xsl:template match="ShipmentStatus" mode="BuildST">
		<xsl:element name="ST">
			<xsl:element name="ST01">
				<xsl:text>214</xsl:text>
			</xsl:element>
			<xsl:element name="ST02">
				<xsl:text>1234</xsl:text>
			</xsl:element>
		</xsl:element>
	</xsl:template>

	<xsl:template match="ShipmentStatus" mode="BuildB10">
		<xsl:element name="ns0:B10">
			<xsl:element name="B1001">
				<xsl:value-of select="ReferenceData/LoadId" />
			</xsl:element>
			<xsl:element name="B1002">
				<xsl:choose>
					<xsl:when test="//BusinessReferences/BusinessReference[@referenceType = '11']/@referenceId = 'ORIN'">
						<xsl:value-of select="//BusinessReferences/BusinessReference[@referenceType = 'MB']/@referenceId" />
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="ReferenceData/Bol"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:element>
			<xsl:element name="B1003">
				<xsl:choose>
					<xsl:when test="BusinessReferences/BusinessReference[@referenceType='7J']/@referenceId!=''">
						<xsl:value-of select="BusinessReferences/BusinessReference[@referenceType='7J']/@referenceId"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:text>ECHS</xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:element>
		</xsl:element>
	</xsl:template>

	<xsl:template match="Detail" mode="BuildLXLoop1">
		<xsl:param name="pShipmentStatusCode" />
		<xsl:element name="ns0:LXLoop1">
			<xsl:apply-templates select="." mode="BuildLXLoop1_LX" />
			<xsl:element name="ns0:AT7Loop1">
				<xsl:apply-templates select="." mode="BuildAT7Loop1_AT7">
					<xsl:with-param name="pShipmentStatusCode" select="$pShipmentStatusCode"></xsl:with-param>
				</xsl:apply-templates>
				<xsl:apply-templates select="EquipmentLocation[not(userCSharp:IsNullOrEmpty(@cityName)) and not(userCSharp:IsNullOrEmpty(@stateOrProvince))]" mode="BuildAT7Loop1_MS1" />
				<xsl:apply-templates select="EquipmentLocation[not(userCSharp:IsNullOrEmpty(@equipmentDescriptionCode)) and not(userCSharp:IsNullOrEmpty(@equipmentNumber))]" mode="BuildAT7Loop1_MS2" />
			</xsl:element>
			<!--  Custom Change
				<xsl:apply-templates select="//ShipmentStatus/ReferenceData[not(userCSharp:IsNullOrEmpty(StopSequenceNumber)) and not(StopSequenceNumber = '0')]" mode="BuildLXLoop1_L11_3" />
			-->
			<xsl:apply-templates select="//ShipmentStatus/ReferenceData" mode="BuildLXLoop1_L11_3" />
			<xsl:apply-templates select="//ShipmentTotals[not(userCSharp:IsNullOrEmpty(./TotalWeight)) and (./TotalWeight > 0)]" mode="BuildLXLoop1_AT8" />
		</xsl:element>
	</xsl:template>

	<xsl:template match="Detail" mode="BuildLXLoop1_LX">
		<xsl:element name="ns0:LX">
			<xsl:element name="LX01">
				<xsl:value-of select="../../@assignedNumber"/>
			</xsl:element>
		</xsl:element>
	</xsl:template>

	<xsl:template match="Detail" mode="BuildAT7Loop1_AT7">
		<xsl:param name="pShipmentStatusCode" />
		<xsl:element name="ns0:AT7">
			<xsl:choose>
				<xsl:when test="@statusCode != 'AA' and @statusCode != 'AB'">
					<xsl:element name="AT701">
						<xsl:value-of select="$pShipmentStatusCode"/>
					</xsl:element>
					<xsl:element name="AT702">
						<xsl:text>NS</xsl:text>
					</xsl:element>
				</xsl:when>
				<xsl:when test="@statusCode = 'AA' or @statusCode = 'AB'">
					<xsl:element name="AT703">
						<xsl:value-of select="@statusCode"/>
					</xsl:element>
					<xsl:element name="AT704">
						<xsl:text>NA</xsl:text>
					</xsl:element>
				</xsl:when>
			</xsl:choose>

			<xsl:if test="not(userCSharp:IsNullOrEmpty(@statusdatetime))">
				<xsl:element name="AT705">
					<xsl:value-of select="userCSharp:GetDate(@statusdatetime)"/>
				</xsl:element>
				<xsl:element name="AT706">
					<xsl:value-of select="userCSharp:GetTime(@statusdatetime)"/>
				</xsl:element>
			</xsl:if>
			<xsl:element name="AT707">
				<xsl:text>LT</xsl:text>
			</xsl:element>
		</xsl:element>
	</xsl:template>

	<!--<xsl:template match="EquipmentLocation" mode="BuildAT7Loop1_MS1">
		<xsl:if test="not(userCSharp:IsNullOrEmpty(@cityName)) and not(userCSharp:IsNullOrEmpty(@stateOrProvince)) ">
			<xsl:if test="string-length(@cityName) > 1 and string-length(@stateOrProvince) = 2 ">
				<xsl:element name="ns0:MS1">
					<xsl:element name="MS101">
						<xsl:value-of select="substring(@cityName,1,30)"/>
					</xsl:element>
					<xsl:element name="MS102">
						<xsl:value-of select="@stateOrProvince"/>
					</xsl:element>
				</xsl:element>
			</xsl:if>
		</xsl:if>
	</xsl:template>-->

	<xsl:template match="EquipmentLocation" mode="BuildAT7Loop1_MS1">
		<xsl:choose>
			<!-- Case 1: Has both longitude and latitude attributes -->
			<xsl:when test="(@longitudeCode != '') and (@latitudeCode != '')">
				<ns0:MS1>
					<xsl:if test="@longitudeCode != ''">
						<MS104>
							<xsl:call-template name="FormatDecimalDegreesLongitude">
								<xsl:with-param name="longitudecode" select="@longitudeCode"/>
							</xsl:call-template>
						</MS104>
					</xsl:if>
					<xsl:if test="@latitudeCode != ''">
						<MS105>
							<xsl:call-template name="FormatDecimalDegreesLatitude">
								<xsl:with-param name="latitudecode" select="@latitudeCode"/>
							</xsl:call-template>
						</MS105>
					</xsl:if>
					<xsl:if test="@longitudeCode != ''">
						<MS106>
							<xsl:choose>
								<xsl:when test="contains(@longitudeCode,'-')">W</xsl:when>
								<xsl:otherwise>E</xsl:otherwise>
							</xsl:choose>
						</MS106>
					</xsl:if>
					<xsl:if test="@latitudeCode != ''">
						<MS107>
							<xsl:choose>
								<xsl:when test="contains(@latitudeCode,'-')">S</xsl:when>
								<xsl:otherwise>N</xsl:otherwise>
							</xsl:choose>
						</MS107>
					</xsl:if>
				</ns0:MS1>
			</xsl:when>

			<!-- Case 2: Location values parsed from activity notes -->
			<xsl:when test="contains($vX6LoadActivityNotes, 'Longitude') and contains($vX6LoadActivityNotes, 'Latitude')">
				<xsl:variable name="vlongitudecode">
					<xsl:call-template name="FormatDecimalDegreesLongitude">
						<xsl:with-param name="longitudecode" select="userCSharp:GetLongitude($vX6LoadActivityNotes)" />
					</xsl:call-template>
				</xsl:variable>
				<xsl:variable name="vlatitudecode">
					<xsl:call-template name="FormatDecimalDegreesLatitude">
						<xsl:with-param name="latitudecode" select="userCSharp:GetLatitude($vX6LoadActivityNotes)" />
					</xsl:call-template>
				</xsl:variable>
				<ns0:MS1>
					<xsl:if test="$vlongitudecode != ''">
						<MS104>
							<xsl:value-of select="$vlongitudecode"/>
						</MS104>
					</xsl:if>
					<xsl:if test="$vlatitudecode != ''">
						<MS105>
							<xsl:value-of select="$vlatitudecode"/>
						</MS105>
					</xsl:if>
					<xsl:if test="$vlongitudecode != ''">
						<MS106>
							<xsl:choose>
								<xsl:when test="contains($vlongitudecode,'-')">W</xsl:when>
								<xsl:otherwise>E</xsl:otherwise>
							</xsl:choose>
						</MS106>
					</xsl:if>
					<xsl:if test="$vlatitudecode != ''">
						<MS107>
							<xsl:choose>
								<xsl:when test="contains($vlatitudecode,'-')">S</xsl:when>
								<xsl:otherwise>N</xsl:otherwise>
							</xsl:choose>
						</MS107>
					</xsl:if>
				</ns0:MS1>
			</xsl:when>

			<!-- Case 3: Fallback to city and state -->
			<xsl:otherwise>
				<xsl:if test="(@cityName != '') or (@stateOrProvince != '')">
					<ns0:MS1>
						<xsl:if test="@cityName != ''">
							<MS101>
								<xsl:call-template name="CleanAlphaField">
									<xsl:with-param name="inputText" select="@cityName" />
									<xsl:with-param name="maxLength" select="30" />
								</xsl:call-template>
							</MS101>
						</xsl:if>
						<xsl:if test="@stateOrProvince != ''">
							<MS102>
								<xsl:call-template name="StateCodetranslationMapValue">
									<xsl:with-param name="ValueToConvert" select="@stateOrProvince" />
								</xsl:call-template>
							</MS102>
						</xsl:if>
					</ns0:MS1>
				</xsl:if>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>


	<xsl:template match="EquipmentLocation" mode="BuildAT7Loop1_MS2">
		<xsl:element name="ns0:MS2">
			<xsl:element name="MS201">
				<xsl:value-of select="@equipmentScac"/>
			</xsl:element>

			<xsl:element name="MS202">
				<!--Only allow numeric values with final field length as 10-->
				<xsl:variable name="varTrimmedEquipNum" select="translate(@equipmentNumber, ' ', '')" />
				<xsl:value-of select="substring(translate($varTrimmedEquipNum, 
											    translate($varTrimmedEquipNum, $varNumeric, ''), ''),
													1, 10)"/>
			</xsl:element>

			<xsl:element name="MS203">
				<xsl:value-of select="@equipmentDescriptionCode"/>
			</xsl:element>
		</xsl:element>
	</xsl:template>

	<xsl:template match="ReferenceData" mode="BuildLXLoop1_L11_3">
		<xsl:choose>
			<xsl:when test="StopSequenceNumber = //BusinessReferences/BusinessReference[@referenceType = 'SC']/@referenceId">
				<xsl:element name="ns0:L11_3">
					<xsl:element name="L1101">
						<xsl:text>99</xsl:text>
					</xsl:element>
					<xsl:element name="L1102">
						<xsl:text>QN</xsl:text>
					</xsl:element>
				</xsl:element>
			</xsl:when>
			<xsl:otherwise>
				<!-- Original 
							<xsl:value-of select="StopSequenceNumber"/> 
						-->
				<xsl:choose>
					<!-- Highest Piority, if header stop sequence number is not empty and non 0, it will be mapped-->
					<xsl:when test="(StopSequenceNumber/text()  != '') and (StopSequenceNumber/text()  > 0)">
						<xsl:element name="ns0:L11_3">
							<xsl:element name="L1101">
								<xsl:call-template name="CleanAlphaField" >
									<xsl:with-param name="inputText" select="StopSequenceNumber/text()" />
									<xsl:with-param name="maxLength" select="30" />
								</xsl:call-template>
							</xsl:element>
							<xsl:element name="L1102">
								<xsl:text>QN</xsl:text>
							</xsl:element>
						</xsl:element>
					</xsl:when>
					<!--  Custom change: Checking if stop sequence number is empty and 0 (done above) and check if it the status is != X6 (as X6 is expected to have it 0 or empty)
												 then apply this following template:
							 
									Pick: AA, AF, X3 and CP
									Drop: AB, X1, A3, D1 and CD

									Pass parameters to template: Equipment City Name and Equipment StateOrProvince.  The template will:

									For pick statuses:
									Confirm that canonical stop type is also Pick and Canonical //Address/City matches the equipment city and //Address/StateOrProvince matches the Equipment StateOrProvince.  If it matches, it selects the Status Assigned Number. If this is !=0 , then it will return this value.
									Else return 1.  

									For Drop statuses:
									Confirm that canonical stop type is also Drop and Canonical //Address/City matches the equipment city and //Address/StateOrProvince matches the Equipment StateOrProvince.  If it matches, it selects the Status Assigned Number. If this is !=0 , then it will return this value.
									Else return 2.   (Confirmed with Mark Anderson if that this should be 2)


									If the conditions for pick and drop are not satisfied (mismatched), it simply returns 1 (Confirmed with Mark Anderson if this is safe to return 1)
								-->
					<xsl:when test="(string-length(../Statuses/Status/Details/Detail[1]/@statusCode) !=0) and (../Statuses/Status/Details/Detail[1]/@statusCode != 'X6')">
						<xsl:element name="ns0:L11_3">
							<xsl:element name="L1101">
								<xsl:call-template name="StopSequenceTypeMapValue">
									<xsl:with-param name="StatusCodeToConvert" select="../Statuses/Status/Details/Detail[1]/@statusCode"/>
									<xsl:with-param name="vStatuscityName" select="../Statuses/Status[Details/Detail[@statusCode]]/Details/Detail[@statusCode]/EquipmentLocation/@cityName"/>
									<xsl:with-param name="vStatusstateOrProvince" select="../Statuses/Status[Details/Detail[@statusCode]]/Details/Detail[@statusCode]/EquipmentLocation/@stateOrProvince"/>
								</xsl:call-template>
							</xsl:element>
							<xsl:element name="L1102">
								<xsl:text>QN</xsl:text>
							</xsl:element>
						</xsl:element>
					</xsl:when>
					<xsl:otherwise>
						<!-- Note: X6 will still have the entire L11 - L1101/L1102 as empty-->
					</xsl:otherwise>
				</xsl:choose>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

	<xsl:template match="ShipmentTotals" mode="BuildLXLoop1_AT8">
		<xsl:element name="ns0:AT8">
			<xsl:element name="AT801">
				<xsl:value-of select="ShipmentTotal/@totalTypeQualifier"/>
			</xsl:element>
			<xsl:element name="AT802">
				<xsl:value-of select="ShipmentTotal/@totalUnitOfMeasure"/>
			</xsl:element>
			<xsl:element name="AT803">
				<xsl:value-of select="format-number(TotalWeight, '0.##')"/>
			</xsl:element>
			<xsl:element name="AT804">
				<xsl:value-of select="TotalHandlingQty"/>
			</xsl:element>
		</xsl:element>
	</xsl:template>

	<!-- CleanAlphaField start  -->
	<xsl:template name="CleanAlphaField">
		<xsl:param name="inputText" />
		<xsl:param name="maxLength" />
		<xsl:variable name="singleQuote" select='"&apos;"' />
		<xsl:variable name="doubleQuote" select="'&quot;'" />
		<xsl:variable name="vAllowedSymbolsPart1" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}\?/#'"/>
		<xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
		<xsl:variable name="vCleanedText" select="translate($inputText,translate($inputText, $vAllowedSymbols, ''),'')"/>
		<xsl:value-of select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
	</xsl:template>
	<!-- Clean AlphaField end -->

	<!--StopSequenceTypeMapValue template-->
	<xsl:template name="StopSequenceTypeMapValue">
		<xsl:param name="StatusCodeToConvert" />
		<xsl:param name="vStatuscityName" />
		<xsl:param name="vStatusstateOrProvince" />
		<xsl:variable name="StopSequenceTypeMap" >
			<map>
				<entry key="AA">Pick</entry>
				<entry key="AF">Pick</entry>
				<entry key="X3">Pick</entry>
				<entry key="CP">Pick</entry>
				<entry key="AB">Drop</entry>
				<entry key="X1">Drop</entry>
				<entry key="A3">Drop</entry>
				<entry key="D1">Drop</entry>
				<entry key="CD">Drop</entry>
			</map>
		</xsl:variable>
		<xsl:variable name="StatusCodeConverted" select="msxsl:node-set($StopSequenceTypeMap)/map/entry[@key=$StatusCodeToConvert]"/>
		<xsl:choose>
			<xsl:when test="$StatusCodeConverted='Pick'">
				<xsl:variable name="vPickStopSequenceNumber" select="../Statuses/Status/Details/Detail[@stopType='Pick' and Addresses/Address[@city=$vStatuscityName and @stateProvince=$vStatusstateOrProvince]]/../../@assignedNumber"/>
				<xsl:choose>
					<xsl:when test="(string-length($vPickStopSequenceNumber) != 0)  and ($vPickStopSequenceNumber > 0)">
						<xsl:value-of select="$vPickStopSequenceNumber"/>
					</xsl:when>
					<xsl:otherwise>1</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:when test="$StatusCodeConverted='Drop'">
				<xsl:variable name="vDropStopSequenceNumber" select="../Statuses/Status/Details/Detail[@stopType='Drop' and Addresses/Address[@city=$vStatuscityName and @stateProvince=$vStatusstateOrProvince]]/../../@assignedNumber"/>
				<xsl:choose>
					<xsl:when test="(string-length($vDropStopSequenceNumber) !=0 ) and ($vDropStopSequenceNumber > 0) ">
						<xsl:value-of select="$vDropStopSequenceNumber"/>
					</xsl:when>
					<xsl:otherwise>2</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:otherwise>1</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<!--StopSequenceTypeMapValue template-->
	<!--FormatDecimalDegreesLatitude  Pad with Leading Zero if less than 7 Characters-->
	<xsl:template name="FormatDecimalDegreesLatitude">
		<xsl:param name="latitudecode"/>
		<xsl:choose>
			<xsl:when test="string-length($latitudecode) &gt; 7">
				<xsl:value-of select="substring($latitudecode, 1, 7)" />
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="substring(concat('0000000', $latitudecode), string-length(concat('0000000', $latitudecode)) - 6)" />
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<!-- FormatDecimalDegreesLongitude Pad with Leading Zero if less than 7 Characters-->
	<xsl:template name="FormatDecimalDegreesLongitude">
		<xsl:param name="longitudecode"/>
		<xsl:choose>
			<xsl:when test="string-length($longitudecode) &gt; 7">
				<xsl:value-of select="substring($longitudecode, 1, 7)" />
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="substring(concat('0000000', $longitudecode), string-length(concat('0000000', $longitudecode)) - 6)" />
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<!-- CleanAlphaField end  -->
	<xsl:template name="StateCodetranslationMapValue">
		<xsl:param name="ValueToConvert" select="0" />
		<xsl:variable name="StateCodetranslationMap" >
			<map>
				<entry key="AGS">AG</entry>
				<entry key="BCS">BS</entry>
				<entry key="CAM">CP</entry>
				<entry key="CHIH">CI</entry>
				<entry key="CHIS">CS</entry>
				<entry key="COAH">CH</entry>
				<entry key="COL">CL</entry>
				<entry key="DGO">DG</entry>
				<entry key="GRO">GE</entry>
				<entry key="GTO">GJ</entry>
				<entry key="HGO">HD</entry>
				<entry key="JAL">JA</entry>
				<entry key="MEX">MX</entry>
				<entry key="MICH">MC</entry>
				<entry key="MOR">MR</entry>
				<entry key="NAY">NA</entry>
				<entry key="OAX">OA</entry>
				<entry key="PUE">PU</entry>
				<entry key="QRO">QE</entry>
				<entry key="QROO">QI</entry>
				<entry key="SIN">SI</entry>
				<entry key="SLP">SL</entry>
				<entry key="SON">SO</entry>
				<entry key="TAB">TB</entry>
				<entry key="TAM">TA</entry>
				<entry key="TLAX">TL</entry>
				<entry key="VER">VC</entry>
				<entry key="YUC">YU</entry>
				<entry key="ZAC">ZA</entry>
			</map>
		</xsl:variable>
		<xsl:variable name="ValueConverted" select="msxsl:node-set($StateCodetranslationMap)/map/entry[@key=$ValueToConvert]"/>
		<xsl:choose>
			<xsl:when test="$ValueConverted">
				<xsl:value-of select="$ValueConverted"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="$ValueToConvert"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<msxsl:script language="C#" implements-prefix="userCSharp">
		<![CDATA[		
				
      public bool IsNullOrEmpty(string str)
      {
	        return System.String.IsNullOrEmpty(str);
      }
      
      public string GetDate(string str)
      {
            string retVal = String.Empty;

            if (!System.String.IsNullOrEmpty(str))
            {
                retVal = System.DateTimeOffset.Parse(str).ToString("yyyyMMdd");
            }

            return retVal;
        }

        public string GetTime(string str)
        {
            string retVal = String.Empty;

            if (!System.String.IsNullOrEmpty(str))
            {
                retVal = System.DateTimeOffset.Parse(str).ToString("HHmm");
            }

            return retVal;
        }    
             public  string GetLongitude(string str)
        {

            string stringOut = "";
            string str1 = "Longitude";
            string str2 = ",";


            if (str.Contains(str1) && str.Contains(str2))
            {
                str = str.Replace(str1, "").Replace("[", "").Replace("]", "").Replace(":", "").Replace(" ", "");

                stringOut = str.Split(new[] { "," }, StringSplitOptions.None)[1];

            }
            return stringOut;
        }

      
        public  string GetLatitude(string str)
        {
   
            string stringOut = "";
            string str1 = "Latitude";
            string str2 = ",";


            if (str.Contains(str1) && str.Contains(str2))
            {
                   str = str.Replace(str1, "").Replace("[", "").Replace("]", "").Replace(":", "").Replace(" ", "");

                 stringOut = str.Split(new[] { "," }, StringSplitOptions.None)[0];

            }
            return stringOut;
        }
				public  string ReplaceSubstring(string input, string oldValue, string newValue)
				{
      
						if (!input.Contains(oldValue))
						{
       
								return input;
						}

						string result = input.Replace(oldValue, newValue);
						return result;
				}
  ]]>
	</msxsl:script>
</xsl:stylesheet>
