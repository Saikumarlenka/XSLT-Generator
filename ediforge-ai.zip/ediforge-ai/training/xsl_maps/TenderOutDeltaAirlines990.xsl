<?xml version="1.0" encoding="UTF-16"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" exclude-result-prefixes="msxsl var s0" version="1.0" xmlns:s0="http://Echo.BSSR.Internal.Canonical.TendorResponse.TenderResponseOut" xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00501.EDI990/v1.0">
	<xsl:output omit-xml-declaration="yes" method="xml" version="1.0" />
	<xsl:template match="/">
		<xsl:apply-templates select="/s0:TenderResponse" />
	</xsl:template>
	<xsl:template match="/s0:TenderResponse">
		<xsl:variable name="vCustomerId" select="@CustomerId" />
		<xsl:variable name="vCompanyId" select="@CompanyId" />
		<xsl:variable name="vDefaultSCAC" select="'ECHS'" />		
		<xsl:variable name="vBookingDateRaw" select="Transaction/Header/BookingDate/text()" />
		<xsl:variable name="vReservationCode" select="Transaction/Header/ReservationCode/text()" />
		<xsl:variable name="vRemarks" select="Transaction/Header/Remarks/text()" />

		<xsl:variable name="vBookingDate" select="substring-before($vBookingDateRaw,'T')" />
		<xsl:variable name="vBookingYear" select="substring-before($vBookingDate, '-')" />
		<xsl:variable name="vBookingMonthDay" select="substring-after($vBookingDate,'-')" />
		<xsl:variable name="vBookingMonth" select="substring-before($vBookingMonthDay,'-')" />
		<xsl:variable name="vBookingDay" select="substring-after($vBookingMonthDay,'-')" />
		<ns0:X12_00501_990>
			<ST>
				<ST01>990</ST01>
				<ST02>0001</ST02>
			</ST>
			<ns0:B1>
				<B101>
					<xsl:value-of select="$vDefaultSCAC"/>
				</B101>
				<B102>
					<xsl:value-of select="Transaction/Header/BOL/text()" />
				</B102>
				<B103>
					<xsl:value-of select="$vBookingYear"/>
					<xsl:value-of select="$vBookingMonth"/>
					<xsl:value-of select="$vBookingDay"/>
				</B103>
				<B104>
					<xsl:value-of select="$vReservationCode"/>
				</B104>
				<xsl:if test="$vReservationCode='D'">
					<xsl:choose>
						<xsl:when test="$vRemarks ='Insufficient lead time'">
							<B106>LNH</B106>
						</xsl:when>
						<xsl:when test="$vRemarks ='No capacity available'">
							<B106>CPU</B106>
						</xsl:when>
						<xsl:when test="$vRemarks ='Other'">
							<B106>OTH</B106>
						</xsl:when>
						<xsl:when test="$vRemarks ='Exceeded bid volume'">
							<B106>WGT</B106>
						</xsl:when>
						<xsl:when test="$vRemarks ='Weather'">
							<B106>WND</B106>
						</xsl:when>
					</xsl:choose>
				</xsl:if>
			</ns0:B1>
			<xsl:if test ="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='CN']/RefValue/text()!=''">
				<ns0:N9>
					<N901>CN</N901>
					<N902>
						<xsl:value-of select="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='CN']/RefValue/text()" />
					</N902>
				</ns0:N9>
			</xsl:if>
			<xsl:if test ="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='CR']/RefValue/text()!=''">
				<ns0:N9>
					<N901>CR</N901>
					<N902>
						<xsl:value-of select="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='CR']/RefValue/text()" />
					</N902>
				</ns0:N9>
			</xsl:if>
		</ns0:X12_00501_990>
	</xsl:template>

</xsl:stylesheet>