<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00401.EDIOB210V2.0" xmlns:s0="http://Echo.BSSR.Internal.Canonical.InvoiceV2" xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp" exclude-result-prefixes="msxsl var s0 userCSharp" version="1.0">
	<xsl:variable name="vLowercaseChars_CONST" select="'abcdefghijklmnopqrstuvwxyz'"/>
	<xsl:variable name="vUppercaseChars_CONST" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'"/>
	<xsl:output omit-xml-declaration="yes" method="xml" version="1.0"/>
	<xsl:template match="/">
		<xsl:apply-templates select="/s0:Invoice"/>
	</xsl:template>
	<xsl:template match="/s0:Invoice">
		<ns0:X12_00401_210>
			<ST>
				<ST01>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetIdentifierCode"/>
				</ST01>
				<ST02>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber"/>
				</ST02>
				<xsl:if test="/s0:Invoice/@CustomerId = '106194' or /s0:Invoice/@CustomerId = '205560' or /s0:Invoice/@CustomerId = '152832'">
					<ST03>CASS157200</ST03>
				</xsl:if>
				
			</ST>
			<xsl:variable name="DRRef" select="Header/ReferenceList/ReferenceInformation[@EDICode = 'DR']/@ReferenceInformation"/>
			<xsl:variable name="bmRef" select="Header/ReferenceList/ReferenceInformation[@EDICode = 'BM']/@ReferenceInformation"/>
			<xsl:variable name="addrSH" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH'][1]/AddressInformation/@AddressInformationLine1"/>
			<xsl:variable name="citySH" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH'][1]/GeographicLocation/@CityName"/>
			<xsl:variable name="zipSH" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH'][1]/GeographicLocation/@PostalCode"/>
			<xsl:variable name="addrCN" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN'][1]/AddressInformation/@AddressInformationLine1"/>
			<xsl:variable name="cityCN" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN'][1]/GeographicLocation/@CityName"/>
			<xsl:variable name="zipCN" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN'][1]/GeographicLocation/@PostalCode"/>
			<xsl:variable name="isOutbound" select="userCSharp:GetLocationCode($addrSH, $citySH)"/>
			<xsl:variable name="isInbound" select="userCSharp:GetLocationCode($addrCN, $cityCN)"/>
			<xsl:variable name="sonocobm1" select="Header/ReferenceList/ReferenceInformation[string-length(@ReferenceInformation) = 8]/@ReferenceInformation"/>
			<xsl:variable name="sonocobm2" select="Header/ReferenceList/ReferenceInformation[string-length(@ReferenceInformation) = 9 and substring(@ReferenceInformation,1,1) = '1']/@ReferenceInformation"/>
			<xsl:variable name="serviceLevel" select="substring(Header/ReferenceList/ReferenceInformation[@EDICode = 'SC']/@ReferenceInformation, 1,2)"/>
			<xsl:variable name="NumberOfN7" select="count (Header/EquipmentList/Equipment[@EquipmentNumber != ''])"/>
			<ns0:B3>
				<!-- Segment not mapped by default
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@ShipmentQualifier != '' ">      
					<B301><xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentQualifier" /></B301>
				</xsl:if>
        -->
				<B302>
					<xsl:call-template name="CleanAlphaField">
						<xsl:with-param name="inputText" select="substring-before(Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber, '-')"/>
						<xsl:with-param name="maxLength" select="22"/>
					</xsl:call-template>
				</B302>
				<B303>
					<xsl:call-template name="CleanAlphaField">
						<xsl:with-param name="inputText" select="Header/BeginningSegmentForCarriersInvoice/@ShipmentIdentificationNumber"/>
						<xsl:with-param name="maxLength" select="30"/>
					</xsl:call-template>
				</B303>
				<B304>
					<xsl:choose>
						<xsl:when test="$isInbound != 'Not Found'">CC</xsl:when>
						<xsl:when test="$isOutbound != 'Not Found'">PP</xsl:when>
						<xsl:otherwise>
							<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentMethodOfPayment"/>
						</xsl:otherwise>
					</xsl:choose>
				</B304>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@WeightUnitCode != '' ">
					<B305>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@WeightUnitCode"/>
					</B305>
				</xsl:if>
				<xsl:variable name="InvoiceDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='InvoiceDate']"/>
				<xsl:variable name="DeliveryDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='DeliveryDate']"/>
				<xsl:variable name="BillingDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='BillingDate']"/>
				<xsl:variable name="PickupDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='PickupDate']"/>
				<xsl:if test="$InvoiceDate != '' ">
					<B306>
						<xsl:value-of select="concat(substring($InvoiceDate, 1, 4), substring($InvoiceDate, 6, 2), substring($InvoiceDate, 9, 2))"/>
					</B306>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@NetAmountDue != '' ">
					<B307>
						<xsl:value-of select="translate(Header/BeginningSegmentForCarriersInvoice/@NetAmountDue,'.','')"/>
					</B307>
				</xsl:if>
				<xsl:choose>
					<xsl:when test="substring-after(Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber, '-') > 1">
						<B308>BD</B308>
					</xsl:when>
					<xsl:when test="not(//LineItem/RateAndCharges/@SpecialChargeOrAllowanceCode = 'LHS')">
						<B308>AD</B308>
					</xsl:when>
				</xsl:choose>
				<xsl:if test="$DeliveryDate != '' ">
					<B309>
						<xsl:value-of select="concat(substring($DeliveryDate, 1, 4), substring($DeliveryDate, 6, 2), substring($DeliveryDate, 9, 2))"/>
					</B309>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@DateTimeQualifier != '' ">
					<B310>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@DateTimeQualifier"/>
					</B310>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@StandardCarrierAlphaCode != '' ">
					<B311>ECHS</B311>
				</xsl:if>
				<xsl:if test="$PickupDate != '' ">
					<B312>
						<xsl:value-of select="concat(substring($PickupDate, 1, 4), substring($PickupDate, 6, 2), substring($PickupDate, 9, 2))"/>
					</B312>
				</xsl:if>
				<!-- 
  Not mapped by default
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@TariffServiceCode != '' ">
					<B313>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@TariffServiceCode" />
					</B313>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@TransportationTermsCode != '' ">
					<B314>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@TransportationTermsCode" />
					</B314>
				</xsl:if>
        
-->
			</ns0:B3>
			<!--
 Not mapped by default
      <ns0:C2>
        <C201>E</C201>
      </ns0:C2>
-->
			<ns0:C3>
				<C301>
					<xsl:value-of select="Header/Currency/@BillingCurrencyCode"/>
				</C301>
			</ns0:C3>
			<xsl:for-each select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='ReferenceList']/*[local-name()='ReferenceInformation'][@ReferenceInformation != '']">
				<xsl:if test="(@EDICode = 'CN' or @EDICode = 'PI' or @EDICode = 'BM' or @EDICode = 'PO' or @EDICode = 'OQ' or @EDICode = 'ZZ' or @EDICode = 'AW' or @EDICode = 'MB' or @EDICode = 'Q1' or @EDICode='EQ') ">
					<ns0:N9>
						<N901>
							<xsl:value-of select="@EDICode"/>
						</N901>
						<N902>
							<xsl:call-template name="CleanAlphaField">
								<xsl:with-param name="inputText" select="@ReferenceInformation"/>
								<xsl:with-param name="maxLength" select="30"/>
							</xsl:call-template>
						</N902>
					</ns0:N9>
				</xsl:if>
			</xsl:for-each>
			<!--<ns0:N9>
        <N901>IO</N901>
          <N902>
            <xsl:value-of select="$IO"/>
          </N902>
      </ns0:N9>-->
			<xsl:variable name="InvoiceDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='InvoiceDate']"/>
			<xsl:variable name="currentDate" select="userCSharp:dateReturn()"/>
			<!--  Not mapped by default -->
			<xsl:variable name="DeliveryDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='DeliveryDate']"/>
			<xsl:variable name="PickupDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='PickupDate']"/>
			<ns0:G62>
				<G6201>86</G6201>
				<G6202>
					<xsl:value-of select="concat(substring($PickupDate, 1, 4), substring($PickupDate, 6, 2), substring($PickupDate, 9, 2))"/>
				</G6202>
			</ns0:G62>
			<ns0:G62>
				<G6201>35</G6201>
				<G6202>
					<xsl:value-of select="concat(substring($DeliveryDate, 1, 4), substring($DeliveryDate, 6, 2), substring($DeliveryDate, 9, 2))"/>
				</G6202>
			</ns0:G62>
			<ns0:R3>
				<R301>ECHS</R301>
				<R302>B</R302>
				<R304>J</R304>
				<R310>G2</R310>
			</ns0:R3>
			<!--			<R304>M</R304>
				<R306>
					<xsl:value-of select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@InvoiceNumber" />
				</R306>
				<R310>G2</R310>
			
      
			<ns0:K1>
				<xsl:variable name="BMRefInfo" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='ReferenceList']/*[local-name()='ReferenceInformation'][@EDICode='BM']" />
				<K101>
					<xsl:choose>
						<xsl:when test="$BMRefInfo &gt; ' ' ">
							<xsl:value-of select="$BMRefInfo" /> 
						</xsl:when>
						<xsl:otherwise>
							<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentIdentificationNumber" />
						</xsl:otherwise> 
					</xsl:choose> 
				</K101>
			</ns0:K1>
-->
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='BT']">
				<ns0:N1Loop1>
					<ns0:N1>
						<N101>
							<xsl:value-of select="Name/@EntityIdentifierCode"/>
						</N101>
						<N102>
							<xsl:call-template name="CleanAlphaField">
								<xsl:with-param name="inputText" select="Name/@Name"/>
								<xsl:with-param name="maxLength" select="60"/>
							</xsl:call-template>
						</N102>
					</ns0:N1>
					<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
						<ns0:N3>
							<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
								<N301>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N301>
							</xsl:if>
							<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
								<N302>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N302>
							</xsl:if>
						</ns0:N3>
					</xsl:if>
					<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
						<ns0:N4>
							<xsl:if test="GeographicLocation/@CityName != ''">
								<N401>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@CityName"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N401>
							</xsl:if>
							<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
								<N402>
									<xsl:value-of select="GeographicLocation/@StateOrProvinceCode"/>
								</N402>
							</xsl:if>
							<xsl:if test="GeographicLocation/@PostalCode != ''">
								<N403>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N403>
							</xsl:if>
							<xsl:if test="GeographicLocation/@CountryCode != ''">
								<N404>
									<xsl:choose>
										<xsl:when test="GeographicLocation/@CountryCode = 'US'">USA</xsl:when>
										<xsl:otherwise>
											<xsl:value-of select="GeographicLocation/@CountryCode"/>
										</xsl:otherwise>
									</xsl:choose>
								</N404>
							</xsl:if>
						</ns0:N4>
					</xsl:if>
				</ns0:N1Loop1>
			</xsl:for-each>
			<!--
Template not used for a code below due to expected changes to mappings from one code to another
-->
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']">
				<!-- below if statement exists to prevent multiple shipper stops from being added if customer is Vyaire (172960). Only first shipper is added, the rest will be S5 segments-->
				<xsl:if test="position() = 1">
					<ns0:N1Loop1>
						<ns0:N1>
							<N101>
								<xsl:value-of select="Name/@EntityIdentifierCode"/>
							</N101>
							<N102>
								<xsl:call-template name="CleanAlphaField">
									<xsl:with-param name="inputText" select="Name/@Name"/>
									<xsl:with-param name="maxLength" select="60"/>
								</xsl:call-template>
							</N102>
							<xsl:if test="$isOutbound !='Not Found'">
								<N103>93</N103>
								<N104>
									<xsl:value-of select="$isOutbound"/>
								</N104>
							</xsl:if>
						</ns0:N1>
						<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
							<ns0:N3>
								<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
									<N301>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N301>
								</xsl:if>
								<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
									<N302>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N302>
								</xsl:if>
							</ns0:N3>
						</xsl:if>
						<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
							<ns0:N4>
								<xsl:if test="GeographicLocation/@CityName != ''">
									<N401>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="GeographicLocation/@CityName"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N401>
								</xsl:if>
								<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
									<N402>
										<xsl:value-of select="GeographicLocation/@StateOrProvinceCode"/>
									</N402>
								</xsl:if>
								<xsl:if test="GeographicLocation/@PostalCode != ''">
									<N403>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N403>
								</xsl:if>
								<xsl:if test="GeographicLocation/@CountryCode != ''">
									<N404>
										<xsl:choose>
											<xsl:when test="GeographicLocation/@CountryCode = 'US'">USA</xsl:when>
											<xsl:otherwise>
												<xsl:value-of select="GeographicLocation/@CountryCode"/>
											</xsl:otherwise>
										</xsl:choose>
									</N404>
								</xsl:if>
							</ns0:N4>
						</xsl:if>
					</ns0:N1Loop1>
				</xsl:if>
			</xsl:for-each>
			<!--
Template not used for a code below due to expected changes to mappings from one code to another
-->
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']">
				<!-- below if statement exists to prevent multiple consignee stops from being added if customer is Vyaire. Only last consignee is added, the rest will be S5 segments-->
				<xsl:if test="position() = last()">
					<ns0:N1Loop1>
						<ns0:N1>
							<N101>
								<xsl:value-of select="Name/@EntityIdentifierCode"/>
							</N101>
							<N102>
								<xsl:call-template name="CleanAlphaField">
									<xsl:with-param name="inputText" select="Name/@Name"/>
									<xsl:with-param name="maxLength" select="60"/>
								</xsl:call-template>
							</N102>
							<xsl:if test="$isInbound !='Not Found'">
								<N103>93</N103>
								<N104>
									<xsl:value-of select="$isInbound"/>
								</N104>
							</xsl:if>
						</ns0:N1>
						<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
							<ns0:N3>
								<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
									<N301>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N301>
								</xsl:if>
								<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
									<N302>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N302>
								</xsl:if>
							</ns0:N3>
						</xsl:if>
						<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
							<ns0:N4>
								<xsl:if test="GeographicLocation/@CityName != ''">
									<N401>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="GeographicLocation/@CityName"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N401>
								</xsl:if>
								<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
									<N402>
										<xsl:value-of select="GeographicLocation/@StateOrProvinceCode"/>
									</N402>
								</xsl:if>
								<xsl:if test="GeographicLocation/@PostalCode != ''">
									<N403>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N403>
								</xsl:if>
								<xsl:if test="GeographicLocation/@CountryCode != ''">
									<N404>
										<xsl:if test="GeographicLocation/@CountryCode = 'US'">USA</xsl:if>
										<xsl:if test="GeographicLocation/@CountryCode != 'US'">
											<xsl:value-of select="GeographicLocation/@CountryCode"/>
										</xsl:if>
									</N404>
								</xsl:if>
							</ns0:N4>
						</xsl:if>
					</ns0:N1Loop1>
				</xsl:if>
			</xsl:for-each>
			<xsl:choose>
				<xsl:when test="$NumberOfN7 > 0">
					<ns0:N7Loop1>
						<xsl:for-each select="Header/EquipmentList/Equipment">
							<ns0:N7>
								<xsl:if test="@EquipmentNumber != ''">
									<N702>
										<xsl:value-of select="@EquipmentNumber"/>
									</N702>
								</xsl:if>
								<xsl:choose>
									<xsl:when test="//ReferenceList/ReferenceInformation[@EDICode='EQ']/@ReferenceInformation!=''">
										<N711>
											<xsl:value-of select="substring(//ReferenceList/ReferenceInformation[@EDICode='EQ']/@ReferenceInformation,1,2)"/>
										</N711>
									</xsl:when>
									<xsl:otherwise>
										<N711>TV</N711>
									</xsl:otherwise>
								</xsl:choose>
								<xsl:if test="@EquipmentDescriptionCode != ''">
									<N715>
										<xsl:value-of select="@EquipmentLength"/>
									</N715>
								</xsl:if>
							</ns0:N7>
						</xsl:for-each>
					</ns0:N7Loop1>
				</xsl:when>
				<xsl:otherwise>
					<ns0:N7Loop1>
						<ns0:N7>
							<N702>1234</N702>
							<N711>TL</N711>
							<xsl:if test="@EquipmentDescriptionCode != ''">
								<N715>
									<xsl:value-of select="@EquipmentLength"/>
								</N715>
							</xsl:if>
						</ns0:N7>
					</ns0:N7Loop1>
				</xsl:otherwise>
			</xsl:choose>
			<!-- stopoff code for Vyaire. Card 101639>-->
			<!--<xsl:if test="/s0:Invoice/@CustomerId = '172960' or /s0:Invoice/@CustomerId != '121224'">
				<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode!='BT']">
					-->
			<!-- shipper stopoffs for Vyaire. Loop through all the SHs except the first one because it's already got an entry in header-->
			<!--
					<xsl:if test="position() != 1 and Name/@EntityIdentifierCode = 'SH'">
						<ns0:S5Loop1>
							<ns0:S5>
								<S501>
									<xsl:value-of select="position()"/>
								</S501>
								<S502>PL</S502>
							</ns0:S5>
							<ns0:N1Loop2>
								<ns0:N1_2>
									<N101>PW</N101>
									<N102>
										<xsl:value-of select="Name/@Name"/>
									</N102>
								</ns0:N1_2>
								<ns0:N4_2>
									<xsl:if test="GeographicLocation/@CityName != '' ">
										<N401>
											<xsl:value-of select="GeographicLocation/@CityName"/>
										</N401>
									</xsl:if>
									<xsl:if test="GeographicLocation/@StateOrProvinceCode != '' ">
										<N402>
											<xsl:value-of select="GeographicLocation/@StateOrProvinceCode"/>
										</N402>
									</xsl:if>
									<xsl:if test="GeographicLocation/@PostalCode != '' ">
										<N403>
											<xsl:value-of select="GeographicLocation/@PostalCode"/>
										</N403>
									</xsl:if>
									<xsl:if test="GeographicLocation/@CountryCode != '' ">
										<N404>
											<xsl:value-of select="GeographicLocation/@CountryCode"/>
										</N404>
									</xsl:if>
								</ns0:N4_2>
							</ns0:N1Loop2>
							<xsl:if test="$NumberOfN7 > 0">
								<ns0:N7Loop1>
									<xsl:for-each select="../../EquipmentList/Equipment">
										<ns0:N7>
											<xsl:if test="@EquipmentNumber != ''">
												<N702>
													<xsl:value-of select="@EquipmentNumber"/>
												</N702>
											</xsl:if>
											<xsl:if test="@EquipmentDescriptionCode != ''">
												<N711>
													<xsl:value-of select="@EquipmentDescriptionCode"/>
												</N711>
											</xsl:if>
											<xsl:if test="@EquipmentDescriptionCode != ''">
											</xsl:if>
										</ns0:N7>
									</xsl:for-each>
								</ns0:N7Loop1>
							</xsl:if>
						</ns0:S5Loop1>
					</xsl:if>
					-->
			<!-- consignee stopoffs for Vyaire. Loop through all the CNs except the last one because it's already got an entry in header-->
			<!--
					<xsl:if test="position() != last() and Name/@EntityIdentifierCode = 'CN'">
						<ns0:S5Loop1>
							<ns0:S5>
								<S501>
									<xsl:value-of select="position()"/>
								</S501>
								<S502>PU</S502>
							</ns0:S5>
							<ns0:N1Loop2>
								<ns0:N1_2>
									<N101>45</N101>
									<N102>
										<xsl:value-of select="Name/@Name"/>
									</N102>
								</ns0:N1_2>
								<ns0:N4_2>
									<xsl:if test="GeographicLocation/@CityName != '' ">
										<N401>
											<xsl:value-of select="GeographicLocation/@CityName"/>
										</N401>
									</xsl:if>
									<xsl:if test="GeographicLocation/@StateOrProvinceCode != '' ">
										<N402>
											<xsl:value-of select="GeographicLocation/@StateOrProvinceCode"/>
										</N402>
									</xsl:if>
									<xsl:if test="GeographicLocation/@PostalCode != '' ">
										<N403>
											<xsl:value-of select="GeographicLocation/@PostalCode"/>
										</N403>
									</xsl:if>
									<xsl:if test="GeographicLocation/@CountryCode != '' ">
										<N404>
											<xsl:value-of select="GeographicLocation/@CountryCode"/>
										</N404>
									</xsl:if>
								</ns0:N4_2>
							</ns0:N1Loop2>
							<xsl:if test="$NumberOfN7 > 0">
								<ns0:N7Loop1>
									<xsl:for-each select="../../EquipmentList/Equipment">
										<ns0:N7>
											<xsl:if test="@EquipmentNumber != ''">
												<N702>
													<xsl:value-of select="@EquipmentNumber"/>
												</N702>
											</xsl:if>
											<xsl:if test="@EquipmentDescriptionCode != ''">
												<N711>
													<xsl:value-of select="@EquipmentDescriptionCode"/>
												</N711>
											</xsl:if>
											<xsl:if test="@EquipmentDescriptionCode != ''">
											</xsl:if>
										</ns0:N7>
									</xsl:for-each>
								</ns0:N7Loop1>
							</xsl:if>
						</ns0:S5Loop1>
					</xsl:if>
				</xsl:for-each>
			</xsl:if>-->
			<!-- Original, non-Vyaire stopoff code. Not sure if it works, honestly-->
			<!--
 Create S5Loop1 only for last recored where party Identifier Codes is 'CN', 
-->
			<!--
<xsl:variable name="NumberOfParties" select="count (Header/PartyList/Party)"/>
-->
			<!--
<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']">
      
-->
			<!-- <xsl:for-each select="Header/PartyList/Party"> -->
			<!--

        <xsl:if test="position() &lt; $NumberOfParties">
				<ns0:S5Loop1>
						<ns0:S5>
							<S501>
								<xsl:value-of select="position()" />
							</S501>
							<S502>PU</S502>
              <xsl:if test="../../../Summary/TotalWeightAndCharges/@Weight">
              <S503>
                <xsl:value-of select="../../../Summary/TotalWeightAndCharges/@Weight" />
              </S503>
              <S504>L</S504>
              </xsl:if>
						</ns0:S5>
           <xsl:for-each select="../../ReferenceList/ReferenceInformation">
            <xsl:if test="(@ReferenceInformationQualifier != '') or (@ReferenceInformation != '') ">
              <ns0:N9_3>
                <xsl:if test="@EDICode != '' ">
                  <N901>
                    <xsl:value-of select="@EDICode" />
                  </N901>
                </xsl:if>
                <xsl:if test="@ReferenceInformation != '' ">
                  <N902>
                    <xsl:call-template name="CleanAlphaField" >
                      <xsl:with-param name="inputText" select="@ReferenceInformation" />
                      <xsl:with-param name="maxLength" select="30" />
                    </xsl:call-template>
                  </N902>
                </xsl:if>
              </ns0:N9_3>
            </xsl:if>
          </xsl:for-each>
				</ns0:S5Loop1>
        </xsl:if>
			</xsl:for-each>
-->
			<!--
<xsl:variable name="CountofSH" select="count(PartyList/Party[Name/@EntityIdentifierCode='SH'][1]) - 1" />


			<xsl:for-each select="PartyList/Party[Name/@EntityIdentifierCode='CN']">
				<xsl:variable name="PositionOfCN" select="position()" />
				<ns0:S5Loop1>
					<xsl:if test="$PositionOfCN != last()">
						<ns0:S5>
							<S501>
								<xsl:value-of select="$CountofSH + position()" />
							</S501>
							<S502>PU</S502>
						</ns0:S5>
						<ns0:N1Loop2>
							<ns0:N1_2>
								<N101>
									<xsl:value-of select="Name/@EntityIdentifierCode" />
								</N101>
								<N102>
									<xsl:value-of select="Name/@Name" />
								</N102>
							</ns0:N1_2>
							<ns0:N3_2>
								<N301>
									<xsl:value-of select="AddressInformation/@AddressInformationLine1" />
								</N301>
							</ns0:N3_2>
							<ns0:N4_2>
								<xsl:if test="GeographicLocation/@CityName != '' ">
									<N401>
										<xsl:value-of select="GeographicLocation/@CityName" />
									</N401>
								</xsl:if>
								<xsl:if test="GeographicLocation/@StateOrProvinceCode != '' ">
									<N402>
										<xsl:value-of select="GeographicLocation/@StateOrProvinceCode" />
									</N402>
								</xsl:if>
								<xsl:if test="GeographicLocation/@PostalCode != '' ">
									<N403>
										<xsl:value-of select="GeographicLocation/@PostalCode" />
									</N403>
								</xsl:if>
								<xsl:if test="GeographicLocation/@CountryCode != '' ">
									<N404>
										<xsl:value-of select="GeographicLocation/@CountryCode" />
									</N404>
								</xsl:if>
							</ns0:N4_2>
						</ns0:N1Loop2>
					</xsl:if>
				</ns0:S5Loop1>
			</xsl:for-each>
-->
			<xsl:for-each select="Detail/LineItemList/LineItem">
				<xsl:if test="RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
					<ns0:LXLoop1>
						<ns0:LX>
							<LX01>
								<xsl:value-of select="position()"/>
							</LX01>
						</ns0:LX>
						<!--<ns0:L5>
							<L501>
								<xsl:value-of select="position()"/>
							</L501>
							<xsl:if test="DescriptionMarksAndNumbers/@LadingDescription != ''">
								<L502>
									<xsl:choose>
										<xsl:when test="DescriptionMarksAndNumbers/@LadingDescription ='Drop Trailer'">
											<xsl:choose>
												<xsl:when test="/s0:Invoice/@CustomerId = '61732'">STORAGE</xsl:when>
												<xsl:otherwise>
													<xsl:call-template name="CleanAlphaField">
														<xsl:with-param name="inputText" select="DescriptionMarksAndNumbers/@LadingDescription"/>
														<xsl:with-param name="maxLength" select="50"/>
													</xsl:call-template>
												</xsl:otherwise>
											</xsl:choose>
										</xsl:when>
										<xsl:when test="DescriptionMarksAndNumbers/@LadingDescription ='Spotting of Trailer'">
											<xsl:choose>
												<xsl:when test="/s0:Invoice/@CustomerId = '61732'">TRAIL SPOTTING/SHUNTING</xsl:when>
												<xsl:otherwise>
													<xsl:call-template name="CleanAlphaField">
														<xsl:with-param name="inputText" select="DescriptionMarksAndNumbers/@LadingDescription"/>
														<xsl:with-param name="maxLength" select="50"/>
													</xsl:call-template>
												</xsl:otherwise>
											</xsl:choose>
										</xsl:when>
										<xsl:otherwise>
											<xsl:call-template name="CleanAlphaField">
												<xsl:with-param name="inputText" select="DescriptionMarksAndNumbers/@LadingDescription"/>
												<xsl:with-param name="maxLength" select="50"/>
											</xsl:call-template>
										</xsl:otherwise>
									</xsl:choose>
								</L502>
							</xsl:if>
						</ns0:L5>-->
						<ns0:L0>
							<L001>
								<xsl:value-of select="position()"/>
							</L001>
							<L002>
								<xsl:value-of select="LineItemQuantityAndWeight/@BilledRatedAsQuantity"/>
							</L002>
							<L003>
								<xsl:value-of select="LineItemQuantityAndWeight/@BilledRatedAsQualifier"/>
							</L003>
							<xsl:choose>
								<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'LHS'">
									<L004>
										<xsl:value-of select="//Summary/TotalWeightAndCharges/@Weight"/>
									</L004>
									<L005>N</L005>
									<L008>
										<xsl:value-of select="//Summary/TotalWeightAndCharges//@LadingQuantity"/>
									</L008>
									<L009>PLT</L009>
									<L011>L</L011>
								</xsl:when>
								<xsl:otherwise>
									<xsl:if test="LineItemQuantityAndWeight/@Weight!=''">
										<L004>
											<xsl:value-of select="LineItemQuantityAndWeight/@Weight"/>
										</L004>
									</xsl:if>
									<xsl:if test="LineItemQuantityAndWeight/@WeightUnitCode!=''">
										<L005>
											<xsl:value-of select="LineItemQuantityAndWeight/@WeightUnitCode"/>
										</L005>
									</xsl:if>
									<xsl:if test="LineItemQuantityAndWeight/@LadingQuantity!=''">
										<L008>
											<xsl:value-of select="LineItemQuantityAndWeight/@LadingQuantity"/>
										</L008>
									</xsl:if>
									<xsl:if test="LineItemQuantityAndWeight/@LadingQuantityPackagingFormCode!=''">
										<L009>
											<xsl:value-of select="LineItemQuantityAndWeight/@LadingQuantityPackagingFormCode"/>
										</L009>
									</xsl:if>
									<xsl:if test="LineItemQuantityAndWeight/@WeightUnitCode!=''">
										<L011>
											<xsl:value-of select="LineItemQuantityAndWeight/@WeightUnitCode"/>
										</L011>
									</xsl:if>
								</xsl:otherwise>
							</xsl:choose>
						</ns0:L0>
						<xsl:if test="RateAndCharges/@FreightRate != '' or RateAndCharges/@Charge != '' or RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
							<ns0:L1>
								<L101>
									<xsl:value-of select="position()"/>
								</L101>
								<xsl:if test="RateAndCharges/@FreightRate != ''">
									<L102>
										<!--
<xsl:value-of select="format-number(RateAndCharges/@FreightRate, '#')" />
-->
										<xsl:value-of select="RateAndCharges/@FreightRate"/>
									</L102>
								</xsl:if>
								<xsl:if test="RateAndCharges/@RateValueQualifier != ''">
									<L103>
										<xsl:value-of select="RateAndCharges/@RateValueQualifier"/>
									</L103>
								</xsl:if>
								<xsl:if test="RateAndCharges/@Charge != ''">
									<L104>
										<xsl:value-of select="translate(RateAndCharges/@Charge, '.', '')"/>
									</L104>
								</xsl:if>
								<!-- L107 not mapped by default -->
								<!--

            <xsl:if test="RateAndCharges/@RateCombinationPointCode != ''">
						  <L107>
							  <xsl:value-of select="RateAndCharges/@RateCombinationPointCode" />
						  </L107>
            </xsl:if>

-->
								<xsl:if test="RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
									<L108>
										<xsl:choose>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='LHS'">BAS</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='455'">445</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='405'">FSC</xsl:when>
											<xsl:otherwise>
												<xsl:value-of select="RateAndCharges/@SpecialChargeOrAllowanceCode"/>
											</xsl:otherwise>
										</xsl:choose>
									</L108>
								</xsl:if>
								<!--
<xsl:if test="RateAndCharges/@SpecialChargeDescription != ''">
              <L112>
                <xsl:call-template name="CleanAlphaField" >
                  <xsl:with-param name="inputText" select="RateAndCharges/@SpecialChargeDescription" />
                  <xsl:with-param name="maxLength" select="25" />
                </xsl:call-template>
              </L112>
            </xsl:if>
-->
							</ns0:L1>
							<xsl:if test="DescriptionMarksAndNumbers/@LadingDescription = 'Line Haul'">
								<xsl:if test="/s0:Invoice/Header/ReferenceList/ReferenceInformation[@EDICode = 'TM']/@ReferenceInformation = 'LTL' or //Detail/LineItemList/LineItem/DescriptionMarksAndNumbers[@CommodityCode2 != '']/@CommodityCode2 !=''">
									<ns0:L7>
										<L707>
											<xsl:value-of select="//Detail/LineItemList/LineItem/DescriptionMarksAndNumbers[@CommodityCode2 != '']/@CommodityCode2"/>
										</L707>
									</ns0:L7>
								</xsl:if>
							</xsl:if>
						</xsl:if>
					</ns0:LXLoop1>
				</xsl:if>
			</xsl:for-each>
			<xsl:for-each select="Summary/TotalWeightAndCharges">
				<ns0:L3>
					<xsl:if test="@Weight">
						<L301>
							<xsl:value-of select="@Weight"/>
						</L301>
					</xsl:if>
					<xsl:if test="@WeightQualifier">
						<L302>G</L302>
					</xsl:if>
					<xsl:variable name="TotalCharges" select="@TotalCharges"/>
					<xsl:variable name="TotalChargesLength" select="string-length(@TotalCharges)"/>
					<xsl:if test="$TotalChargesLength > 2">
						<L305>
							<xsl:value-of select="translate(@TotalCharges,',','')"/>
							<!--
<xsl:value-of select="concat(substring($TotalCharges, 1, $TotalChargesLength - 2), '.',  substring($TotalCharges, $TotalChargesLength - 2 , 2))" />
-->
						</L305>
					</xsl:if>
					<xsl:if test="@LadingQuantity">
						<L311>
							<xsl:value-of select="@LadingQuantity"/>
						</L311>
					</xsl:if>
				</ns0:L3>
			</xsl:for-each>
			<SE>
				<SE01>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetIdentifierCode"/>
				</SE01>
				<SE02>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber"/>
				</SE02>
			</SE>
		</ns0:X12_00401_210>
	</xsl:template>
	<msxsl:script language="C#" implements-prefix="userCSharp">
		<![CDATA[
    public string dateReturn()
    {
	    DateTime localDate = DateTime.Now;
	    return localDate.ToString("yyyyMMdd");
    }
    ]]>
	</msxsl:script>
	<!-- Custom Templates -->
	<!--  Created by Neal, not specific to L108 -->
	<xsl:template name="ChangeThisName">
		<xsl:param name="ValueToConvert" select="0"/>
		<xsl:param name="LadingDescriptionParm" select="1"/>
		<xsl:variable name="L108Map">
			<map>
				<entry key="LHS">400</entry>
				<entry key="LYC">LAY</entry>
				<entry key="SRG">STR</entry>
				<entry key="TDT">DET</entry>
			</map>
		</xsl:variable>
		<xsl:variable name="ValueConverted" select="msxsl:node-set($L108Map)/map/entry[@key=$ValueToConvert]"/>
		<xsl:choose>
			<xsl:when test="$ValueConverted">
				<xsl:value-of select="$ValueConverted"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:choose>
					<xsl:when test="$LadingDescriptionParm = 'Lumper'">
						<xsl:text>LAB</xsl:text>
					</xsl:when>
					<xsl:when test="$LadingDescriptionParm = 'Unloading'">
						<xsl:text>UNL</xsl:text>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="$ValueToConvert"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<!--  Created by Neal, not specific to L108 -->
	<!-- CleanAlphaField start  -->
	<xsl:template name="CleanAlphaField">
		<xsl:param name="inputText"/>
		<xsl:param name="maxLength"/>
		<xsl:variable name="singleQuote" select='"&apos;"'/>
		<xsl:variable name="doubleQuote" select="'&quot;'"/>
		<xsl:variable name="vAllowedSymbolsPart1" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}\?/#'"/>
		<xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
		<xsl:variable name="vCleanedText" select="translate($inputText,translate($inputText, $vAllowedSymbols, ''),'')"/>
		<xsl:value-of select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
	</xsl:template>
	<!-- Clean AlphaField end -->
	<!-- Value mapping template -->
	<xsl:template name="StopTypeMapValue">
		<xsl:param name="ValueToConvert" select="0"/>
		<xsl:variable name="StopTypeMap">
			<map>
				<entry key="Pick">SF</entry>
				<entry key="Drop">CN</entry>
			</map>
		</xsl:variable>
		<xsl:value-of select="msxsl:node-set($StopTypeMap)/map/entry[@key=$ValueToConvert]"/>
	</xsl:template>
	<!-- Value mapping template -->
	<!-- Set default if empty template start -->
	<xsl:template name="SetDefaultIfEmpty">
		<xsl:param name="pNode"/>
		<xsl:param name="pDefaultValue"/>
		<xsl:if test="$pNode">
			<xsl:value-of select="$pNode"/>
		</xsl:if>
		<xsl:if test="not($pNode)">
			<xsl:value-of select="$pDefaultValue"/>
		</xsl:if>
	</xsl:template>
	<msxsl:script language="C#" implements-prefix="userCSharp">
		<msxsl:using namespace="System.Text.RegularExpressions" />
		<msxsl:using namespace="System.Collections.Generic" />
		<![CDATA[
public class LoadAddress
{
	public String LocationCode;
	public String Addr;
	public String City;
	public String ZipCode;

	public LoadAddress (String locationCode, String addr, String city, String zipCode)
	{
		LocationCode = locationCode;
    	Addr = SanitizeInput(addr);
		City = SanitizeInput(city);
		ZipCode = SanitizeInput(zipCode);
	}
	
	// Matches if either address is a match for the account
	public bool isMatch(String addr1, String city1)
	{
		if (SanitizeInput(city1) == City && SanitizeInput(addr1) == Addr)
		{
			return true;
		}
		return false;
	}
	
	private String SanitizeInput(String input)
	{
		return Regex.Replace(input, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
}

	// Used by xslt to get N104 value for BY line
	public String GetLocationCode(String addr1, String city1)
	{
		foreach(LoadAddress lad in LOAD_ADDRESSES)
		{
			if(lad.isMatch(addr1, city1))
			{
				return lad.LocationCode;
			}
		}
		return "Not Found";
	}
	
	
	//Column 2 for Address code is required additionally on some accounts - it is an additional code associated with the address and is returned on the pick/drop. Leave NULL if not in use. 
	public List<LoadAddress> LOAD_ADDRESSES = new List<LoadAddress>()
	{
		// 1st column is LocationCode, 2nd column is Address, 3rd column is City, 4th column is ZipCode,
		
			new LoadAddress("Goodyear3", "1376 TECH CENTER DRIVE", "AKRON", "44316"),
			new LoadAddress("Goodyear4", "1376 TECHWAY DR FLR 4", "AKRON", "44316"),
			new LoadAddress("Goodyear5", "1376 TECHWAY DRIVE", "AKRON", "44316"),
			new LoadAddress("Goodyear6", "1376 TECHWAY DRIVE -  BLDG 72", "AKRON", "44316"),
			new LoadAddress("Goodyear7", "200 INNOVATION WAY", "AKRON", "44316"),
			new LoadAddress("Goodyear9", "BUILDING 61 NORTH D/109B", "AKRON", "44306"),
			new LoadAddress("Goodyear10", "BUILDING 63", "AKRON", "44316"),
			new LoadAddress("Goodyear11", "BUILDING 63 DOC 550A", "AKRON", "44316"),
			new LoadAddress("Goodyear13", "100 NATIONAL DR", "ANNISTON", "36207"),
			new LoadAddress("Goodyear14", "221 MULBERRY ST", "BATH", "18014"),
			new LoadAddress("Goodyear15", "5055 PORT ARTHUR RD", "BEAUMONT", "77705"),
			new LoadAddress("Goodyear17", "1655 LOUIS-MARCHAND", "BELOEIL", "J3G 6S4"),
			new LoadAddress("Goodyear18", "170 VAN KIRK DR.", "BRAMPTON", "L7A 1K9"),
			new LoadAddress("Goodyear19", "265 RUTHERFORD ROAD SOUTH", "BRAMPTON", "L6W 1V9"),
			new LoadAddress("Goodyear20", "205 BROOME ROAD", "BROCKVILLE", "K6V 7N5"),
			new LoadAddress("Goodyear21", "291 NORFOLK SOUTHERN WAY", "BYHALIA", "38611"),
			new LoadAddress("Goodyear22", "3800 WESTWINDS DRIVE N", "CALGARY", "T3J 5H3"),
			new LoadAddress("Goodyear23", "2205 DR. MARTIN LUTHER KING DR", "CLARKSDALE", "38614"),
			new LoadAddress("Goodyear24", "9799 HEARTLAND COURT", "COLUMBUS", "43217"),
			new LoadAddress("Goodyear25", "11106 TREYNORTH DRIVE", "CORNELIUS", "28031"),
			new LoadAddress("Goodyear26", "121 MARTHA ST", "DANVILLE", "24541"),
			new LoadAddress("Goodyear27", "1901 GOODYEAR BOULEVARD", "DANVILLE", "24541"),
			new LoadAddress("Goodyear28", "3095 CORPORATE DRIVE", "DEKALB", "60115"),
			new LoadAddress("Goodyear29", "75756 N HWY 81", "DUNCAN", "73533"),
			new LoadAddress("Goodyear30", "150 SOUTH CONNELL AVENUE", "DYERSBURG", "38024"),
			new LoadAddress("Goodyear31", "800 WISCONSIN STREET", "EAU CLAIRE", "54703"),
			new LoadAddress("Goodyear32", "KM3 5 CARR EL SLTO VIA CAPILLA", "EL SALTO", "45680"),
			new LoadAddress("Goodyear33", "318 BLOUNT ST", "FAYETTEVILLE", "28301"),
			new LoadAddress("Goodyear34", "6650 RAMSEY STREET", "FAYETTEVILLE", "28311"),
			new LoadAddress("Goodyear35", "5410 12TH STREET EAST", "FIFE", "98424"),
			new LoadAddress("Goodyear36", "1325 WESTERN AVE.", "FINDLAY", "45840"),
			new LoadAddress("Goodyear37", "1625 LAKE CASCADES PKWY", "FINDLAY", "45840"),
			new LoadAddress("Goodyear38", "2025 PRODUCTION DRIVE", "FINDLAY", "45840"),
			new LoadAddress("Goodyear39", "6000 FOSTORIA AVE", "FINDLAY", "45840"),
			new LoadAddress("Goodyear40", "701 LIMA AVENUE", "FINDLAY", "45840"),
			new LoadAddress("Goodyear41", "800 WESTERN AVE", "FINDLAY", "45840"),
			new LoadAddress("Goodyear42", "13 OVERMEYER WAY", "FOREST PARK", "30297"),
			new LoadAddress("Goodyear43", "1500 AKRON WAY", "FORNEY", "75126"),
			new LoadAddress("Goodyear44", "4115 LEGION RD", "HOPE MILLS", "28348"),
			new LoadAddress("Goodyear45", "1423 FARRELL ROAD", "HOUSTON", "77073"),
			new LoadAddress("Goodyear47", "1600 WASHINGTON STREET", "INDIANA", "15701"),
			new LoadAddress("Goodyear48", "260 OLD STATE ROUTE 34", "JONESBOROUGH", "37659"),
			new LoadAddress("Goodyear49", "4105 MOHAVE AIRPORT DRIVE", "KINGMAN", "86401"),
			new LoadAddress("Goodyear50", "9400 COMMERCE DR BUILDING B", "KINGMAN", "86401"),
			new LoadAddress("Goodyear51", "101 GLASGOW STREET", "KITCHENER", "N2G 4X8"),
			new LoadAddress("Goodyear53", "1061 INDUSTRIAL BLVD", "LAFAYETTE", "36862"),
			new LoadAddress("Goodyear54", "2322 SOUTH 30TH STREET", "LAFAYETTE", "47909"),
			new LoadAddress("Goodyear55", "1 GOODYEAR BOULEVARD", "LAWTON", "73505"),
			new LoadAddress("Goodyear56", "5201 SOUTHWEST 11TH ST", "LAWTON", "73501"),
			new LoadAddress("Goodyear57", "4644 LOUISVILLE AVE UNIT 1", "LOUISVILLE", "40209"),
			new LoadAddress("Goodyear58", "1 GOODYEAR WAY NW", "MEDICINE HAT", "T1C 1W8"),
			new LoadAddress("Goodyear59", "11057 NW 122TH STREET #13", "MEDLEY", "33178"),
			new LoadAddress("Goodyear60", "4221 PILOT DRIVE", "MEMPHIS", "38118"),
			new LoadAddress("Goodyear61", "14910 MADISON ROAD", "MIDDLEFIELD", "44062"),
			new LoadAddress("Goodyear62", "6611 NORTHWEST DRIVE", "MISSISSAUGA", "L4V 1L1"),
			new LoadAddress("Goodyear63", "113 ARENDELL ST", "MOREHEAD CITY", "28557"),
			new LoadAddress("Goodyear64", "388 GOODYEAR ROAD", "NAPANEE", "K7R 3L2"),
			new LoadAddress("Goodyear65", "490 CAMPUS DRIVE", "NEWNAN", "30263"),
			new LoadAddress("Goodyear67", "100 BOOTH ROAD", "NORTH BAY", "P1B 0B3"),
			new LoadAddress("Goodyear68", "100 BOOTH ROAD", "NORTH BAY", "P1B 0B3"),
			new LoadAddress("Goodyear70", "7215 SW TOPEKA BLVD", "PAULINE", "66619"),
			new LoadAddress("Goodyear71", "200 EXPANSION BLVD", "PORT WENTWORTH", "31407"),
			new LoadAddress("Goodyear72", "9363 LUCAS RANCH ROAD", "RANCHO CUCAMONGA", "91730"),
			new LoadAddress("Goodyear73", "ROUTE 68 SOUTH", "RAVENSWOOD", "26164"),
			new LoadAddress("Goodyear74", "126 SENECA DR", "RIPLEY", "25271"),
			new LoadAddress("Goodyear75", "2600 BOUL MONSEIGNEUR LANGLOIS", "SALABERRY-DE-VALLEYFI", "J6S 5G6"),
			new LoadAddress("Goodyear76", "11570 NORTH US HWY 277", "SAN ANGELO", "76905"),
			new LoadAddress("Goodyear77", "1089 EAST MILL", "SAN BERNARDINO", "92408"),
			new LoadAddress("Goodyear78", "AVENIDA PRINCIPAL 1100", "SAN LUIS POTOSI", "78395"),
			new LoadAddress("Goodyear80", "500 AIRBOSS PARKWAY", "SCOTLAND NECK", "27874"),
			new LoadAddress("Goodyear81", "31 CURTIS DR.", "SHELBY", "44875"),
			new LoadAddress("Goodyear82", "1 WINGFOOT WAY", "SOCIAL CIRCLE", "30025"),
			new LoadAddress("Goodyear83", "108 BUSINESS PARK DRIVE", "STATESVILLE", "28677"),
			new LoadAddress("Goodyear84", "100 BUSINESS CENTER DRIVE", "STOCKBRIDGE", "30281"),
			new LoadAddress("Goodyear85", "4651 PROSPER DRIVE", "STOW", "44224"),
			new LoadAddress("Goodyear86", "4651 PROSPER DR", "STOW", "44224"),
			new LoadAddress("Goodyear87", "3012 142ND AVENUE EAST", "SUMNER", "98390"),
			new LoadAddress("Goodyear88", "11470 131ST STREET", "SURREY", "V3R 4S7"),
			new LoadAddress("Goodyear89", "101 STOFFEL DR", "TALLAPOOSA", "30176"),
			new LoadAddress("Goodyear90", "3500 EAST WASHINGTON ROAD", "TEXARKANA", "71854"),
			new LoadAddress("Goodyear91", "3535 GENOA RD.", "TEXARKANA", "71854"),
			new LoadAddress("Goodyear92", "423 RICHMOND ROAD", "TEXARKANA", "75503"),
			new LoadAddress("Goodyear93", "2000 NW HIGHWAY 24", "TOPEKA", "66618"),
			new LoadAddress("Goodyear94", "2700 NW BUTTON ROAD", "TOPEKA", "66618"),
			new LoadAddress("Goodyear95", "450 KIPLING AVENUE", "TORONTO", "M8Z 5E1"),
			new LoadAddress("Goodyear98", "139 S 122ND EAST AVENUE", "TULSA", "74108"),
			new LoadAddress("Goodyear99", "167 ENTERPRISE DR", "TUPELO", "38804"),
			new LoadAddress("Goodyear100", "1804 SOUTH GREEN STREET", "TUPELO", "38804"),
			new LoadAddress("Goodyear101", "229 ENTERPRISE DR.", "TUPELO", "38804"),
			new LoadAddress("Goodyear102", "3260 GOODYEAR BLVD", "UNION CITY", "38261"),
			new LoadAddress("Goodyear103", "11198 WILL WALKER ROAD", "VANCE", "35490"),
			new LoadAddress("Goodyear104", "17477 NISQUALLI ROAD", "VICTORVILLE", "92395"),
			new LoadAddress("Goodyear105", "19100 GATEWAY DR.", "VICTORVILLE", "92394"),
			new LoadAddress("Goodyear106", "19100 GATEWAY DR.", "VICTORVILLE", "92394"),
			new LoadAddress("Goodyear107", "94-360 UKEE STREET", "WAIPAHU", "96797"),
			new LoadAddress("Goodyear108", "2400 EAST WHITELAND RD", "WHITELAND", "46184"),
			new LoadAddress("Goodyear109", "225 HAGGART STREET", "WINNIPEG", "R2R 2V8"),
			new LoadAddress("Goodyear110", "300 SOUTH SALEM CHURCH ROAD", "YORK", "17404")
				};


		]]>
	</msxsl:script>
	<!-- Set default if empty template end -->
</xsl:stylesheet>
