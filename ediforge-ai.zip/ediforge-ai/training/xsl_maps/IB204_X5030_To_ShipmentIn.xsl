<?xml version="1.0" encoding="UTF-16"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
                xmlns:msxsl="urn:schemas-microsoft-com:xslt" 
                xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" 
                exclude-result-prefixes="msxsl var s0 ScriptCtx userCSharp" version="1.0" 
                xmlns:ns0="http://Echo.BSSR.Internal.Canonical.ShipmentIn/v1.0" 
                xmlns:s0="http://Echo.BSSR.Schemas.EDI.X12_00503.IB204"
                xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp"
                xmlns:ScriptCtx="http://schemas.microsoft.com/BizTalk/2003/ScriptCtx">
  <xsl:output omit-xml-declaration="yes" method="xml" version="1.0" />
  <xsl:template match="/">
    <xsl:apply-templates select="/s0:X12_00503_204" />
  </xsl:template>
  <xsl:template match="/s0:X12_00503_204">
    <ns0:Shipment>
      <xsl:variable name="vSenderPartyName" select="ScriptCtx:AccessContext(&quot;SenderPartyName&quot; , &quot;http://schemas.microsoft.com/Edi/PropertySchema&quot;)" /> 
      <xsl:variable name="vSenderId" select="ScriptCtx:AccessContext(&quot;GS02&quot; , &quot;http://schemas.microsoft.com/Edi/PropertySchema&quot;)" /> 
      <xsl:variable name="vReceiverId" select="ScriptCtx:AccessContext(&quot;GS03&quot; , &quot;http://schemas.microsoft.com/Edi/PropertySchema&quot;)" /> 
      <xsl:variable name="vIsTEST" select="ScriptCtx:AccessContext(&quot;ISA15&quot; , &quot;http://schemas.microsoft.com/Edi/PropertySchema&quot;)" />      
      <xsl:variable name="vENumber" select="userCSharp:GET_ENumberFromName($vSenderPartyName)" />
      <xsl:variable name="vCustomerName" select="userCSharp:GET_CustomerNameFromName($vSenderPartyName)" />
      <xsl:variable name="vBA01" select="s0:B2A/B2A01/text()" />
      <xsl:variable name="vB202CMMS" select="userCSharp:LogicalEq(string(ns0:B2/B202/text()) , &quot;CMMS&quot;)" />
      <xsl:variable name="vNotCMMS" select="userCSharp:LogicalNot(string($vB202CMMS))" />
      <xsl:variable name="vModeName" select="s0:MS3/MS304/text()" />
      <xsl:variable name="vNTEReefer" select="s0:NTE[NTE02 = 'REEFER']/NTE02" />
      <xsl:variable name="vShipmentId" select="s0:B2/B204/text()" />
      <xsl:variable name="vPackageTypeSource" select="''" />
      <xsl:variable name="vPackageQtySource" select="''" />
      <xsl:variable name="vHandlingTypeSource" select="''" />
      <xsl:variable name="vHandlingQtySource" select="''" />
      <xsl:variable name="vShipmentItemsL5">
           <xsl:value-of select="count(//ns0:OIDLoop1[(../s0:S5Loop1/s0:S5/S502/text()='CU' or ../s0:S5Loop1/s0:S5/S502/text()='PU')]/s0:L5Loop2/s0:L5_2/L502)" />
        </xsl:variable>
        <xsl:variable name="vShipmentItemsSansL5">
           <xsl:value-of select="count(//s0:OIDLoop1[(../s0:S5Loop1/s0:S5/S502/text()='CU' or ../s0:S5Loop1/s0:S5/S502/text()='PU')]/s0:OID/OID02)" />
        </xsl:variable>
      <xsl:variable name="vShipmentStops">
        <xsl:value-of select="count(//s0:S5Loop1/s0:S5/S501/text())" /> 
      </xsl:variable>        
      <xsl:attribute name="MessageName">LOADTENDER</xsl:attribute>
      <xsl:attribute name="MessageType">Echo.BSSR.Schemas.EDI.X12_00503.IB204</xsl:attribute>
      <xsl:attribute name="Direction">Inbound</xsl:attribute>
      <xsl:attribute name="SourceId">
          <xsl:value-of select="$vSenderPartyName" /> 
        </xsl:attribute>
       <xsl:attribute name="CustomerId">
        <xsl:value-of select="$vENumber"/>
      </xsl:attribute>
      <xsl:attribute name="DestinationId">ECHO</xsl:attribute>
      <xsl:attribute name="TestFlag">
        <xsl:value-of select="$vIsTEST"/>
      </xsl:attribute>
      <xsl:attribute name="OperationName">
        <xsl:choose>
          <xsl:when test="$vBA01 = '00'">CREATE</xsl:when>
          <xsl:when test="$vBA01 = '20'">CREATE</xsl:when>
          <xsl:when test="$vBA01 = '01'">CANCEL</xsl:when>
          <xsl:when test="$vBA01 = '03'">CANCEL</xsl:when>
          <xsl:when test="$vBA01 = '17'">CANCEL</xsl:when>
          <xsl:when test="$vBA01 = '02'">UPDATE</xsl:when>
          <xsl:when test="$vBA01 = '04'">UPDATE</xsl:when>
          <xsl:when test="$vBA01 = '05'">UPDATE</xsl:when>
          <xsl:when test="$vBA01 = 'CO'">UPDATE</xsl:when>
          <xsl:otherwise>CREATE</xsl:otherwise>
         </xsl:choose>          
        </xsl:attribute>
     <xsl:attribute name="SenderId">
       <xsl:value-of select="$vSenderId"/>
      </xsl:attribute>
       <xsl:attribute name="ReceiverId">
       <xsl:value-of select="$vReceiverId"/>
      </xsl:attribute>
      <xsl:attribute name="ConfigurationType">AgreementId_AgreementName</xsl:attribute>
      <xsl:attribute name="ConfigurationValue">
         <xsl:value-of select="ScriptCtx:AccessContext(&quot;AgreementID&quot; , &quot;http://schemas.microsoft.com/Edi/PropertySchema&quot;)" />_<xsl:value-of select="ScriptCtx:AccessContext(&quot;AgreementName&quot; , &quot;http://schemas.microsoft.com/Edi/PropertySchema&quot;)" /> 
        </xsl:attribute>
      <xsl:attribute name="EventTypeId">
        <xsl:value-of select="$vBA01" />
      </xsl:attribute>
      <xsl:attribute name="CustomerName">
        <xsl:value-of select="$vCustomerName"/>
      </xsl:attribute>
      <Header>
        <ActivityDate>
          <xsl:value-of select="userCSharp:GetMapActivityDate()" />
        </ActivityDate>
        <TransactionSetCode>
          <xsl:value-of select="ST/ST01/text()" />        
        </TransactionSetCode>
         <ControlNumber>
          <xsl:value-of select="ST/ST02/text()" />        
        </ControlNumber>
        <ImplementationReference>
          <xsl:value-of select="ST/ST03/text()" />        
        </ImplementationReference>
        <xsl:choose>
          <xsl:when test="$vENumber != ''">
            <InternalCustomerId>
              <xsl:value-of select="$vENumber"/> 
            </InternalCustomerId>
          </xsl:when>
           <xsl:when test="$vCustomerName != ''">
            <InternalCustomerId>
              <xsl:value-of select="$vCustomerName"/> 
            </InternalCustomerId>
          </xsl:when>
          <xsl:otherwise>
            <InternalCustomerId>
              <xsl:value-of select="$vSenderId"/> 
            </InternalCustomerId>
          </xsl:otherwise>
        </xsl:choose>        
        <CustomerMainSCAC>
          <xsl:value-of select="s0:B2/B202/text()" />        
        </CustomerMainSCAC>
        <xsl:choose>          
          <xsl:when test="s0:MS3/MS301!=''">
            <SCAC>
              <xsl:value-of select="s0:MS3/MS301/text()" />
            </SCAC>
          </xsl:when>
          <xsl:when test="string($vB202CMMS)='true' or s0:B2/B202 ='CMMS' ">
            <SCAC>
              <xsl:value-of select="s0:B2/B202/text()" />
            </SCAC>
          </xsl:when>
        <xsl:otherwise>
          <SCAC>ECHS</SCAC>
        </xsl:otherwise>
        </xsl:choose>
        <xsl:if test="s0:B2/B204">
          <ShipmentId>
            <xsl:value-of select="s0:B2/B204/text()" />
          </ShipmentId>
        </xsl:if>
        <ShipmentMode>          
          <xsl:choose>
            <xsl:when test="$vModeName = 'X'">Intermodal</xsl:when>
            <xsl:when test="$vModeName= 'LT'">LTL</xsl:when>
            <xsl:when test="$vModeName = 'M'">TL</xsl:when>
            <xsl:when test="$vModeName = 'A'">Air</xsl:when>
            <xsl:when test="$vModeName = 'E'">Expedited</xsl:when>
            <xsl:when test="$vModeName = 'D'">SmallParcel</xsl:when>
            <xsl:otherwise>TL</xsl:otherwise>
          </xsl:choose>
        </ShipmentMode>
          <Mode>
          <xsl:value-of select="s0:MS3/MS304/text()" />
        </Mode>
        <ModeId>
          <xsl:variable name="var:modeType" select="s0:MS3/MS304/text()" />
          <xsl:choose>
            <xsl:when test="$var:modeType = 'X'">4</xsl:when>
            <xsl:when test="$var:modeType = 'LT'">6</xsl:when>
            <xsl:when test="$var:modeType = 'M'">5</xsl:when>
          </xsl:choose>
        </ModeId>
        <xsl:if test="s0:B2/B206">
          <Terms>
            <xsl:value-of select="s0:B2/B206/text()" />
          </Terms>
        </xsl:if>
        <RecordType>
          <xsl:value-of select="s0:B2A/B2A01/text()" />
        </RecordType>
				<xsl:if test="s0:B2A/B2A02">
					<ApplicationType>
						<xsl:value-of select="s0:B2A/B2A02/text()"/>
					</ApplicationType>
				</xsl:if>
        <xsl:variable name="varAccessorialService" >
          <xsl:for-each select="(s0:L11[L1102='4C' or L1102='4B'])">
            <xsl:value-of select="L1101" />
            <xsl:if test="position()!=last()">, </xsl:if>
          </xsl:for-each>
        </xsl:variable>
        <AccessorialService>
          <xsl:value-of select="$varAccessorialService" />
        </AccessorialService>
        <xsl:if test="s0:NTE/NTE01='LOI'">
          <GuaranteedDelivery>
            <xsl:value-of select="s0:NTE/NTE02/text()" />
          </GuaranteedDelivery>
        </xsl:if>
        <xsl:choose>
          <xsl:when test="s0:AT5/AT501='HZD'">
            <HazMat>1</HazMat>
          </xsl:when>
          <xsl:otherwise>
            <HazMat>0</HazMat>
          </xsl:otherwise>
        </xsl:choose>
          <xsl:if test="(s0:S5Loop1/s0:G62_2[G6201='38'])['1']">
            <PickUpByDate>
              <xsl:value-of select="(s0:S5Loop1/s0:G62_2[G6201='38'])['1']/G6202/text()" />T<xsl:value-of select="(s0:S5Loop1/s0:G62_2[G6201='38'])['1']/G6204/text()" />
            </PickUpByDate>
          </xsl:if>
          <xsl:if test="(s0:S5Loop1/s0:G62_2[G6201='37'])['1']">
            <PickUpReadyByDate>
              <xsl:value-of select="(s0:S5Loop1/s0:G62_2[G6201='37'])['1']/G6202/text()" />T<xsl:value-of select="(s0:S5Loop1/s0:G62_2[G6201='37'])['1']/G6204/text()" />
            </PickUpReadyByDate>
          </xsl:if>
          <xsl:if test="(s0:S5Loop1/s0:G62_2[G6201='54'])['2']">
            <RequestedDeliveryByDate>
              <xsl:value-of select="(s0:S5Loop1/s0:G62_2[G6201='54'])['2']/G6202/text()" />T<xsl:value-of select="(s0:S5Loop1/s0:G62_2[G6201='54'])['2']/G6204/text()" />
            </RequestedDeliveryByDate>
          </xsl:if>
       

        <!--<xsl:variable name="varExternalNotes" >
          <xsl:for-each select="(s0:NTE[NTE01='BOL' or NTE01='ZZZ'])">
            <xsl:if test="position()!=last()">
              <xsl:value-of select="concat(./NTE02,' ')" />
            </xsl:if>
            <xsl:if test="position()=last()">
              <xsl:value-of select="./NTE02" />
            </xsl:if>
          </xsl:for-each>
        </xsl:variable>

        <xsl:if test="string-length($varExternalNotes) > 0">
          <ExternalNotes>
            <xsl:value-of select="$varExternalNotes" />
          </ExternalNotes>
        </xsl:if>

        <xsl:variable name="varInternalNotes" >
          <xsl:for-each select="(s0:NTE[NTE01='ADD' or NTE01=''])">
            <xsl:if test="position()!=last()">
              <xsl:value-of select="concat(./NTE02,' ')" />
            </xsl:if>
            <xsl:if test="position()=last()">
              <xsl:value-of select="./NTE02" />
            </xsl:if>
          </xsl:for-each>
        </xsl:variable>


        <xsl:if test="string-length($varInternalNotes) > 0">
          <InternalNotes>
            <xsl:value-of select="$varInternalNotes" />
          </InternalNotes>
        </xsl:if>-->

        <xsl:for-each select="s0:N7Loop1[1]">
          <TrailerNumber>
            <xsl:value-of select="s0:N7/N702/text()" />
          </TrailerNumber>
        </xsl:for-each>
        <xsl:choose>
          <xsl:when test="s0:PLD/PLD01/text()!=''">
            <NumberOfPallets>
              <xsl:value-of select="s0:PLD/PLD01/text()" />
            </NumberOfPallets>
          </xsl:when>  
          <xsl:when test="s0:S5Loop1['1']/s0:PLD_2/PLD01/text()!=''">
            <NumberOfPallets>
              <xsl:value-of select="s0:S5Loop1['1']/s0:PLD_2/PLD01/text()"/>
            </NumberOfPallets>
          </xsl:when>
          <xsl:when test="s0:S5Loop1['1']/s0:OIDLoop1/s0:L5Loop2/s0:AT8_3/AT805/text()!=''">
            <NumberOfPallets>
              <xsl:value-of select="s0:S5Loop1['1']/s0:OIDLoop1/s0:L5Loop2/s0:AT8_3/AT805/text()"/>
            </NumberOfPallets>
          </xsl:when>
          <xsl:when test="s0:L3/L311/text()!=''">
            <NumberOfPallets>
              <xsl:value-of select="s0:L3/L311/text()" />
            </NumberOfPallets>
          </xsl:when>
          <xsl:when test="s0:S5Loop1['1']/s0:L5Loop1/s0:AT8_2/AT804/text()!=''">
            <NumberOfPallets>
              <xsl:value-of select="s0:S5Loop1['1']/s0:L5Loop1/s0:AT8_2/AT804/text()"/>
            </NumberOfPallets>
          </xsl:when>
          <xsl:otherwise>
            <NumberOfPallets>0</NumberOfPallets>          
          </xsl:otherwise>
        </xsl:choose>
          
        <!--<PalletStackAble>1</PalletStackAble>-->
        <xsl:if test="s0:L3/L301">
          <TotalWeight>
            <xsl:choose>
              <xsl:when test="not(number(s0:L3/L301/text()))">
                <xsl:value-of select="'0'" />
              </xsl:when>
              <xsl:otherwise>
                <xsl:value-of select="s0:L3/L301/text()" />
              </xsl:otherwise>
            </xsl:choose>
          </TotalWeight>
        </xsl:if>
        <xsl:choose>
          <xsl:when test="s0:L3/L312">
            <TotalWeightUnit>
              <xsl:value-of select="s0:L3/L312/text()" />
              <!--<xsl:call-template name="TotalWeightUnitMapValue">
                <xsl:with-param name="ValueToConvert" select="s0:L3/L312/text()" />
              </xsl:call-template>-->
            </TotalWeightUnit>
          </xsl:when>
          <xsl:otherwise>
            <TotalWeightUnit>L</TotalWeightUnit>
          </xsl:otherwise>
        </xsl:choose>
        <xsl:choose>         
          <xsl:when test="s0:N7Loop1/s0:N7/N711">
            <EquipmentType>
              <xsl:value-of select="s0:N7Loop1/s0:N7/N711/text()" />   
            </EquipmentType>
          </xsl:when>
          <xsl:when test="string(boolean($vNTEReefer)) = 'true'">
            <EquipmentType>43</EquipmentType>
          </xsl:when>          
          <xsl:otherwise>
            <EquipmentType>2</EquipmentType>
          </xsl:otherwise>            
        </xsl:choose>
        <xsl:if test="s0:N7Loop1/s0:N7/N711">
          <EquipmentAccessorials>
            <xsl:value-of select="s0:N7Loop1/s0:N7/N711/text()" />           
          </EquipmentAccessorials>
        </xsl:if>
        <xsl:if test="s0:N7Loop1/s0:N7/N715">
          <EquipmentLength>
            <xsl:value-of select="s0:N7Loop1/s0:N7/N715/text()" />
          </EquipmentLength>
        </xsl:if>
        <!--<EquipmentTarp>
        <xsl:call-template name="EquipmentTarpCodeMapValue">
          <xsl:with-param name="ValueToConvert" select="L1102/text()" />
        </xsl:call-template>
      </EquipmentTarp>-->
        <!--<EquipmentNotes></EquipmentNotes>-->
        
      </Header>
      <LoadReferences>
        <xsl:variable name="var:L11BM" select="//s0:L11[L1102/text()='BM']/L1101/text()" />
        <xsl:variable name="vL11CB" select="//s0:L11[L1102/text()='CB']/L1101/text()" />
        <xsl:variable name="vL11CC" select="//s0:L11[L1102/text()='CC']/L1101/text()" />
        <xsl:variable name="vL11AC" select="//s0:L11[L1102/text()='AC']/L1101/text()" />
        <xsl:variable name="vL11AR" select="//s0:L11[L1102/text()='AR']/L1101/text()" />
        <xsl:if test="$vL11CB != '' and not(string($vL11CC))">
          <LoadReference>
                <LoadReferenceCode>CC.CB</LoadReferenceCode>
                <LoadReferenceValue>
                  <xsl:value-of select="$vL11CB" />
                </LoadReferenceValue>
                <LoadReferenceDescription>CBToCC</LoadReferenceDescription>
                <LoadReferenceType>EDI.EXT</LoadReferenceType>
              </LoadReference>
         </xsl:if>
        <xsl:if test="s0:B2/B202">
        <xsl:if test="$vL11AC = '' or not(string($vL11AC))">
          <LoadReference>
                <LoadReferenceCode>AC.B202</LoadReferenceCode>
                <LoadReferenceValue>
                  <xsl:value-of select="s0:B2/B202/text()" />
                </LoadReferenceValue>
                <LoadReferenceDescription>B202</LoadReferenceDescription>
                <LoadReferenceType>EDI.EXT</LoadReferenceType>
              </LoadReference>
         </xsl:if>
          </xsl:if>
        <xsl:if test="count(s0:L11/L1102/text()) >= '1'">
          <LoadReference>
                <LoadReferenceCode>AR.L11Any</LoadReferenceCode>
                <LoadReferenceValue>
                  <xsl:value-of select="s0:L11/L1101/text()" />
                </LoadReferenceValue>
                <LoadReferenceDescription>L11Any</LoadReferenceDescription>
                <LoadReferenceType>EDI.EXT</LoadReferenceType>
             </LoadReference>
        </xsl:if>
        <xsl:choose>
          <xsl:when test="$var:L11BM!=''">
            <xsl:for-each select="s0:L11">
              <LoadReference>
                <LoadReferenceCode>
                  <xsl:value-of select="userCSharp:StringReferenceTrim(L1102/text())" />
                </LoadReferenceCode>
                <LoadReferenceValue>
                  <xsl:value-of select="L1101/text()" />
                </LoadReferenceValue>
                <LoadReferenceDescription>
                  <xsl:value-of select="L1103/text()" />
                </LoadReferenceDescription>
                <LoadReferenceType>EDI.EXT</LoadReferenceType>
              </LoadReference>
            </xsl:for-each>
            <LoadReference>
              <LoadReferenceCode>BM.B204</LoadReferenceCode>
              <LoadReferenceValue>
                <xsl:value-of select="s0:B2/B204/text()" />
              </LoadReferenceValue>
              <LoadReferenceDescription>B204</LoadReferenceDescription>
             <LoadReferenceType>EDI.EXT</LoadReferenceType>
            </LoadReference>
            <xsl:for-each select="s0:N1Loop1">
              <LoadReference>
                <xsl:if test="s0:N1/N101">
                  <LoadReferenceCode>
                    <xsl:value-of select="s0:N1/N101/text()" /><xsl:value-of select="'.N1'"/>                    
                  </LoadReferenceCode>
                </xsl:if>
                <xsl:if test="s0:N1/N104">
                  <LoadReferenceValue>
                    <xsl:value-of select="s0:N1/N104/text()" />
                  </LoadReferenceValue>
                </xsl:if>
                <LoadReferenceDescription>AddressReference</LoadReferenceDescription>
                <LoadReferenceType>EDI.EXT</LoadReferenceType>
              </LoadReference>
            </xsl:for-each>
            <xsl:for-each select="s0:S5Loop1">
              <xsl:if test="s0:S5/S502/text()='CL' or s0:S5/S502/text()='PL'">
                <xsl:for-each select="s0:OIDLoop1/s0:OID">
                  <xsl:if test="OID02/text()!=''">
                    <LoadReference>
                      <LoadReferenceCode>
                        <xsl:value-of select="'PO.OID02.Pickup'"/>
                      </LoadReferenceCode>
                      <LoadReferenceValue>
                        <xsl:value-of select="OID02/text()" />
                      </LoadReferenceValue>
                    <LoadReferenceDescription>OID02Reference</LoadReferenceDescription>
                    <LoadReferenceType>EDI.EXT</LoadReferenceType>
                  </LoadReference>
                    </xsl:if>
                </xsl:for-each>
              </xsl:if>
             <xsl:for-each select="s0:N1Loop2">
                <LoadReference>
                  <xsl:if test="s0:N1_2/N101">
                    <LoadReferenceCode>
                      <xsl:value-of select="s0:N1_2/N101/text()" /><xsl:value-of select="'.N1_2'"/>
                    </LoadReferenceCode>
                  </xsl:if>
                  <xsl:if test="s0:N1_2/N104">
                    <LoadReferenceValue>
                      <xsl:value-of select="s0:N1_2/N104/text()" />
                    </LoadReferenceValue>
                  </xsl:if>
                  <LoadReferenceDescription>StopAddressReference</LoadReferenceDescription>
                  <LoadReferenceType>EDI.EXT</LoadReferenceType>
                </LoadReference>
              </xsl:for-each>
            </xsl:for-each>
          <xsl:for-each select="s0:S5Loop1">
              <xsl:for-each select="s0:L11_3">                
                  <LoadReference>
                    <LoadReferenceCode>
                      <xsl:choose>
                        <xsl:when test="L1102 = 'BM'">MB</xsl:when>
                        <xsl:otherwise>
                          <xsl:value-of select="L1102/text()" />
                        </xsl:otherwise>
                      </xsl:choose>
                    </LoadReferenceCode>
                    <LoadReferenceValue>
                      <xsl:value-of select="L1101/text()" />
                    </LoadReferenceValue>
                    <LoadReferenceDescription>
                      <xsl:value-of select="L1103/text()" />
                    </LoadReferenceDescription>
                    <LoadReferenceType>EDI.Stop</LoadReferenceType>
                  </LoadReference>
              </xsl:for-each>
            </xsl:for-each>
            <xsl:for-each select="s0:S5Loop1">
                <xsl:for-each select="s0:L5Loop1/s0:G61Loop1/s0:L11_4">
                  <LoadReference>
                    <LoadReferenceCode>
                      <xsl:value-of select="L1102/text()" />
                    </LoadReferenceCode>
                    <LoadReferenceValue>
                      <xsl:value-of select="L1101/text()" />
                    </LoadReferenceValue>
                    <LoadReferenceDescription>
                      <xsl:value-of select="L1103/text()" />
                    </LoadReferenceDescription>
                    <LoadReferenceType>EDI.Item</LoadReferenceType>
                  </LoadReference>
                </xsl:for-each>
            </xsl:for-each>
          </xsl:when>
          <xsl:otherwise>
            <LoadReference>
              <LoadReferenceCode>BM</LoadReferenceCode>
              <LoadReferenceValue>
                <xsl:value-of select="s0:B2/B204/text()" />
              </LoadReferenceValue>
              <LoadReferenceDescription>B204</LoadReferenceDescription>
             <LoadReferenceType>EDI</LoadReferenceType>
            </LoadReference>
            <xsl:for-each select="s0:L11">
              <LoadReference>
                <LoadReferenceCode>
                  <xsl:value-of select="userCSharp:StringReferenceTrim(L1102/text())" />
                </LoadReferenceCode>
                <LoadReferenceValue>
                  <xsl:value-of select="L1101/text()" />
                </LoadReferenceValue>
                <LoadReferenceDescription>
                  <xsl:value-of select="L1103/text()" />
                </LoadReferenceDescription>
                <LoadReferenceType>EDI</LoadReferenceType>
              </LoadReference>
            </xsl:for-each>
            <xsl:for-each select="s0:N1Loop1">
              <LoadReference>
                <xsl:if test="s0:N1/N101">
                  <LoadReferenceCode>
                    <xsl:value-of select="s0:N1/N101/text()" /><xsl:value-of select="'.N1'"/>
                  </LoadReferenceCode>
                </xsl:if>
                <xsl:if test="s0:N1/N104">
                  <LoadReferenceValue>
                    <xsl:value-of select="s0:N1/N104/text()" />
                  </LoadReferenceValue>
                </xsl:if>
                <LoadReferenceDescription>AddressReference</LoadReferenceDescription>
                <LoadReferenceType>EDI.EXT</LoadReferenceType>
              </LoadReference>
            </xsl:for-each>
            <xsl:for-each select="s0:S5Loop1">
               <xsl:if test="s0:S5/S502/text()='CL' or s0:S5/S502/text()='PL'">
                <xsl:for-each select="s0:OIDLoop1/s0:OID">
                  <xsl:if test="OID02/text()!=''">
                    <LoadReference>
                      <LoadReferenceCode>
                        <xsl:value-of select="'PO.OID02.Pickup'"/>
                      </LoadReferenceCode>
                      <LoadReferenceValue>
                        <xsl:value-of select="OID02/text()" />
                      </LoadReferenceValue>
                    <LoadReferenceDescription>OID02Reference</LoadReferenceDescription>
                    <LoadReferenceType>EDI.EXT</LoadReferenceType>
                  </LoadReference>
                  </xsl:if>
                </xsl:for-each>
              </xsl:if>
              <xsl:for-each select="s0:N1Loop2">
                <LoadReference>
                  <xsl:if test="s0:N1_2/N101">
                    <LoadReferenceCode>
                      <xsl:value-of select="s0:N1_2/N101/text()" /><xsl:value-of select="'.N1_2'"/>
                    </LoadReferenceCode>
                  </xsl:if>
                  <xsl:if test="s0:N1_2/N104">
                    <LoadReferenceValue>
                      <xsl:value-of select="s0:N1_2/N104/text()" />
                    </LoadReferenceValue>
                  </xsl:if>
                  <LoadReferenceDescription>StopAddressReference</LoadReferenceDescription>
                  <LoadReferenceType>EDI.EXT</LoadReferenceType>
                </LoadReference>
              </xsl:for-each>
            </xsl:for-each>
            <xsl:for-each select="s0:S5Loop1">
              <xsl:for-each select="s0:L11_3">                
                  <LoadReference>
                    <LoadReferenceCode>
                      <xsl:choose>
                        <xsl:when test="L1102 = 'BM'">MB</xsl:when>
                        <xsl:otherwise>
                          <xsl:value-of select="L1102/text()" />
                        </xsl:otherwise>
                      </xsl:choose>
                    </LoadReferenceCode>
                    <LoadReferenceValue>
                      <xsl:value-of select="L1101/text()" />
                    </LoadReferenceValue>
                    <LoadReferenceDescription>
                      <xsl:value-of select="L1103/text()" />
                    </LoadReferenceDescription>
                    <LoadReferenceType>EDI.Stop</LoadReferenceType>
                  </LoadReference>
              </xsl:for-each>
            </xsl:for-each>
            <xsl:for-each select="s0:S5Loop1">
                <xsl:for-each select="s0:L5Loop1/s0:G61Loop1/s0:L11_4">
                  <LoadReference>
                    <LoadReferenceCode>
                      <xsl:value-of select="L1102/text()" />
                    </LoadReferenceCode>
                    <LoadReferenceValue>
                      <xsl:value-of select="L1101/text()" />
                    </LoadReferenceValue>
                    <LoadReferenceDescription>
                      <xsl:value-of select="L1103/text()" />
                    </LoadReferenceDescription>
                    <LoadReferenceType>EDI.Item</LoadReferenceType>
                  </LoadReference>
                </xsl:for-each>
            </xsl:for-each>
              
          </xsl:otherwise>
        </xsl:choose>
      </LoadReferences>
      <Dates>
        <xsl:for-each select="s0:G62">
          <Date>
            <xsl:attribute name="dateType">EDI</xsl:attribute>
            <xsl:attribute name="dateCode">
            <xsl:value-of select="G6201/text()"/>
            </xsl:attribute>
            <xsl:attribute name="timeCode">
              <xsl:value-of select="G6203/text()"/>
            </xsl:attribute>
            <xsl:attribute name="dateTime">
              <xsl:value-of select="G6202/text()"/>T<xsl:value-of select="G6204/text()"/>
            </xsl:attribute>                    
            <xsl:attribute name="timeZone">
              <xsl:value-of select="G6205/text()"/>
            </xsl:attribute>   
          </Date>
        </xsl:for-each>
      </Dates>

      <xsl:if test="s0:MS3/MS301/text()!=''!='' or s0:MS3/MS302/text()!=''!='' or s0:MS3/MS303/text()!='' ">
        <RouteInterlines>
          <xsl:for-each select="s0:MS3">
            <RouteInfo>
              <xsl:attribute name="scac">
                <xsl:value-of select="MS301/text()"/>
              </xsl:attribute>
              <xsl:attribute name="sequenceCode">
                <xsl:value-of select="MS302/text()"/>
              </xsl:attribute>
              <xsl:attribute name="cityName">
                <xsl:value-of select="MS303/text()"/>
              </xsl:attribute>
              <xsl:attribute name="transportMethodCode">
                <xsl:value-of select="MS304/text()"/>
              </xsl:attribute>
              <xsl:attribute name="stateOrProvince">
                <xsl:value-of select="MS305/text()"/>
              </xsl:attribute>
            </RouteInfo>
          </xsl:for-each>
        </RouteInterlines>
      </xsl:if>

      <xsl:if test="count(s0:NTE) > '0' or s0:L3/L305/text()!='' or s0:N1Loop1/s0:G61[G6101='OC']/G6102/text()!='' or s0:N7Loop1/s0:MEA/MEA03/text()!='' ">
      <Notes>
        <xsl:if test="s0:L3/L305/text()!=''">
          <xsl:variable name="vTotalRate" select="userCSharp:ConvertNnToNumeric(s0:L3/L305/text(),'N2')" />
          <Note>
            <xsl:attribute name="notePriority">
              <xsl:value-of select="'-1'"/>
            </xsl:attribute>
            <xsl:attribute name="noteType">
              <xsl:value-of select="'L305'"/>
            </xsl:attribute>
            <xsl:attribute name="noteVisibility">
              <xsl:value-of select="'APP.EDI.BRE'"/>
            </xsl:attribute>
            <xsl:attribute name="note">
              <xsl:value-of select="concat('Total Rate: ',$vTotalRate,'; ')"/>
            </xsl:attribute>
          </Note>
        </xsl:if>
        <xsl:for-each select="s0:N1Loop1">
        <xsl:for-each select="s0:G61">
        <xsl:if test="G6101='OC' and G6102/text()!=''">
          <Note>
            <xsl:attribute name="notePriority">
              <xsl:value-of select="'-1'"/>
            </xsl:attribute>
            <xsl:attribute name="noteType">
              <xsl:value-of select="'G6102.OC'"/>
            </xsl:attribute>
            <xsl:attribute name="noteVisibility">
              <xsl:value-of select="'APP.EDI.BRE'"/>
            </xsl:attribute>
            <xsl:attribute name="note">
              <xsl:text>Order Contact: </xsl:text>
              <xsl:value-of select="G6102/text()"/>
              <xsl:text>(</xsl:text>
              <xsl:value-of select="G6104/text()"/>
              <xsl:text>)</xsl:text>              
              <xsl:text>;</xsl:text>
            </xsl:attribute>
          </Note>
        </xsl:if>
         </xsl:for-each>
          </xsl:for-each>
        <xsl:if test="s0:N7Loop1/s0:MEA/MEA03/text()!=''">
          <Note>
            <xsl:attribute name="notePriority">
              <xsl:value-of select="'-1'"/>
            </xsl:attribute>
            <xsl:attribute name="noteType">
              <xsl:value-of select="'MEA03'"/>
            </xsl:attribute>
            <xsl:attribute name="noteVisibility">
              <xsl:value-of select="'APP.EDI.BRE'"/>
            </xsl:attribute>
            <xsl:attribute name="note">
              <xsl:text>Miles: </xsl:text>
              <xsl:value-of select="s0:N7Loop1/s0:MEA/MEA03/text()"/>
              <xsl:text>;</xsl:text>
            </xsl:attribute>
          </Note>
        </xsl:if>
        <xsl:if test="count(s0:NTE) > '0'">
        <xsl:for-each select="s0:NTE">
          <Note>
            <xsl:attribute name="notePriority">
              <xsl:value-of select="position()"/>
            </xsl:attribute>
            <xsl:attribute name="noteType">
              <xsl:value-of select="NTE01/text()"/>
            </xsl:attribute>
            <xsl:attribute name="noteVisibility">
              <xsl:value-of select="'EDI.NTE'"/>
            </xsl:attribute>
            <xsl:attribute name="note">
              <xsl:value-of select="NTE02/text()"/>
            </xsl:attribute>
          </Note>
        </xsl:for-each>
        </xsl:if>
        <xsl:for-each select="s0:S5Loop1[s0:S5/S502 = 'LD']">
          <xsl:for-each select="s0:OIDLoop1/s0:L5Loop2">
            <xsl:if test="s0:L5_2/L502/text()=''">
            <Note>
                <xsl:attribute name="notePriority">
                  <xsl:value-of select="'-1'"/>
                </xsl:attribute>
                <xsl:attribute name="noteType">
                  <xsl:value-of select="'L502'"/>
                </xsl:attribute>
                <xsl:attribute name="noteVisibility">
                  <xsl:value-of select="'APP.EDI.BRE'"/>
                </xsl:attribute>
                <xsl:attribute name="note">
                  <xsl:value-of select="s0:L5_2/L502/text()"/>
                  <xsl:text>;</xsl:text>
                </xsl:attribute>
              </Note>
              </xsl:if>
          </xsl:for-each>
        </xsl:for-each>
         <xsl:for-each select="s0:S5Loop1[s0:S5/S502 = 'UL']">
          <xsl:for-each select="s0:OIDLoop1/s0:L5Loop2">
            <xsl:if test="s0:L5_2/L502/text()=''">
            <Note>
                <xsl:attribute name="notePriority">
                  <xsl:value-of select="'-1'"/>
                </xsl:attribute>
                <xsl:attribute name="noteType">
                  <xsl:value-of select="'L502'"/>
                </xsl:attribute>
                <xsl:attribute name="noteVisibility">
                  <xsl:value-of select="'APP.EDI.BRE'"/>
                </xsl:attribute>
                <xsl:attribute name="note">
                  <xsl:value-of select="s0:L5_2/L502/text()"/>
                  <xsl:text>;</xsl:text>
                </xsl:attribute>
              </Note>
              </xsl:if>
          </xsl:for-each>
        </xsl:for-each>
      </Notes>
      </xsl:if>  
      
      <xsl:if test="s0:N1Loop1[s0:N1/N101='BT']">
        <BillTo>
          <xsl:for-each select="s0:N1Loop1/s0:N1[N101='BT']">
            <xsl:if test="position()='1'">
              
                <xsl:attribute name="customerAccountId">
                  <xsl:value-of select="N104/text()" />
                </xsl:attribute>

                <xsl:attribute name="name">
                  <xsl:value-of select="N102/text()" />
                </xsl:attribute>

                <xsl:if test="../s0:N3/N301">
                  <xsl:attribute name="address1">
                    <xsl:value-of select="../s0:N3/N301/text()" />
                  </xsl:attribute>
                </xsl:if>

                <xsl:if test="../s0:N3/N302">
                  <xsl:attribute name="address2">
                    <xsl:value-of select="../s0:N3/N302/text()" />
                  </xsl:attribute>
                </xsl:if>

                <xsl:if test="../s0:N4/N401">
                  <xsl:attribute name="city">
                    <xsl:value-of select="../s0:N4/N401/text()" />
                  </xsl:attribute>
                </xsl:if>

                <xsl:if test="../s0:N4/N402">
                  <xsl:attribute name="stateProvince">
                    <xsl:value-of select="../s0:N4/N402/text()" />
                  </xsl:attribute>
                </xsl:if>

                <xsl:if test="../s0:N4/N403">
                  <xsl:attribute name="postalCode">
                    <xsl:value-of select="../s0:N4/N403/text()" />
                  </xsl:attribute>
                </xsl:if>

                <xsl:choose>
                  <xsl:when test="../s0:N4/N404">
                    <xsl:attribute name="country">
                      <xsl:value-of select="../s0:N4/N404/text()" />
                    </xsl:attribute>
                  </xsl:when>
                  <xsl:otherwise>
                    <xsl:attribute name="country">US</xsl:attribute>
                  </xsl:otherwise>
                </xsl:choose>
              
            </xsl:if>
            
          </xsl:for-each>
          
        </BillTo>
      </xsl:if>

      <xsl:if test="s0:N1Loop1/s0:N1/N101">        
        <Addresses>

          <xsl:for-each select="s0:N1Loop1">
            <Address>
              
              <xsl:attribute name="addressType">
                <xsl:value-of select="s0:N1/N101/text()" />
              </xsl:attribute>
  
              <xsl:attribute name="accountIdType">
                <xsl:value-of select="s0:N1/N103/text()" />
              </xsl:attribute>

              <xsl:attribute name="accountId">
                <xsl:value-of select="s0:N1/N104/text()" />
              </xsl:attribute>

              <xsl:attribute name="name">
                <xsl:value-of select="s0:N1/N102/text()" />
              </xsl:attribute>

              <xsl:if test="s0:N3/N301">
                <xsl:attribute name="address1">
                  <xsl:value-of select="s0:N3/N301/text()" />
                </xsl:attribute>
              </xsl:if>
              
              
              
               <xsl:if test="s0:N3/N302">
                <xsl:attribute name="address2">
                  <xsl:value-of select="s0:N3/N302/text()" />
                </xsl:attribute>
              </xsl:if>

              <xsl:if test="s0:N4/N401">
                <xsl:attribute name="city">
                  <xsl:value-of select="s0:N4/N401/text()" />
                </xsl:attribute>
              </xsl:if>

              <xsl:if test="s0:N4/N402">
                <xsl:attribute name="stateProvince">
                  <xsl:value-of select="s0:N4/N402/text()" />
                </xsl:attribute>
              </xsl:if>

              <xsl:if test="s0:N4/N403">
                <xsl:attribute name="postalCode">
                  <xsl:value-of select="s0:N4/N403/text()" />
                </xsl:attribute>
              </xsl:if>

              <xsl:choose>
                <xsl:when test="s0:N4/N404">
                  <xsl:attribute name="country">
                    <xsl:value-of select="s0:N4/N404/text()" />
                  </xsl:attribute>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:attribute name="country">US</xsl:attribute>
                </xsl:otherwise>
              </xsl:choose>
              <xsl:if test="s0:G61/G6102!=''">
                <Contacts>
                  <xsl:for-each select="s0:G61">
                    <Contact>
                      <xsl:attribute name="functionCode">
                        <xsl:value-of select="G6101/text()" />
                      </xsl:attribute>
                      <xsl:attribute name="name">
                        <xsl:value-of select="G6102/text()" />
                      </xsl:attribute>
                      <xsl:choose>
                        <xsl:when test="G6103='EM'">
                          <xsl:attribute name="email">
                            <xsl:value-of select="G6104/text()" />
                          </xsl:attribute>
                        </xsl:when>
                      </xsl:choose>
                      <xsl:choose>
                        <xsl:when test="G6103='TE' or G6103='WP' or G6103='WC' or G6103='SP'">
                          <xsl:attribute name="phone">
                            <xsl:value-of select="G6104/text()" />
                          </xsl:attribute>
                        </xsl:when>
                        <xsl:when test="G6103='OT' or G6103='NP' or G6103='IT' or G6103='HP'">
                          <xsl:attribute name="phone">
                            <xsl:value-of select="G6104/text()" />
                          </xsl:attribute>
                        </xsl:when>
                        <xsl:when test="G6103='EX' or G6103='CP' or G6103='AP' or G6103='AD'">
                          <xsl:attribute name="phone">
                            <xsl:value-of select="G6104/text()" />
                          </xsl:attribute>
                        </xsl:when>
                        <xsl:when test="G6103='PC' or G6103='PP'">
                          <xsl:attribute name="phone">
                            <xsl:value-of select="G6104/text()" />
                          </xsl:attribute>
                        </xsl:when>
                      </xsl:choose>
                      <xsl:attribute name="contactMethod">
                        <xsl:value-of select="G6103/text()" />
                      </xsl:attribute>
                      <xsl:attribute name="contactNumber">
                        <xsl:value-of select="G6104/text()" />
                      </xsl:attribute>
                      <xsl:attribute name="contactReference">
                        <xsl:value-of select="G6105/text()" />
                      </xsl:attribute>
                    </Contact>
                  </xsl:for-each>
                </Contacts>
              </xsl:if>
            </Address>
          </xsl:for-each>
        </Addresses>
      </xsl:if>

      <xsl:if test="s0:N1Loop1/s0:G61/G6102!=''">
        <Contacts>
          <xsl:for-each select="s0:N1Loop1/s0:G61">
            <Contact>
              <xsl:attribute name="functionCode">
                <xsl:value-of select="G6101/text()" />
              </xsl:attribute>
              <xsl:attribute name="name">
                <xsl:value-of select="G6102/text()" />
              </xsl:attribute>
              <xsl:choose>
                <xsl:when test="G6103='EM'">
                  <xsl:attribute name="email">
                    <xsl:value-of select="G6104/text()" />
                  </xsl:attribute>
                </xsl:when>
              </xsl:choose>
              <xsl:choose>
                <xsl:when test="G6103='TE' or G6103='WP' or G6103='WC' or G6103='SP'">
                  <xsl:attribute name="phone">
                    <xsl:value-of select="G6104/text()" />
                  </xsl:attribute>
                </xsl:when>
                <xsl:when test="G6103='OT' or G6103='NP' or G6103='IT' or G6103='HP'">
                  <xsl:attribute name="phone">
                    <xsl:value-of select="G6104/text()" />
                  </xsl:attribute>
                </xsl:when>
                <xsl:when test="G6103='EX' or G6103='CP' or G6103='AP' or G6103='AD'">
                  <xsl:attribute name="phone">
                    <xsl:value-of select="G6104/text()" />
                  </xsl:attribute>
                </xsl:when>
                <xsl:when test="G6103='PC' or G6103='PP'">
                  <xsl:attribute name="phone">
                    <xsl:value-of select="G6104/text()" />
                  </xsl:attribute>
                </xsl:when>
              </xsl:choose>
              <xsl:attribute name="contactMethod">
                <xsl:value-of select="G6103/text()" />
              </xsl:attribute>
              <xsl:attribute name="contactNumber">
                <xsl:value-of select="G6104/text()" />
              </xsl:attribute>
              <xsl:attribute name="contactReference">
                <xsl:value-of select="G6105/text()" />
              </xsl:attribute>
            </Contact>
          </xsl:for-each>
        </Contacts>
      </xsl:if>
      
      <xsl:if test="count(//s0:N7Loop1/s0:N7) > 0">
        <EquipmentList>
          <xsl:for-each select="s0:N7Loop1/s0:N7">
            <Equipment>
            <xsl:if test="N701">
              <xsl:attribute name="initial">
                <xsl:value-of select="N701/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N702">
              <xsl:attribute name="number">
                <xsl:value-of select="N702/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N718">
              <xsl:attribute name="numberCheckDigit">
                <xsl:value-of select="N718/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N703">
              <xsl:attribute name="weight">
                <xsl:value-of select="N703/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N704">
              <xsl:attribute name="weightType">
                <xsl:value-of select="N704/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N705">
              <xsl:attribute name="tareWeight">
                <xsl:value-of select="N705/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N706">
              <xsl:attribute name="weightAllowance">
                <xsl:value-of select="N706/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N717">
              <xsl:attribute name="weightUnitCode">
                <xsl:value-of select="N717/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N707">
              <xsl:attribute name="dunnage">
                <xsl:value-of select="N707/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N708">
              <xsl:attribute name="volume">
                <xsl:value-of select="N708/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N709">
              <xsl:attribute name="volumeUnitType">
                <xsl:value-of select="N709/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N710">
              <xsl:attribute name="ownershipCode">
                <xsl:value-of select="N710/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N711">
              <xsl:attribute name="descriptionCode">
                <xsl:value-of select="N711/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N712">
              <xsl:attribute name="equipmentSCAC">
                <xsl:value-of select="N712/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N723">
              <xsl:attribute name="equipmentSCAC2">
                <xsl:value-of select="N723/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N713">
              <xsl:attribute name="temperatureControl">
                <xsl:value-of select="N713/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N714">
              <xsl:attribute name="position">
                <xsl:value-of select="N714/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N715">
              <xsl:attribute name="length">
                <xsl:value-of select="N715/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N716">
              <xsl:attribute name="tareQualifierCode">
                <xsl:value-of select="N716/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N719">
              <xsl:attribute name="typeOfServiceCode">
                <xsl:value-of select="N719/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N720">
              <xsl:attribute name="height">
                <xsl:value-of select="N720/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N721">
              <xsl:attribute name="width">
                <xsl:value-of select="N721/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N722">
              <xsl:attribute name="equipmentType">
                <xsl:value-of select="N722/text()"/>              
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="N724">
              <xsl:attribute name="carTypeCode">
                <xsl:value-of select="N724/text()"/>              
              </xsl:attribute>
            </xsl:if>
            </Equipment>
          </xsl:for-each>
       </EquipmentList>
      </xsl:if>
      

      <Stops>
        <xsl:for-each select="s0:S5Loop1">
           <xsl:variable name="vStopTypeId">
                  <xsl:call-template name="StopTypeMapValue">
                    <xsl:with-param name="ValueToConvert" select="s0:S5/S502/text()" />
                  </xsl:call-template>
                </xsl:variable>
          <Stop>
            <xsl:if test="s0:N1Loop2/s0:N1_2/N104/text()!=''">
              <xsl:attribute name="StopIdentificationValue">
                <xsl:value-of select="s0:N1Loop2/s0:N1_2/N104/text()"/>
              </xsl:attribute>
            </xsl:if>
            <xsl:if test="s0:N1Loop2/s0:N1_2/N103/text()!=''">
              <xsl:attribute name="StopIdentificationType">
                <xsl:value-of select="s0:N1Loop2/s0:N1_2/N103/text()"/>
              </xsl:attribute>
            </xsl:if>
            <xsl:choose>
              <xsl:when test="s0:S5/S502/text()">
               
                <StopTypeId>
                  <xsl:value-of select="$vStopTypeId"/>                
                </StopTypeId>
                <StopType>
                  <xsl:value-of select="s0:S5/S502/text()" />                                  
                </StopType>
              </xsl:when>
              <xsl:otherwise>
                <StopTypeId>-1</StopTypeId>
                <StopType></StopType>
              </xsl:otherwise>
            </xsl:choose>
            <StopNumber>
              <xsl:value-of select="position()" />
            </StopNumber>
            <xsl:choose>
              <xsl:when test="s0:L11_3[L1102 = 'BM']/L1101">
                <StopBillOfLading>
                  <xsl:value-of select="s0:L11_3[L1102 = 'BM']/L1101/text()" />
                </StopBillOfLading>
              </xsl:when>
              <xsl:when test="s0:L11_3[L1102 = 'Z5']/L1101">
                <StopBillOfLading>
                  <xsl:value-of select="s0:L11_3[L1102 = 'Z5']/L1101/text()" />
                </StopBillOfLading>
              </xsl:when>
            </xsl:choose>
            <!--Get location type start-->
            <xsl:choose>
              <xsl:when test="s0:S5/S502/text()">
                <xsl:variable name="varLocationStopType">
                  <xsl:call-template name="StopTypeMapValue">
                    <xsl:with-param name="ValueToConvert" select="s0:S5/S502/text()" />
                  </xsl:call-template>
                </xsl:variable>
                <xsl:choose>
                  <xsl:when test="$varLocationStopType = '1'">
                    <xsl:choose>
                      <xsl:when test="../s0:L11/L1101='61'">
                        <LocationType>1</LocationType>
                      </xsl:when>
                      <xsl:when test="../s0:L11/L1101='59'">
                        <LocationType>2</LocationType>
                      </xsl:when>
                      <xsl:when test="../s0:L11/L1101='63'">
                        <LocationType>3</LocationType>
                      </xsl:when>
                      <xsl:otherwise>
                        <LocationType>4</LocationType>
                      </xsl:otherwise>
                    </xsl:choose>
                  </xsl:when>
                  <xsl:when test="$varLocationStopType = '2'">
                    <xsl:choose>
                      <xsl:when test="../s0:L11/L1101='62'">
                        <LocationType>1</LocationType>
                      </xsl:when>
                      <xsl:when test="../s0:L11/L1101='50'">
                        <LocationType>2</LocationType>
                      </xsl:when>
                      <xsl:when test="../s0:L11/L1101='64'">
                        <LocationType>3</LocationType>
                      </xsl:when>
                      <xsl:otherwise>
                        <LocationType>4</LocationType>
                      </xsl:otherwise>
                    </xsl:choose>
                  </xsl:when>
                </xsl:choose>
              </xsl:when>
            </xsl:choose>
            <!--Get location type end-->

            <!--<xsl:variable name="varStopExternalNotes" >
              <xsl:for-each select="(s0:NTE_2)">
                <xsl:if test="position()!=last()">
                  <xsl:value-of select="concat(./NTE02,' ')" />
                </xsl:if>
                <xsl:if test="position()=last()">
                  <xsl:value-of select="./NTE02" />
                </xsl:if>
              </xsl:for-each>
            </xsl:variable>
            
            <xsl:choose>
              <xsl:when test="string-length($varStopExternalNotes) > 0">
                <ExternalNotes>
                  <xsl:value-of select="$varStopExternalNotes" />
                </ExternalNotes>
              </xsl:when>
              <xsl:otherwise>
                <ExternalNotes>
                <xsl:value-of select="$varStopExternalNotes" />
              </ExternalNotes>  
            </xsl:otherwise>
            </xsl:choose>-->

			  <xsl:variable name="vWarehouseName">
				  <xsl:choose>
					  <xsl:when test="normalize-space(s0:N1Loop2/s0:N1_2/N102/text())!=''">
						  <xsl:value-of select="s0:N1Loop2/s0:N1_2/N102/text()"/>
					  </xsl:when>
					  <xsl:when test="../s0:N1Loop1[s0:N1/N101='BT']/s0:N1/N102/text()!='' and not(contains(../s0:N1Loop1[s0:N1/N101='BT']/s0:N1/N102/text(),'Echo')) and not(contains(../s0:N1Loop1[s0:N1/N101='BT']/s0:N1/N102/text(),'ECHO')) ">
						  <xsl:value-of select="concat(../s0:N1Loop1[s0:N1/N101='BT']/s0:N1/N102/text(),' ',s0:N1Loop2/s0:N4_2/N401/text(),' ',s0:N1Loop2/s0:N1_2/N104/text())"/>
					  </xsl:when>
					  <xsl:otherwise>
						  <xsl:value-of select="concat(s0:N1Loop2/s0:N4_2/N401/text(),' ',s0:N1Loop2/s0:N1_2/N104/text())"/>
					  </xsl:otherwise>
				  </xsl:choose>
			  </xsl:variable>

			  <xsl:choose>
            <xsl:when test="s0:N1Loop2/s0:N1_2/N101">

              
                <Warehouse>
                  <xsl:value-of select="$vWarehouseName" />
                </Warehouse>
              
              <xsl:variable name="vN301Count" select="count(s0:N1Loop2/s0:N3_2/N301)"/>
              <xsl:choose>
                <xsl:when test="$vN301Count='1'">
                    <Address1>
                        <xsl:value-of select="s0:N1Loop2/s0:N3_2/N301/text()" />
                    </Address1>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:for-each select="s0:N1Loop2/s0:N3_2">
                    <xsl:variable name="vAddAd1" select="userCSharp:SetAddress(N301/text())" />
                  </xsl:for-each>
                    <Address1>
                       <xsl:value-of select="userCSharp:GetAddress()" />
                    </Address1>
                
                </xsl:otherwise>
              
             </xsl:choose>
              
              <xsl:if test="s0:N1Loop2/s0:N3_2/N302/text()!=''">
               <Address2>
                <xsl:value-of select="s0:N1Loop2/s0:N3_2/N302/text()" />
              </Address2>
              </xsl:if>
              <xsl:choose>
                <xsl:when test="s0:N1Loop2/s0:N4_2/N401">
                  <City>
                    <xsl:value-of select="s0:N1Loop2/s0:N4_2/N401/text()" />
                  </City>
                </xsl:when>
                <xsl:otherwise>
                  <City>Default</City>
                </xsl:otherwise>
              </xsl:choose>

              <xsl:choose>
                <xsl:when test="s0:N1Loop2/s0:N4_2/N402">
                  <State>
                    <xsl:value-of select="s0:N1Loop2/s0:N4_2/N402/text()" />
                  </State>
                </xsl:when>
                <xsl:otherwise>
                  <State>ZZ</State>
                </xsl:otherwise>
              </xsl:choose>

              <xsl:choose>
                <xsl:when test="s0:N1Loop2/s0:N4_2/N403">
                  <Zip>
                    <xsl:value-of select="s0:N1Loop2/s0:N4_2/N403/text()" />
                  </Zip>
                </xsl:when>
                <xsl:otherwise>
                  <Zip>00000</Zip>
                </xsl:otherwise>
              </xsl:choose>
              <xsl:choose>
                <xsl:when test="s0:N1Loop2/s0:N4_2/N404">
                  <CountryCode>
                    <xsl:value-of select="substring(s0:N1Loop2/s0:N4_2/N404/text(), 1, 2)" />
                  </CountryCode>
                </xsl:when>
                <xsl:otherwise>
                  <CountryCode>US</CountryCode>
                </xsl:otherwise>
              </xsl:choose>

            </xsl:when>
          <xsl:otherwise>
                 <WarehouseId>
                  <xsl:value-of select="'-1'" />
                </WarehouseId>
                <Warehouse>
                  <xsl:value-of select="'UNKNOWN'" />
                </Warehouse>
                <City>Default</City>
                <State>ZZ</State>
                <Zip>00000</Zip>
                <CountryCode>US</CountryCode>
          </xsl:otherwise>
             
         </xsl:choose>
          
            <xsl:if test="s0:N1Loop2/s0:G61_2/G6102">
              <Contact>
                <xsl:value-of select="substring(s0:N1Loop2/s0:G61_2/G6102/text(), 1, 50)" />
              </Contact>
            </xsl:if>

            <xsl:for-each select="(s0:N1Loop2/s0:G61_2[G6103='TE'])[1]">
              <ContactPhone>
                <xsl:value-of select="G6104/text()" />
              </ContactPhone>
            </xsl:for-each>

            <xsl:for-each select="(s0:N1Loop2/s0:G61_2[G6103='EM'])[1]">
              <ContactEmail>
                <xsl:value-of select="G6104/text()" />
              </ContactEmail>
            </xsl:for-each>

            <xsl:variable name="vDateTypesCount" select="count(s0:G62_2)" />
            <xsl:variable name="vCountWindowStartDates" select="count(s0:G62_2[G6201='37' or G6201='53' or G6201='68' or G6201='EP']/G6202)" />
            <xsl:variable name="vCountWindowEndDates" select="count(s0:G62_2[G6201='38' or G6201='54' or G6201='69' or G6201='70' or G6201='79' or G6201='80' or G6201='96' or G6201='97' or G6201='98' or G6201='99' or G6201='LP']/G6202)" />

            <xsl:variable name="vOIDDateTypesCount" select="count(s0:OIDLoop1/s0:G62_3)" />
            <xsl:variable name="vOIDCountWindowStartDates" select="count(s0:OIDLoop1/s0:G62_3[G6201='37' or G6201='53' or G6201='68' or G6201='EP']/G6202)" />
            <xsl:variable name="vOIDCountWindowEndDates" select="count(s0:OIDLoop1/s0:G62_3[G6201='38' or G6201='54' or G6201='69' or G6201='70' or G6201='79' or G6201='80' or G6201='96' or G6201='97' or G6201='98' or G6201='99' or G6201='LP']/G6202)" />

            <xsl:choose>
              <xsl:when test="$vDateTypesCount='0' and $vOIDCountWindowStartDates!='0'">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6201='37' or G6201='53' or G6201='68' or G6201='EP'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateStart>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateStart>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount!= '0' and $vStopTypeId='2'">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6203='3' or G6203='5' or G6203='7' or G6203='G' or G6203='T' or G6203='X' or G6203='Z' or G6203='ED'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateStart>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateStart>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount!= '0'">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6203='2' or G6203='4' or G6203='6' or G6203='I' or G6203='S' or G6203='U' or G6203='Y' or G6203='EP'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateStart>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateStart>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vCountWindowStartDates!='0'">
                <xsl:for-each select="(s0:G62_2[G6201='37' or G6201='53' or G6201='68' or G6201='EP'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateStart>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateStart>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vStopTypeId='2'">
                <xsl:for-each select="(s0:G62_2[G6203='3' or G6203='5' or G6203='7' or G6203='G' or G6203='T' or G6203='X' or G6203='Z' or G6203='ED'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateStart>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateStart>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:otherwise>
                <xsl:for-each select="(s0:G62_2[G6203='2' or G6203='4' or G6203='6' or G6203='I' or G6203='S' or G6203='U' or G6203='Y' or G6203='EP'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateStart>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateStart>
                  </xsl:if>
                </xsl:for-each>
              </xsl:otherwise>
            </xsl:choose>

            <xsl:choose>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount>='3' and s0:OIDLoop1/s0:G62_3['2']/G6202/text()!=''">
                <AppointmentDateEnd>
                  <xsl:value-of select="s0:OIDLoop1/s0:G62_3['2']/G6202/text()" />
                </AppointmentDateEnd>
              </xsl:when>
              <xsl:when test="$vDateTypesCount='0' and $vStopTypeId='2' and $vOIDCountWindowEndDates>1">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6203='3' or G6203='5' or G6203='7' or G6203='L' or G6203='S' or G6203='X' or G6203='Z' or G6203='LD'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateEnd>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vDateTypesCount='0' and $vOIDCountWindowEndDates>1">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6203='2' or G6203='4' or G6203='6' or G6203='K' or G6203='S' or G6203='U' or G6203='Y' or G6203='LP'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateEnd>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount>0 and $vStopTypeId='2'">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6203='3' or G6203='5' or G6203='7' or G6203='L' or G6203='S' or G6203='X' or G6203='Z' or G6203='LD'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateEnd>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount>0 ">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6203='2' or G6203='4' or G6203='6' or G6203='K' or G6203='S' or G6203='U' or G6203='Y' or G6203='LP'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateEnd>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vDateTypesCount>='3' and s0:G62_2['2']/G6202/text()!=''">
                <AppointmentDateEnd>
                  <xsl:value-of select="s0:G62_2['2']/G6202/text()" />
                </AppointmentDateEnd>
              </xsl:when>
              <xsl:when test="$vStopTypeId='2' and $vCountWindowEndDates>1">
                <xsl:for-each select="(s0:G62_2[G6203='3' or G6203='5' or G6203='7' or G6203='L' or G6203='S' or G6203='X' or G6203='Z' or G6203='LD'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateEnd>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vCountWindowEndDates>1">
                <xsl:for-each select="(s0:G62_2[G6203='2' or G6203='4' or G6203='6' or G6203='K' or G6203='S' or G6203='U' or G6203='Y' or G6203='LP'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateEnd>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vCountWindowEndDates!='0'">
                <xsl:for-each select="(s0:G62_2[G6201='38' or G6201='54' or G6201='69' or G6201='70' or G6201='79' or G6201='80' or G6201='96' or G6201='97' or G6201='98' or G6201='99' or G6201='LP'])[1]">
                  <xsl:variable name="vPosition" select="position()" />
                  <xsl:if test="G6202/text()!='' and $vPosition='1'">
                    <AppointmentDateEnd>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vStopTypeId='2'">
                <xsl:for-each select="(s0:G62_2[G6203='3' or G6203='5' or G6203='7' or G6203='L' or G6203='S' or G6203='X' or G6203='Z' or G6203='LD'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateEnd>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:otherwise>
                <xsl:for-each select="(s0:G62_2[G6203='2' or G6203='4' or G6203='6' or G6203='K' or G6203='S' or G6203='U' or G6203='Y' or G6203='LP'])[1]">
                  <xsl:if test="G6202">
                    <AppointmentDateEnd>
                      <xsl:value-of select="G6202/text()" />
                    </AppointmentDateEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:otherwise>
            </xsl:choose>



            <xsl:choose>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount>0 and $vOIDCountWindowStartDates!='0'">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6201='37' or G6201='53' or G6201='68' or G6201='EP'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeStart>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeStart>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount>0 and $vStopTypeId='2'">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6203='3' or G6203='5' or G6203='7' or G6203='G' or G6203='T' or G6203='X' or G6203='Z' or G6203='ED'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeStart>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeStart>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount>0">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6203='2' or G6203='4' or G6203='6' or G6203='I' or G6203='S' or G6203='U' or G6203='Y' or G6203='EP'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeStart>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeStart>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vCountWindowStartDates!='0'">
                <xsl:for-each select="(s0:G62_2[G6201='37' or G6201='53' or G6201='68' or G6201='EP'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeStart>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeStart>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vStopTypeId='2'">
                <xsl:for-each select="(s0:G62_2[G6203='3' or G6203='5' or G6203='7' or G6203='G' or G6203='T' or G6203='X' or G6203='Z' or G6203='ED'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeStart>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeStart>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:otherwise>
                <xsl:for-each select="(s0:G62_2[G6203='2' or G6203='4' or G6203='6' or G6203='I' or G6203='S' or G6203='U' or G6203='Y' or G6203='EP'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeStart>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeStart>
                  </xsl:if>
                </xsl:for-each>
              </xsl:otherwise>
            </xsl:choose>

            <xsl:choose>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount>0 and $vOIDDateTypesCount>='3' and s0:OIDLoop1/s0:G62_3['2']/G6204/text()!=''">
                <AppointmentTimeEnd>
                  <xsl:value-of select="s0:OIDLoop1/s0:G62_3['2']/G6204/text()" />
                </AppointmentTimeEnd>
              </xsl:when>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount>0 and $vStopTypeId='2' and $vOIDCountWindowEndDates>'1'">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6203='3' or G6203='5' or G6203='7' or G6203='L' or G6203='S' or G6203='X' or G6203='Z' or G6203='LD'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeEnd>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount>0 and $vOIDCountWindowEndDates>1">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6203='2' or G6203='4' or G6203='6' or G6203='K' or G6203='S' or G6203='U' or G6203='Y' or G6203='LP'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeEnd>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount>0 and $vOIDCountWindowEndDates!='0'">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6201='38' or G6201='54' or G6201='69' or G6201='70' or G6201='79' or G6201='80' or G6201='96' or G6201='97' or G6201='98' or G6201='99' or G6201='LP'])[1]">
                  <xsl:variable name="vPosition" select="position()" />

                  <xsl:if test="G6204/text()!='' and $vPosition='1'">
                    <AppointmentTimeEnd>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount>0 and $vStopTypeId='2'">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6203='3' or G6203='5' or G6203='7' or G6203='L' or G6203='S' or G6203='X' or G6203='Z' or G6203='LD'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeEnd>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vDateTypesCount='0' and $vOIDDateTypesCount>0">
                <xsl:for-each select="(s0:OIDLoop1/s0:G62_3[G6203='2' or G6203='4' or G6203='6' or G6203='K' or G6203='S' or G6203='U' or G6203='Y' or G6203='LP'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeEnd>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vDateTypesCount>='3' and s0:G62_2['2']/G6204/text()!=''">
                <AppointmentTimeEnd>
                  <xsl:value-of select="s0:G62_2['2']/G6204/text()" />
                </AppointmentTimeEnd>
              </xsl:when>
              <xsl:when test="$vStopTypeId='2' and $vCountWindowEndDates>'1'">
                <xsl:for-each select="(s0:G62_2[G6203='3' or G6203='5' or G6203='7' or G6203='L' or G6203='S' or G6203='X' or G6203='Z' or G6203='LD'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeEnd>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vCountWindowEndDates>1">
                <xsl:for-each select="(s0:G62_2[G6203='2' or G6203='4' or G6203='6' or G6203='K' or G6203='S' or G6203='U' or G6203='Y' or G6203='LP'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeEnd>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vCountWindowEndDates!='0'">
                <xsl:for-each select="(s0:G62_2[G6201='38' or G6201='54' or G6201='69' or G6201='70' or G6201='79' or G6201='80' or G6201='96' or G6201='97' or G6201='98' or G6201='99' or G6201='LP'])[1]">
                  <xsl:variable name="vPosition" select="position()" />

                  <xsl:if test="G6204/text()!='' and $vPosition='1'">
                    <AppointmentTimeEnd>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:when test="$vStopTypeId='2'">
                <xsl:for-each select="(s0:G62_2[G6203='3' or G6203='5' or G6203='7' or G6203='L' or G6203='S' or G6203='X' or G6203='Z' or G6203='LD'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeEnd>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:when>
              <xsl:otherwise>
                <xsl:for-each select="(s0:G62_2[G6203='2' or G6203='4' or G6203='6' or G6203='K' or G6203='S' or G6203='U' or G6203='Y' or G6203='LP'])[1]">
                  <xsl:if test="G6204/text()!=''">
                    <AppointmentTimeEnd>
                      <xsl:value-of select="G6204/text()" />
                    </AppointmentTimeEnd>
                  </xsl:if>
                </xsl:for-each>
              </xsl:otherwise>
            </xsl:choose>
            
            <xsl:variable name="vCountOID02" select="count(s0:OIDLoop1/s0:OID/OID02)" />
            <xsl:variable name="vCountL11_4PO" select="count(s0:L5Loop1/s0:G61Loop1/s0:L11_4[L1102='PO'])"/>
            <xsl:variable name="vStopType" select="s0:S5/S502/text()" />
            
            <xsl:choose>
              <xsl:when test="count(s0:L11_3) > 0">
                <StopReferences>
                  <xsl:for-each select="s0:L11_3">
                    <xsl:choose>                      
                       <xsl:when test="L1102='Z5'">
                          <StopReference>
                            <StopReferenceCode>BM.Z5</StopReferenceCode>
                            <StopReferenceValue>
                              <xsl:value-of select="L1101/text()" />
                            </StopReferenceValue>
                            <StopReferenceDescription>
                              <xsl:value-of select="L1103/text()" />                  
                            </StopReferenceDescription>
                            <StopReferenceType>EDI.EXT</StopReferenceType>                    
                          </StopReference>  
                        </xsl:when>
                      <xsl:otherwise>
                          <StopReference>
                            <StopReferenceCode>
                              <xsl:value-of select="L1102/text()" />
                            </StopReferenceCode>
                            <StopReferenceValue>
                              <xsl:value-of select="L1101/text()" />
                            </StopReferenceValue>
                            <StopReferenceDescription>
                              <xsl:value-of select="L1103/text()" />                  
                            </StopReferenceDescription>
                            <StopReferenceType>EDI</StopReferenceType>                    
                          </StopReference>
                        </xsl:otherwise>
                     </xsl:choose>
                  </xsl:for-each>
                  <xsl:for-each select="s0:OIDLoop1">
                    <xsl:for-each select="s0:OID">  
                      <xsl:if test="OID02/text()!=''">
                         <StopReference>
                          <StopReferenceCode>P8.OID02</StopReferenceCode>
                          <StopReferenceValue>
                            <xsl:value-of select="OID02/text()" />
                          </StopReferenceValue>
                          <StopReferenceDescription>OIDLoop1.OID02</StopReferenceDescription>
                          <StopReferenceType>EDI.EXT</StopReferenceType>                    
                        </StopReference>
                        <StopReference>
                          <StopReferenceCode>KK.OID02</StopReferenceCode>
                          <StopReferenceValue>
                            <xsl:value-of select="OID02/text()" />
                          </StopReferenceValue>
                          <StopReferenceDescription>OIDLoop1.OID02</StopReferenceDescription>
                          <StopReferenceType>EDI.EXT</StopReferenceType>                    
                        </StopReference>
                      </xsl:if>
                    </xsl:for-each>                
                  </xsl:for-each>
                  <xsl:if test="$vCountL11_4PO > '0'">
                  <xsl:for-each select="s0:L5Loop1/s0:G61Loop1/s0:L11_4">
                    <xsl:if test="L1102='PO'">
                      <StopReference>
                          <StopReferenceCode>KK.L11_4.PO</StopReferenceCode>
                          <StopReferenceValue>
                            <xsl:value-of select="L1101/text()" />
                          </StopReferenceValue>
                          <StopReferenceDescription>L11_4.PO</StopReferenceDescription>
                          <StopReferenceType>EDI.EXT</StopReferenceType>                    
                        </StopReference>                  
                    </xsl:if>                  
                  </xsl:for-each>                    
                 </xsl:if>
                <StopReference>
                          <StopReferenceCode>P8.B204</StopReferenceCode>
                          <StopReferenceValue>
                            <xsl:value-of select="$vShipmentId" />
                          </StopReferenceValue>
                          <StopReferenceDescription>B204</StopReferenceDescription>
                          <StopReferenceType>EDI.EXT</StopReferenceType>                    
                    </StopReference>
                </StopReferences>
              </xsl:when>
            <xsl:when test="$vCountOID02 >'0' or $vCountL11_4PO > '0'">
              <StopReferences>
                <xsl:if test="$vCountOID02 >'0'">
                <xsl:for-each select="s0:OIDLoop1">
                    <xsl:for-each select="s0:OID">  
                      <xsl:if test="OID02/text()!=''">
                         <StopReference>
                          <StopReferenceCode>P8.OID02</StopReferenceCode>
                          <StopReferenceValue>
                            <xsl:value-of select="OID02/text()" />
                          </StopReferenceValue>
                          <StopReferenceDescription>OIDLoop1.OID02</StopReferenceDescription>
                          <StopReferenceType>EDI.EXT</StopReferenceType>                    
                        </StopReference>
                        <StopReference>
                          <StopReferenceCode>KK.OID02</StopReferenceCode>
                          <StopReferenceValue>
                            <xsl:value-of select="OID02/text()" />
                          </StopReferenceValue>
                          <StopReferenceDescription>OIDLoop1.OID02</StopReferenceDescription>
                          <StopReferenceType>EDI.EXT</StopReferenceType>                    
                        </StopReference>
                      </xsl:if>
                    </xsl:for-each>                
                  </xsl:for-each>
                 </xsl:if>
                 <xsl:if test="$vCountL11_4PO > '0'">
                  <xsl:for-each select="s0:L5Loop1/s0:G61Loop1/s0:L11_4">
                    <xsl:if test="L1102='PO'">
                      <StopReference>
                          <StopReferenceCode>KK.L11_4.PO</StopReferenceCode>
                          <StopReferenceValue>
                            <xsl:value-of select="L1101/text()" />
                          </StopReferenceValue>
                          <StopReferenceDescription>L11_4.PO</StopReferenceDescription>
                          <StopReferenceType>EDI.EXT</StopReferenceType>                    
                        </StopReference>                  
                    </xsl:if>                  
                  </xsl:for-each>                    
                 </xsl:if>
                    <StopReference>
                          <StopReferenceCode>P8.B204</StopReferenceCode>
                          <StopReferenceValue>
                            <xsl:value-of select="$vShipmentId" />
                          </StopReferenceValue>
                          <StopReferenceDescription>B204</StopReferenceDescription>
                          <StopReferenceType>EDI.EXT</StopReferenceType>                    
                    </StopReference>
                </StopReferences>
            </xsl:when>
            </xsl:choose>
            
            <StopLineItems>
              <xsl:choose>
                <xsl:when test="s0:L5Loop1/s0:L5/L502!=''">
                  <xsl:for-each select="s0:L5Loop1">                   
                    <StopLineItem>                        
                      <xsl:choose>                    
                        <xsl:when test="../s0:OIDLoop1/s0:LAD_2/LAD13!=''">
                            <xsl:attribute name="id">
                              <xsl:value-of select="'L5Loop1.OIDLoop1.LAD13'"/>
                            </xsl:attribute>
                            <xsl:attribute name="productId">
                               <xsl:value-of select="../s0:OIDLoop1/s0:LAD_2/LAD13/text()" />
                            </xsl:attribute>
                            <ProductDescription>
                              <xsl:value-of select="../s0:OIDLoop1/s0:LAD_2/LAD13/text()" />
                            </ProductDescription>
                         </xsl:when>
                          <xsl:when test="s0:L5/L502">
                            <xsl:attribute name="id">
                              <xsl:value-of select="'L5Loop1.L502'"/>
                            </xsl:attribute>
                            <xsl:attribute name="productId">
                               <xsl:value-of select="s0:L5/L502/text()" />
                            </xsl:attribute>
                            <ProductDescription>
                              <xsl:value-of select="s0:L5/L502/text()" />
                            </ProductDescription>
                          </xsl:when>                          
                       </xsl:choose>
                      <xsl:choose>
                        <xsl:when test="s0:AT5/AT501='HZD'">
                          <Hazmat>1</Hazmat>
                        </xsl:when>
                        <xsl:otherwise>
                          <Hazmat>0</Hazmat>
                        </xsl:otherwise>
                      </xsl:choose>
                      <xsl:choose> 
                       <xsl:when test="../s0:OIDLoop1/s0:OID/OID04 != ''">
                          <PackagingType>
                           <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID04/text()" />
                          </PackagingType>
                        </xsl:when>
                        <xsl:when test="../s0:OIDLoop1/s0:LAD_2/LAD01!=''">
                            <PackagingType>
                              <xsl:value-of select="../s0:OIDLoop1/s0:LAD_2/LAD01/text()" />
                              <!--<xsl:call-template name="PackagingTypeMapValue">
                                <xsl:with-param name="ValueToConvert" select="../s0:LAD_2/LAD01/text()" />
                              </xsl:call-template>-->
                            </PackagingType>
                          </xsl:when>                        
                          <xsl:otherwise>
                            <PackagingType>PCS</PackagingType>
                          </xsl:otherwise>
                        </xsl:choose>
                      <xsl:choose>
                        <xsl:when test="../s0:OIDLoop1/s0:OID/OID05/text() != ''">
                            <PackageQuantity>
                              <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID05/text()" />
                            </PackageQuantity>
                         </xsl:when>
                        <xsl:when test="../s0:OIDLoop1/s0:LAD_2/LAD02/text() != ''">
                          <PackageQuantity>
                            <xsl:value-of select="../s0:OIDLoop1/s0:LAD_2/LAD02/text()" />
                          </PackageQuantity>
                        </xsl:when>                        
                        <xsl:when test="s0:AT8_2/AT804/text() != ''">
                           <PackageQuantity>
                              <xsl:value-of select="s0:AT8_2/AT804/text()" />
                            </PackageQuantity>
                         </xsl:when>
                       </xsl:choose>
                      <xsl:choose>
                         <xsl:when test="../s0:OIDLoop1/s0:LAD_2/LAD01 != ''">
                          <HandlingType>
                            <xsl:value-of select="../s0:OIDLoop1/s0:LAD_2/LAD01/text()" />
                            <!--<xsl:call-template name="HandlingTypeMapValue">
                            <xsl:with-param name="ValueToConvert" select="../s0:OID/OID04/text()" />
                          </xsl:call-template>-->
                            <!--<xsl:value-of select="s0:OID/OID04/text()" />-->
                          </HandlingType>
                        </xsl:when>
                      <xsl:when test="../s0:OIDLoop1/s0:OID/OID04 != ''">
                        <HandlingType>
                          <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID04/text()" />
                          <!--<xsl:call-template name="HandlingTypeMapValue">
                            <xsl:with-param name="ValueToConvert" select="../s0:OID/OID04/text()" />
                          </xsl:call-template>-->
                          <!--<xsl:value-of select="s0:OID/OID04/text()" />-->
                        </HandlingType>
                      </xsl:when>
                        <xsl:when test="s0:L5/L505/text() != ''">
                          <HandlingType>
                            <xsl:value-of select="s0:L5/L505/text()" />
                            <!--<xsl:call-template name="HandlingTypeMapValue">
                            <xsl:with-param name="ValueToConvert" select="../s0:OID/OID04/text()" />
                          </xsl:call-template>-->
                            <!--<xsl:value-of select="s0:OID/OID04/text()" />-->
                          </HandlingType>
                        </xsl:when>
                       
                      </xsl:choose>

                     <xsl:choose>
                        <xsl:when test="../s0:OIDLoop1/s0:LAD_2/LAD02 != ''">
                        <HandlingUnitQuantity>
                          <xsl:value-of select="../s0:OIDLoop1/s0:LAD_2/LAD02/text()" />
                        </HandlingUnitQuantity>
                      </xsl:when>
                        <xsl:when test="s0:AT8_2/AT804/text() != ''">
                           <HandlingUnitQuantity>
                              <xsl:value-of select="s0:AT8_2/AT804/text()" />
                            </HandlingUnitQuantity>
                         </xsl:when>
                      <xsl:when test="../s0:OIDLoop1/s0:OID/OID05">
                        <HandlingUnitQuantity>
                          <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID05/text()" />
                        </HandlingUnitQuantity>
                      </xsl:when>
                       <xsl:when test="s0:AT8_2/AT805/text()!=''">
                         <HandlingUnitQuantity>
                           <xsl:value-of select="s0:AT8_2/AT805/text()" />
                         </HandlingUnitQuantity>
                       </xsl:when>
                     
                     </xsl:choose>
                        
                       <xsl:choose>
                          <xsl:when test="s0:L5/L509/text()!=''">
                            <FreightClass>
                              <xsl:value-of select="s0:L5/L509/text()" />
                            </FreightClass>
                          </xsl:when>
                          <xsl:when test="s0:L5/L503/text()!=''">
                            <FreightClass>
                              <xsl:value-of select="s0:L5/L503/text()" />
                            </FreightClass>
                          </xsl:when>
                        </xsl:choose>
                      <xsl:if test="s0:L5/L503">
                        <NMFC>
                          <xsl:value-of select="s0:L5/L503/text()" />
                        </NMFC>
                      </xsl:if>
                      <xsl:if test="s0:L5/L505">
                        <NMFCSub>
                          <xsl:value-of select="s0:L5/L505/text()" />
                        </NMFCSub>
                      </xsl:if>
                        <MinimumEstimatedWeight>
                          <xsl:choose>                            
                            <xsl:when test="number(../s0:OIDLoop1/s0:OID/OID07/text())">
                              <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID07/text()" />
                            </xsl:when>
                            <xsl:when test="not(number(s0:AT8_2/AT803/text()))">
                              <xsl:value-of select="'0'" />
                            </xsl:when>
                            <xsl:otherwise>
                              <xsl:value-of select="s0:AT8_2/AT803/text()" />
                            </xsl:otherwise>
                          </xsl:choose>
                        </MinimumEstimatedWeight>
                        <MaximumEstimatedWeight>
                          <xsl:choose>                            
                            <xsl:when test="number(../s0:OIDLoop1/s0:OID/OID07/text())">
                              <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID07/text()" />
                            </xsl:when>
                            <xsl:when test="not(number(s0:AT8_2/AT803/text()))">
                              <xsl:value-of select="'0'" />
                            </xsl:when>
                            <xsl:otherwise>
                              <xsl:value-of select="s0:AT8_2/AT803/text()" />
                            </xsl:otherwise>
                          </xsl:choose>
                        </MaximumEstimatedWeight>
                      <xsl:choose>
                        
                        <xsl:when test="../s0:OIDLoop1/s0:OID/OID06/text() != ''">
                          <UnitType>
                              <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID06/text()" />
                          </UnitType>
                        </xsl:when>                    
                        
                        <xsl:when test="s0:AT8_2/AT802">
                          <UnitType>
                            <xsl:value-of select="s0:AT8_2/AT802/text()" />
                            <!--<xsl:call-template name="TotalWeightUnitMapValue">
                              <xsl:with-param name="ValueToConvert" select="s0:AT8_2/AT802/text()" />
                            </xsl:call-template>-->
                          </UnitType>
                        </xsl:when>
                        <xsl:otherwise>
                            <UnitType>L</UnitType>
                          </xsl:otherwise>
                       </xsl:choose>
                       <xsl:if test="count(../s0:L5Loop1/s0:G61Loop1/s0:L11_4) > 0">
                          <ItemReferences>
                            <xsl:for-each select="../s0:L5Loop1/s0:G61Loop1/s0:L11_4">
                              <ItemReference>
                                <ItemReferenceCode>
                                  <xsl:value-of select="L1102/text()" />
                                </ItemReferenceCode>
                                <ItemReferenceValue>
                                  <xsl:value-of select="L1101/text()" />
                                </ItemReferenceValue>
                                <ItemReferenceDescription>
                                  <xsl:value-of select="L1103/text()" />                  
                                </ItemReferenceDescription>
                                <ItemReferenceType>EDI</ItemReferenceType>                    
                              </ItemReference>
                            </xsl:for-each>
                          </ItemReferences>
                      </xsl:if>
                    </StopLineItem>
                  </xsl:for-each>                  
                </xsl:when>

                <xsl:when test="s0:L5Loop1/s0:AT8_2/AT803!=''">
                  <xsl:for-each select="s0:L5Loop1">
                    <StopLineItem>
                      <xsl:choose>
                        <xsl:when test="s0:L5/L502">
                           <xsl:attribute name="id">
                              <xsl:value-of select="'L5Loop1.AT803'"/>
                            </xsl:attribute>
                            <xsl:attribute name="productId">
                               <xsl:value-of select="s0:L5/L502/text()" />
                            </xsl:attribute>
                          <ProductDescription>
                            <xsl:value-of select="s0:L5/L502/text()" />
                          </ProductDescription>
                        </xsl:when>
                      </xsl:choose>
                      <xsl:choose>
                        <xsl:when test="s0:AT5/AT501='HZD'">
                          <Hazmat>1</Hazmat>
                        </xsl:when>
                        <xsl:otherwise>
                          <Hazmat>0</Hazmat>
                        </xsl:otherwise>
                      </xsl:choose>
                      <xsl:choose>
                        <xsl:when test="s0:L5/L505!=''">
                          <PackagingType>
                            <xsl:value-of select="s0:L5/L505/text()" />
                            <!--<xsl:call-template name="PackagingTypeMapValue">
                              <xsl:with-param name="ValueToConvert" select="../s0:LAD_2/LAD01/text()" />
                            </xsl:call-template>-->
                          </PackagingType>
                        </xsl:when>
                         <xsl:when test="../s0:OIDLoop1/s0:OID/OID04">
                           <PackagingType>
                          <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID04/text()" />
                          <!--<xsl:call-template name="HandlingTypeMapValue">
                            <xsl:with-param name="ValueToConvert" select="../s0:OID/OID04/text()" />
                          </xsl:call-template>-->
                          <!--<xsl:value-of select="s0:OID/OID04/text()" />-->
                        </PackagingType>
                      </xsl:when>
                        <xsl:otherwise>
                          <PackagingType>PCS</PackagingType>
                        </xsl:otherwise>
                      </xsl:choose>
                      <xsl:choose>
                         <xsl:when test="../s0:OIDLoop1/s0:OID/OID05">
                          <PackageQuantity>
                            <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID05/text()" />
                          </PackageQuantity>
                        </xsl:when>
                        <xsl:when test="s0:AT8_2/AT804/text() != ''">
                          <PackageQuantity>
                            <xsl:value-of select="s0:AT8_2/AT804/text()" />
                          </PackageQuantity>
                        </xsl:when>                     
                       
                      </xsl:choose>

                      <xsl:choose>
                       <xsl:when test="../s0:OIDLoop1/s0:LAD_2/LAD01 != ''">
                        <HandlingType>
                          <xsl:value-of select="../s0:OIDLoop1/s0:LAD_2/LAD01/text()" />
                        </HandlingType>
                      </xsl:when>
                        
                      <xsl:when test="../s0:OIDLoop1/s0:OID/OID04">
                        <HandlingType>
                          <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID04/text()" />
                          <!--<xsl:call-template name="HandlingTypeMapValue">
                            <xsl:with-param name="ValueToConvert" select="../s0:OID/OID04/text()" />
                          </xsl:call-template>-->
                          <!--<xsl:value-of select="s0:OID/OID04/text()" />-->
                        </HandlingType>
                      </xsl:when>
                      </xsl:choose>
                        
                      <xsl:choose>
                         <xsl:when test="../s0:OIDLoop1/s0:LAD_2/LAD02 != ''">
                        <HandlingUnitQuantity>
                          <xsl:value-of select="../s0:OIDLoop1/s0:LAD_2/LAD02/text()" />
                        </HandlingUnitQuantity>
                      </xsl:when>
                       <xsl:when test="s0:AT8_2/AT804/text() != ''">
                        <HandlingUnitQuantity>
                            <xsl:value-of select="s0:AT8_2/AT804/text()" />
                        </HandlingUnitQuantity>
                      </xsl:when>
                      <xsl:when test="../s0:OIDLoop1/s0:OID/OID05">
                        <HandlingUnitQuantity>
                          <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID05/text()" />
                        </HandlingUnitQuantity>
                      </xsl:when>
                     
                      </xsl:choose>
                       <xsl:choose>
                          <xsl:when test="s0:L5/L509/text()!=''">
                            <FreightClass>
                              <xsl:value-of select="s0:L5/L509/text()" />
                            </FreightClass>
                          </xsl:when>
                          <xsl:when test="s0:L5/L503/text()!=''">
                            <FreightClass>
                              <xsl:value-of select="s0:L5/L503/text()" />
                            </FreightClass>
                          </xsl:when>
                        </xsl:choose>
                      <xsl:if test="s0:L5/L503">
                        <NMFC>
                          <xsl:value-of select="s0:L5/L503/text()" />
                        </NMFC>
                      </xsl:if>
                      <xsl:if test="s0:L5/L505">
                        <NMFCSub>
                          <xsl:value-of select="s0:L5/L505/text()" />
                        </NMFCSub>
                      </xsl:if>
                      <MinimumEstimatedWeight>
                        <xsl:choose>
                          <xsl:when test="number(../s0:OIDLoop1/s0:OID/OID07/text())">
                            <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID07/text()" />
                          </xsl:when>
                          <xsl:when test="not(number(s0:AT8_2/AT803/text()))">
                            <xsl:value-of select="'0'" />
                          </xsl:when>
                          <xsl:otherwise>
                            <xsl:value-of select="s0:AT8_2/AT803/text()" />
                          </xsl:otherwise>
                        </xsl:choose>
                      </MinimumEstimatedWeight>
                      <MaximumEstimatedWeight>
                        <xsl:choose>
                          <xsl:when test="number(../s0:OIDLoop1/s0:OID/OID07/text())">
                            <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID07/text()" />
                          </xsl:when>
                          <xsl:when test="not(number(s0:AT8_2/AT803/text()))">
                            <xsl:value-of select="'0'" />
                          </xsl:when>
                          <xsl:otherwise>
                            <xsl:value-of select="s0:AT8_2/AT803/text()" />
                          </xsl:otherwise>
                        </xsl:choose>
                      </MaximumEstimatedWeight>
                      <xsl:choose>

                        <xsl:when test="../s0:OIDLoop1/s0:OID/OID06/text() != ''">
                          <UnitType>
                            <xsl:value-of select="../s0:OIDLoop1/s0:OID/OID06/text()" />
                          </UnitType>
                        </xsl:when>

                        <xsl:when test="s0:AT8_2/AT802">
                          <UnitType>
                            <xsl:value-of select="s0:AT8_2/AT802/text()" />
                            <!--<xsl:call-template name="TotalWeightUnitMapValue">
                              <xsl:with-param name="ValueToConvert" select="s0:AT8_2/AT802/text()" />
                            </xsl:call-template>-->
                          </UnitType>
                        </xsl:when>
                        <xsl:otherwise>
                          <UnitType>L</UnitType>
                        </xsl:otherwise>
                      </xsl:choose>
                      <xsl:if test="count(../s0:L5Loop1/s0:G61Loop1/s0:L11_4) > 0">
                        <ItemReferences>
                          <xsl:for-each select="../s0:L5Loop1/s0:G61Loop1/s0:L11_4">
                            <ItemReference>
                              <ItemReferenceCode>
                                <xsl:value-of select="L1102/text()" />
                              </ItemReferenceCode>
                              <ItemReferenceValue>
                                <xsl:value-of select="L1101/text()" />
                              </ItemReferenceValue>
                              <ItemReferenceDescription>
                                <xsl:value-of select="L1103/text()" />
                              </ItemReferenceDescription>
                              <ItemReferenceType>EDI</ItemReferenceType>
                            </ItemReference>
                          </xsl:for-each>
                        </ItemReferences>
                      </xsl:if>
                    </StopLineItem>
                  </xsl:for-each>
                </xsl:when>
                
                <xsl:when test="s0:OIDLoop1/s0:L5Loop2/s0:L5_2/L502!=''">
              
                  <xsl:for-each select="s0:OIDLoop1">
                    <xsl:for-each select="s0:L5Loop2">
                      <StopLineItem>
                        <xsl:choose>
                          <xsl:when test="s0:L5_2/L502">
                            <xsl:attribute name="id">
                              <xsl:value-of select="'OIDLoop1.L5Loop2.L502'"/>
                            </xsl:attribute>
                            <xsl:attribute name="productId">
                                <xsl:value-of select="s0:L5_2/L502/text()" />
                            </xsl:attribute>
                          <ProductDescription>
                            <xsl:value-of select="s0:L5_2/L502/text()" />
                          </ProductDescription>
                          </xsl:when>
                        </xsl:choose>
                        <xsl:if test="s0:G61Loop2/s0:LH6_3/LH602">
                          <Hazmat>
                            <xsl:value-of select="s0:G61Loop2/s0:LH6_3/LH602/text()" />
                          </Hazmat>
                        </xsl:if>
                        <xsl:choose>
                        <xsl:when test="../s0:OID/OID04">
                          <PackagingType>
                            <xsl:value-of select="../s0:OID/OID04/text()" />
                            <!--<xsl:call-template name="PackagingTypeMapValue">
                              <xsl:with-param name="ValueToConvert" select="../s0:LAD_2/LAD01/text()" />
                            </xsl:call-template>-->
                          </PackagingType>
                        </xsl:when>
                         <xsl:otherwise>
                            <PackagingType>PCS</PackagingType>
                          </xsl:otherwise>
                         </xsl:choose>
                         
                      <xsl:choose>
                        <xsl:when test="../s0:OID/OID05/text()!=''">
                          <PackageQuantity>
                            <xsl:value-of select="../s0:OID/OID05/text()" />
                          </PackageQuantity>
                        </xsl:when>
                          <xsl:when test="../../s0:AT8/AT804/text()!=''">
                          <PackageQuantity>
                            <xsl:value-of select="../../s0:AT8/AT804/text()" />
                          </PackageQuantity>
                        </xsl:when>
                        
                        <xsl:when test="../s0:LAD_2/LAD02/text()!=''">
                          <PackageQuantity>
                            <xsl:value-of select="../s0:LAD_2/LAD02/text()" />
                          </PackageQuantity>
                        </xsl:when>
                         <xsl:when test="../../s0:LAD/LAD02/text()!=''">
                          <PackageQuantity>
                            <xsl:value-of select="../../s0:LAD/LAD02/text()" />
                          </PackageQuantity>
                        </xsl:when>
                        <xsl:otherwise>
                          <PackageQuantity>1</PackageQuantity>
                        </xsl:otherwise>
                        </xsl:choose>
                        
                        <xsl:choose>
                           <xsl:when test="../s0:LAD_2/LAD01/text()!=''">
                          <HandlingType>
                            <xsl:value-of select="../s0:LAD_2/LAD01/text()" />
                            <!--<xsl:call-template name="HandlingTypeMapValue">
                              <xsl:with-param name="ValueToConvert" select="../s0:OID/OID04/text()" />
                            </xsl:call-template>-->                            
                          </HandlingType>
                        </xsl:when>
                           <xsl:when test="../../s0:LAD/LAD01/text()!=''">
                          <HandlingType>
                            <xsl:value-of select="../../s0:LAD/LAD01/text()" />
                            <!--<xsl:call-template name="HandlingTypeMapValue">
                              <xsl:with-param name="ValueToConvert" select="../s0:OID/OID04/text()" />
                            </xsl:call-template>-->                            
                          </HandlingType>
                        </xsl:when>
                        <xsl:when test="../s0:OID/OID04!=''">
                          <HandlingType>
                            <xsl:value-of select="s0:OID/OID04/text()" />
                            <!--<xsl:call-template name="HandlingTypeMapValue">
                              <xsl:with-param name="ValueToConvert" select="../s0:OID/OID04/text()" />
                            </xsl:call-template>-->                            
                          </HandlingType>
                        </xsl:when>
                       
                        </xsl:choose>
                         
                        <xsl:choose>
                          <xsl:when test="../s0:LAD_2/LAD02/text()!=''">
                          <HandlingUnitQuantity>
                            <xsl:value-of select="../s0:LAD_2/LAD02/text()" />
                          </HandlingUnitQuantity>
                        </xsl:when>
                           <xsl:when test="../../s0:LAD/LAD02/text()!=''">
                          <HandlingUnitQuantity>
                            <xsl:value-of select="../../s0:LAD/LAD02/text()" />
                          </HandlingUnitQuantity>
                        </xsl:when>
                          <xsl:when test="s0:AT8_3/AT805/text()!=''">
                            <HandlingUnitQuantity>
                              <xsl:value-of select="s0:AT8_3/AT805/text()" />
                            </HandlingUnitQuantity>
                          </xsl:when>
                          <xsl:when test="s0:AT8_3/AT804/text()!=''">
                            <HandlingUnitQuantity>
                              <xsl:value-of select="s0:AT8_3/AT804/text()" />
                            </HandlingUnitQuantity>
                          </xsl:when>
                          <xsl:when test="../../s0:AT8/AT804/text()!=''">
                          <HandlingUnitQuantity>
                            <xsl:value-of select="../../s0:AT8/AT804/text()" />
                          </HandlingUnitQuantity>
                        </xsl:when>
                        <xsl:when test="../s0:OID/OID05/text()!=''">
                          <HandlingUnitQuantity>
                            <xsl:value-of select="../s0:OID/OID05/text()" />
                          </HandlingUnitQuantity>
                        </xsl:when>
                        
                        </xsl:choose>
                          
                         <xsl:choose>
                          <xsl:when test="s0:L5_2/L509/text()!=''">
                            <FreightClass>
                              <xsl:value-of select="s0:L5_2/L509/text()" />
                            </FreightClass>
                          </xsl:when>
                          <xsl:when test="s0:L5_2/L503/text()!=''">
                            <FreightClass>
                              <xsl:value-of select="s0:L5_2/L503/text()" />
                            </FreightClass>
                          </xsl:when>
                        </xsl:choose>
                        <xsl:if test="s0:L5_2/L503">
                          <NMFC>
                            <xsl:value-of select="s0:L5_2/L503/text()" />
                          </NMFC>
                        </xsl:if>
                        <xsl:if test="s0:L5_2/L505">
                          <NMFCSub>
                            <xsl:value-of select="s0:L5_2/L505/text()" />
                          </NMFCSub>
                        </xsl:if>
                        <xsl:choose>
                          <xsl:when test="s0:AT8_3/AT803/text()!=''">
                            <MinimumEstimatedWeight>
                              <xsl:choose>
                                <xsl:when test="not(number(s0:AT8_3/AT803/text()))">
                                  <xsl:value-of select="'0'" />
                                </xsl:when>
                                <xsl:otherwise>
                                  <xsl:value-of select="s0:AT8_3/AT803/text()" />
                                </xsl:otherwise>
                              </xsl:choose>
                            </MinimumEstimatedWeight>
                          </xsl:when>
                          <xsl:when test="../../s0:AT8/AT803/text()!=''">
                            <MinimumEstimatedWeight>
                              <xsl:choose>
                                <xsl:when test="not(number(../../s0:AT8/AT803/text()))">
                                  <xsl:value-of select="'0'" />
                                </xsl:when>
                                <xsl:otherwise>
                                  <xsl:value-of select="../../s0:AT8/AT803/text()" />
                                </xsl:otherwise>
                              </xsl:choose>
                            </MinimumEstimatedWeight>
                            
                          </xsl:when>
                          <xsl:when test="../s0:OID/OID07/text()!=''">
                            <MinimumEstimatedWeight>
                              <xsl:choose>
                                <xsl:when test="not(number(../s0:OID/OID07/text()))">
                                  <xsl:value-of select="'0'" />
                                </xsl:when>
                                <xsl:otherwise>
                                  <xsl:value-of select="../s0:OID/OID07/text()" />
                                </xsl:otherwise>
                              </xsl:choose>
                            </MinimumEstimatedWeight>

                          </xsl:when>
                        </xsl:choose>
                       
                        <xsl:choose>
                          <xsl:when test="s0:AT8_3/AT803">
                            <MaximumEstimatedWeight>
                              <xsl:choose>
                                <xsl:when test="not(number(s0:AT8_3/AT803/text()))">
                                  <xsl:value-of select="'0'" />
                                </xsl:when>
                                <xsl:otherwise>
                                  <xsl:value-of select="s0:AT8_3/AT803/text()" />
                                </xsl:otherwise>
                              </xsl:choose>
                            </MaximumEstimatedWeight>
                          </xsl:when>
                         <xsl:when test="../../s0:AT8/AT803/text()!=''">
                            <MaximumEstimatedWeight>
                              <xsl:choose>
                                <xsl:when test="not(number(../../s0:AT8/AT803/text()))">
                                  <xsl:value-of select="'0'" />
                                </xsl:when>
                                <xsl:otherwise>
                                  <xsl:value-of select="../../s0:AT8/AT803/text()" />
                                </xsl:otherwise>
                              </xsl:choose>
                            </MaximumEstimatedWeight>
                            
                          </xsl:when>
                          <xsl:when test="../s0:OID/OID07/text()!=''">
                            <MaximumEstimatedWeight>
                              <xsl:choose>
                                <xsl:when test="not(number(../s0:OID/OID07/text()))">
                                  <xsl:value-of select="'0'" />
                                </xsl:when>
                                <xsl:otherwise>
                                  <xsl:value-of select="../s0:OID/OID07/text()" />
                                </xsl:otherwise>
                              </xsl:choose>
                            </MaximumEstimatedWeight>
                            
                          </xsl:when>
                        </xsl:choose>
                        
                        <xsl:choose>
                        <xsl:when test="s0:AT8_3/AT802/text()!=''">
                          <UnitType>
                            <xsl:value-of select="s0:AT8_3/AT802/text()" />
                            <!--<xsl:call-template name="TotalWeightUnitMapValue">
                              <xsl:with-param name="ValueToConvert" select="s0:AT8_3/AT802/text()" />
                            </xsl:call-template>-->
                          </UnitType>
                        </xsl:when>
                        <xsl:when test="../../s0:AT8/AT802/text()!=''">
                          <UnitType>
                            <xsl:value-of select="../../s0:AT8/AT802/text()" />
                            <!--<xsl:call-template name="TotalWeightUnitMapValue">
                              <xsl:with-param name="ValueToConvert" select="s0:AT8_3/AT802/text()" />
                            </xsl:call-template>-->
                          </UnitType>
                        </xsl:when>
                          <xsl:when test="../s0:OID/OID06/text()!=''">
                            <UnitType>
                              <xsl:value-of select="../s0:OID/OID06/text()" />
                              <!--<xsl:call-template name="TotalWeightUnitMapValue">
                              <xsl:with-param name="ValueToConvert" select="s0:AT8_3/AT802/text()" />
                            </xsl:call-template>-->
                            </UnitType>
                          </xsl:when>
                        </xsl:choose>

                        <ItemReferences>

                          <ItemReference>
                            <ItemReferenceCode>
                              <xsl:value-of select="'L5'" />
                            </ItemReferenceCode>
                            <ItemReferenceValue>
                              <xsl:value-of select="substring(s0:L5_2/L502/text(),1,30)" />
                            </ItemReferenceValue>
                            <ItemReferenceDescription>
                              <xsl:value-of select="s0:L5_2/L502/text()" />
                            </ItemReferenceDescription>
                            <ItemReferenceType>EDI.L502/</ItemReferenceType>
                          </ItemReference>
                          <xsl:for-each select="../s0:OID">
                            <ItemReference>
                              <ItemReferenceCode>
                                <xsl:value-of select="'OI'" />
                              </ItemReferenceCode>
                              <ItemReferenceValue>
                                <xsl:value-of select="substring(OID01/text(),1,30)" />
                              </ItemReferenceValue>
                              <ItemReferenceDescription>
                              <xsl:value-of select="OID01/text()" />
                            </ItemReferenceDescription>
                              <ItemReferenceType>EDI.OID01</ItemReferenceType>
                            </ItemReference>
                          </xsl:for-each>
                          <xsl:for-each select="s0:G61Loop2/s0:L11_5">
                            <ItemReference>
                              <ItemReferenceCode>
                                <xsl:value-of select="L1102/text()" />
                              </ItemReferenceCode>
                              <ItemReferenceValue>
                                <xsl:value-of select="L1101/text()" />
                              </ItemReferenceValue>
                              <ItemReferenceDescription>
                                <xsl:value-of select="L1103/text()" />
                              </ItemReferenceDescription>
                              <ItemReferenceType>EDI.G61Loop2</ItemReferenceType>
                            </ItemReference>
                          </xsl:for-each>
                        </ItemReferences>
                        
                      </StopLineItem>
                      </xsl:for-each>                
                  </xsl:for-each>
                </xsl:when>
                
                
                <xsl:when test="s0:OIDLoop1/s0:OID">              
                  <xsl:for-each select="s0:OIDLoop1">
                      <StopLineItem>
                        <xsl:choose>
                           <xsl:when test="s0:LAD_2/LAD13/text()!=''">
                             <xsl:attribute name="id">
                              <xsl:value-of select="'OIDLoop1.OID.LAD13'"/>
                            </xsl:attribute>
                            <xsl:attribute name="productId">
                                <xsl:value-of select="s0:LAD_2/LAD13/text()" />
                            </xsl:attribute>
                            <ProductDescription>
                              <xsl:value-of select="s0:LAD_2/LAD13/text()" />
                            </ProductDescription>
                          </xsl:when>
                          <xsl:when test="s0:OID/OID02/text()!=''">
                            <xsl:attribute name="id">
                              <xsl:value-of select="'OIDLoop1.OID.OID02'"/>
                            </xsl:attribute>
                            <xsl:attribute name="productId">
                                <xsl:value-of select="s0:OID/OID02/text()" />
                            </xsl:attribute>
                            <ProductDescription>
                              <xsl:value-of select="s0:OID/OID02/text()" />
                            </ProductDescription>
                          </xsl:when>
                          <xsl:when test="s0:OID/OID01/text()!=''">
                            <xsl:attribute name="id">
                              <xsl:value-of select="'OIDLoop1.OID.OID01'"/>
                            </xsl:attribute>
                            <xsl:attribute name="productId">
                                <xsl:value-of select="s0:OID/OID01/text()" />
                            </xsl:attribute>
                            <ProductDescription>
                              <xsl:value-of select="s0:OID/OID01/text()" />
                            </ProductDescription>
                          </xsl:when>
                        <xsl:otherwise>
                           <xsl:attribute name="id">
                              <xsl:value-of select="'OIDLoop1.OID'"/>
                            </xsl:attribute>
                            <xsl:attribute name="productId">
                                <xsl:value-of select="'UNKNOWN'" />
                            </xsl:attribute>
                          <ProductDescription>UNKNOWN</ProductDescription>
                        </xsl:otherwise>
                        </xsl:choose>
                        <xsl:choose>
                          <xsl:when test="../s0:L5Loop1['1']/s0:G61Loop1/s0:LH6_2/LH602">
                            <Hazmat>
                              <xsl:value-of select="../s0:L5Loop1['1']/s0:G61Loop1/s0:LH6_2/LH602/text()" />
                            </Hazmat>
                          </xsl:when>
                          <xsl:when test="s0:L5Loop2['1']/s0:G61Loop2/s0:LH6_3/LH602">
                            <Hazmat>
                              <xsl:value-of select="../s0:L5Loop2['1']/s0:G61Loop2/s0:LH6_3/LH602/text()" />
                            </Hazmat>
                          </xsl:when>
                        </xsl:choose>
                        <xsl:choose>
                          <xsl:when test="s0:OID/OID04/text()!=''">
                            <PackagingType>
                              <xsl:value-of select="s0:OID/OID04/text()" />
                              <!--<xsl:call-template name="HandlingTypeMapValue">
                              <xsl:with-param name="ValueToConvert" select="s0:OID/OID04/text()" />
                            </xsl:call-template>-->
                            </PackagingType>
                          </xsl:when>
                        <xsl:when test="s0:LAD_2/LAD01/text()!=''">
                          <PackagingType>
                            <xsl:value-of select="s0:LAD_2/LAD01/text()" />
                            <!--<xsl:call-template name="PackagingTypeMapValue">
                              <xsl:with-param name="ValueToConvert" select="../s0:LAD_2/LAD01/text()" />
                            </xsl:call-template>-->
                          </PackagingType>
                        </xsl:when>
                          
                          <xsl:otherwise>
                            <PackagingType>PCS</PackagingType>
                          </xsl:otherwise>
                        </xsl:choose>
                        <xsl:choose>
                           <xsl:when test="s0:OID/OID05['1']/text()!=''">
                            <PackageQuantity>
                              <xsl:value-of select="s0:OID/OID05['1']/text()" />
                            </PackageQuantity>
                          </xsl:when>
                          <xsl:when test="s0:LAD_2/LAD02/text()!=''">
                            <PackageQuantity>
                              <xsl:value-of select="s0:LAD_2/LAD02/text()" />
                            </PackageQuantity>
                          </xsl:when>
                         
                           <xsl:otherwise>
                            <PackageQuantity>1</PackageQuantity>
                          </xsl:otherwise>
                        </xsl:choose>
                     <xsl:choose>
                        <xsl:when test="s0:LAD_2/LAD01/text()!=''">
                          <HandlingType>
                            <xsl:value-of select="s0:LAD_2/LAD01/text()" />
                            <!--<xsl:call-template name="HandlingTypeMapValue">
                              <xsl:with-param name="ValueToConvert" select="s0:OID/OID04/text()" />
                            </xsl:call-template>-->                            
                          </HandlingType>
                        </xsl:when>
                       <xsl:when test="../s0:PLD_2/PLD01/text() != ''">
                         <HandlingType>
                           <xsl:value-of select="'PLT'" />
                         </HandlingType>
                       </xsl:when>
                     </xsl:choose>
                     <xsl:choose>
                        <xsl:when test="s0:LAD_2/LAD02/text()!=''">
                          <HandlingUnitQuantity>
                            <xsl:value-of select="s0:LAD_2/LAD02/text()" />
                          </HandlingUnitQuantity>
                        </xsl:when>
                         <xsl:when test="s0:AT8_2/AT804/text() != ''">
                        <HandlingUnitQuantity>
                            <xsl:value-of select="s0:AT8_2/AT804/text()" />
                        </HandlingUnitQuantity>
                      </xsl:when>
                        <xsl:when test="../s0:PLD_2/PLD01/text() != ''">
                        <HandlingUnitQuantity>
                            <xsl:value-of select="../s0:PLD_2/PLD01/text()" />
                        </HandlingUnitQuantity>
                      </xsl:when>
                       <xsl:when test="../s0:AT8/AT804/text() != ''">
                         <HandlingUnitQuantity>
                           <xsl:value-of select="../s0:AT8/AT804/text()" />
                         </HandlingUnitQuantity>
                       </xsl:when>
                     </xsl:choose>
                        
                        <xsl:choose>
                          <xsl:when test="s0:L5_2/L509/text()!=''">
                            <FreightClass>
                              <xsl:value-of select="s0:L5_2/L509/text()" />
                            </FreightClass>
                          </xsl:when>
                          <xsl:when test="s0:L5_2/L503/text()!=''">
                            <FreightClass>
                              <xsl:value-of select="s0:L5_2/L503/text()" />
                            </FreightClass>
                          </xsl:when>
                        </xsl:choose>
                        <xsl:if test="s0:L5_2/L503">
                          <NMFC>
                            <xsl:value-of select="s0:L5_2/L503/text()" />
                          </NMFC>
                        </xsl:if>
                        <xsl:if test="s0:L5_2/L505">
                          <NMFCSub>
                            <xsl:value-of select="s0:L5_2/L505/text()" />
                          </NMFCSub>
                        </xsl:if>
                        
                        <xsl:choose>
                          <xsl:when test="s0:AT8_3/AT803/text()!=''">
                            <MinimumEstimatedWeight>
                              <xsl:choose>
                                <xsl:when test="not(number(s0:AT8_3/AT803/text()))">
                                  <xsl:value-of select="'0'" />
                                </xsl:when>
                                <xsl:otherwise>
                                  <xsl:value-of select="s0:AT8_3/AT803/text()" />
                                </xsl:otherwise>
                              </xsl:choose>
                            </MinimumEstimatedWeight>
                          </xsl:when>
                          <xsl:when test="../s0:AT8/AT803/text()!=''">
                            <MinimumEstimatedWeight>
                              <xsl:choose>
                                <xsl:when test="not(number(../s0:AT8/AT803/text()))">
                                  <xsl:value-of select="'0'" />
                                </xsl:when>
                                <xsl:otherwise>
                                  <xsl:value-of select="../s0:AT8/AT803/text()" />
                                </xsl:otherwise>
                              </xsl:choose>
                            </MinimumEstimatedWeight>
                          </xsl:when>
                          <xsl:when test="s0:OID/OID07/text()!=''">
                            <xsl:choose>
                              <xsl:when test="not(number(s0:OID/OID07/text()))">
                                <MinimumEstimatedWeight>
                                  <xsl:value-of select="'0'" />
                                </MinimumEstimatedWeight>
                              </xsl:when>
                              <xsl:otherwise>
                                <MinimumEstimatedWeight>
                                  <xsl:value-of select="s0:OID/OID07/text()" />
                                </MinimumEstimatedWeight>
                              </xsl:otherwise>
                            </xsl:choose>
                          </xsl:when>
                          <xsl:when test="../s0:S5/S503/text()!=''">
                            <xsl:choose>
                              <xsl:when test="not(number(../s0:S5/S503/text()))">
                                <MinimumEstimatedWeight>
                                  <xsl:value-of select="'0'" />
                                </MinimumEstimatedWeight>
                              </xsl:when>
                              <xsl:otherwise>
                                <MinimumEstimatedWeight>
                                  <xsl:value-of select="../s0:S5/S503/text()" />
                                </MinimumEstimatedWeight>
                              </xsl:otherwise>
                            </xsl:choose>
                          </xsl:when>
                        </xsl:choose>
                        
                        <xsl:choose>
                        <xsl:when test="s0:AT8_3/AT803/text()!=''">
                          <MaximumEstimatedWeight>
                            <xsl:choose>
                              <xsl:when test="not(number(s0:AT8_3/AT803/text()))">
                                <xsl:value-of select="'0'" />
                              </xsl:when>
                              <xsl:otherwise>
                                <xsl:value-of select="s0:AT8_3/AT803/text()" />
                              </xsl:otherwise>
                            </xsl:choose>
                          </MaximumEstimatedWeight>
                        </xsl:when>
                          <xsl:when test="../s0:AT8/AT803/text()!=''">
                            <MaximumEstimatedWeight>
                              <xsl:choose>
                                <xsl:when test="not(number(../s0:AT8/AT803/text()))">
                                  <xsl:value-of select="'0'" />
                                </xsl:when>
                                <xsl:otherwise>
                                  <xsl:value-of select="../s0:AT8/AT803/text()" />
                                </xsl:otherwise>
                              </xsl:choose>
                            </MaximumEstimatedWeight>
                          </xsl:when>
                          <xsl:when test="s0:OID/OID07/text()!=''">
                            <xsl:choose>
                              <xsl:when test="not(number(s0:OID/OID07/text()))">
                                <MaximumEstimatedWeight>
                                  <xsl:value-of select="'0'" />
                                </MaximumEstimatedWeight>
                              </xsl:when>
                              <xsl:otherwise>
                                <MaximumEstimatedWeight>
                                  <xsl:value-of select="s0:OID/OID07/text()" />
                                </MaximumEstimatedWeight>
                              </xsl:otherwise>
                            </xsl:choose>
                          </xsl:when>
                          <xsl:when test="../s0:S5/S503/text()!=''">
                            <xsl:choose>
                              <xsl:when test="not(number(../s0:S5/S503/text()))">
                                <MaximumEstimatedWeight>
                                  <xsl:value-of select="'0'" />
                                </MaximumEstimatedWeight>
                              </xsl:when>
                              <xsl:otherwise>
                                <MaximumEstimatedWeight>
                                  <xsl:value-of select="../s0:S5/S503/text()" />
                                </MaximumEstimatedWeight>
                              </xsl:otherwise>
                            </xsl:choose>
                          </xsl:when>
                        </xsl:choose>
                        
                        <xsl:choose>
                          <xsl:when test="s0:AT8_3/AT802">
                            <UnitType>
                              <xsl:value-of select="s0:AT8_3/AT802/text()" />
                              <!--<xsl:call-template name="TotalWeightUnitMapValue">
                                <xsl:with-param name="ValueToConvert" select="s0:AT8_3/AT802/text()" />
                              </xsl:call-template>-->
                            </UnitType>
                          </xsl:when>
                          <xsl:when test="s0:OID/OID06">
                            <UnitType>
                              <xsl:value-of select="s0:OID/OID06/text()" />
                              <!--<xsl:call-template name="TotalWeightUnitMapValue">
                                <xsl:with-param name="ValueToConvert" select="s0:OID/OID06/text()" />
                              </xsl:call-template>-->
                            </UnitType>
                          </xsl:when>
                          <xsl:otherwise>
                            <UnitType>L</UnitType>
                          </xsl:otherwise>
                          
                        </xsl:choose>

                        <ItemReferences>
                          <ItemReference>
                            <ItemReferenceCode>
                              <xsl:value-of select="'ZZ'" />
                            </ItemReferenceCode>
                            <ItemReferenceValue>
                              <xsl:value-of select="substring(s0:LAD_2/LAD08/text(),1,30)" />
                            </ItemReferenceValue>
                            <ItemReferenceDescription>
                              <xsl:value-of select="s0:LAD_2/LAD08/text()" />
                            </ItemReferenceDescription>
                            <ItemReferenceType>EDI.LAD_2.LAD08</ItemReferenceType>
                          </ItemReference>
                          <xsl:for-each select="../s0:L5Loop1/s0:G61Loop1/s0:L11_4">
                            <ItemReference>
                              <ItemReferenceCode>
                                <xsl:value-of select="L1102/text()" />
                              </ItemReferenceCode>
                              <ItemReferenceValue>
                                <xsl:value-of select="L1101/text()" />
                              </ItemReferenceValue>
                              <ItemReferenceDescription>
                                <xsl:value-of select="L1103/text()" />
                              </ItemReferenceDescription>
                              <ItemReferenceType>EDI</ItemReferenceType>
                            </ItemReference>
                          </xsl:for-each>
                        </ItemReferences>
                        
                      </StopLineItem>
                      </xsl:for-each> 
                </xsl:when>

                <xsl:otherwise>
                  <StopLineItem>
                    <xsl:choose>
                      <xsl:when test="s0:S5/S509!=''">
                        <xsl:attribute name="id">
                          <xsl:value-of select="'S5.S509'"/>
                        </xsl:attribute>
                        <xsl:attribute name="productId">
                          <xsl:value-of select="s0:S5/S509/text()" />
                        </xsl:attribute>
                        <ProductDescription>
                          <xsl:value-of select="s0:S5/S509/text()" />
                        </ProductDescription>
                      </xsl:when>
                      <xsl:otherwise>
                        <xsl:attribute name="id">
                          <xsl:value-of select="'S5.OTHERWISE'"/>
                        </xsl:attribute>
                        <xsl:attribute name="productId">
                          <xsl:value-of select="'UNKNOWN'" />
                        </xsl:attribute>
                        <ProductDescription>UNKNOWN</ProductDescription>
                      </xsl:otherwise>
                    </xsl:choose>
                    <xsl:if test="../s0:L5Loop1['1']/s0:G61Loop1/s0:LH6_2/LH602">
                      <Hazmat>
                        <xsl:value-of select="../s0:L5Loop1['1']/s0:G61Loop1/s0:LH6_2/LH602/text()" />
                      </Hazmat>
                    </xsl:if>
                    <PackagingType>PCS</PackagingType>
                    <xsl:choose>
                      <xsl:when test="s0:S5/S505/text()!=''">
                        <PackageQuantity>
                          <xsl:value-of select="s0:S5/S505/text()" />
                        </PackageQuantity>
                      </xsl:when>
                      <xsl:when test="s0:AT8/AT804/text()!=''">
                        <PackageQuantity>
                          <xsl:value-of select="s0:AT8/AT804/text()" />
                        </PackageQuantity>
                      </xsl:when>
                      <xsl:otherwise>
                        <PackageQuantity>1</PackageQuantity>
                      </xsl:otherwise>
                    </xsl:choose>
                    <xsl:choose>
                      <xsl:when test="s0:S5/S506">
                        <HandlingType>
                          <xsl:value-of select="s0:S5/S506/text()" />
                          <!--<xsl:call-template name="HandlingTypeMapValue">
                                <xsl:with-param name="ValueToConvert" select="s0:OID/OID04/text()" />
                              </xsl:call-template>-->
                        </HandlingType>
                      </xsl:when>
                      <xsl:otherwise>
                        <HandlingType>PL</HandlingType>
                      </xsl:otherwise>
                    </xsl:choose>
                    <xsl:choose>
                      <xsl:when test="s0:S5/S505/text()!=''">
                        <HandlingUnitQuantity>
                          <xsl:value-of select="s0:S5/S505/text()" />
                        </HandlingUnitQuantity>
                      </xsl:when>
                      <xsl:when test="s0:LAD/LAD02/text()!=''">
                        <HandlingUnitQuantity>
                          <xsl:value-of select="s0:LAD/LAD02/text()" />
                        </HandlingUnitQuantity>
                      </xsl:when>
                    </xsl:choose>

                    <xsl:choose>
                      <xsl:when test="s0:L5_2/L509/text()!=''">
                        <FreightClass>
                          <xsl:value-of select="s0:L5_2/L509/text()" />
                        </FreightClass>
                      </xsl:when>
                      <xsl:when test="s0:L5_2/L503/text()!=''">
                        <FreightClass>
                          <xsl:value-of select="s0:L5_2/L503/text()" />
                        </FreightClass>
                      </xsl:when>
                    </xsl:choose>
                    <xsl:if test="s0:L5_2/L503">
                      <NMFC>
                        <xsl:value-of select="s0:L5_2/L503/text()" />
                      </NMFC>
                    </xsl:if>
                    <xsl:if test="s0:L5_2/L505">
                      <NMFCSub>
                        <xsl:value-of select="s0:L5_2/L505/text()" />
                      </NMFCSub>
                    </xsl:if>
                    <xsl:choose>
                      <xsl:when test="s0:S5/S503">
                        <MinimumEstimatedWeight>
                          <xsl:choose>
                            <xsl:when test="not(number(s0:S5/S503/text()))">
                              <xsl:value-of select="'0'" />
                            </xsl:when>
                            <xsl:otherwise>
                              <xsl:value-of select="s0:S5/S503/text()" />
                            </xsl:otherwise>
                          </xsl:choose>
                        </MinimumEstimatedWeight>
                      </xsl:when>
                      <xsl:when test="s0:AT8/AT803/text()!=''">
                        <MinimumEstimatedWeight>
                          <xsl:value-of select="s0:AT8/AT803/text()" />
                        </MinimumEstimatedWeight>
                      </xsl:when>
                      <xsl:when test="not(number(//s0:L3/L301/text()))">
                        <MinimumEstimatedWeight>
                          <xsl:value-of select="'0'" />
                        </MinimumEstimatedWeight>
                      </xsl:when>
                      <xsl:otherwise>
                        <MinimumEstimatedWeight>
                          <xsl:value-of select="//s0:L3/L301/text()" />
                        </MinimumEstimatedWeight>
                      </xsl:otherwise>
                    </xsl:choose>
                    <xsl:choose>
                      <xsl:when test="s0:S5/S503">
                        <MaximumEstimatedWeight>
                          <xsl:choose>
                            <xsl:when test="not(number(s0:S5/S503/text()))">
                              <xsl:value-of select="'0'" />
                            </xsl:when>
                            <xsl:otherwise>
                              <xsl:value-of select="s0:S5/S503/text()" />
                            </xsl:otherwise>
                          </xsl:choose>
                        </MaximumEstimatedWeight>
                      </xsl:when>
                      <xsl:when test="s0:AT8/AT803/text()!=''">
                        <MaximumEstimatedWeight>
                          <xsl:value-of select="s0:AT8/AT803/text()" />
                        </MaximumEstimatedWeight>
                      </xsl:when>
                      <xsl:when test="not(number(//s0:L3/L301/text()))">
                        <MaximumEstimatedWeight>
                          <xsl:value-of select="'0'" />
                        </MaximumEstimatedWeight>
                      </xsl:when>
                      <xsl:otherwise>
                        <MaximumEstimatedWeight>
                          <xsl:value-of select="//s0:L3/L301/text()" />
                        </MaximumEstimatedWeight>
                      </xsl:otherwise>
                    </xsl:choose>
                    <xsl:choose>
                      <xsl:when test="s0:S5/S504">
                        <UnitType>
                          <xsl:value-of select="s0:S5/S504/text()" />
                          <!--<xsl:call-template name="TotalWeightUnitMapValue">
                                <xsl:with-param name="ValueToConvert" select="s0:AT8_3/AT802/text()" />
                              </xsl:call-template>-->
                        </UnitType>
                      </xsl:when>
                      <xsl:otherwise>
                        <UnitType>L</UnitType>
                      </xsl:otherwise>

                    </xsl:choose>

                    <xsl:if test="count(../s0:L5Loop1/s0:G61Loop1/s0:L11_4) > 0">
                      <ItemReferences>
                        <xsl:for-each select="../s0:L5Loop1/s0:G61Loop1/s0:L11_4">
                          <ItemReference>
                            <ItemReferenceCode>
                              <xsl:value-of select="L1102/text()" />
                            </ItemReferenceCode>
                            <ItemReferenceValue>
                              <xsl:value-of select="L1101/text()" />
                            </ItemReferenceValue>
                            <ItemReferenceDescription>
                              <xsl:value-of select="L1103/text()" />
                            </ItemReferenceDescription>
                            <ItemReferenceType>EDI</ItemReferenceType>
                          </ItemReference>
                        </xsl:for-each>
                      </ItemReferences>
                    </xsl:if>

                  </StopLineItem>
                </xsl:otherwise>
              </xsl:choose>
            </StopLineItems>

            

            <xsl:if test="s0:N1Loop2/s0:N1_2/N101">
              <Addresses>

                <xsl:for-each select="s0:N1Loop2">
                  <Address>

                    <xsl:attribute name="addressType">
                      <xsl:value-of select="s0:N1_2/N101/text()" />
                    </xsl:attribute>

                    <xsl:attribute name="accountIdType">
                      <xsl:value-of select="s0:N1_2/N103/text()" />
                    </xsl:attribute>

                    <xsl:attribute name="accountId">
                      <xsl:value-of select="s0:N1_2/N104/text()" />
                    </xsl:attribute>

                    <xsl:attribute name="name">
                      <xsl:value-of select="s0:N1_2/N102/text()" />
                    </xsl:attribute>

                    <xsl:if test="s0:N3_2/N301">
                      <xsl:attribute name="address1">
                        <xsl:value-of select="s0:N3_2/N301/text()" />
                      </xsl:attribute>
                    </xsl:if>
                    
                    <xsl:if test="s0:N3_2/N302">
                      <xsl:attribute name="address2">
                        <xsl:value-of select="s0:N3_2/N302/text()" />
                      </xsl:attribute>
                    </xsl:if>

                    <xsl:if test="s0:N4_2/N401">
                      <xsl:attribute name="city">
                        <xsl:value-of select="s0:N4_2/N401/text()" />
                      </xsl:attribute>
                    </xsl:if>

                    <xsl:if test="s0:N4_2/N402">
                      <xsl:attribute name="stateProvince">
                        <xsl:value-of select="s0:N4_2/N402/text()" />
                      </xsl:attribute>
                    </xsl:if>

                    <xsl:if test="s0:N4_2/N403">
                      <xsl:attribute name="postalCode">
                        <xsl:value-of select="s0:N4_2/N403/text()" />
                      </xsl:attribute>
                    </xsl:if>

                    <xsl:choose>
                      <xsl:when test="s0:N4_2/N404">
                        <xsl:attribute name="country">
                          <xsl:value-of select="s0:N4_2/N404/text()" />
                        </xsl:attribute>
                      </xsl:when>
                      <xsl:otherwise>
                        <xsl:attribute name="country">US</xsl:attribute>
                      </xsl:otherwise>
                    </xsl:choose>
                    
                    
                  </Address>
                </xsl:for-each>
              </Addresses>
            </xsl:if>
            
            <xsl:if test="s0:N1Loop2/s0:G61_2/G6102!='E'">
              <Contacts>
                <xsl:for-each select="s0:N1Loop2/s0:G61_2">
                  <Contact>
                    <xsl:attribute name="functionCode">
                      <xsl:value-of select="G6101/text()" />
                    </xsl:attribute>
                    <xsl:attribute name="name">
                      <xsl:value-of select="G6102/text()" />
                    </xsl:attribute>
                    <xsl:choose>
                      <xsl:when test="G6103='EM'">
                        <xsl:attribute name="email">
                          <xsl:value-of select="G6104/text()" />
                        </xsl:attribute>
                      </xsl:when>
                    </xsl:choose>
                    <xsl:choose>
                      <xsl:when test="G6103='TE' or G6103='WP' or G6103='WC' or G6103='SP'">
                        <xsl:attribute name="phone">
                          <xsl:value-of select="G6104/text()" />
                        </xsl:attribute>
                      </xsl:when>
                       <xsl:when test="G6103='OT' or G6103='NP' or G6103='IT' or G6103='HP'">
                        <xsl:attribute name="phone">
                          <xsl:value-of select="G6104/text()" />
                        </xsl:attribute>
                      </xsl:when>
                       <xsl:when test="G6103='EX' or G6103='CP' or G6103='AP' or G6103='AD'">
                        <xsl:attribute name="phone">
                          <xsl:value-of select="G6104/text()" />
                        </xsl:attribute>
                      </xsl:when>
                      <xsl:when test="G6103='PC' or G6103='PP'">
                        <xsl:attribute name="phone">
                          <xsl:value-of select="G6104/text()" />
                        </xsl:attribute>
                      </xsl:when>
                    </xsl:choose>
                    <xsl:attribute name="contactMethod">
                      <xsl:value-of select="G6103/text()" />
                    </xsl:attribute>
                    <xsl:attribute name="contactNumber">
                      <xsl:value-of select="G6104/text()" />
                    </xsl:attribute>
                    <xsl:attribute name="contactReference">
                      <xsl:value-of select="G6105/text()" />
                    </xsl:attribute>
                  </Contact>
                </xsl:for-each>
              </Contacts>
            </xsl:if>
              <Dates>
                <xsl:for-each select="s0:G62_2">
                  <Date>
                    <xsl:attribute name="dateType">EDI</xsl:attribute>
                    <xsl:attribute name="dateCode">
                      <xsl:value-of select="G6201/text()"/>
                    </xsl:attribute>
                    <xsl:attribute name="timeCode">
                      <xsl:value-of select="G6203/text()"/>
                    </xsl:attribute>
                    <xsl:attribute name="dateTime">
                      <xsl:value-of select="G6202/text()"/>T<xsl:value-of select="G6204/text()"/>
                    </xsl:attribute>                    
                    <xsl:attribute name="timeZone">
                      <xsl:value-of select="G6205/text()"/>
                    </xsl:attribute>
                  </Date>
                </xsl:for-each>
                <xsl:for-each select="s0:OIDLoop1/s0:G62_3">
                  <Date>
                    <xsl:attribute name="dateType">EDI</xsl:attribute>
                    <xsl:attribute name="dateCode">
                      <xsl:value-of select="G6201/text()"/>
                    </xsl:attribute>
                    <xsl:attribute name="timeCode">
                      <xsl:value-of select="G6203/text()"/>
                    </xsl:attribute>
                    <xsl:attribute name="dateTime">
                      <xsl:value-of select="G6202/text()"/>T<xsl:value-of select="G6204/text()"/>
                    </xsl:attribute>
                    <xsl:attribute name="timeZone">
                      <xsl:value-of select="G6205/text()"/>
                    </xsl:attribute>
                  </Date>
                </xsl:for-each>
              </Dates>

            <xsl:if test="count(s0:NTE_2)>'0' or count(s0:N1Loop2/s0:N3_2/N302) > '0'">
              <Notes>
                <xsl:for-each select="s0:N1Loop2">
                  <xsl:for-each select="s0:N3_2">
                    <xsl:if test="N302!=''">
                     <Note>
                      <xsl:attribute name="notePriority">
                        <xsl:value-of select="'-1'"/>
                      </xsl:attribute>
                      <xsl:attribute name="noteType">
                        <xsl:value-of select="'N302'"/>
                      </xsl:attribute>
                       <xsl:attribute name="noteVisibility">
                        <xsl:value-of select="'APP.EDI.BRE'"/>
                      </xsl:attribute>
                      <xsl:attribute name="note">
                        <xsl:text>Address 2 Line: </xsl:text>
                        <xsl:value-of select="N302/text()"/>
                      </xsl:attribute>
                    </Note>
                      </xsl:if>
                  </xsl:for-each>                
                  </xsl:for-each>
                <xsl:for-each select="s0:NTE_2">
                  <Note>
                    <xsl:attribute name="notePriority">
                      <xsl:value-of select="position()"/>
                    </xsl:attribute>
                    <xsl:attribute name="noteType">
                      <xsl:value-of select="NTE01/text()"/>
                    </xsl:attribute>
                    <xsl:attribute name="noteVisibility">
                        <xsl:value-of select="'EDI.NTE_2'"/>
                      </xsl:attribute>
                    <xsl:attribute name="note">
                      <xsl:value-of select="NTE02/text()"/>
                    </xsl:attribute>
                  </Note>
                </xsl:for-each>
              </Notes>
            </xsl:if>
            
          </Stop>
        </xsl:for-each>
      </Stops>
      <ShipmentTotals>        
        <xsl:choose>
          <xsl:when test="$vShipmentItemsL5 != '' ">
            <xsl:attribute name="ShipmentItemCount" >
               <xsl:value-of select="$vShipmentItemsL5"/>          
           </xsl:attribute>
          </xsl:when>
          <xsl:otherwise>
            <xsl:attribute name="ShipmentItemCount" >
                 <xsl:value-of select="$vShipmentItemsSansL5"/>          
             </xsl:attribute>
          </xsl:otherwise>
        </xsl:choose>
        <xsl:attribute name="ShipmentStops">
          <xsl:value-of select="$vShipmentStops" />       
        </xsl:attribute>
        <xsl:for-each select="s0:L3">
         <ShipmentTotal>
           <xsl:if test="L301">
            <xsl:attribute name="Weight">
              <xsl:value-of select="L301/text()"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L302">
            <xsl:attribute name="WeightType">
              <xsl:value-of select="L302/text()"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L303">
            <xsl:attribute name="FreightRate">
              <xsl:value-of select="L303/text()"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L304">
            <xsl:attribute name="FreightRateType">
              <xsl:value-of select="L304/text()"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L305">
             <xsl:variable name="vCharge" select="userCSharp:ConvertNnToNumeric(L305/text(),'N2')" />
            <xsl:attribute name="Charge">
              <xsl:value-of select="$vCharge"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L306">
             <xsl:variable name="vAdvances" select="userCSharp:ConvertNnToNumeric(L306/text(),'N2')" />
            <xsl:attribute name="Advances">
              <xsl:value-of select="$vAdvances"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L307">
             <xsl:variable name="vPrepaidAmmount" select="userCSharp:ConvertNnToNumeric(L307/text(),'N2')" />
            <xsl:attribute name="PrepaidAmmount">
              <xsl:value-of select="$vPrepaidAmmount"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L308">
            <xsl:attribute name="SpecialChargeCode">
              <xsl:value-of select="L308/text()"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L309">
            <xsl:attribute name="Volume">
              <xsl:value-of select="L309/text()"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L310">
            <xsl:attribute name="VolumeUnit">
              <xsl:value-of select="L310/text()"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L311">
            <xsl:attribute name="LadingQuantity">
              <xsl:value-of select="L311/text()"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L312">
            <xsl:attribute name="WeightUnit">
              <xsl:value-of select="L312/text()"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L313">
            <xsl:attribute name="TariffNumber">
              <xsl:value-of select="L313/text()"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L314">
             <xsl:variable name="vDeclaredValue" select="userCSharp:ConvertNnToNumeric(L314/text(),'N2')" />
            <xsl:attribute name="DeclaredValue">
              <xsl:value-of select="$vDeclaredValue"/>           
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="L315">
            <xsl:attribute name="DeclaredValueType">
              <xsl:value-of select="L315/text()"/>           
            </xsl:attribute>
           </xsl:if>
       
         </ShipmentTotal>
       </xsl:for-each>
      </ShipmentTotals>

      <xsl:variable name="vSourceOfNumberOfPallets">
       <xsl:choose>
          <xsl:when test="s0:PLD/PLD01/text()!=''">
            <xsl:value-of select="'PLD01'" />
          </xsl:when>
         <xsl:when test="s0:S5Loop1['1']/s0:PLD_2/PLD01/text()!=''">           
             <xsl:value-of select="'PLD01'"/>
         </xsl:when>
          <xsl:when test="s0:S5Loop1['1']/s0:OIDLoop1/s0:L5Loop2/s0:AT8_3/AT805/text()!=''">
            <xsl:value-of select="'S5Loop1.s0:OIDLoop1.s0:L5Loop2.s0:AT8_3.AT805'" />
          </xsl:when>
          <xsl:when test="s0:L3/L311/text()!=''">
            <xsl:value-of select="'L3.L311'" />
          </xsl:when>
          <xsl:when test="s0:S5Loop1['1']/s0:L5Loop1/s0:AT8_2/AT804/text()!=''">
              <xsl:value-of select="'S5Loop1.L5Loop1.AT8_2.AT804'"/>
          </xsl:when>
          <xsl:otherwise>
            <xsl:value-of select="'0'" />
          </xsl:otherwise>
        </xsl:choose>
      </xsl:variable>

      <ProcessingInstructions>        

        
        <xsl:if test="$vSourceOfNumberOfPallets != ''">
          <ProcessingInstruction>
            <xsl:attribute name="name">
              <xsl:value-of select="'SourceOfNumberOfPallets'" />
            </xsl:attribute>
            <xsl:attribute name="value">
              <xsl:value-of select="$vSourceOfNumberOfPallets" />
            </xsl:attribute>
            <xsl:attribute name="datatype">
              <xsl:value-of select="'string'" />
            </xsl:attribute>
            <xsl:attribute name="source">
              <xsl:value-of select="'Echo.BSSR.Surface.ShipmentIn.Maps.IB204_X5030'" />
            </xsl:attribute>
          </ProcessingInstruction>
        </xsl:if>
      </ProcessingInstructions>
    
    </ns0:Shipment>
  </xsl:template>

  <xsl:template name="HandlingTypeMapValue">
    <xsl:param name="ValueToConvert" select="0" />
    <xsl:variable name="HandlingTypeMap" >
      <map>
        <entry key="RL">1</entry>
        <entry key="SV">2</entry>
        <entry key="PL">3</entry>
        <entry key="PC">4</entry>
        <entry key="BA">5</entry>
        <entry key="PL">6</entry>
        <entry key="BX">7</entry>
        <entry key="CP">8</entry>
        <entry key="CA">8</entry>
      </map>
    </xsl:variable>
    <xsl:value-of select="msxsl:node-set($HandlingTypeMap)/map/entry[@key=$ValueToConvert]"/>
  </xsl:template>

  <xsl:template name="PackagingTypeMapValue">
    <xsl:param name="ValueToConvert" select="0" />
    <xsl:variable name="PackagingTypeMap" >
      <map>
        <entry key="BAG">1</entry>
        <entry key="BOX">2</entry>
        <entry key="CAN">3</entry>
        <entry key="CTN">4</entry>
        <entry key="CAS">5</entry>
        <entry key="CRT">6</entry>
        <entry key="DRM">7</entry>
        <entry key="EA">8</entry>
        <entry key="UNT">8</entry>
        <entry key="KEG">11</entry>
        <entry key="REL">14</entry>
        <entry key="ROL">15</entry>
        <entry key="TBN">16</entry>
        <entry key="TBE">17</entry>
        <entry key="BDL">18</entry>
        <entry key="PLT">19</entry>
        <entry key="PCS">20</entry>
      </map>
    </xsl:variable>
    <xsl:value-of select="msxsl:node-set($PackagingTypeMap)/map/entry[@key=$ValueToConvert]"/>
  </xsl:template>

  <xsl:template name="StopTypeMapValue">
    <xsl:param name="ValueToConvert" select="0" />
    <xsl:variable name="StopTypeMap" >
      <map>       
        <entry key="LD">1</entry>
        <entry key="PU">2</entry>
        <entry key="UL">2</entry>
        <entry key="CL">1</entry>
        <entry key="CN">1</entry>
        <entry key="CU">2</entry>
        <entry key="PL">1</entry>
        <entry key="AL">1</entry>
        <entry key="DR">1</entry>
        <entry key="DT">2</entry>
        <entry key="LE">1</entry>
        <entry key="PA">1</entry>
        <entry key="RT">1</entry>
        <entry key="SL">1</entry>
        <entry key="SU">2</entry>
        <entry key="TL">1</entry>
        <entry key="WL">1</entry>
        <entry key="Pick">1</entry>
        <entry key="Drop">2</entry>
        <entry key="1">1</entry>
        <entry key="2">2</entry>
      </map>
    </xsl:variable>
    <xsl:variable name="ValueConverted" select="msxsl:node-set($StopTypeMap)/map/entry[@key=$ValueToConvert]" />
    <xsl:choose>
      <xsl:when test="$ValueConverted">
        <xsl:value-of select="$ValueConverted"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="3"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>
  


  <xsl:template name="HazMatMapValue">
    <xsl:param name="ValueToConvert" select="0" />
    <xsl:variable name="vHazMatMap" >
      <map>
        <entry key="045">0</entry>
        <entry key="15">1</entry>
      </map>
    </xsl:variable>
    <xsl:value-of select="msxsl:node-set($vHazMatMap)/map/entry[@key=$ValueToConvert]"/>
  </xsl:template>

  <xsl:template name="ShipmentModeMapValue">
    <xsl:param name="ValueToConvert" select="0" />
    <xsl:variable name="vShipmentModeMap" >
      <map>
        <entry key="6">5</entry>
        <entry key="7">6</entry>
      </map>
    </xsl:variable>
    <xsl:value-of select="msxsl:node-set($vShipmentModeMap)/map/entry[@key=$ValueToConvert]"/>
  </xsl:template>
  <xsl:template name="TotalWeightUnitMapValue">
    <xsl:param name="ValueToConvert" select="0" />
    <xsl:variable name="vTotalWeightUnitMap" >
      <map>
        <entry key="L">1</entry>
        <entry key="K">2</entry>
        <entry key="G">1</entry>
      </map>
    </xsl:variable>
    <xsl:value-of select="msxsl:node-set($vTotalWeightUnitMap)/map/entry[@key=$ValueToConvert]"/>
  </xsl:template>

  <xsl:template name="EquipmentLengthMapValue">
    <xsl:param name="ValueToConvert" select="0" />
    <xsl:variable name="vEquipmentLengthMap" >
      <map>
        <entry key="2000">1</entry>
        <entry key="2400">2</entry>
        <entry key="2800">3</entry>
        <entry key="4000">4</entry>
        <entry key="4500">5</entry>
        <entry key="4800">6</entry>
        <entry key="5300">7</entry>
        <entry key="6000">8</entry>
        <entry key="5000">9</entry>
        <entry key="6000">10</entry>
      </map>
    </xsl:variable>
    <xsl:value-of select="msxsl:node-set($vEquipmentLengthMap)/map/entry[@key=$ValueToConvert]"/>
  </xsl:template>

  <xsl:template name="EquipmentAccesorialsMapValue">
    <xsl:param name="ValueToConvert" select="0" />
    <xsl:variable name="vEquipmentAccesorialsMap" >
      <map>
        <entry key="TF">3</entry>
        <entry key="DRIVER_WORK">4</entry>
        <entry key="WEEKEND_PICKUP_DELIVERY_USEUIRED">11</entry>
        <entry key="TEMPERATURE_CONTROL_USEUIRED">12</entry>
        <entry key="SPECIAL_SERVICES">17</entry>
      </map>
    </xsl:variable>
    <xsl:value-of select="msxsl:node-set($vEquipmentAccesorialsMap)/map/entry[@key=$ValueToConvert]"/>
  </xsl:template>

  <xsl:template name="EquipmentTypeMapValue">
    <xsl:param name="ValueToConvert" select="0" />
    <xsl:variable name="vEquipmentTypeMap" >
      <map>
        <entry key="CU">1</entry>
        <entry key="TV">2</entry>
        <entry key="CV">2</entry>
        <entry key="SS">3</entry>
        <entry key="ST">4</entry>
        <entry key="DT">5</entry>
        <entry key="SA">6</entry>
        <entry key="SC">7</entry>
        <entry key="SK">8</entry>
        <entry key="SL">9</entry>
        <entry key="ID">10</entry>
        <entry key="IX">11</entry>
        <entry key="LO">12</entry>
        <entry key="LS">13</entry>
        <entry key="OB">14</entry>
        <entry key="OT">15</entry>
        <entry key="TP">16</entry>
        <entry key="VA">17</entry>
        <entry key="VE">18</entry>
        <entry key="2B">19</entry>
        <entry key="20">20</entry>
        <entry key="VL">21</entry>
        <entry key="22">22</entry>
        <entry key="PL">23</entry>
        <entry key="PP">24</entry>
        <entry key="FN">25</entry>
        <entry key="FT">26</entry>
        <entry key="SR">27</entry>
        <entry key="SD">28</entry>
        <entry key="DD">29</entry>
        <entry key="TM">30</entry>
        <entry key="TU">31</entry>
        <entry key="ET">32</entry>
        <entry key="TT">33</entry>
        <entry key="2E">34</entry>
        <entry key="CA">35</entry>
        <entry key="SV">36</entry>
        <entry key="BR">37</entry>
        <entry key="2F">38</entry>
        <entry key="FS">39</entry>
        <entry key="FH">40</entry>
        <entry key="RE">41</entry>
        <entry key="RF">42</entry>
        <entry key="RG">43</entry>
        <entry key="TA">44</entry>
        <entry key="PT">45</entry>
        <entry key="AT">46</entry>
        <entry key="TN">47</entry>
        <entry key="CB">48</entry>
        <entry key="CC">49</entry>
        <entry key="CD">50</entry>
        <entry key="CG">51</entry>
        <entry key="CH">52</entry>
        <entry key="CI">53</entry>
        <entry key="CJ">54</entry>
        <entry key="CK">55</entry>
        <entry key="HC">56</entry>
        <entry key="CM">57</entry>
        <entry key="RA">58</entry>
        <entry key="RC">59</entry>
        <entry key="RD">60</entry>
        <entry key="RI">61</entry>
        <entry key="RO">62</entry>
        <entry key="DF">64</entry>
        <entry key="HB">65</entry>
        <entry key="AC">67</entry>
        <entry key="BH">68</entry>
        <entry key="AL">69</entry>
        <entry key="CQ">70</entry>
        <entry key="CT">71</entry>
        <entry key="CS">72</entry>
        <entry key="CW">74</entry>
        <entry key="FR">75</entry>
        <entry key="HT">76</entry>
        <entry key="HV">77</entry>
        <entry key="FP">78</entry>
        <entry key="FX">79</entry>
        <entry key="OV">80</entry>
        <entry key="TB">81</entry>
        <entry key="TC">82</entry>
        <entry key="CL">83</entry>
        <entry key="TO">84</entry>
        <entry key="LU">85</entry>
        <entry key="TF">2</entry>
        <entry key="4B">49</entry>
        <entry key="RT">42</entry>
        <entry key="TL">2</entry>
        <entry key="TW">43</entry>
      </map>
    </xsl:variable>
    <xsl:variable name="ValueConverted" select="msxsl:node-set($vEquipmentTypeMap)/map/entry[@key=$ValueToConvert]"/>
     <xsl:choose>
      <xsl:when test="$ValueConverted">
        <xsl:value-of select="$ValueConverted"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$ValueToConvert"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="LocationTypeMapValue">
    <xsl:param name="parL1101" select="0" />
    <xsl:param name="parL1102" select="0" />
    <xsl:choose>
      <xsl:when test="$parL1101='4B' and $parL1102 = '61'">
        <xsl:value-of select="1" />
      </xsl:when>
      <xsl:when test="$parL1101='4C' and $parL1102 = '62'">
        <xsl:value-of select="1" />
      </xsl:when>
      <xsl:when test="$parL1101='4B' and $parL1102 = '59'">
        <xsl:value-of select="2" />
      </xsl:when>
      <xsl:when test="$parL1101='4C' and $parL1102 = '60'">
        <xsl:value-of select="2" />
      </xsl:when>
      <xsl:when test="$parL1101='4B' and $parL1102 = '63'">
        <xsl:value-of select="3" />
      </xsl:when>
      <xsl:when test="$parL1101='4C' and $parL1102 = '64'">
        <xsl:value-of select="3" />
      </xsl:when>
    </xsl:choose>
  </xsl:template>

  <msxsl:script language="C#" implements-prefix="userCSharp">
    <![CDATA[
    
string address = "";
string newaddress = "";

        public string SetAddress(string add)
        {
            if (String.IsNullOrEmpty(address))
                address = address + add;
            else
                address = address + ", " + add;

            return address;
        }
        
        public string GetAddress()
        {
            newaddress = address;
            address = "";
            return newaddress;
        }
        
        

public string GET_ENumberFromName(string PartyOrAgreementName)
{
    string returnValue = "";
    decimal decimals = 0;

    string [] split = PartyOrAgreementName.Split(new Char[] {'_','.',':','\t'});

    foreach(string s in split) {
        
        if ( (s.StartsWith("E")) && s.Length > 3 )
        {
            if (Decimal.TryParse(s.Substring(1), out decimals))
            {
                returnValue = s;
            }
                
        }
        else if (!s.StartsWith("E"))
        {
            if (Decimal.TryParse(s, out decimals))
            {
                returnValue = "E" + s;
            }
        }
    }    

    return returnValue;
}


public string GET_CustomerNameFromName(string PartyOrAgreementName)
{
    string returnValue = PartyOrAgreementName;
    decimal decimals = 0;

    string[] split = PartyOrAgreementName.Split(new Char[] { '_', '.', ':', '\t' });

    foreach (string s in split)
    {

        if ((s.StartsWith("E")) && s.Length > 3)
        {
            if (!Decimal.TryParse(s.Substring(1), out decimals))
            {
                returnValue = s;
            }

        }
        else if (!s.StartsWith("E"))
        {
            if (!Decimal.TryParse(s, out decimals))
            {
                returnValue = s;
            }
        }
        
    }

    return returnValue;
}
public string StringConcat(string param0)
{
   return param0;
}
public string StringReferenceTrim(string param0)
{
  if(param0.Length > 3)
	return  param0.Substring(0,3).Trim();
  else 
  return  param0.Trim();
}
public string GetMapActivityDate()
{
  return DateTime.Now.ToString("yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
}

public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

  public bool LogicalEq(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) & IsNumeric(val2, ref d2))
	{
		ret = d1 == d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) == 0;
	}
	return ret;
}


public bool LogicalNot(string val)
{
	return !ValToBool(val);
}


public bool LogicalOr(string param0, string param1)
{
	return ValToBool(param0) || ValToBool(param1);
	return false;
}

public bool ValToBool(string val)
{
	if (val != null)
	{
		if (string.Compare(val, bool.TrueString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return true;
		}
		if (string.Compare(val, bool.FalseString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return false;
		}
		val = val.Trim();
		if (string.Compare(val, bool.TrueString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return true;
		}
		if (string.Compare(val, bool.FalseString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return false;
		}
		double d = 0;
		if (IsNumeric(val, ref d))
		{
			return (d > 0);
		}
	}
	return false;
}


  public string ConvertNnToNumeric (string val1, string val2)
        {
            string convertedResult = val1;
           // int val1Lenght = val1.Length;
            int decimals = 0;
            string digitsOnly = val1.Replace("-", "");
            string sign = "";
            int digitsOnlyLenght = digitsOnly.Length;
            
            if (val1.StartsWith("-"))
            {
                sign = "-";
            }
                        
            if (!String.IsNullOrEmpty(val2))
            {
                val2 = val2.Replace("N", "");
                val2 = val2.Replace("n", "");
            }

            if (Int32.TryParse(val2, out decimals))
            {
                if (digitsOnlyLenght < decimals)
                {
                    char padChar = '0';

                    convertedResult = "0." + digitsOnly.PadLeft(decimals, padChar); 

                }
                else if (digitsOnlyLenght == decimals)
                {
                    convertedResult = "0." + digitsOnly;
                }
                else
                {
                    string cents = digitsOnly.Substring(digitsOnlyLenght - decimals);
                    string dollars = digitsOnly.Substring(0, digitsOnlyLenght - decimals);

                    convertedResult = dollars + "." + cents;
                }                

            }

            convertedResult = sign + convertedResult;

            return convertedResult;
        }

]]>
  </msxsl:script>
</xsl:stylesheet>