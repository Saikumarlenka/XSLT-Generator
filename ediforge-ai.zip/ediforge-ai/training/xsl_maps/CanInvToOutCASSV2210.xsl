<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00401.EDI210.RV.L108/v1.0" xmlns:s0="http://Echo.BSSR.Internal.Canonical.InvoiceV2" xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp" exclude-result-prefixes="msxsl var s0 userCSharp" version="1.0">
	<xsl:variable name="vLowercaseChars_CONST" select="'abcdefghijklmnopqrstuvwxyz'"/>
	<xsl:variable name="vUppercaseChars_CONST" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'"/>
	<xsl:output omit-xml-declaration="yes" method="xml" version="1.0"/>
	<xsl:template match="/">
		<xsl:apply-templates select="/s0:Invoice"/>
	</xsl:template>
	<xsl:template match="/s0:Invoice">
		<ns0:X12_00401_210>
			<ST>
				<ST01>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetIdentifierCode"/>
				</ST01>
				<ST02>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber"/>
				</ST02>
				<ST03>
					<xsl:choose>
						<xsl:when test="/s0:Invoice/@CustomerId = '172960' or /s0:Invoice/@CustomerId='121224'">CASS146500</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '61732'">CASS037300</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '97230'">CASS037300</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '215553'">CASS037300</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '106057'">CASS139800</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '25079'">CASS144900</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '190438'">CASS123300</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '124663'">CASS506000</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '109694'">CASS101302</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '14411'">CASS101311</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '165938'">CASS115800</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '171417'">CASS220100</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '6807'">CASS137300</xsl:when>
					</xsl:choose>
				</ST03>
			</ST>
			<xsl:variable name="eNum" select="/s0:Invoice/@CustomerId"/>
			<xsl:variable name="DRRef" select="Header/ReferenceList/ReferenceInformation[@EDICode = 'DR']/@ReferenceInformation"/>
			<xsl:variable name="bmRef" select="Header/ReferenceList/ReferenceInformation[@EDICode = 'BM']/@ReferenceInformation"/>
			<xsl:variable name="addr" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']/AddressInformation/@AddressInformationLine1"/>
			<xsl:variable name="city" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']/GeographicLocation/@CityName"/>
			<xsl:variable name="zip" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']/GeographicLocation/@PostalCode"/>
			<xsl:variable name="addr2" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']/AddressInformation/@AddressInformationLine1"/>
			<xsl:variable name="city2" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']/GeographicLocation/@CityName"/>
			<xsl:variable name="zip2" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']/GeographicLocation/@PostalCode"/>
			<xsl:variable name="account" select="Header/PartyList/Party[Name/@EntityIdentifierCode='BT']/Name/@Name"/>
			<xsl:variable name="IO" select ="userCSharp:delegator($account, 'IO', $addr, $city, $addr2, $city2)"/>
			<xsl:variable name="sonocobm1" select="Header/ReferenceList/ReferenceInformation[string-length(@ReferenceInformation) = 8]/@ReferenceInformation"/>
			<xsl:variable name="sonocobm2" select="Header/ReferenceList/ReferenceInformation[string-length(@ReferenceInformation) = 9 and substring(@ReferenceInformation,1,1) = '1']/@ReferenceInformation"/>
			<xsl:variable name="serviceLevel" select="substring(Header/ReferenceList/ReferenceInformation[@EDICode = 'SC']/@ReferenceInformation, 1,2)"/>
			<xsl:variable name="NumberOfN7" select="count (Header/EquipmentList/Equipment[@EquipmentNumber != ''])"/>
			<ns0:B3>
				<!-- Segment not mapped by default
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@ShipmentQualifier != '' ">      
					<B301><xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentQualifier" /></B301>
				</xsl:if>
        -->
				<xsl:variable name="ENum" select="/s0:Invoice/@CustomerId"/>
				<B302>
					<xsl:choose>
						<xsl:when test="/s0:Invoice/@CustomerId = '106057'">
							<xsl:value-of select="concat(substring-before(Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber, '-'), substring-after(Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber, '-'))"/>
						</xsl:when>
						<xsl:when test="(/s0:Invoice/@CustomerId ='61732' or /s0:Invoice/@CustomerId = '97230') ">
							<xsl:call-template name="CleanAlphaField">
								<xsl:with-param name="inputText" select="Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber"/>
								<xsl:with-param name="maxLength" select="22"/>
							</xsl:call-template>
						</xsl:when>
						<xsl:otherwise>
							<xsl:call-template name="CleanAlphaField">
								<xsl:with-param name="inputText" select="substring-before(Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber, '-')"/>
								<xsl:with-param name="maxLength" select="22"/>
							</xsl:call-template>
						</xsl:otherwise>
					</xsl:choose>
				</B302>
				<B303>
					<xsl:choose>
						<xsl:when test="/s0:Invoice/@CustomerId = '106057' or /s0:Invoice/@CustomerId = '6807'">
							<xsl:call-template name="CleanAlphaField">
								<xsl:with-param name="inputText" select="substring-before(Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber, '-')"/>
								<xsl:with-param name="maxLength" select="22"/>
							</xsl:call-template>
						</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '124663'">
							<xsl:value-of select="$bmRef"/>
						</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '165938'">
							<xsl:choose>
								<xsl:when test ="$sonocobm2 != ''">
									<xsl:value-of select="$sonocobm2"/>
								</xsl:when>
								<xsl:otherwise>
									<xsl:value-of select="$sonocobm1"/>
								</xsl:otherwise>
							</xsl:choose>
						</xsl:when>
						<xsl:otherwise>
							<xsl:call-template name="CleanAlphaField">
								<xsl:with-param name="inputText" select="Header/BeginningSegmentForCarriersInvoice/@ShipmentIdentificationNumber"/>
								<xsl:with-param name="maxLength" select="30"/>
							</xsl:call-template>
						</xsl:otherwise>
					</xsl:choose>
				</B303>

				<B304>
					<xsl:choose>
						<xsl:when test="$IO = 'O'">PP</xsl:when>
						<xsl:when test="$IO = 'I'">CC</xsl:when>
						<xsl:otherwise>
							<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentMethodOfPayment"/>
						</xsl:otherwise>
					</xsl:choose>
				</B304>

				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@WeightUnitCode != '' ">
					<B305>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@WeightUnitCode"/>
					</B305>
				</xsl:if>

				<xsl:variable name="InvoiceDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='InvoiceDate']"/>
				<xsl:variable name="DeliveryDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='DeliveryDate']"/>
				<xsl:variable name="BillingDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='BillingDate']"/>
				<xsl:variable name="PickupDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='PickupDate']"/>
				<xsl:if test="$InvoiceDate != '' ">
					<B306>
						<xsl:value-of select="concat(substring($BillingDate, 1, 4), substring($BillingDate, 6, 2), substring($BillingDate, 9, 2))"/>
					</B306>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@NetAmountDue != '' ">
					<B307>
						<xsl:value-of select="translate(Header/BeginningSegmentForCarriersInvoice/@NetAmountDue,'.','')"/>
					</B307>
				</xsl:if>
				<!--

				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@CorrectionIndicator != '' ">
					<B308><xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@CorrectionIndicator" /></B308>
				</xsl:if>
        
-->
				<xsl:if test="$DeliveryDate != '' ">
					<B309>
						<xsl:value-of select="concat(substring($DeliveryDate, 1, 4), substring($DeliveryDate, 6, 2), substring($DeliveryDate, 9, 2))"/>
					</B309>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@DateTimeQualifier != '' ">
					<B310>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@DateTimeQualifier"/>
					</B310>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@StandardCarrierAlphaCode != '' ">
					<B311>ECHS</B311>
				</xsl:if>
				<xsl:if test="$PickupDate != '' ">
					<B312>
						<xsl:value-of select="concat(substring($PickupDate, 1, 4), substring($PickupDate, 6, 2), substring($PickupDate, 9, 2))"/>
					</B312>
				</xsl:if>
				<!-- 
  Not mapped by default
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@TariffServiceCode != '' ">
					<B313>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@TariffServiceCode" />
					</B313>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@TransportationTermsCode != '' ">
					<B314>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@TransportationTermsCode" />
					</B314>
				</xsl:if>
        
-->
			</ns0:B3>
			<!--
 Not mapped by default
      <ns0:C2>
        <C201>E</C201>
      </ns0:C2>
-->
			<xsl:if test="Header/Currency/@BillingCurrencyCode!=''">
				<ns0:C3>
					<C301>
						<xsl:value-of select="Header/Currency/@BillingCurrencyCode"/>
					</C301>
				</ns0:C3>
			</xsl:if>

			<xsl:for-each select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='ReferenceList']/*[local-name()='ReferenceInformation']">
				<xsl:if test="(@EDICode = 'CN' or @EDICode = 'PI' or @EDICode = 'BM' or @EDICode = 'PO' or @EDICode = 'OQ' or @EDICode = 'ZZ' or (/s0:Invoice/@CustomerId = '124663' and @EDICode = 'TN')) ">

					<xsl:if test="@EDICode != '' ">
						<ns0:N9>
							<N901>
								<xsl:value-of select="@EDICode"/>
							</N901>
							<xsl:if test="@ReferenceInformation != '' ">
								<N902>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="@ReferenceInformation"/>
										<xsl:with-param name="maxLength" select="30"/>
									</xsl:call-template>
								</N902>
							</xsl:if>
						</ns0:N9>
					</xsl:if>
				</xsl:if>
			</xsl:for-each>
			<!--<ns0:N9>
        <N901>IO</N901>
          <N902>
            <xsl:value-of select="$IO"/>
          </N902>
      </ns0:N9>-->

			<xsl:variable name="InvoiceDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='InvoiceDate']"/>
			<xsl:variable name="currentDate" select="userCSharp:dateReturn()"/>
			<!--  Not mapped by default -->
			<xsl:variable name="DeliveryDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='DeliveryDate']"/>
			<xsl:variable name="PickupDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='PickupDate']"/>

			<ns0:G62>
				<G6201>86</G6201>
				<G6202>

					<xsl:value-of select="$currentDate"/>
					<!-- <xsl:value-of select="concat(substring($currentDate, 1, 4), substring($currentDate, 6, 2), substring($currentDate, 9, 2))"/> -->

				</G6202>
			</ns0:G62>
			<ns0:G62>
				<G6201>35</G6201>
				<G6202>
					<xsl:value-of select="concat(substring($DeliveryDate, 1, 4), substring($DeliveryDate, 6, 2), substring($DeliveryDate, 9, 2))"/>
				</G6202>
			</ns0:G62>

			<ns0:R3>
				<R301>ECHS</R301>
				<R302>B</R302>
				<R304>
					<xsl:choose>
						<xsl:when test="/s0:Invoice/Header/ReferenceList/ReferenceInformation[@EDICode = 'TM']/@ReferenceInformation = 'LTL'">LT</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '106057'">J</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '172960'">J</xsl:when>
						<xsl:when test="/s0:Invoice/@CustomerId = '121224'">J</xsl:when>
						<xsl:otherwise>M</xsl:otherwise>
					</xsl:choose>
				</R304>
				<!--     <xsl:if test="$eNum = '165938'"> -->
				<xsl:if test="$serviceLevel!=''">
					<R310>
						<xsl:value-of select="$serviceLevel"/>
					</R310>
				</xsl:if>
			</ns0:R3>


			<!--			<R304>M</R304>
				<R306>
					<xsl:value-of select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@InvoiceNumber" />
				</R306>
				<R310>G2</R310>
			
      
			<ns0:K1>
				<xsl:variable name="BMRefInfo" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='ReferenceList']/*[local-name()='ReferenceInformation'][@EDICode='BM']" />
				<K101>
					<xsl:choose>
						<xsl:when test="$BMRefInfo &gt; ' ' ">
							<xsl:value-of select="$BMRefInfo" /> 
						</xsl:when>
						<xsl:otherwise>
							<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentIdentificationNumber" />
						</xsl:otherwise> 
					</xsl:choose> 
				</K101>
			</ns0:K1>
-->
			<xsl:variable name="ENum" select="/s0:Invoice/@CustomerId"/>
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='BT']">
				<ns0:N1Loop1>
					<ns0:N1>
						<N101>
							<xsl:value-of select="Name/@EntityIdentifierCode"/>
						</N101>
						<N102>
							<xsl:call-template name="CleanAlphaField">
								<xsl:with-param name="inputText" select="Name/@Name"/>
								<xsl:with-param name="maxLength" select="60"/>
							</xsl:call-template>
						</N102>
					</ns0:N1>
					<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
						<ns0:N3>
							<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
								<N301>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N301>
							</xsl:if>
							<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
								<N302>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N302>
							</xsl:if>
						</ns0:N3>
					</xsl:if>
					<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
						<ns0:N4>
							<xsl:if test="GeographicLocation/@CityName != ''">
								<N401>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@CityName"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N401>
							</xsl:if>
							<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
								<N402>
									<xsl:value-of select="GeographicLocation/@StateOrProvinceCode"/>
								</N402>
							</xsl:if>
							<xsl:if test="GeographicLocation/@PostalCode != ''">
								<N403>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode"/>
										<xsl:with-param name="maxLength" select="55"/>
									</xsl:call-template>
								</N403>
							</xsl:if>
							<xsl:if test="GeographicLocation/@CountryCode != ''">
								<N404>
									<xsl:choose>
										<xsl:when test ="GeographicLocation/@CountryCode = 'US'">USA</xsl:when>
										<xsl:otherwise>
											<xsl:value-of select="GeographicLocation/@CountryCode"/>
										</xsl:otherwise>
									</xsl:choose>
								</N404>
							</xsl:if>
						</ns0:N4>
					</xsl:if>
				</ns0:N1Loop1>
			</xsl:for-each>
			<!--
Template not used for a code below due to expected changes to mappings from one code to another
-->
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']">
				<!-- below if statement exists to prevent multiple shipper stops from being added if customer is Vyaire (172960). Only first shipper is added, the rest will be S5 segments-->
				<xsl:if test="position() = 1 or /s0:Invoice/@CustomerId != '172960'  or /s0:Invoice/@CustomerId != '121224'">
					<ns0:N1Loop1>
						<ns0:N1>
							<N101>
								<xsl:value-of select="Name/@EntityIdentifierCode"/>
							</N101>
							<N102>
								<xsl:call-template name="CleanAlphaField">
									<xsl:with-param name="inputText" select="Name/@Name"/>
									<xsl:with-param name="maxLength" select="60"/>
								</xsl:call-template>
							</N102>
							<xsl:if test="$IO = 'O'">
								<N103>93</N103>
								<N104>
									<xsl:value-of select="userCSharp:delegator($account, $IO, $addr, $city, $addr2, $city2)"/>
								</N104>
							</xsl:if>
						</ns0:N1>
						<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
							<ns0:N3>
								<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
									<N301>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N301>
								</xsl:if>
								<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
									<N302>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N302>
								</xsl:if>
							</ns0:N3>
						</xsl:if>
						<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
							<ns0:N4>
								<xsl:if test="GeographicLocation/@CityName != ''">
									<N401>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="GeographicLocation/@CityName"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N401>
								</xsl:if>
								<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
									<N402>
										<xsl:value-of select="GeographicLocation/@StateOrProvinceCode"/>
									</N402>
								</xsl:if>
								<xsl:if test="GeographicLocation/@PostalCode != ''">
									<N403>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N403>
								</xsl:if>
								<xsl:if test="GeographicLocation/@CountryCode != ''">
									<N404>
										<xsl:choose>
											<xsl:when test ="GeographicLocation/@CountryCode = 'US'">USA</xsl:when>
											<xsl:otherwise>
												<xsl:value-of select="GeographicLocation/@CountryCode"/>
											</xsl:otherwise>
										</xsl:choose>
									</N404>
								</xsl:if>
							</ns0:N4>
						</xsl:if>
					</ns0:N1Loop1>
				</xsl:if>
			</xsl:for-each>
			<!--
Template not used for a code below due to expected changes to mappings from one code to another
-->
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']">
				<!-- below if statement exists to prevent multiple consignee stops from being added if customer is Vyaire. Only last consignee is added, the rest will be S5 segments-->
				<xsl:if test="position() = last() or /s0:Invoice/@CustomerId != '172960' or /s0:Invoice/@CustomerId != '121224'">
					<ns0:N1Loop1>
						<ns0:N1>
							<N101>
								<xsl:value-of select="Name/@EntityIdentifierCode"/>
							</N101>
							<N102>
								<xsl:call-template name="CleanAlphaField">
									<xsl:with-param name="inputText" select="Name/@Name"/>
									<xsl:with-param name="maxLength" select="60"/>
								</xsl:call-template>
							</N102>
							<xsl:if test="$IO = 'I'">
								<N103>93</N103>
								<N104>
									<xsl:value-of select="userCSharp:delegator($account, $IO, $addr, $city, $addr2, $city2)"/>
								</N104>
							</xsl:if>
						</ns0:N1>
						<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
							<ns0:N3>
								<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
									<N301>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N301>
								</xsl:if>
								<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
									<N302>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N302>
								</xsl:if>
							</ns0:N3>
						</xsl:if>
						<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
							<ns0:N4>
								<xsl:if test="GeographicLocation/@CityName != ''">
									<N401>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="GeographicLocation/@CityName"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N401>
								</xsl:if>
								<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
									<N402>
										<xsl:value-of select="GeographicLocation/@StateOrProvinceCode"/>
									</N402>
								</xsl:if>
								<xsl:if test="GeographicLocation/@PostalCode != ''">
									<N403>
										<xsl:call-template name="CleanAlphaField">
											<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode"/>
											<xsl:with-param name="maxLength" select="55"/>
										</xsl:call-template>
									</N403>
								</xsl:if>
								<xsl:if test="GeographicLocation/@CountryCode != ''">
									<N404>
										<xsl:if test ="GeographicLocation/@CountryCode = 'US'">USA</xsl:if>
										<xsl:if test ="GeographicLocation/@CountryCode != 'US'">
											<xsl:value-of select="GeographicLocation/@CountryCode"/>
										</xsl:if>
									</N404>
								</xsl:if>
							</ns0:N4>
						</xsl:if>
					</ns0:N1Loop1>
				</xsl:if>
			</xsl:for-each>
			<xsl:choose>
				<xsl:when test="$NumberOfN7 > 0">
					<ns0:N7Loop1>
						<xsl:for-each select="Header/EquipmentList/Equipment">
							<ns0:N7>
								<xsl:if test="@EquipmentNumber != ''">
									<N702>
										<xsl:value-of select="@EquipmentNumber" />
									</N702>
								</xsl:if>
								<xsl:if test="@EquipmentDescriptionCode != ''">
									<N711>
										<xsl:value-of select="@EquipmentDescriptionCode" />
									</N711>
								</xsl:if>
								<xsl:if test="@EquipmentDescriptionCode != ''">
									<!--<N715>
                  <xsl:value-of select="@EquipmentLength"/>
                </N715>-->
								</xsl:if>
							</ns0:N7>
						</xsl:for-each>
					</ns0:N7Loop1>
				</xsl:when>
				<xsl:otherwise>
					<ns0:N7Loop1>
						<ns0:N7>
							<N702>1234</N702>
							<N711>TL</N711>
							<xsl:if test="@EquipmentDescriptionCode != ''">
								<!--<N715>
                  <xsl:value-of select="@EquipmentLength"/>
                </N715>-->
							</xsl:if>
						</ns0:N7>
					</ns0:N7Loop1>
				</xsl:otherwise>
			</xsl:choose>


			<!-- stopoff code for Vyaire. Card 101639>-->
			<xsl:if test="/s0:Invoice/@CustomerId = '172960' or /s0:Invoice/@CustomerId != '121224'">
				<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode!='BT']">
					<!-- shipper stopoffs for Vyaire. Loop through all the SHs except the first one because it's already got an entry in header-->
					<xsl:if test="position() != 1 and Name/@EntityIdentifierCode = 'SH'">
						<ns0:S5Loop1>
							<ns0:S5>
								<S501>
									<xsl:value-of select="position()" />
								</S501>
								<S502>PL</S502>
							</ns0:S5>
							<ns0:N1Loop2>
								<ns0:N1_2>
									<N101>PW</N101>
									<N102>
										<xsl:value-of select="Name/@Name" />
									</N102>
								</ns0:N1_2>
								<ns0:N4_2>
									<xsl:if test="GeographicLocation/@CityName != '' ">
										<N401>
											<xsl:value-of select="GeographicLocation/@CityName" />
										</N401>
									</xsl:if>
									<xsl:if test="GeographicLocation/@StateOrProvinceCode != '' ">
										<N402>
											<xsl:value-of select="GeographicLocation/@StateOrProvinceCode" />
										</N402>
									</xsl:if>
									<xsl:if test="GeographicLocation/@PostalCode != '' ">
										<N403>
											<xsl:value-of select="GeographicLocation/@PostalCode" />
										</N403>
									</xsl:if>
									<xsl:if test="GeographicLocation/@CountryCode != '' ">
										<N404>
											<xsl:value-of select="GeographicLocation/@CountryCode" />
										</N404>
									</xsl:if>
								</ns0:N4_2>
							</ns0:N1Loop2>
							<xsl:if test="$NumberOfN7 > 0">
								<ns0:N7Loop1>
									<xsl:for-each select="../../EquipmentList/Equipment">
										<ns0:N7>
											<xsl:if test="@EquipmentNumber != ''">
												<N702>
													<xsl:value-of select="@EquipmentNumber" />
												</N702>
											</xsl:if>
											<xsl:if test="@EquipmentDescriptionCode != ''">
												<N711>
													<xsl:value-of select="@EquipmentDescriptionCode" />
												</N711>
											</xsl:if>
											<xsl:if test="@EquipmentDescriptionCode != ''">
											</xsl:if>
										</ns0:N7>
									</xsl:for-each>
								</ns0:N7Loop1>
							</xsl:if>
						</ns0:S5Loop1>
					</xsl:if>
					<!-- consignee stopoffs for Vyaire. Loop through all the CNs except the last one because it's already got an entry in header-->
					<xsl:if test="position() != last() and Name/@EntityIdentifierCode = 'CN'">
						<ns0:S5Loop1>
							<ns0:S5>
								<S501>
									<xsl:value-of select="position()" />
								</S501>
								<S502>PU</S502>
							</ns0:S5>
							<ns0:N1Loop2>
								<ns0:N1_2>
									<N101>45</N101>
									<N102>
										<xsl:value-of select="Name/@Name" />
									</N102>
								</ns0:N1_2>
								<ns0:N4_2>
									<xsl:if test="GeographicLocation/@CityName != '' ">
										<N401>
											<xsl:value-of select="GeographicLocation/@CityName" />
										</N401>
									</xsl:if>
									<xsl:if test="GeographicLocation/@StateOrProvinceCode != '' ">
										<N402>
											<xsl:value-of select="GeographicLocation/@StateOrProvinceCode" />
										</N402>
									</xsl:if>
									<xsl:if test="GeographicLocation/@PostalCode != '' ">
										<N403>
											<xsl:value-of select="GeographicLocation/@PostalCode" />
										</N403>
									</xsl:if>
									<xsl:if test="GeographicLocation/@CountryCode != '' ">
										<N404>
											<xsl:value-of select="GeographicLocation/@CountryCode" />
										</N404>
									</xsl:if>
								</ns0:N4_2>
							</ns0:N1Loop2>
							<xsl:if test="$NumberOfN7 > 0">
								<ns0:N7Loop1>
									<xsl:for-each select="../../EquipmentList/Equipment">
										<ns0:N7>
											<xsl:if test="@EquipmentNumber != ''">
												<N702>
													<xsl:value-of select="@EquipmentNumber" />
												</N702>
											</xsl:if>
											<xsl:if test="@EquipmentDescriptionCode != ''">
												<N711>
													<xsl:value-of select="@EquipmentDescriptionCode" />
												</N711>
											</xsl:if>
											<xsl:if test="@EquipmentDescriptionCode != ''">
											</xsl:if>
										</ns0:N7>
									</xsl:for-each>
								</ns0:N7Loop1>
							</xsl:if>
						</ns0:S5Loop1>
					</xsl:if>
				</xsl:for-each>
			</xsl:if>

			<!-- Original, non-Vyaire stopoff code. Not sure if it works, honestly-->
			<!--
 Create S5Loop1 only for last recored where party Identifier Codes is 'CN', 
-->
			<!--
<xsl:variable name="NumberOfParties" select="count (Header/PartyList/Party)"/>
-->
			<!--
<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']">
      
-->
			<!-- <xsl:for-each select="Header/PartyList/Party"> -->
			<!--

        <xsl:if test="position() &lt; $NumberOfParties">
				<ns0:S5Loop1>
						<ns0:S5>
							<S501>
								<xsl:value-of select="position()" />
							</S501>
							<S502>PU</S502>
              <xsl:if test="../../../Summary/TotalWeightAndCharges/@Weight">
              <S503>
                <xsl:value-of select="../../../Summary/TotalWeightAndCharges/@Weight" />
              </S503>
              <S504>L</S504>
              </xsl:if>
						</ns0:S5>
           <xsl:for-each select="../../ReferenceList/ReferenceInformation">
            <xsl:if test="(@ReferenceInformationQualifier != '') or (@ReferenceInformation != '') ">
              <ns0:N9_3>
                <xsl:if test="@EDICode != '' ">
                  <N901>
                    <xsl:value-of select="@EDICode" />
                  </N901>
                </xsl:if>
                <xsl:if test="@ReferenceInformation != '' ">
                  <N902>
                    <xsl:call-template name="CleanAlphaField" >
                      <xsl:with-param name="inputText" select="@ReferenceInformation" />
                      <xsl:with-param name="maxLength" select="30" />
                    </xsl:call-template>
                  </N902>
                </xsl:if>
              </ns0:N9_3>
            </xsl:if>
          </xsl:for-each>
				</ns0:S5Loop1>
        </xsl:if>
			</xsl:for-each>
-->
			<!--
<xsl:variable name="CountofSH" select="count(PartyList/Party[Name/@EntityIdentifierCode='SH'][1]) - 1" />


			<xsl:for-each select="PartyList/Party[Name/@EntityIdentifierCode='CN']">
				<xsl:variable name="PositionOfCN" select="position()" />
				<ns0:S5Loop1>
					<xsl:if test="$PositionOfCN != last()">
						<ns0:S5>
							<S501>
								<xsl:value-of select="$CountofSH + position()" />
							</S501>
							<S502>PU</S502>
						</ns0:S5>
						<ns0:N1Loop2>
							<ns0:N1_2>
								<N101>
									<xsl:value-of select="Name/@EntityIdentifierCode" />
								</N101>
								<N102>
									<xsl:value-of select="Name/@Name" />
								</N102>
							</ns0:N1_2>
							<ns0:N3_2>
								<N301>
									<xsl:value-of select="AddressInformation/@AddressInformationLine1" />
								</N301>
							</ns0:N3_2>
							<ns0:N4_2>
								<xsl:if test="GeographicLocation/@CityName != '' ">
									<N401>
										<xsl:value-of select="GeographicLocation/@CityName" />
									</N401>
								</xsl:if>
								<xsl:if test="GeographicLocation/@StateOrProvinceCode != '' ">
									<N402>
										<xsl:value-of select="GeographicLocation/@StateOrProvinceCode" />
									</N402>
								</xsl:if>
								<xsl:if test="GeographicLocation/@PostalCode != '' ">
									<N403>
										<xsl:value-of select="GeographicLocation/@PostalCode" />
									</N403>
								</xsl:if>
								<xsl:if test="GeographicLocation/@CountryCode != '' ">
									<N404>
										<xsl:value-of select="GeographicLocation/@CountryCode" />
									</N404>
								</xsl:if>
							</ns0:N4_2>
						</ns0:N1Loop2>
					</xsl:if>
				</ns0:S5Loop1>
			</xsl:for-each>
-->
			<xsl:for-each select="Detail/LineItemList/LineItem">
				<xsl:if test="RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
					<ns0:LXLoop1>
						<ns0:LX>
							<LX01>
								<xsl:value-of select="position()"/>
							</LX01>
						</ns0:LX>
						<ns0:L5>
							<L501>
								<xsl:value-of select="position()"/>
							</L501>
							<xsl:if test="DescriptionMarksAndNumbers/@LadingDescription != ''">
								<L502>
									<xsl:choose>
										<xsl:when test="DescriptionMarksAndNumbers/@LadingDescription ='Drop Trailer'">
											<xsl:choose>
												<xsl:when test="/s0:Invoice/@CustomerId = '61732'">STORAGE</xsl:when>
												<xsl:otherwise>
													<xsl:call-template name="CleanAlphaField" >
														<xsl:with-param name="inputText" select="DescriptionMarksAndNumbers/@LadingDescription" />
														<xsl:with-param name="maxLength" select="50" />
													</xsl:call-template>
												</xsl:otherwise>
											</xsl:choose>
										</xsl:when>
										<xsl:when test="DescriptionMarksAndNumbers/@LadingDescription ='Spotting of Trailer'">
											<xsl:choose>
												<xsl:when test="/s0:Invoice/@CustomerId = '61732'">TRAIL SPOTTING/SHUNTING</xsl:when>
												<xsl:otherwise>
													<xsl:call-template name="CleanAlphaField" >
														<xsl:with-param name="inputText" select="DescriptionMarksAndNumbers/@LadingDescription" />
														<xsl:with-param name="maxLength" select="50" />
													</xsl:call-template>
												</xsl:otherwise>
											</xsl:choose>
										</xsl:when>
										<xsl:otherwise>
											<xsl:call-template name="CleanAlphaField" >
												<xsl:with-param name="inputText" select="DescriptionMarksAndNumbers/@LadingDescription" />
												<xsl:with-param name="maxLength" select="50" />
											</xsl:call-template>
										</xsl:otherwise>
									</xsl:choose>



								</L502>
							</xsl:if>
						</ns0:L5>
						<ns0:L0>
							<L001>
								<xsl:value-of select="position()"/>
							</L001>
							<L002>
								<xsl:value-of select="LineItemQuantityAndWeight/@BilledRatedAsQuantity"/>
							</L002>
							<L003>
								<xsl:value-of select="LineItemQuantityAndWeight/@BilledRatedAsQualifier"/>
							</L003>
							<xsl:if test ="RateAndCharges/@SpecialChargeOrAllowanceCode = 'LHS'">
								<L004>
									<xsl:value-of select="//Summary/TotalWeightAndCharges/@Weight"/>
								</L004>
								<L005>N</L005>
								<L008>
									<xsl:value-of select="//Summary/TotalWeightAndCharges//@LadingQuantity"/>
								</L008>
								<L009>PLT</L009>
								<L011>L</L011>
							</xsl:if>
						</ns0:L0>
						<xsl:if test="RateAndCharges/@FreightRate != '' or RateAndCharges/@Charge != '' or RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
							<ns0:L1>
								<L101>
									<xsl:value-of select="position()"/>
								</L101>
								<xsl:if test="RateAndCharges/@FreightRate != ''">
									<L102>
										<!--
<xsl:value-of select="format-number(RateAndCharges/@FreightRate, '#')" />
-->
										<xsl:value-of select="RateAndCharges/@FreightRate"/>
									</L102>
								</xsl:if>
								<xsl:if test="RateAndCharges/@RateValueQualifier != ''">
									<L103>
										<xsl:choose>
											<!-- Vyaire and SunMed wants the code "PD" sent for Layover charges. Card 101575 -->
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='LYC' and (/s0:Invoice/@CustomerId = '172960' or /s0:Invoice/@CustomerId = '121224')">PD</xsl:when>
											<xsl:otherwise>
												<xsl:value-of select="RateAndCharges/@RateValueQualifier"/>
											</xsl:otherwise>
										</xsl:choose>
									</L103>
								</xsl:if>
								<xsl:if test="RateAndCharges/@Charge != ''">
									<L104>
										<xsl:value-of select="translate(RateAndCharges/@Charge, '.', '')"/>
									</L104>
								</xsl:if>
								<!-- L107 not mapped by default -->
								<!--

            <xsl:if test="RateAndCharges/@RateCombinationPointCode != ''">
						  <L107>
							  <xsl:value-of select="RateAndCharges/@RateCombinationPointCode" />
						  </L107>
            </xsl:if>

-->
								<xsl:if test="RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
									<L108>
										<xsl:choose>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='SPT'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '61732' and DescriptionMarksAndNumbers/@LadingDescription ='Spotting of Trailer'">STP</xsl:when>
													<xsl:otherwise>SPT</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='SPT'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '61732' and DescriptionMarksAndNumbers/@LadingDescription ='Drop Trailer'">STO</xsl:when>
													<xsl:otherwise>SPT</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='TDT'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '61732'">DTU</xsl:when>
													<xsl:when test="/s0:Invoice/@CustomerId = '14411' or /s0:Invoice/@CustomerId = '109694' or /s0:Invoice/@CustomerId = '6807'">DET</xsl:when>
													<xsl:otherwise>TDT</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='VOR'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '61732'">TNU</xsl:when>
													<xsl:otherwise>VOR</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<!--Alrick changes for L108 additions-->
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='LHS'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '61732'">BAS</xsl:when>
													<xsl:when test="/s0:Invoice/@CustomerId = '172960'">BAS</xsl:when>
													<xsl:when test="/s0:Invoice/@CustomerId = '121224'">BAS</xsl:when>
													<xsl:when test="/s0:Invoice/@CustomerId = '97230'">BAS</xsl:when>
													<xsl:when test="/s0:Invoice/@CustomerId = '215553'">BAS</xsl:when>
													<xsl:when test="/s0:Invoice/@CustomerId = '124663'"></xsl:when>
													<xsl:when test="/s0:Invoice/@CustomerId = '109694'"></xsl:when>
													<xsl:when test="/s0:Invoice/@CustomerId = '14411'"></xsl:when>
													<xsl:when test="/s0:Invoice/@CustomerId = '106057'"></xsl:when>
													<xsl:otherwise>LHS</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='420'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '61732'">HAZ</xsl:when>
													<xsl:otherwise>420</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='IHT'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '14411' or /s0:Invoice/@CustomerId = '109694'">TOL</xsl:when>
													<xsl:otherwise>IHT</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='STP'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '14411' or /s0:Invoice/@CustomerId = '109694'">SAM</xsl:when>
													<xsl:otherwise>STP</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='MSG'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '14411' or /s0:Invoice/@CustomerId = '109694'">MSC</xsl:when>
													<xsl:otherwise>MSG</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='LYC'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '14411' or /s0:Invoice/@CustomerId = '109694'">LAY</xsl:when>
													<xsl:otherwise>LYC</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='DTU'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '14411' or /s0:Invoice/@CustomerId = '109694'">DET</xsl:when>
													<xsl:otherwise>
														<xsl:value-of select="RateAndCharges/@SpecialChargeOrAllowanceCode"/>
													</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='UNL' or RateAndCharges/@SpecialChargeOrAllowanceCode ='LYT'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '124663'">LUM</xsl:when>
													<xsl:otherwise>
														<xsl:value-of select="RateAndCharges/@SpecialChargeOrAllowanceCode"/>
													</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='455'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '6807'">INC</xsl:when>
													<xsl:otherwise>
														<xsl:value-of select="RateAndCharges/@SpecialChargeOrAllowanceCode"/>
													</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='CBL'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '6807'">LAC</xsl:when>
													<xsl:otherwise>
														<xsl:value-of select="RateAndCharges/@SpecialChargeOrAllowanceCode"/>
													</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='520'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '6807'">OVR</xsl:when>
													<xsl:otherwise>
														<xsl:value-of select="RateAndCharges/@SpecialChargeOrAllowanceCode"/>
													</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='IPU'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '6807'">450</xsl:when>
													<xsl:otherwise>
														<xsl:value-of select="RateAndCharges/@SpecialChargeOrAllowanceCode"/>
													</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode ='MNC'">
												<xsl:choose>
													<xsl:when test="/s0:Invoice/@CustomerId = '6807'">APT</xsl:when>
													<xsl:otherwise>
														<xsl:value-of select="RateAndCharges/@SpecialChargeOrAllowanceCode"/>
													</xsl:otherwise>
												</xsl:choose>
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of select="RateAndCharges/@SpecialChargeOrAllowanceCode" />
											</xsl:otherwise>
										</xsl:choose>

									</L108>
								</xsl:if>
								<!--
<xsl:if test="RateAndCharges/@SpecialChargeDescription != ''">
              <L112>
                <xsl:call-template name="CleanAlphaField" >
                  <xsl:with-param name="inputText" select="RateAndCharges/@SpecialChargeDescription" />
                  <xsl:with-param name="maxLength" select="25" />
                </xsl:call-template>
              </L112>
            </xsl:if>
-->
							</ns0:L1>
							<xsl:if test="DescriptionMarksAndNumbers/@LadingDescription = 'Line Haul'">
								<xsl:if test="/s0:Invoice/Header/ReferenceList/ReferenceInformation[@EDICode = 'TM']/@ReferenceInformation = 'LTL' or //Detail/LineItemList/LineItem/DescriptionMarksAndNumbers[@CommodityCode2 != '']/@CommodityCode2 !=''">
									<ns0:L7>
										<L707>
											<xsl:value-of select="//Detail/LineItemList/LineItem/DescriptionMarksAndNumbers[@CommodityCode2 != '']/@CommodityCode2"/>
										</L707>
									</ns0:L7>
								</xsl:if>
							</xsl:if>
						</xsl:if>
					</ns0:LXLoop1>
				</xsl:if>
			</xsl:for-each>
			<xsl:for-each select="Summary/TotalWeightAndCharges">
				<ns0:L3>
					<xsl:if test="@Weight">
						<L301>
							<xsl:value-of select="@Weight"/>
						</L301>
					</xsl:if>
					<xsl:if test="@WeightQualifier">
						<L302>G</L302>
					</xsl:if>
					<xsl:variable name="TotalCharges" select="@TotalCharges"/>
					<xsl:variable name="TotalChargesLength" select="string-length(@TotalCharges)"/>
					<xsl:if test="$TotalChargesLength > 2">
						<L305>
							<xsl:value-of select="translate(@TotalCharges,',','')"/>
							<!--
<xsl:value-of select="concat(substring($TotalCharges, 1, $TotalChargesLength - 2), '.',  substring($TotalCharges, $TotalChargesLength - 2 , 2))" />
-->
						</L305>
					</xsl:if>
					<xsl:if test="@LadingQuantity">
						<L311>
							<xsl:value-of select="@LadingQuantity"/>
						</L311>
					</xsl:if>
				</ns0:L3>
			</xsl:for-each>
			<SE>
				<SE01>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetIdentifierCode"/>
				</SE01>
				<SE02>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber"/>
				</SE02>
			</SE>
		</ns0:X12_00401_210>
	</xsl:template>
	<msxsl:script language="C#" implements-prefix="userCSharp">
		<![CDATA[
    public string dateReturn()
    {
	    DateTime localDate = DateTime.Now;
	    return localDate.ToString("yyyyMMdd");
    }
    ]]>
	</msxsl:script>
	<!-- Custom Templates -->
	<!--  Created by Neal, not specific to L108 -->
	<xsl:template name="ChangeThisName">
		<xsl:param name="ValueToConvert" select="0"/>
		<xsl:param name="LadingDescriptionParm" select="1"/>
		<xsl:variable name="L108Map">
			<map>
				<entry key="LHS">400</entry>
				<entry key="LYC">LAY</entry>
				<entry key="SRG">STR</entry>
				<entry key="TDT">DET</entry>
			</map>
		</xsl:variable>
		<xsl:variable name="ValueConverted" select="msxsl:node-set($L108Map)/map/entry[@key=$ValueToConvert]"/>
		<xsl:choose>
			<xsl:when test="$ValueConverted">
				<xsl:value-of select="$ValueConverted"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:choose>
					<xsl:when test="$LadingDescriptionParm = 'Lumper'">
						<xsl:text>LAB</xsl:text>
					</xsl:when>
					<xsl:when test="$LadingDescriptionParm = 'Unloading'">
						<xsl:text>UNL</xsl:text>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="$ValueToConvert"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<!--  Created by Neal, not specific to L108 -->
	<!-- CleanAlphaField start  -->
	<xsl:template name="CleanAlphaField">
		<xsl:param name="inputText" />
		<xsl:param name="maxLength" />
		<xsl:variable name="singleQuote" select='"&apos;"' />
		<xsl:variable name="doubleQuote" select="'&quot;'" />
		<xsl:variable name="vAllowedSymbolsPart1" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}\?/#'"/>
		<xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
		<xsl:variable name="vCleanedText" select="translate($inputText,translate($inputText, $vAllowedSymbols, ''),'')"/>
		<xsl:value-of select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
	</xsl:template>
	<!-- Clean AlphaField end -->
	<!-- Value mapping template -->
	<xsl:template name="StopTypeMapValue">
		<xsl:param name="ValueToConvert" select="0"/>
		<xsl:variable name="StopTypeMap">
			<map>
				<entry key="Pick">SF</entry>
				<entry key="Drop">CN</entry>
			</map>
		</xsl:variable>
		<xsl:value-of select="msxsl:node-set($StopTypeMap)/map/entry[@key=$ValueToConvert]"/>
	</xsl:template>
	<!-- Value mapping template -->
	<!-- Set default if empty template start -->
	<xsl:template name="SetDefaultIfEmpty">
		<xsl:param name="pNode"/>
		<xsl:param name="pDefaultValue"/>
		<xsl:if test="$pNode">
			<xsl:value-of select="$pNode"/>
		</xsl:if>
		<xsl:if test="not($pNode)">
			<xsl:value-of select="$pDefaultValue"/>
		</xsl:if>
	</xsl:template>
	<msxsl:script language="C#" implements-prefix="userCSharp">
		<![CDATA[
  //The below line initializes the Array to hold the values listed below. For example: [x,y] x = number of rows, and y = number of columns. update accordingly
  string[,] addrListControlled = new string[39, 4] {
  {"CPSG1","10855 METRO COURT #E-F","MARYLAND HEIGHTS","63043"},
{"CPSG2","11110 METRIC BLVD., STE. C","AUSTIN","78758"},
{"CPSG3","1150 W. ALAMEDA DR SUITE #3","TEMPE","85282"},
{"CPSG4","11621 INVESTOR DRIVE","BATON ROUGE","70814"},
{"CPSG5","1172 NATIONAL DRIVE SUITE#70","SACRAMENTO","95834"},
{"CPSG6","11819 STARCREST RD","SAN ANTONIO","78247"},
{"CPSG7","13220 MURPHY RD #600","STAFFORD","77477"},
{"CPSG8","1339 WEST TRENTON AVE","ORANGE","92867"},
{"CPSG9","1350-A GREENBRIAR DRIVE","ADDISON","60101"},
{"CPSG10","14520 INTERURBAN AVE. SOUTH #150","TUKWILA","98168"},
{"CPSG11","1506 CAPITAL AVE #100","PLANO","75074"},
{"CPSG11","1506 Capital Ave #100","PLANO","75074"},
{"CPSG11","1506 Capital Ave #100","PLANO","75074"},
{"CPSG12","15525 NEO PARKWAY","GARFIELD HEIGHTS","44128"},
{"CPSG13","16659 ARMINTA ST","VAN NUYS","91406"},
{"CPSG14","1810 OAKLAND RD #D","SAN JOSE","95131"},
{"CPSG15","1859 LINDBERGH ST. #300","CHARLOTTE","28208"},
{"CPSG16","19020 N. INDIAN CANYON DR","DESERT PALM SPRINGS","92258"},
{"CPSG17","222 EAST REDONDO BEACH BLVD #B","GARDENA","90248"},
{"CPSG18","2282 S PRESIDENTS DR SUITE D","WEST VALLEY CITY","84120"},
{"CPSG19","2425 POMONA RD","CORONA","92880"},
{"CPSG20","2495 BLVD OF THE GENERALS BLDG B #700","NORRISTOWN","19406"},
{"CPSG21","300 TOWNPARK DR NW  BLDG 2 SUITE 210","KENNESAW","30144"},
{"CPSG22","3008 SKYWAY CIRCLE S","IRVING","75038"},
{"CPSG23","3110 W. CALIFORNIA AVE. SUITE C","SALT LAKE CITY","84104"},
{"CPSG24","35 MELANIE LANE","WHIPPANY","07981"},
{"CPSG25","3901 SW 47TH AVE # 406","FT LAUDERDALE","33314"},
{"CPSG26","4601 S. PINEMONT DR # 118","HOUSTON","77041"},
{"CPSG27","5000 LINBAR DRIVE SUITE# 297","NASHVILLE","37211"},
{"CPSG28","5000 OSAGE ST # 500","DENVER","80221"},
{"CPSG29","5906 BRECKENRIDGE PKWY SUITE H","TAMPA","33610"},
{"CPSG30","6329 ALL AMERICAN BLVD.","ORLANDO","32810"},
{"CPSG31","637 S. VINEWOOD ST.","ESCONDIDO","92029"},
{"CPSG32","6380 S. VALLEY VIEW RD #D-400","LAS VEGAS","89118"},
{"CPSG33","66 BRIDGE ROAD","ISLANDIA","11749"},
{"CPSG34","6816-C ACADEMY PKWY EAST NE","ALBUQUERQUE","87109"},
{"CPSG35","6824 INDUSTRIAL DRIVE #101","BELTSVILLE","20705"},
{"CPSG36","685 CROSS POINTE RD","GAHANNA","43230"},
{"CPSG37","8410 NW 17TH ST","DORAL","33126"}
};
  

public string ControlledInOut(string addr, string city, string addr2, string city2)
{
	string retVal = "Not Found";
	addr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	addr2 = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city2 = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	
	for (int row = 0; row < 39; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListControlled.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city)
			{
				if (Regex.Replace(addrListControlled.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr)
				{
					retVal = "O";
					break;
				}
			}
		}
	}
	if (retVal == "Not Found")
	{
		for (int row = 0; row < 39; row++)
		{
			for (int col = 0; col < 4; col++)
			{
				if (Regex.Replace(addrListControlled.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city2)
				{
					if (Regex.Replace(addrListControlled.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr2)
					{
						retVal = "I";
						break;
					}
				}
			}
		}
	}
	return retVal;
}

public string ControlledLocCode(string addr, string city, string addr2, string city2, string inOut)
{
	string vAddr;
	string vCity;
	string retVal = "Not Found";
	
	if (inOut == "O")
	{
		vAddr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	else
	{
		vAddr = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	
	for (int row = 0; row < 39; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListControlled.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vCity)
			{
				if (Regex.Replace(addrListControlled.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vAddr)
				{
					retVal = addrListControlled.GetValue(row, col-2).ToString();
					break;
				}
			}
		}
	}
	return retVal;
}

  string[,] addrListMaclin = new string[82, 4] {
{"ATTLE","330 VICTOR AVENUE","ATTLEBORO","02703"},
{"ATTLEA","330 OAKHILL AVENUE","ATTLEBORO","02703"},
{"BROWN","751 NORTH DUPREE AVE","BROWNSVILLE","38012"},
{"BROWNA","751R NORTH DUPREE AVE","BROWNSVILLE","38012"},
{"BROWNK","595 BLACKWELL STREET","BROWNSVILLE","38012"},
{"BROWNL","1667 E MAIN ST","BROWNSVILLE","38012"},
{"BROWNL","70 E MAIN ST","BROWNSVILLE","38012"},
{"BROWNL","70 E MAIN STREET","BROWNSVILLE","38012"},
{"BGS","JOHN DEERE STR  3","BRUCHSAL","76646"},
{"BRUCH","JOHNDEERESTR 3","BRUCHSAL","76646"},
{"CHARL","1917 JOHN CROSLAND JR DR","CHARLOTTE","28260"},
{"CITYO","420 SOUTH 6TH AVENUE","CITY OF INDUSTRY","91746"},
{"CITYOA","515 SOUTH 6TH AVENUE","CITY OF INDUSTRY","91747"},
{"ADA","100 ADAMS ROAD","CLINTON","01510"},
{"COMME","6080 PEACHTREE STREET","COMMERCE","90040"},
{"MOR","8470 GRAN VISTA","EL PASO","79907"},
{"CON","703 SOUTH CLEVELAND MASSILLON","FAIRLAWN","44333"},
{"FOUNT","1092 N OLD LAURENS ROAD","FOUNTAIN INN","29644"},
{"DUR","502 CONNIE AVENUE","FREMONT","49412"},
{"GENK","PANISWIJERSTRAAT 92","GENK","3600"},
{"GENKB","3600 GENK","GENK",""},
{"GENKC","GELEENLAAN 23","GENK",""},
{"BYC","SCHEMMENER STR 28 30","GUMMERSBACH","51647"},
{"HENDE","3058 OHIO DRIVE","HENDERSON","42420"},
{"HENDEC","3070 OHIO DRIVE","HENDERSON","42420"},
{"HENDEF","390 COMMUNITY DRIVE","HENDERSON","42420"},
{"ISI","240 NOVY STREET","JACKSON","38301"},
{"JACKS","4545 NORTH JACKSON","JACKSONVILLE","75766"},
{"JAMESC","3518 DILLON ROAD","JAMESTOWN","27282"},
{"CSK","78 PING SHENG ROAD","JIANGSU","215126"},
{"JIANGB","NO 78 PING SHENG ROAD","JIANGSU","215126"},
{"JIANGC","78 PING SHENG ROAD","JIANGSU","215126"},
{"KENTO","320 MAIN STREET","KENTON","38233"},
{"GRL","GUSTAV STRESEMANN STR  2","Leipheim","89340"},
{"AIC","20 MOHAWK DRIVE","LEOMINSTER","01453"},
{"LEOMI","33 FULLER STREET","LEOMINSTER","01453"},
{"LEOMID","20 MOHAWK DRIVE","LEOMINSTER","01453"},
{"LEOMIE","78 MARGUERITE AVE","LEOMINSTER","01453"},
{"MOD","78 MARGUERITE AVE","LEOMINSTER","01453"},
{"CLP","880 ACADEMY ROAD","LONG CREEK","29658"},
{"JER","250 BRIDGE ST","MINVERVA","44657"},
{"MOUNT","400 GOODYEAR ROAD","MOUNT PLEASANT","56241"},
{"BEL","1600 W LA QUINTA RD STE 1","NOGALES","85621"},
{"IMP","2439 N GRAND AVE","NOGALES","85621"},
{"NOGALA","1600 W LAQUINTA ROAD  STE 1","NOGALES","85621"},
{"PAWTU","505 CENTRAL AVENUE","PAWTUCKET","02861"},
{"PAWTUF","300 ARMISTICE BLVD","PAWTUCKET","02861"},
{"PAWTUH","1100 YORK AVE","PAWTUCKET","02861"},
{"PAWTUI","90 MENDON AVE","PAWTUCKET","02861"},
{"THIRD","THIRD PARTY GENERIC EDI","PAWTUCKET","02862"},
{"PHILD","2900 EAST ALLEGHANY AVE","PHILDELPHIA","19134"},
{"HAR","1711 COMMERCE DRIVE","PIQUA","45356"},
{"COS","194 ROUTE DE LORIENT","RENNES","35043"},
{"LOU","8636 SORENSEN AVE","SANTA FE SPRINGS","90670"},
{"CAP","105 WAREHOUSE ROAD","SENECA","29672"},
{"CSS","4600 WAIQINGSONG ROAD","SHANGHAI",""},
{"GLL","21 LOK YANG WAY JURONG","SINGAPORE","628635"},
{"SINGA","41 SHIPYARD ROAD","SINGAPORE","628134"},
{"SINGAC","21 LOK YANG WAY JURONG","SINGAPORE","628635"},
{"SAINT","300 INDUSTRIAL PARK ROAD","ST ALBANS","05478"},
{"STEIN","DORFSTRASSE 13","STEINSFELD","91628"},
{"BCW","1050 GREENFIELD DRIVE","TIFFIN","52340"},
{"MEI","700 INDUSTRIAL DRIVE","WAPAKONETA","45895"},
{"ARL","60 EAST STREET A","WARE","01082"},
{"WASHI","2833 WEST CHESTNUT STREET","WASHINGTON","15301"},
{"SCN","145 LINWOOD RAOD","WATERTOWN","37184"},
{"WHEEL","555 ALLENDALE DR","WHEELING","60090"},
{"WILLI","170 BOYER CIR SUITE 10","WILLISTON","05495"},
{"MSP","150 BLACKSTONE RIVER ROAD","WORCESTER","01607"},
{"BROWN","751 N DUPREE AVE","BROWNSVILLE","38012"},
{"BROWNK","595 BLACKWELL ST","BROWNSVILLE","38012"},
{"BROWNL","1667 E MAIN STREET","BROWNSVILLE","38012"},
{"CITYOB","420 S 6TH AVE","CITY OF INDUSTRY","91746"},
{"HENDEC","3070 OHIO DR","HENDERSON","42420"},
{"JAMESC","3518 DILLON RD","JAMESTOWN","27282"},
{"FOUNT","1092 N OLD LAURENS RD","FOUNTAIN INN","29644"},
{"SAINT","300 INDUSTRIAL PARK RD","ST ALBANS","05478"},
{"JACKS","4545 N JACKSON ST","JACKSONVILLE","75766"},
{"JACKS","4545 NORTH JACKSON ST","JACKSONVILLE","75766"},
{"LEOMI","33 FULLER ST","LEOMINSTER","01453"},
{"SAINT","300 INDUSTRIAL PARK RD","SAINT ALBANS","05478"},
{"ATTLE","330 VICTOR RD","ATTLEBORO","02703"}
};
  

public string MaclinInOut(string addr, string city, string addr2, string city2)
{
	string retVal = "Not Found";
	addr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	addr2 = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city2 = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	
	for (int row = 0; row < 82; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListMaclin.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city)
			{
				if (Regex.Replace(addrListMaclin.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr)
				{
					retVal = "O";
					break;
				}
			}
		}
	}
	if (retVal == "Not Found")
	{
		for (int row = 0; row < 82; row++)
		{
			for (int col = 0; col < 4; col++)
			{
				if (Regex.Replace(addrListMaclin.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city2)
				{
					if (Regex.Replace(addrListMaclin.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr2)
					{
						retVal = "I";
						break;
					}
				}
			}
		}
	}
	return retVal;
}

public string MaclinLocCode(string addr, string city, string addr2, string city2, string inOut)
{
	string vAddr;
	string vCity;
	string retVal = "Not Found";
	
	if (inOut == "O")
	{
		vAddr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	else
	{
		vAddr = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	
	for (int row = 0; row < 82; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListMaclin.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vCity)
			{
				if (Regex.Replace(addrListMaclin.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vAddr)
				{
					retVal = addrListMaclin.GetValue(row, col-2).ToString();
					break;
				}
			}
		}
	}
	return retVal;
}

 string[,] addrListVyaire = new string[14, 4] {
{"Vyaire5","1749 STERGIOS RD.","CALEXICO","92231"},
{"Vyaire6","2710 NORTHRIDGE DR NW","GRAND RAPIDS","49544"},
{"Vyaire14","6201 GLOBAL DISTRIBUTION WAY","LOUISVILLE","40228"},
{"Vyaire15","6201 GLOBAL DISTRIBUTION WAY","LOUISVILLE","40228"},
{"Vyaire18","CERRADA VIA DE LA PROD NO 85","MEXICALI","21397"},
{"Vyaire19","CERRADA VIA DE LA PROD NO 85","MEXICALI","21397"},
{"Vyaire23","500 PALMETTO LOGISTICS PKWY","PALMETTO","30268"},
{"Vyaire26","6141 EASTON RD","PLUMSTEADVILLE","18949"},
{"Vyaire27","3328 COPELAND WAY","POWHATAN","23139"},
{"Vyaire30","CERRADA VIA DELA PRODUCCIONN85","SANTA ROSA","21397"},
{"Vyaire38","15152 W CAMELBACK RD","LITCHFIELD PARK","85340"},
{"Vyaire39","15152 W CAMELBACK RD","GLENDALE","85340"},
{"Vyaire40","30 SPUR DR","EL PASO","79906"},
{"Vyaire41","8655 COMMERCE DR","SOUTHAVEN","38671"},
};
public string SunMedInOut(string addr, string city, string addr2, string city2)
{
	string retVal = "Not Found";
	addr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	addr2 = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city2 = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	
	for (int row = 0; row < 14; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListVyaire.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city)
			{
				if (Regex.Replace(addrListVyaire.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr)
				{
					retVal = "O";
					break;
				}
			}
		}
	}
	if (retVal == "Not Found")
	{
		for (int row = 0; row < 14; row++)
		{
			for (int col = 0; col < 4; col++)
			{
				if (Regex.Replace(addrListVyaire.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city2)
				{
					if (Regex.Replace(addrListVyaire.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr2)
					{
						retVal = "I";
						break;
					}
				}
			}
		}
	}
	return retVal;
}

public string SunMedLocCode(string addr, string city, string addr2, string city2, string inOut)
{
	string vAddr;
	string vCity;
	string retVal = "Not Found";
	
	if (inOut == "O")
	{
		vAddr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	else
	{
		vAddr = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	
	for (int row = 0; row < 14; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListVyaire.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vCity)
			{
				if (Regex.Replace(addrListVyaire.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vAddr)
				{
					retVal = addrListVyaire.GetValue(row, col-2).ToString();
					break;
				}
			}
		}
	}
	return retVal;
}

string[,] addrListSmuckers = new string[380, 4] {
{"SMCK1","250 JOHNSON LAKE RD","ADAIRSVILLE","30103"},
{"SMCK2","1347 N MAIN ST.","ORRIVILLE","44667"},
{"SMCK3","110 COLLINS","ORRVILLE","44618"},
{"SMCK4","375 ORR STREET","ORRVILLE","44667"},
{"SMCK5","NORTH WALNUT ST WH","ORRVILLE","44667"},
{"SMCK6","1840 W SPENCER STREET","APPLETON","54914"},
{"SMCK7","2730 N ROEMER RD","APPLETON","54911"},
{"SMCK8","P.O. BOX 280","ORRVILLE","44667"},
{"SMCK9","11420 GULF STREAM AVE.","ARLINGTON","38002"},
{"SMCK10","37 SPEEDWAY AVENUE","CHICO","95928"},
{"SMCK11","502 BROWN AVE","ASHTON","61006"},
{"SMCK12","505 HICKS","ASHTON","61006"},
{"SMCK13","PO BOX 371","ASHTON","61006"},
{"SMCK14","340 OLD BAY LANE","HAVRE DE GRACE","21078"},
{"SMCK15","1775 WEST GATE PARKWAY","ATLANTA","30336"},
{"SMCK16","6150 XAVIER DRIVE SW","ATLANTA","30336"},
{"SMCK17","7916 W. BELLEVUE RD.","ATWATER","95301"},
{"SMCK18","18101 E. COLFAX","AURORA","80011"},
{"SMCK19","2450 AIRPORT BLVD.","AURORA","80011"},
{"SMCK20","2450 AIRPORT BLVD.UNIT H","AURORA","80011"},
{"SMCK21","5000 E RAINES RD","MEMPHIS","38118"},
{"SMCK22","4740 BURBANK RD","MEMPHIS","38118"},
{"SMCK23","1050 STANTON","RIPON","54971"},
{"SMCK24","100 HOPE ROAD","BYESVILLE","43723"},
{"SMCK25","1147 AKRON ROAD","WOOSTER","44691"},
{"SMCK26","718 CEDAR & ELLICOTT ST","BATAVIA","14021"},
{"SMCK27","PO BOX 718","BATAVIA","14021"},
{"SMCK28","4875 SW GRIFFITH DR","BEAVERTONOR","97005"},
{"SMCK29","4622 MERCEDES DRIVE","BELCAMP","21017"},
{"SMCK30","50 HELLER ROAD","BELLMAWR","8031"},
{"SMCK31","700 SOUTH RAYMOND AVENUE","FULLERTON","92631"},
{"SMCK32","950 CLOVERLEAF ST NE","MASSILLION","44646"},
{"SMCK33","10959 FISHER ROAD NW","BOLIVAR","44680"},
{"SMCK34","1602 ISLAND","LAREDO","78041"},
{"SMCK35","885 NORTH KINZIE AVE","BRADLEY","60915"},
{"SMCK36","301 S WALNUT","BURLINGTON","98223"},
{"SMCK37","10 WEST MAGNOLIA BOULEVARD","BURBANK","91502"},
{"SMCK38","800 COMMERCIAL AVE","OXNARD","93030"},
{"SMCK39","300 STATE STREET","BROCKPORT","14420"},
{"SMCK40","7130 WINNETKA AVE N.","BROOKLYN PARK","55428"},
{"SMCK41","6200 BECKLEY STREET","BALTIMORE","21224"},
{"SMCK42","5650 DOLLY AVENUE","BUENA PARK",""},
{"SMCK43","6570 ALTURA BLVD","BUENA PARK","90621"},
{"SMCK44","908 EAST 3RD ST","OXNARD","93030"},
{"SMCK45","315 SHIP CANAL PARKWAY","BUFFALO","14218"},
{"SMCK46","4900 N AMERICA DRIVE","BUFFALO","14224"},
{"SMCK47","901 FUHMANN BLVD","BUFFALO","14203"},
{"SMCK48","17400 NE SACRAMENTO","PORTLAND","97230"},
{"SMCK49","23303 NE SANDY BLVD","TROUTDALE","97060"},
{"SMCK50","6350 BRACKBILL BLVD HAMPDEN #1","MECHANICSBURG","17050"},
{"SMCK51","14840 E PROCTER AVE","CITY OF INDUSTRY","91746"},
{"SMCK52","10754 ARTESIA BLVD","CERRITOS","90703"},
{"SMCK53","10028 METROMOUNT INDUSTRIAL BL","CHARLOTTE","28269"},
{"SMCK54","2641 STEPHENSON DR","MURFREESBORO","37130"},
{"SMCK55","P.O. BOX 604","GRANDVIEW","98930"},
{"SMCK56","2515 EAST 43RD ST","CHATTANOOGA","37407"},
{"SMCK57","1037 STATE ST","CHESTER","62233"},
{"SMCK58","2150 ROSWELL DRIVE","PITTSBURGH","15205"},
{"SMCK59","3101 SOUTH KEDZIE AVENUE","CHICAGO","60623"},
{"SMCK60","3247 SOUTH KEDZIE AVENUE","CHICAGO","60623"},
{"SMCK61","1310 CITIZEN'S PKWY","MORROW","30260"},
{"SMCK62","29 SPEEDWAY AVE","CHICO","95928"},
{"SMCK63","525 DUNHAM ROAD","ST CHARLES","60174"},
{"SMCK64","2151 EAST KEMPER RD","CINCINNATI","45241"},
{"SMCK65","300 SHORELAND DRIVE","CINCINNATI","41094"},
{"SMCK66","565 EAST CALIFORNIA STREET","ONTARIO","91761"},
{"SMCK67","4204 SPRING GROVE AVE","CINCINNATI","45217"},
{"SMCK68","7510 SE ALTMAN","GRESHAM","97080"},
{"SMCK69","5300 VINE ST","CINCINNATI","45217"},
{"SMCK70","551 MURRAY RD","CINCINNATI","45217"},
{"SMCK71","5750 ESTES AVE","CINCINNATI","45232"},
{"SMCK72","14601 OLD GENTILLY ROAD","NEW ORLEANS","70129"},
{"SMCK73","6190 CENTER HILL AVE.","CINCINNATI","45244"},
{"SMCK74","6210 CENTER HILL AVENUE","CINCINNATI","45224"},
{"SMCK75","701 BROADWAY","KANSAS CITY","64105"},
{"SMCK76","2700 EAST 40TH STREET","CLEVELAND","44115"},
{"SMCK77","300 W FM HIGHWAY 1417","SHERMAN","75092"},
{"SMCK78","400 TECHNOLOGY DRIVE","COAL CENTER","15423"},
{"SMCK79","216 DELAWARE AVENUE","COHOES",""},
{"SMCK80","89 EASTLY RD","COLLIERVILLE","38017"},
{"SMCK81","26100 SW 95TH AVE. #205","WILSONVILLE","97070"},
{"SMCK82","2400 SETTERLIN DRIVE","COLUMBUS","43228"},
{"SMCK83","4350 ROBERT ROAD","COLUMBUS","43228"},
{"SMCK84","2550 AIRPORT BLVD.","AURORA","80011"},
{"SMCK85","4040 PIPESTONE ROAD","DALLAS","75212"},
{"SMCK86","8901 FORNEY ROAD","DALLAS","75227"},
{"SMCK87","1725 MACLEOD DR. STE M","LAWRENCEVILLE","30043"},
{"SMCK88","100 WEST ALLUVIAL","DELMAR","95077"},
{"SMCK89","2450 AIRPORT BLVD.","DENVER","80011"},
{"SMCK90","2450 AIRPORT BLVD.UNIT H","DENVER","80011"},
{"SMCK91","4475 EAST 50TH AVENUE","DENVER","80216"},
{"SMCK92","12885 EATON AVENUE","DETROIT","48227"},
{"SMCK93","1267 COBB INDUSTRIAL DRIVE","MARIETTA","30066"},
{"SMCK94","303 A SALINAS ROAD","WATSONVILLE","95077"},
{"SMCK95","100 HAWKINS BLVD","EL PASO","79932"},
{"SMCK96","1000 HAWKINS","EL PASO","79932"},
{"SMCK97","400 CASCADE WAY","WATSONVILLE","95076"},
{"SMCK98","5500 CHEF MENTEUR HWY","NEW ORLEANS","70126"},
{"SMCK99","64490 HIGHWAY 434","LACOMBE","70446"},
{"SMCK100","6920 EXECUTIVE PARKWAY","KANSAS CITY","64120"},
{"SMCK101","6920 NE EXECUTIVE DRIVE","KANSAS CITY","64120"},
{"SMCK102","15-01 POLLITT DRIVE","FAIR LAWN","7410"},
{"SMCK103","8180 NW 58TH STREET","DORAL","33166"},
{"SMCK104","325 OSBORNE-WHSE","FAIRFIELD","45014"},
{"SMCK105","4275 THUNDERBIRD LANE","FAIRFIELD","45014"},
{"SMCK106","100 WEST ALLUVIAL","CLOVIS","93611"},
{"SMCK107","JM SMUCKER CO","GRANDVIEW","98930"},
{"SMCK108","5625 W 1200-SOUTH","PAYSON","84651"},
{"SMCK109","10459 S MUSKEGON AVE","CHICAGO","60617"},
{"SMCK110","122 KOHLMAN ROAD","FOND DU LAC","54936"},
{"SMCK110","122 KOHLMAN RD","FOND DU LAC","54936"},
{"SMCK111","2550 23RD AVE","FOREST GROVE","97116"},
{"SMCK112","4124 24TH AVENUE","FOREST GROVE","97116"},
{"SMCK113","11130 WEST KING ST","FRANKLIN PARK","60131"},
{"SMCK114","216 12TH ST NE","STRASBURG",""},
{"SMCK115","266 OLDMAN ROAD","WOOSTER","44691"},
{"SMCK116","333 WADSWORTH ROAD","ORRVILLE","44667"},
{"SMCK117","5635 CLAY AVENUE SW","GRAND RAPIDS","49548"},
{"SMCK118","100 FORSEL ROAD","GRANDVIEW","98930"},
{"SMCK119","250 AVENUE B","GRANDVIEW","98930"},
{"SMCK120","250 GRAND RIDGE","GRANDVIEW","90930"},
{"SMCK121","1740 MAIN AVENUE WEST","FARGO","58078"},
{"SMCK122","1740 MAIN AVENUE  W","WEST FARGO","58078"},
{"SMCK123","PO BOX 608","GRANDVIEW","98930"},
{"SMCK124","651 MILL  ROAD","FOGELSVILLE","18051"},
{"SMCK125","6531 COCHRAN ROAD","SOLON","44139"},
{"SMCK126","4000-A PORETT DRIVE","GURNEE","60031"},
{"SMCK127","4000-A PORETT DRIVE STE A","GURNEE","60031"},
{"SMCK128","3110 HOMEWARD WAY","HAMILTON","45014"},
{"SMCK129","542 PORTWALL ST.","HOUSTON","77029"},
{"SMCK130","2035 INNIS ROAD","COLUMBUS","43224"},
{"SMCK130","2035 INNIS RD","COLUMBUS","43224"},
{"SMCK131","801 EDWARD AVE.","HARAHAN","70123"},
{"SMCK132","4075 LAKESIDE DRIVE","RICHMOND","94806"},
{"SMCK133","ROUTE 28","HAWTHORN","16230"},
{"SMCK134","111B ENTERPRISE DR","HEBRON","43025"},
{"SMCK135","3100 WAREHAM RD.","SHELBY","44875"},
{"SMCK136","1740 WESTGATE PARKWAY","ATLANTA","30336"},
{"SMCK137","1060 LOCKWOOD DRIVE","HOUSTON","77020"},
{"SMCK138","16110 E HARDY ROAD","HOUSTON","77032"},
{"SMCK139","700 MALOGA PLACE","ONTARIO","91761"},
{"SMCK140","3900 HARRISBURG BLVD","HOUSTON","77003"},
{"SMCK141","4494 CAMPBELL RD","HOUSTON","77041"},
{"SMCK142","2875 S. PIPESTONE ROAD","BENTON HARBOR","49022"},
{"SMCK143","800 BURNETT","HOUSTON",""},
{"SMCK144","9802 WINDMILL PARK LANE","HOUSTON","77064"},
{"SMCK145","3420 EAST VERNON AVENUE","LOS ANGELES","90058"},
{"SMCK146","232 WEST HAYREND WAY","IDAHO FALLS","83402"},
{"SMCK147","1200 JUDD AVE","GRAND RAPIDS","49509"},
{"SMCK148","4444 AIRPORT EXPRESSWAY","INDIANAPOLIS","46241"},
{"SMCK149","804 BENNETT AVENUE","PROSSER","99350"},
{"SMCK150","1 INTERSTATE DR.","NAPOLEON","43535"},
{"SMCK151","207 DOLITTLE","JACKSONVILLE","32254"},
{"SMCK152","2 COLONY ROAD","JERSEY CITY","7305"},
{"SMCK153","2525 WEST 20TH WSE #2","JOPLIN","64801"},
{"SMCK154","3001 DAVIS BLVD","JOPLIN","64801"},
{"SMCK155","3001 DAVIS BLVD WHSE 3","JOPLIN","64801"},
{"SMCK156","3001 DAVIS BLVD. WAREHOUSE # 6","JOPLIN","64804"},
{"SMCK157","14555 SOUTH PEACH AVENUE","SELMA","93662"},
{"SMCK158","6147 WESTERN ROW","MASON","45040"},
{"SMCK159","6301 STILLWELL","KANSAS","64120"},
{"SMCK160","1026 N. CENTURY AVENUE","KANSAS CITY","64120"},
{"SMCK161","3177 MERCIER STREET","KANSAS CITY","64111"},
{"SMCK162","4141 FAIRBANKS AVE","KANSAS CITY","66106"},
{"SMCK163","6500 INLAND DRIVE","KANSAS CITY","66110"},
{"SMCK164","10900 CENTRAL PORT DRIVE","ORLANDO","32824"},
{"SMCK165","401 MURRAY RD","CINCINNATI","45217"},
{"SMCK166","5204 SPRING GROVE AVE","CINCINNATI","45217"},
{"SMCK167","19005 64TH SO","KENT","98124"},
{"SMCK168","7011 S. 188TH STREET","KENT","98032"},
{"SMCK169","681 W WARELOO ROAD","AKRON","44314"},
{"SMCK170","2705 CASPAR","BLYTHEVILLE","72315"},
{"SMCK171","1 WEST HEGELER LANE","DANVILLE","61832"},
{"SMCK172","5787 HAROLD GATTY DRIVE","SALT LAKE CITY","84116"},
{"SMCK173","3592 KNIGHT ARNOLD RD","MEMPHIS","38118"},
{"SMCK174","5264 LAKE STREET","SANDY LAKE","16145"},
{"SMCK175","3010 SADDLECREEK RD","LAKELAND","33081"},
{"SMCK176","1601 W. CALTON STREET","LAREDO","78044"},
{"SMCK177","4789 CROMWELL RD","MEMPHIS","38118"},
{"SMCK178","240 CHESTER ST","SAINT PAUL","55107"},
{"SMCK179","833 EAST MAIN","LEHI","84043"},
{"SMCK180","2425 PALUMBO DR","LEXINGTON","40505"},
{"SMCK180","2471 PALUMBO DR","LEXINGTON","40505"},
{"SMCK181","440 GREENDALE RD","LEXINGTON","40511"},
{"SMCK181","440 GREENDALE RD S#125","LEXINGTON","40511"},
{"SMCK182","767 EAST 3RD STREET","LEXINGTON","40505"},
{"SMCK183","767 WINCHESTER RD","LEXINGTON","40505"},
{"SMCK184","714 SOUTH BLOSSER ROAD","SANTA MARIA","93458"},
{"SMCK185","12001 SEARS DR","LIVONIA","48151"},
{"SMCK186","5653 CREEKSIDE PARKWAY BLD 1","LOCKBOURNE","43137"},
{"SMCK187","625 WEST ANAHEIM STREET","LONG BEACH","90813"},
{"SMCK188","1727 JP HENNESSY DR","LAVERGNE","37086"},
{"SMCK189","1333 SOUTH BLOSSER DRIVE","SANTA MARIA","93458"},
{"SMCK190","1070 SMITHS GROVE","SCOTTSVILLE","42164"},
{"SMCK191","406 2ND ST","LYNDEN","98264"},
{"SMCK192","440 JOE TAMPLIN INDUSTRIAL BLVD","MACON","31217"},
{"SMCK193","605 N WAYNE AVENUE","CINCINNATI","45215"},
{"SMCK194","245 EAST 4TH STREET","MANSFIELD","44901"},
{"SMCK195","16500 E TRUMAN ROAD","INDEPENDENCE","64051"},
{"SMCK196","1225 CASTLE DRIVE","MASON","45040"},
{"SMCK197","905 W OSTEND","BALTIMORE","21230"},
{"SMCK198","6501 DISTRICT BLVD","BAKERSFIELD","93313"},
{"SMCK199","6800 SOUTH WARE RD","MCALLEN","78503"},
{"SMCK200","810 EAST CONTINENTAL AVE","TULARE","92374"},
{"SMCK201","140 GREENWOOD INDUSTRIAL PKWY","MCDONOUGH","30253"},
{"SMCK202","117 MITCH MCCONNELL WAY","BOWLING GREEN","42102"},
{"SMCK203","230 GREENWOOD COURT","MCDONOUGH","30253"},
{"SMCK204","260 DECLARATION DRIVE","MCDONOUGH","30253"},
{"SMCK205","4100 BANDINI BLVD","LOS ANGELES","90023"},
{"SMCK206","3271 INFINITY PARKWAY","MEMPHIS","72301"},
{"SMCK207","187 KOLHMAN ROAD","FOND DU LAC","54936"},
{"SMCK208","4270 CHRYSLER DR","MEMPHIS","38118"},
{"SMCK209","1720 W. BEACH BLVD ROAD","WATSONVILLE","95077"},
{"SMCK210","200 KING MILL ROAD","MCDONOUGH","30253"},
{"SMCK211","5650 CHALLENGE DRIVE","MEMPHIS","38115"},
{"SMCK212","N92 WEST 14401 ANTHONY AVENUE","MENOMOMEE","53051"},
{"SMCK213","1250 LASKEY ROAD","TOLEDO","43612"},
{"SMCK214","420 WEST JONES STREET","MILLERSBURG","44654"},
{"SMCK215","9696 S.E. OMARK DR","MILWAUKEE","97222"},
{"SMCK216","2400 SE MAILWELL DRIVE","MILWAUKIE","97269"},
{"SMCK217","12350 PHILADELPHIA ST","MIRA LOMA","91752"},
{"SMCK218","1260 LASKEY ROAD","TOLEDO","43612"},
{"SMCK219","705 BOULDER DRIVE","BREINIGSVILLE","18031"},
{"SMCK220","120 DECLARATION DR","MCDONOUGH","30253"},
{"SMCK221","1867 DR. FE WRIGHT RD","JACKSON","38301"},
{"SMCK222","10 EMPIRE BLVD","MOONACHIE","7074"},
{"SMCK223","4560 HAMNER AVENUE","MIRA LOMA","91752"},
{"SMCK224","300 CENTRAL AVENUE","UNIVERSITY PARK","60466"},
{"SMCK224","300 CENTRAL AVE","UNIVERSITY PARK","60466"},
{"SMCK225","702 COMMERCE PARK","UNIVERSITY PARK","60466"},
{"SMCK226","8511 MARTIN DRIVE","NEENAH","54956"},
{"SMCK227","300 KECK AVE","NEW BETHLEHEM","16242"},
{"SMCK228","2130 COMMERCE DRIVE","NEW CASTLE","16101"},
{"SMCK229","5690 INDUSTRIAL PARKWAY","SAN BERNARDINO","92407"},
{"SMCK229","5690A INDUSTRIAL PKWY","SAN BERNARDINO","92407"},
{"SMCK230","14800 OLD GENTILLY ROAD","NEW ORLEANS","70129"},
{"SMCK231","434 SOUTH EMERSON","SHELLEY","83274"},
{"SMCK232","240 PRESTON ST","JACKSON","38301"},
{"SMCK233","924 COOKSEN AVE SE","NEW PHILADEPLHIA","44663"},
{"SMCK234","301 ENTERPRISE DRIVE","NEWCOMERSTOWN","43832"},
{"SMCK235","250 GANSON ST","BUFFALO","14240"},
{"SMCK236","50 OAX ROAD","NORTH UMBERLAND","17857"},
{"SMCK237","5653 CREEKSIDE PARKWAY","OBETZ","43125"},
{"SMCK238","5020 SHREVE AVE","SAINT LOUIS","63115"},
{"SMCK239","1301 NORTH 4TH ST","ENID","73702"},
{"SMCK240","4160 SPARTAN DR","OREGON","43616"},
{"SMCK241","100 EAST 1ST ST","ROME","30162"},
{"SMCK242","4636 W COLONIAL DR","ORLANDO","32808"},
{"SMCK243","705 N. SPARTA","STEELVILLE","62288"},
{"SMCK244","1 STRAWBERRY LANE","ORRVILLE","44667"},
{"SMCK245","1111 BOWES ROAD","ELGIN","60123"},
{"SMCK246","ONE QUALITY PLACE","BUCKNER","40010"},
{"SMCK247","1200 NORTH RADDANT ROAD","BATAVIA","60510"},
{"SMCK248","110 NORTH KENSINGTON DRIVE","APPLETON","54915"},
{"SMCK249","7401 TRADE PORT DRIVE","LOUISVILLE","40258"},
{"SMCK250","PO BOX 7","HUDSON","67545"},
{"SMCK251","2050 LAPHAM DRIVE","MODESTO","95354"},
{"SMCK252","125 SALINAS ROAD","PAJARO","95076"},
{"SMCK253","9817 CRESCENT PARK CORPORATION","WEST CHESTER","45069"},
{"SMCK254","560 J STREET","PERRYSBURG","43551"},
{"SMCK255","851 SECOND STREET","PERRYSBURG","43551"},
{"SMCK256","431 N. 47TH AVENUE","PHOENIX","85043"},
{"SMCK257","FIRST & GRAND","STUTTFART","72160"},
{"SMCK258","5900 CARLSON AVE","PORTAGE","46368"},
{"SMCK259","7132 RUPPSVILLE ROAD","ALLENTOWN","18106"},
{"SMCK260","1883 ILLINOIS RT 38 WEST","ASHTON","61006"},
{"SMCK261","2811 SOUTH 11TH ST","SAINT JOSEPH","64503"},
{"SMCK262","3231 NO. 6 RD","RICHMOND",""},
{"SMCK263","3251 DE FOREST CIRCLE","MIRA LOMA","91752"},
{"SMCK264","1050 STANTON","RIPON","54971"},
{"SMCK265","2780 G AVE","OGDEN","84401"},
{"SMCK266","1120 KING STREET","CHATTANOOGA","37407"},
{"SMCK267","300 GATEWAY PKWY","ROANOKE","76262"},
{"SMCK268","5225 TELEGRAPH RD","TOLEDO","43612"},
{"SMCK269","11891 C.R. KOON HWY","PROSPERITY","29127"},
{"SMCK270","5 DOUGLAS STREET","ROME","30161"},
{"SMCK271","PO BOX 908","ROME","30162"},
{"SMCK272","1500 SEDALIA ROAD","SADALIA",""},
{"SMCK273","401 MURRAY RD.","SAINT BERNARD","45217"},
{"SMCK274","551 MURRAY RD","SAINT BERNARD","45217"},
{"SMCK275","2700 HORACE SHEPPARD DR","DOTHAN","36303"},
{"SMCK276","1605 PROSSER RD BLG 4","KNOXVILLE","37917"},
{"SMCK277","255 MONTOYA ROAD","EL PASO","79932"},
{"SMCK278","105 WASHINGTON AVE","SENECA","64865"},
{"SMCK279","2525 EWALD AVE SE","SALEM","97302"},
{"SMCK280","4095 PORTLAND RD","SALEM","97308"},
{"SMCK281","1275 HANSEN STREET","SALINAS","93901"},
{"SMCK282","340 EL CAMINO REAL SOUTH","SALINAS","93901"},
{"SMCK283","546 BRUNKEN AVENUE","SALINAS","93901"},
{"SMCK284","950 S. SANBORN RD","SALINAS","93904"},
{"SMCK285","P.O. BOX 81447","SALINAS","93912"},
{"SMCK286","1200 SOUTH MAIN ST","ANTHONY","79923"},
{"SMCK287","5050 STOUT DR","SAN ANTONIO","78219"},
{"SMCK288","5315 DANSHER ROAD","COUNTRYSIDE","60131"},
{"SMCK289","3211 INDUSTRIAL RD WHSE # 3","JOPLIN","64801"},
{"SMCK290","1665 CATALINA STREET","SAND CITY","93955"},
{"SMCK291","21705 MISSISSIPPI ST","ELWOOD","60421"},
{"SMCK292","196 NEWTON STREET","FREDONIA","14063"},
{"SMCK293","165 WEST LAKE STREET","NORTH LAKE","60164"},
{"SMCK294","611 JAMISON ROAD","ELMA","14059"},
{"SMCK295","4900 NORTH AMERICA DRIVE","WEST SENECA","14224"},
{"SMCK296","BOX 1267","SEDALIA",""},
{"SMCK297","3271 INFINITY PARKWAY","W MEMPHIS","72301"},
{"SMCK298","3271 INFINITY PARKWAY","WEST MEMPHIS","72301"},
{"SMCK299","2151 East Kemper Road","SHARONVILLE","45241"},
{"SMCK300","355 S.HARVARD AVE.","LINDSAY","93247"},
{"SMCK301","831 ALMAR AVE","SANTA CRUZ","95060"},
{"SMCK302","400  N MAIN","HENNING","61848"},
{"SMCK303","1 OLIVE GROVE ST","ROME","30162"},
{"SMCK304","912 SOUTH BLACK CAT ROAD","JOPLIN","64801"},
{"SMCK305","N. 3808 SULLIVAN RD, BLDG 32","SPOKANE","99216"},
{"SMCK306","5204 SPRING GROVE","ST BERNARD","45217"},
{"SMCK307","5289 VINE ST","ST BERNARD","45216"},
{"SMCK308","31900 SOLON ROAD","SOLON","44139"},
{"SMCK309","3901 UNION BLVD","ST LOUIS","63115"},
{"SMCK310","LABASTIDA 912","ZAMORA","2300"},
{"SMCK311","138 SHERLAKE LANE","KNOXVILLE","37923"},
{"SMCK312","750 OAKWOOD ROAD","LAKE ZURICH","60047"},
{"SMCK313","8301 INDUSTRIAL BLVD","BREINIGSVILLE","18031"},
{"SMCK314","8451 WILLARD AVE., STE 100","BREINIGSVILLE","18031"},
{"SMCK315","1525 OAKLEY INDUSTRIAL BLVD","FAIRBURN","30213"},
{"SMCK316","5610 E COLUMBUS DR","TAMPA","33619"},
{"SMCK317","3109 WATER PLANT ROAD","KNOXVILLE","37914"},
{"SMCK317","3109 WATER PLANT RD","KNOXVILLE","37914"},
{"SMCK318","11767 ROAD 27 1/2","MADERA","93637"},
{"SMCK319","2100 STOUGHTON AVE","CHASKA","55318"},
{"SMCK320","7440 SANTA FEE DR","CHICAGO","60525"},
{"SMCK321","1021 N. WALNUT AVE","TULARE","93274"},
{"SMCK322","ARRO CORP","HODGKINS","60525"},
{"SMCK323","33400 DOWE AVENUE","UNION CITY","94587"},
{"SMCK324","1370 PROGRESS ROAD","SUFFOLK","23434"},
{"SMCK325","1201 EDWARDS AVE","HARAHAN","70123"},
{"SMCK326","4100 BANDINI BLVD","VERNON","90023"},
{"SMCK327","117 BARTLEY FLANDERS ROAD","FLANDERS","7836"},
{"SMCK328","16 LAPE ROAD","WATERFORD",""},
{"SMCK329","555 PLEASANT STREET","WATERTON","2172"},
{"SMCK330","857-897 SCHOOL PLACE","GREEN BAY","54303"},
{"SMCK331","400 HIGH POINT ROAD STE. 100","CARTERSVILLE","30120"},
{"SMCK332","3945 OHIO AVE","SAINT CHARLES","60174"},
{"SMCK333","423 SALINAS ROAD","WATSONVILLE","95077"},
{"SMCK334","555 WALKER STREET","WATSONVILLE","95076"},
{"SMCK335","P O BOX 2730","WATSONVILLE","95077"},
{"SMCK336","1 ENGLEHARD DRIVE","MONROE TWP","8831"},
{"SMCK337","235 NORTH NORWOOD","HOUSTON","77011"},
{"SMCK338","1016 SOUTH SUMMIT","ARKANSAS CITY","67005"},
{"SMCK339","935 EDWARDS AVE","NEW ORLEANS","70123"},
{"SMCK340","175 EAST BROADWAY AVE","WESTERVILLE","43081"},
{"SMCK341","1400 B STREET","WILMINGTON","19801"},
{"SMCK342","1420 COIL AVENUE","WILMINGTON","90744"},
{"SMCK343","1192 ILLINOIS STREET","SAN FRANSICO","94107"},
{"SMCK344","1440 SILVERTON RD","WOODBURN","97071"},
{"SMCK345","1625 DOWN RIVER RD","WOODLAND","98837"},
{"SMCK346","26 TOWER HILL LANE","KINNELON","7405"},
{"SMCK347","1700 B OLD MANSFIELD ROAD","WOOSTER","44691"},
{"SMCK348","7255 HAMILTON ENTERPRISE PARK","HAMILTON","45011"},
{"SMCK349","PO BOX 345","RIPON","1"},
{"SMCK350","727 NORTH IOWA STREET","LAWRENCE","66049"},
{"SMCK350","727 NORTH IOWA ST","LAWRENCE","66049"},
{"SMCK350","727 N IOWA ST","LAWRENCE","66049"},
{"SMCK368","3051 Lakeview rd","LAWRENCE","66049"},
{"SMCK351","3939 HIGHWAY 24","TOPEKA","66618"},
{"SMCK352","201 INDUSTRIAL AVE","OKEENE","73763"},
{"SMCK353","6650 LOW STREET","BLOOMSBURG","17815"},
{"SMCK353","6650 LOW ST","BLOOMSBURG","17815"},
{"SMCK354","1200 MARKET ST NE","DECATUR","35601"},
{"SMCK355","64490 HIGHWAY 434","LACOMBE","70445"},
{"SMCK356","18746 MILL ST","MEADVILLE","16335"},
{"SMCK357","345 ROGERS FERRY RD","MEADVILLE","16335"},
{"SMCK358","5000 Bohannon Rd Bldg A","FAIRBURN","30213"},
{"SMCK359","1200 FULGHUM ROAD","WILMER","75172"},
{"SMCK359","1200 FULGHUM RD","WILMER","75172"},
{"SMCK360","6140 PROMONTORY PARKWAY","TRACY","95377"},
{"SMCK360","6140 PROMONTORY PKWY","TRACY","95377"},
{"SMCK361","185 E 1600 N"," SPANISH FORK","84660"},
{"SMCK363","5000 Bohannon Rd Bldg A","FAIRBURN","30213"},
{"SMCK363","5000 Bohannon Rd","FAIRBURN","30213"},
{"SMCK365","801 CENTERVILLE RD","NEWVILLE","17241"},
{"SMCK366","3401 ENTERPRISE ST","SHAFTER","93263"},
{"SMCK367","3800 FANUCCHI WAY","SHAFTER","93262"},
{"SMCK368","60 YUMA ST.","DENVER","80223"}
};
  

public string SmuckersInOut(string addr, string city, string addr2, string city2)
{
	string retVal = "Not Found";
	addr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	addr2 = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city2 = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	
	for (int row = 0; row < 380; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListSmuckers.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city)
			{
				if (Regex.Replace(addrListSmuckers.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr)
				{
					retVal = "O";
					break;
				}
			}
		}
	}
	if (retVal == "Not Found")
	{
		for (int row = 0; row < 380; row++)
		{
			for (int col = 0; col < 4; col++)
			{
				if (Regex.Replace(addrListSmuckers.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city2)
				{
					if (Regex.Replace(addrListSmuckers.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr2)
					{
						retVal = "I";
						break;
					}
				}
			}
		}
	}
	return retVal;
}

public string SmuckersLocCode(string addr, string city, string addr2, string city2, string inOut)
{
	string vAddr;
	string vCity;
	string retVal = "Not Found";
	
	if (inOut == "O")
	{
		vAddr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	else
	{
		vAddr = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	
	for (int row = 0; row < 380; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListSmuckers.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vCity)
			{
				if (Regex.Replace(addrListSmuckers.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vAddr)
				{
					retVal = addrListSmuckers.GetValue(row, col-2).ToString();
					break;
				}
			}
		}
	}
	return retVal;
}

  string[,] addrListMacy = new string[87, 4] {
{"Macy1","219 PERIMETER CENTER PKWY","ATLANTA","30346"},
{"Macy2","3880 N MISSION RD","ATLANTA","30346"},
{"Macy3","500 MEADOWLANDS PKWY","ATLANTA","30346"},
{"Macy4","17000 S CENTER PKWY","ATLANTA","30346"},
{"Macy5","4130 GANDY BLVD","ATLANTA","30346"},
{"Macy6","21301 E 33RD DR","AURORA","80011"},
{"Macy7","12629 MAHONING AVE","NORTH JACKSON","44451"},
{"Macy8","300 ROCK INDUSTRIAL PARK DR","BRIDGETON","63044"},
{"Macy9","20 ELM","BROOKLYN","11201"},
{"Macy10","501 SE WYOMING BLVD","CASPER","82609"},
{"Macy11","524 MEADOWLANDS PARKWAY","SECAUCUS","07097"},
{"Macy12","11 PERINA BLVD","CHERRY HILL","08003"},
{"Macy13","475 KNOTTER DRIVE","CHESHIRE","06410"},
{"Macy14","181 WEST JOHNSON AVE","CHESHIRE","06410"},
{"Macy15","4111 W GEORGE ST","CHICAGO","60641"},
{"Macy16","4340 EUCALYPTUS AVE BUILDING 7","CHINO","91710"},
{"Macy17","15541 E GALE AVE","CITY OF INDUSTRY","91715"},
{"Macy18","PO BOX 182181","COLUMBUS","43218"},
{"Macy19","1661 RAIL COURT NORTH","COLUMBUS","43217"},
{"Macy20","355 WEST CAROB","COMPTON","90220"},
{"Macy21","425 WEST CAROB ST","COMPTON","90220"},
{"Macy22","510 EAST 51ST AVE","DENVER","80216"},
{"Macy23","510 EAST 51ST AVE","DENVER","80216"},
{"Macy24","1124 ELON PLACE","HIGH POINT","27260"},
{"Macy25","1124 ELON PLACE","HIGH POINT","27260"},
{"Macy26","16575 WEST COMMERCE DR","GOODYEAR","85338"},
{"Macy27","7500 BUSINESS PARK DR","GREENSBORO","27409"},
{"Macy28","5300 S.76TH STREET","GREENDALE","53129"},
{"Macy29","28701 HALL RD","HAYWARD","94545"},
{"Macy30","1124 ELON PLACE","HIGH POINT","27260"},
{"Macy31","2103 ERNESTINE","HOUSTON","77023"},
{"Macy32","6020 E 82ND ST","INDIANAPOLIS","46250"},
{"Macy33","15541 E GALE WAY","INDUSTRY","91745"},
{"Macy34","15541 E GALE WAY","INDUSTRY","91745"},
{"Macy35","12629 MAHONING AVE","JACKSON","44451"},
{"Macy36","3300 FASHION WAY","JOPPA","21085"},
{"Macy37","45 OSAGE","KANSAS CITY","660105"},
{"Macy38","91-262 OIHANA","KAPOLEI","96707"},
{"Macy39","15541 EAST GALE AVENUE","CITY OF INDUSTRY","91745"},
{"Macy40","3880 N MISSION RD","LOS ANGELES","90031"},
{"Macy41","333 CAPERTON BLVD","MARTINSBURG","25403"},
{"Macy42","333 CAPERTON BLVD","MARTINSBURG","25403"},
{"Macy43","333 CAPERTON BLVD","MARTINSBURG","25403"},
{"Macy44","22 E FLAGLER ST","MIAMI","33147"},
{"Macy45","13521 SE PHEASANT CT","MILWAUKIE","97222"},
{"Macy46","13521 SE PHEASANT CT","MILWAUKIE","97222"},
{"Macy47","601 MIDPOINT RD","MINOOKA","60447"},
{"Macy48","4401 SARR PKWY","MOUNTAIN","30083"},
{"Macy49","500 MEADOWLANDS PKWY","MOUNTAIN","30083"},
{"Macy50","7373 WESTSIDE AVE","NORTH BERGEN","07047"},
{"Macy51","12629 MAHONING AVE","NORTH JACKSON","44451"},
{"Macy52","7373 WESTSIDE AVE","NORTH BERGEN","07047"},
{"Macy53","451 WEST CAROB ST","COMPTON","90220"},
{"Macy54","35 HENRY ST","SECAUCUS","07094"},
{"Macy55","425 WEST CAROB ST","COMPTON","90220"},
{"Macy56","35 HENRY STREET","SECAUSUS","07094"},
{"Macy57","335 WEST CAROB ST","COMPTON","90220"},
{"Macy58","2820 16TH ST C BLDG","NORTH BERGEN","07047"},
{"Macy59","3775 ALAMEDA ST","OAKLAND","94601"},
{"Macy60","1155 VAUGHN PKWY","PORTLAND","37148"},
{"Macy61","401 CLEARVIEW ROAD","EDISON","08837"},
{"Macy62","401 CLEARVIEW ROAD","EDISON","08837"},
{"Macy63","401 CLEARVIEW RD","EDISON","08837"},
{"Macy64","6200 FRANKLIN BLVD","SACRAMENTO","95824"},
{"Macy65","6200 FRANLIN BLVD SUITE W20C","SACRAMENTO","95824"},
{"Macy66","3728 MARKET ST","SAINT LOUIS","63110"},
{"Macy67","21 SOUTH MAIN STREET","SALT LAKE CITY","84111"},
{"Macy68","500 MEADOWLAND PKWY","SECAUCUS","07094"},
{"Macy68","500 MEADOWLANDS PKWY","SECAUCUS","07094"},
{"Macy69","301 GOVERNOR'S HIGHWAY","SOUTH WINDSOR","06074"},
{"Macy70","4401 SARR PKWY","STONE MOUNTAIN","30083"},
{"Macy71","4130 W GANDY BLVD","TAMPA","33611"},
{"Macy72","17000 SOUTHCENTER PKWY","TUKWILA","98188"},
{"Macy73","7120 E 76TH STREET NORTH","OWASSO","74055"},
{"Macy74","7120 E 76TH STREET NORTH","OWASSO","74055"},
{"Macy75","7120 E 76TH STREET NORTH","OWASSO","74055"},
{"Macy76","1401 NEW YORK AVE PKWY","WASHINGTON","20002"},
{"Macy77","1400 OKIE ST","WASHINGTON","20002"},
{"Macy78","6200 FRANKLIN BLVD","SACRAMENTO","95824"},
{"Macy79","6200 Franklin Blvd","Sacramento","95824"},
{"Macy80","6200 FRANKLIN BLVD","SACRAMENTO","95824"},
{"Macy81","181 WEST JOHNSON AVENUE","CHESHIRE","06410"},
{"Macy82","181 WEST JOHNSON AVENUE","CHESHIRE","06410"},
{"Macy83","9249 MERIDIAN WAY","WEST CHESTER","45069"},
{"Macy84","3919 CHANNEL DR","WEST SACRAMENTO","95691"},
{"Macy85","3601 S 2700 W","WEST VALLEY CITY","84119"},
{"Macy86","301 GOVERNORS HWY","WINDSOR","06074"}
};
public string MacyInOut(string addr, string city, string addr2, string city2)
{
	string retVal = "Not Found";
	addr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	addr2 = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city2 = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	
	for (int row = 0; row < 87; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListMacy.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city)
			{
				if (Regex.Replace(addrListMacy.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr)
				{
					retVal = "O";
					break;
				}
			}
		}
	}
	if (retVal == "Not Found")
	{
		for (int row = 0; row < 87; row++)
		{
			for (int col = 0; col < 4; col++)
			{
				if (Regex.Replace(addrListMacy.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city2)
				{
					if (Regex.Replace(addrListMacy.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr2)
					{
						retVal = "I";
						break;
					}
				}
			}
		}
	}
	return retVal;
}

public string MacyLocCode(string addr, string city, string addr2, string city2, string inOut)
{
	string vAddr;
	string vCity;
	string retVal = "Not Found";
	
	if (inOut == "O")
	{
		vAddr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	else
	{
		vAddr = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	
	for (int row = 0; row < 86; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListMacy.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vCity)
			{
				if (Regex.Replace(addrListMacy.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vAddr)
				{
					retVal = addrListMacy.GetValue(row, col-2).ToString();
					break;
				}
			}
		}
	}
	return retVal;
}

  string[,] addrListSensus = new string[359, 4] {
{"Sensus1","1 INTERNATIONAL DRIVE","RYE BROOK","10573"},
{"Sensus2","151 GRAHAM ROAD","COLLEGE STATION","77842"},
{"Sensus3","2148 PELHAM PARKWAYBLDG 400","PELHAM","35124"},
{"Sensus4","1700/1725 BRANNUM LANE","YELLOW SPRINGS","45387"},
{"Sensus5","7100 BUSSINES PARK DRIVE","HOUSTON","77041"},
{"Sensus6","8200 AUSTIN AVE","MORTON GROVE","60053"},
{"Sensus7","175 STANDARD PARKWAY","CHEEKTOWAGA","14227"},
{"Sensus8","1 GOULDS DRIVE","AUBURN","13021"},
{"Sensus9","4608 BRADLEY","LUBBOCK","79415"},
{"Sensus10","55 ROYAL RD","GUELPH","N1H1T1"},
{"Sensus11","3878 S WILLOW AVENUE 104","FRESNO","93725"},
{"Sensus12","4828 PARKWAY PLAZA BLVD STE 200","CHARLOTTE","28217"},
{"Sensus13","300 LABROSSE AVE","POINTE CLAIRE","H9R4V5"},
{"Sensus14","N 27TH W 23293 ROUNDY DRIVE","PEWAUKEE","53072"},
{"Sensus15","227 S DIVISION STREET","ZELIENOPLE","16063"},
{"Sensus16","84 FLOODGATE ROAD","BRIDGEPORT","08014"},
{"Sensus17","3701 COMPLEJO INDUSTRIAL","CHIHUAHUA","31201"},
{"Sensus18","4001 MURFREESBORO ROAD","ANTIOCH","37013"},
{"Sensus19","*2152 SPRINT BLVD","APOPKA","32703"},
{"Sensus20","*2525 S ORANGE BLOSSOM TRAIL","APOPKA","32703"},
{"Sensus21","2152 SPRINT BLVD","APOPKA","32703"},
{"Sensus22","*2525 S ORANGE BLOSSOM TRAIL","APOPKA","32703"},
{"Sensus23","10590 17TH RD","ARGOS","46501"},
{"Sensus24","11209 LEADBETTER ROAD","ASHLAND","23005"},
{"Sensus25","200 TRADEPORT DRIVESUITE 400","ATLANTA","30354"},
{"Sensus26","817 WEST PEACHTREE STREET","ATLANTA","30308"},
{"Sensus27","*1 GOULDS DRIVE","AUBURN","13021"},
{"Sensus28","*WRIGHT AVE.","AUBURN","13021"},
{"Sensus29","40 YORK ST WAREHOUSE D2","AUBURN","13021"},
{"Sensus30","8039 OAK ORCHARD ROAD","BATAVIA","14020"},
{"Sensus31","12231 INDUSTRIPLEX BLVD STE A","BATON ROUGE","70809"},
{"Sensus32","4725 MERCANTILE STREET","BEAUMONT","77705"},
{"Sensus33","*420 AVENUE DES ROCHEUSES","BEAUPORT","G1C7G6"},
{"Sensus34","*609 RUE ADANAC","BEAUPORT","G1C6G7"},
{"Sensus35","*420 AVENUE DES ROCHEUSES","BEAUPORT","G1C7G6"},
{"Sensus36","*609 RUE ADANAC","BEAUPORT","G1C6G7"},
{"Sensus37","800-900 X STREET","BEDFORD","47421"},
{"Sensus38","80 GREGORY ROAD","BELVILLE","28451"},
{"Sensus39","80 GREGORY ROAD","BELVILLE","28451"},
{"Sensus40","*500 COUNTRY CLUB DR","BENSENVILLE","60106"},
{"Sensus41","510 COUNTRY CLUB DR","BENSENVILLE","60106"},
{"Sensus42","*501 COUNTRY CLUB DR","BENSENVILLE","60106"},
{"Sensus43","100 CUMMINGS CENTERSUITE 445-D","BEVERLY","01915"},
{"Sensus44","100 CUMMINGS CENTERSUITE 535-N","BEVERLY","01915"},
{"Sensus45","100 CUMMINGS CENTERSUITE 535-N","BEVERLY","01915"},
{"Sensus46","6871 KING AVE W","BILLINGS","59106"},
{"Sensus47","2020 HIGHWAY 75","BLOUNTVILLE","37617"},
{"Sensus48","2707 SATURN WAY","BOISE","83709"},
{"Sensus49","10147 WEST EMERALD STREET","BOISE","83704"},
{"Sensus50","99 STOCKHOUSE ROAD","BOZRAH","06334"},
{"Sensus51","*1 FLOODGATE ROAD","BRIDGEPORT","08014"},
{"Sensus52","*22 FLOODGATE ROAD","BRIDGEPORT","08014"},
{"Sensus53","*84 FLOODGATE ROAD","BRIDGEPORT","08014"},
{"Sensus54","*8400 S 77TH AVE","BRIDGEVIEW","60455"},
{"Sensus55","9333 N 49TH STREET","BROWN DEER","53223"},
{"Sensus56","*1950 ELMWOOD AVE","BUFFALO","14207"},
{"Sensus57","*757 E. FERRY STREET","BUFFALO","14211"},
{"Sensus58","*175 STANDARD PARKWAY","BUFFALO","14227"},
{"Sensus59","1744 ROLLINS ROAD","BURLINGAME","94010"},
{"Sensus60","7867 EXPRESS ST UNIT 111","BURNABY","V5A1S4"},
{"Sensus61","*10940 BONAVENTURE DRIVE STE 86","CALGARY","T2J5C8"},
{"Sensus62","*6704-30TH ST","CALGARY","T2C1N9"},
{"Sensus63","*6704-30TH ST","CALGARY","T2C1N9"},
{"Sensus64","110 CATALYST DRIVE","CANTON","28716"},
{"Sensus65","2400 TARPLEYPO BOX 597","CARROLLTON","75006"},
{"Sensus66","2310 MCDANIEL DR.","CARROLLTON","75006"},
{"Sensus67","2310 MCDANIEL DR.","CARROLLTON","75006"},
{"Sensus68","747 E 223RD STREET","CARSON","90745"},
{"Sensus69","*1800 SUPPLY ROAD","CARTERVILLE","62918"},
{"Sensus70","*402 OLD MILL RD","CARTERSVILLE","30120"},
{"Sensus71","204 INDUSTRIAL BLVD","CEDAR PARK","78613"},
{"Sensus72","*5329 SISSONVILLE DRIVE","CHARLESTON","25312"},
{"Sensus73","14125 SOUTH BRIDGE CIRCLE","CHARLOTTE","28273"},
{"Sensus74","14125 SOUTH BRIDGE CIRCLE","CHARLOTTE","28273"},
{"Sensus75","14125 SOUTH BRIDGE CIRCLE","CHARLOTTE","28273"},
{"Sensus76","14125 SOUTH BRIDGE CIRCLE","CHARLOTTE","28273"},
{"Sensus77","4828 PARKWAY PLAZA BLVD STE 200","CHARLOTTE","28217"},
{"Sensus78","4828 PARKWAY PLAZA BLVD STE 200","CHARLOTTE","28217"},
{"Sensus79","4828 PARKWAY PLAZA BLVD STE 200","CHARLOTTE","28217"},
{"Sensus80","*175 STANDARD PARKWAY","CHEEKTOWAGA","14227"},
{"Sensus81","175 STANDARD PARKWAY","CHEEKTOWAGA","14227"},
{"Sensus82","175 STANDARD PARKWAY","CHEEKTOWAGA","14227"},
{"Sensus83","5716 COLUMBIA PARK ROAD","CHEVERLY","20785"},
{"Sensus84","3636 KILBOURNE","CHICAGO","60641"},
{"Sensus85","3701 COMPLEJO INDUSTRIAL","CHIHUAHUA","31201"},
{"Sensus86","7096 HWY 87 EAST","CHINA GROVE","78263"},
{"Sensus87","151 GRAHAM ROAD","COLLEGE STATION","77842"},
{"Sensus88","1701 W WALNUT PARKWAY","COMPTON","90220"},
{"Sensus89","1701 W. WALNUT PARKWAY","COMPTON","90220"},
{"Sensus90","74 GLACIER STREET","COQUITLAM","V3K5Y9"},
{"Sensus91","*1959 SARATOGABLD 29","CORPUS CHRISTI","78417"},
{"Sensus92","*2029 N LEXINGTON BLVD","CORPUS CHRISTI","78409"},
{"Sensus93","*1959 SARATOGABLD 29","CORPUS CHRISTI","78417"},
{"Sensus94","2029 N LEXINGTON BLVD","CORPUS CHRISTI","78409"},
{"Sensus95","114 NORTHPARK BLVD 10","COVINGTON","15401"},
{"Sensus96","570 SOUTH AVENUE","CRANFORD","07016"},
{"Sensus97","10661 NEWKIRK ROAD","DALLAS","75220"},
{"Sensus98","10661 NEWKIRK ROAD","DALLAS","75220"},
{"Sensus99","3001 ROY ORR BLVD","DALLAS","75220"},
{"Sensus100","*107 COLE DR","DARTMOUTH","B2W6K5"},
{"Sensus101","*45A RADDALL AVE","DARTMOUTH","B3B1L4"},
{"Sensus102","*45A RADDALL AVE","DARTMOUTH","B3BIL4"},
{"Sensus103","*3222 11TH AVE SITE C D E","DICKENSON","58104"},
{"Sensus104","*3222 11TH AVE C D E","DICKINSON","58104"},
{"Sensus105","805 LIBERTY BLVD","DU BOIS","15801"},
{"Sensus106","10 DOCK STREET","DU BOIS","15801"},
{"Sensus107","60 POTTSTOWN PIKE PO BOX 160","EAGLE","19480"},
{"Sensus108","6 CONNERTY COURT","EAST BRUNSWICK","08816"},
{"Sensus109","75 NORTHFIELD AVE  RARITAN CTR","EDISON","08837"},
{"Sensus110","20 TRUMAN DRIVE SOUTH","EDISON","8817"},
{"Sensus111","10554 169TH ST","EDMONTON","T5P3X6"},
{"Sensus112","*2000 ARTHUR AVENUE SUITE A","ELK GROVE VILLAGE","60007"},
{"Sensus113","*850 MARK STREET","ELK GROVE VILLAGE","60007"},
{"Sensus114","*2000 ARTHUR AVENUE SUITE A","ELK GROVE VILLAGE","60007"},
{"Sensus115","145 PHILO ROAD W","ELMIRA","14903"},
{"Sensus116","12035 ROJAS DR SUITE F","EL PASO","79936"},
{"Sensus117","12035 ROJAS DR SUITE F","EL PASO","79936"},
{"Sensus118","1450 PULLMAN DRIVE","EL PASO","79936"},
{"Sensus119","1450 PULLMAN DRIVE ROOM 100","EL PASO","79936"},
{"Sensus120","12120 ESTHER LAMA #100","EL PASO","79936"},
{"Sensus121","1450 PULLMAN DR","EL PASO","79936"},
{"Sensus122","12035 ROJAS DR SUITE F","EL PASO","79936"},
{"Sensus123","12035 ROJAS DR SUITE F","EL PASO","79936"},
{"Sensus124","12035 ROJAS DR SUITE F","EL PASO","79936"},
{"Sensus125","93 CLAIREVILLE DRIVE","ETOBICOKE","M9W6K9"},
{"Sensus126","*5323 S HIGHWAY 150","EVANSTON","82930"},
{"Sensus127","9745 HEDDEN ROAD","EVANSVILLE","47725"},
{"Sensus128","9745 HEDDEN ROAD","EVANSVILLE","47725"},
{"Sensus129","*225 WEST STREET","EVANSTON","82930"},
{"Sensus130","9745 HEDDEN ROAD","EVANSVILLE","47725"},
{"Sensus131","950 MAXWELL AVE","EVANSVILLE","47711"},
{"Sensus132","790 A CHADBOURNE RD","FAIRFIELD","94533"},
{"Sensus133","*151 MARTINE STREET","FALL RIVER","02723"},
{"Sensus134","151 MARTINE STREET","FALL RIVER","02723"},
{"Sensus135","275 MARTINE STREET","FALL RIVER","02723"},
{"Sensus136","1373 INDIAN FIELDS RD","FEURA BUSH","12067"},
{"Sensus137","5771 COUNTRY LAKES DRIVE","FORT MYERS","33905"},
{"Sensus138","635 GOLD HILL ROAD","FORT MILL","29715"},
{"Sensus139","635 GOLD HILL ROAD","FORT MILL","29715"},
{"Sensus140","124 COMMERCE DRIVE  BLDG 7","FREEDOM","15042"},
{"Sensus141","3878 S WILLOW AVENUE 104","FRESNO","93725"},
{"Sensus142","3878 S WILLOW STE 104","FRESNO","93725"},
{"Sensus143","3878 S WILLOW STE 104","FRESNO","93725"},
{"Sensus144","5771 COUNTRY LAKES DRIVE","FT MYERS","33905"},
{"Sensus145","124 AIRPORT PARK DRIVE","GARDEN CITY","31408"},
{"Sensus146","128A AIRPORT PARK DR","GARDEN CITY","31408"},
{"Sensus147","2306 SHERWIN ST","GARLAND","75041"},
{"Sensus148","300 SIGMA DR","GARNER","27529"},
{"Sensus149","2240 GOLD RIVER ROAD STE 210","GOLD RIVER","95670"},
{"Sensus150","374 PULASKI HIGHWAY","GOSHEN","10924"},
{"Sensus151","3001 ROY ORR BLVD","GRAND PRAIRIE","75050"},
{"Sensus152","DO NOT USE","DO NOT USE",""},
{"Sensus153","755 PORT AMERICAN PLACE #370","GRAPEVINE","76051"},
{"Sensus154","101 CENTER ST","GREENWOOD","46143"},
{"Sensus155","*55 ROYAL ROAD","GUELPH","N1H1T1"},
{"Sensus156","55 ROYAL RD","GUELPH","N1H1T1"},
{"Sensus157","15 MCQUADE LAKE CRESCENTBAYERS","HALIFAX","B3S1C4"},
{"Sensus158","*5422 W ROSECRANS AVE","HAWTHORNE","90250"},
{"Sensus159","*12200 WILKIE AVE","HAWTHORNE","90250"},
{"Sensus160","*5422 W ROSECRANS AVE","HAWTHORNE","90250"},
{"Sensus161","*12200 WILKIE AVE","HAWTHORNE","90250"},
{"Sensus162","3860 HELBERG DRIVE","HELENA","59602"},
{"Sensus163","6795 PASADENA DRIVE","HORN LAKE","38637"},
{"Sensus164","145 PHILO ROAD WEST","HORSEHEADS","14903"},
{"Sensus165","145 PHILO ROAD WEST","HORSEHEADS","14903"},
{"Sensus166","2727 APPELT DRIVE","HOUSTON","77015"},
{"Sensus167","4310 DIRECTORS ROW","HOUSTON","77092"},
{"Sensus168","7100 BUSSINES PARK DRIVE","HOUSTON","77041"},
{"Sensus169","2754 PACIFIC HIGHWAY","HUBBARD","97032"},
{"Sensus170","8210 HUMBLE-WESTFIELD RDSTE 100","HUMBLE","77338"},
{"Sensus171","5716 COLUMBIA PARK RD","HYATTSVILLE","20785"},
{"Sensus172","7615 W NEW YORK STREET","INDIANAPOLIS","46214"},
{"Sensus173","7615 W NEW YORK STREET","INDIANAPOLIS","46214"},
{"Sensus174","7615 W NEW YORK STREET","INDIANAPOLIS","46214"},
{"Sensus175","17942 COWAN","IRVINE","92614"},
{"Sensus176","17942 COWAN","IRVINE","92614"},
{"Sensus177","240 HAMMOND BLVD","JACKSONVILLE","32254"},
{"Sensus178","6975 12TH ST W","JACKSONVILLE","32220"},
{"Sensus179","15132 PARK OF COMMERCE BLVDSTE1","JUPITER","33478"},
{"Sensus180","2378 WEST LAKE RD","KELOWNA","V1P"},
{"Sensus181","1320 LOCKHART DRIVE NW","KENNESAW","30144"},
{"Sensus182","8445 SOUTH 218TH STREET","KENT","98031"},
{"Sensus183","202 WINSTON CREEK PARKWAY","LAKELAND","33810"},
{"Sensus184","1150 EMMA OAKS TRAILSUITE 150","LAKE MARY","32746"},
{"Sensus185","1150 EMMA OAKS TRAILSUITE 150","LAKE MARY","32746"},
{"Sensus186","RT 4  HWY 9 W","LANCASTER","29720"},
{"Sensus187","20353 64TH AVE STE 203","LANGELY","V2Y1N5"},
{"Sensus188","16830 CHICAGO AVE","LANSING","60438"},
{"Sensus189","1000 HURRICANE SHOALS STE 30","LAWRENCEVILLE","30043"},
{"Sensus190","109 3RD STREETSUITE A","LEETSDALE","15056"},
{"Sensus191","80 GREGORY ROAD","LELAND","28451"},
{"Sensus192","11850 SEARS STREET","LIVONIA","48150"},
{"Sensus193","75 WEST 100 SOUTH XYLEM","LOGAN","84321"},
{"Sensus194","131 MASONVILLE CR","LONDON","N5X3T1"},
{"Sensus195","* 4608 BRADLEY","LUBBOCK","79415"},
{"Sensus196","4608 BRADLEY","LUBBOCK","79415"},
{"Sensus197","NORTH QUAKER RD AND CLOVIS","LUBBOCK","79408"},
{"Sensus198","4621 MURRAY PLACE","LYNCHBURG","24502"},
{"Sensus199","2330 YELLOW SPRINGS RD","MALVERN","19355"},
{"Sensus200","865 W LIBERTY ST RM STE 270","MEDINA","44256"},
{"Sensus201","5570 OLD US HWY 78","MEMPHIS","38118"},
{"Sensus202","7270 N W 12TH STREET","MIAMI","33126"},
{"Sensus203","56 BRADLEY STREET","MIDDLETOWN","06457"},
{"Sensus204","2509 EAST COUNTY RD 90","MIDLAND","79706"},
{"Sensus205","2509 E CR90","MIDLAND","79706"},
{"Sensus206","1615 STATE ROUTE 131","MILFORD","45150"},
{"Sensus207","1615 STATE ROUTE 131","MILFORD","45150"},
{"Sensus208","1615 STATE ROUTE 131","MILFORD","45150"},
{"Sensus209","INACTIVE 2031 S ALDRICH","MILWAUKEE","53207"},
{"Sensus210","*9333 N 49TH ST","MILWAUKE","53223"},
{"Sensus211","4080 N PORT WASHINGTON RD","MILWAUKEE","53212"},
{"Sensus212","11161 HARREL STREET","MIRA LOMA","91752"},
{"Sensus213","11161 HARREL STREET","MIRA LOMA","91752"},
{"Sensus214","11161 HARREL STREET","MIRA LOMA","91752"},
{"Sensus215","5055 SATELLITE DR","MISSISSAUGA","L4W5K7"},
{"Sensus216","9661 194TH ST","MOKENA","60448"},
{"Sensus217","9661 194TH ST","MOKENA","60448"},
{"Sensus218","189 COLLISHAW STPO BOX 158","MONCTON","E1C8K9"},
{"Sensus219","700 LAKEVIEW DRIVE","MONROE","45050"},
{"Sensus220","400 PERIMETER PARK DRIVE","MORRISVILLE","27560"},
{"Sensus221","633 DAVIS DRIVE","MORRISVILLE","27560"},
{"Sensus222","635 DAVIS DRIVE","MORRISVILLE","27560"},
{"Sensus223","637 DAVIS DRIVE","MORRISVILLE","27560"},
{"Sensus224","639 DAVIS DRIVE","MORRISVILLE","27560"},
{"Sensus225","*8200 AUSTIN","MORTON GROVE","60053"},
{"Sensus226","8200 AUSTIN","MORTON GROVE","60053"},
{"Sensus227","8200 AUSTIN","MORTON GROVE","60053"},
{"Sensus228","8200 AUSTIN AVE","MORTON GROVE","60053"},
{"Sensus229","8200 N AUSTIN AVE","MORTON GROVE","60053"},
{"Sensus230","8200 N AUSTIN AVENUE","MORTON GROVE","60053"},
{"Sensus231","6211 MONROE COURT","MORTON GROVE","60053"},
{"Sensus232","157 GLENCOE DR","MT PEARL","A1N4S7"},
{"Sensus233","157 GLENCOE DR","MT PEARL","A1N4S7"},
{"Sensus234","4128 CEDARDALE RDSUITE 103","MT VERNON","98273"},
{"Sensus235","1812 HIGH GROVE LANE","NAPERVILLE","60540"},
{"Sensus236","2291 TECHNICAL PARKWAY","NORTH CHARLESTON","29406"},
{"Sensus237","21 BENTLEY AVE","NEPEAN","K2E6T7"},
{"Sensus238","UNIT 1-5; 1260-34 AVE","NISKU","T9E1K7"},
{"Sensus239","85 DURFEE ST BLDG 315","N KINSTOWN","02852"},
{"Sensus240","10503 MAUMELLE BLVD","N LITTLE ROCK","72113"},
{"Sensus241","10503 MAUMELLE BLVD BUILDING 4","N LITTLE ROCK","72113"},
{"Sensus242","*1621 W CALLE PLATA","NOGALES","85621"},
{"Sensus243","1621 W CALLE PLATA","NOGALES","85621"},
{"Sensus244","*909 W BELL RD","NOGALES","85621"},
{"Sensus245","765 N TARGET RD RM STE 4&5","NOGALES","85621"},
{"Sensus246","1190 HARMONY ROAD","NORFOLK","23502"},
{"Sensus247","2291 TECHNICAL PARKWAY","NORTH CHARLESTON","29406"},
{"Sensus248","427 MCARTHUR - UNIT 3","OTTAWA","K1K1G5"},
{"Sensus249","300 TEMPLE STREET","PAINESVILLE","44077"},
{"Sensus250","300 TEMPLE AVE","PAINSVILLE","44077"},
{"Sensus251","2 CORPORATE DRIVESUITE 200","PALM COAST","32137"},
{"Sensus252","2148 PELHAM PARKWAYBLDG 400","PELHAM","35124"},
{"Sensus253","*5750 STATE ROUT 251","PERU","61354"},
{"Sensus254","*W 8TH & JEFFERSON PO BOX 228","PERU","46970"},
{"Sensus255","INACTIVE*1275 HICKORY STREET","PEWAUKEE","53072"},
{"Sensus256","*N 27TH W 23291 ROUNDY DRIVE","PEWAUKEE","53072"},
{"Sensus257","*N 27TH W 23293 ROUNDY DRIVE","PEWAUKEE","53072"},
{"Sensus258","*N28W23240 ROUNDY DRIVE","PEWAUKEE","53072"},
{"Sensus259","N 26 W 23445 PAUL RD","PEWAUKEE","53072"},
{"Sensus260","*N 27TH W 23291 ROUNDY DRIVE","PEWAUKEE","53072"},
{"Sensus261","2148 PELHAM PARKWAY BLDG","PELHAM","35124"},
{"Sensus262","5501 EAST VAN BUREN STREET","PHOENIX","85008"},
{"Sensus263","*300 LABROSSE AVE","POINTE CLAIRE","H9R4V5"},
{"Sensus264","300 LABROSSE AVE","POINTE CLAIRE","H9R4V5"},
{"Sensus265","300 LABROSSE AVE","POINTE CLAIRE","H9R4V5"},
{"Sensus266","300 LABROSSE AVE","POINTE CLAIRE","H9R4V5"},
{"Sensus267","300 LABROSSE AVE","POINTE CLAIRE","H9R4V5"},
{"Sensus268","*300 LABROSSE AVE","POINTE CLAIRE","H9R4V5"},
{"Sensus269","1201  NW 18TH STREET","POMPANO BEACH","33069"},
{"Sensus270","1 INTERNATIONAL DRIVE","PORT CHESTER","10573"},
{"Sensus271","2630 NORTH MARINE DR","PORTLAND","97217"},
{"Sensus272","87 AUBURN WAY S","QUISPAMSIS","E2E1B1"},
{"Sensus273","108 SKYWAY AVENUE","REXDALE","M9W4Y9"},
{"Sensus274","451 SOUTHLAKE RD","RICHMOND","23236"},
{"Sensus275","1730 W 10TH STREET","RIVIERA BEACH","33404"},
{"Sensus276","*600 MILE CROSSING","ROCHESTER","14624"},
{"Sensus277","*HWY 25 NPO BOX 420","ROCHESTER","46975"},
{"Sensus278","*600 MILE CROSSING","ROCHESTER","14624"},
{"Sensus279","1362 CONSTITUTION BLVD","ROCK HILL","29732"},
{"Sensus280","1 INTERNATIONAL DRIVE","RYE BROOK","10573"},
{"Sensus281","9843 18TH STREET N STE 1200A","SAINT PETERSBURG","33716"},
{"Sensus282","DO NOT USE","",""},
{"Sensus283","9843 18TH STREET N STE 1200A","SAINT PETERSBURG","33716"},
{"Sensus284","2464 WEST 1500 SOUTH","SALT LAKE CITY","84104"},
{"Sensus285","7096 HWY 87 EAST","SAN ANTONIO","78263"},
{"Sensus286","4965 EISENHAUR ROAD STE 102","SAN ANTONIO","78218"},
{"Sensus287","9940 SUMMERS RIDGE ROAD","SAN DIEGO","92121"},
{"Sensus288","9940 SUMMERS RIDGE RD","SAN DIEGO","92121"},
{"Sensus289","455 HARVEST TIME DRIVE","SANFORD","32771"},
{"Sensus290","BAY 10-3111 MILLER AVE","SASKATOON","S7K6N3"},
{"Sensus291","128A AIRPORT PARK DRIVE","SAVANNAH","28273"},
{"Sensus292","37 STRODE DRIVE","SCARBOROUGH","M1J1L8"},
{"Sensus293","1701 E WOODFIELD RD STE 300","SCHAUMBURG","60173"},
{"Sensus294","17352 BELL NORTH DRIVE","SCHERTZ","78154"},
{"Sensus295","1521 RT 9W BLDG 4APO BOX 98","SELKIRK","12158"},
{"Sensus296","2881 EAST BAYARD STREET STE B","SENECA FALLS","13148"},
{"Sensus297","2881 EAST BAYARD STREET","SENECA FALLS","13148"},
{"Sensus298","240 FALLS ST","SENECA FALLS","13148"},
{"Sensus299","889 BRIDGEPORT AVE2ND FLOOR","SHELTON","06484"},
{"Sensus300","889 BRIDGEPORT AVE","SHELTON","06484"},
{"Sensus301","275 N QUEEN STREET","SHIPPENSBURG","17257"},
{"Sensus302","7260 LINDER AVE","SKOKIE","60077"},
{"Sensus303","1470 INDUSTRIAL DR PO BOX 708","SLATON","79364"},
{"Sensus304","1085 STATELINE RD ESUITE 107","SOUTHAVEN","38671"},
{"Sensus305","1085 STATELINE ROAD EASTSUITE 1","SOUTHAVEN","38671"},
{"Sensus306","1085 STATELINE ROAD EAST","SOUTHAVEN","38671"},
{"Sensus307","1085 STATELINE RD E STE 107","SOUTHAVEN","38671"},
{"Sensus308","1085 STATELINE RD ESUITE 107","SOUTHAVEN","38671"},
{"Sensus309","1085 STATELINE RD STE 107","SOUTHAVEN","38671"},
{"Sensus310","115 RUE LISBONNE","ST AUGUSTIN","G3A0M9"},
{"Sensus311","FLYGT BLDG 7 VANGUARD COURT","ST JOHNS","A1C5H5"},
{"Sensus312","*6800 CHEMIN ST FRANCOIS","ST LAURENT","H4S1B7"},
{"Sensus313","*9300 HENRI-BOURASSA BLVD QUEST","ST LAURENT","H4S1L5"},
{"Sensus314","*6800 CHEMIN ST FRANCOIS","ST LAURENT","H4S1B7"},
{"Sensus315","8000 HALL STREET","ST. LOUIS","63147"},
{"Sensus316","263 BARTON UNIT 12TH","STONEY CREEK","L8E2K4"},
{"Sensus317","9843 18TH STREET N STE 1200A","ST PETERSBURG","33716"},
{"Sensus318","1086 ELISABELLA ST","SUDBURY","P3A4R7"},
{"Sensus319","255 FARMINGTON ROAD","SUMMERVILLE","29486"},
{"Sensus320","8431 160TH STREET","SURREY","V3S3T9"},
{"Sensus321","90 HORIZON DRIVE","SUWANEE","30024"},
{"Sensus322","30 GLOBE AVE","TEXARKANA","71854"},
{"Sensus323","105 N MAY ST STE 214","THUNDER BAY","P7C3N9"},
{"Sensus324","637 BOLL ALGONQUIN","TIMMINS","P4N7C9"},
{"Sensus325","*18522 81ST ST","TINLEY PARK","60477"},
{"Sensus326","*18524 SOUTH 81ST AVE","TINLEY PARK","60477"},
{"Sensus327","*8402 WEST 183RD STREET","TINLEY PARK","60477"},
{"Sensus328","*8402 WEST 183RD STREET","TINLEY PARK","60477"},
{"Sensus329","93 CLAIREVILLE DRIVE","TORONTO","M9W6K9"},
{"Sensus330","9625 SW TUALATIN SHERWOOD RD","TUALATIN","97062"},
{"Sensus331","9625 SW TUALATIN SHERWOOD RD","TUALATIN","97062"},
{"Sensus332","9625 SW TUALATIN SHERWOOD RD","TUALATIN","97062"},
{"Sensus333","450 NORTH GALLATIN AVE","UNIONTOWN","15401"},
{"Sensus334","221 COMMERCE DRIVE","UPPER MARLBORO","20774"},
{"Sensus335","1070 RUE LEO-FOURNIERCP 1550","VAL D'OR","J9P6X8"},
{"Sensus336","6800 CHEMIN ST","VILLE ST LAURENT","H4S1B7"},
{"Sensus337","6800 CHEMIN ST(AIR FREIGHT)","VILLE ST LAURENT","H4S1B7"},
{"Sensus338","8TH STREET & GLEN GERRY","WATSONTOWN","17777"},
{"Sensus339","455 EAST 8TH ST","WATSONTOWN","17777"},
{"Sensus340","31332 VIA COLINAS STE 111","WESTLAKE VILLAGE","91362"},
{"Sensus341","1400 DIVISION ROAD","WEST WARWICK","02893"},
{"Sensus342","1133 WESTCHESTER AVESUITE N200","WHITE PLAINS","10604"},
{"Sensus343","4113 US HWY 421 NORTH","WILMINGTON","28401"},
{"Sensus344","4965 EISENHAUR ROAD STE 102","WINDCREST","78218"},
{"Sensus345","4965 EISENHAUR ROAD STE 102","WINDCREST","78218"},
{"Sensus346","*208-666 ST JAMES STREET","WINNIPEG","R3G3J6"},
{"Sensus347","*328 KEEWATIN STREET","WINNIPEG","R2X2R9"},
{"Sensus348","*55 TERRACON PLACE","WINNIPEG","R2J4B3"},
{"Sensus349","*328 KEEWATIN STREET","WINNIPEG","R2X2R9"},
{"Sensus350","*55 TERRACON PLACE","WINNIPEG","R2J4B3"},
{"Sensus351","78 K OLYMPIA AVE","WOBURN","01801"},
{"Sensus352","101 MARK ST UNIT G","WOOD DALE","60191"},
{"Sensus353","71 ELM STREET","WORCESTER","01609"},
{"Sensus354","124 N FRONT STREET","WRIGHTSVILLE","17368"},
{"Sensus355","1700/1725 BRANNUM LANE","YELLOW SPRINGS","45387"},
{"Sensus356","*227 S DIVISION STREET","ZELIENOPLE","16063"},
{"Sensus357","*610 W BEAVER STREET","ZELIENOPLE","16063"},
{"Sensus358","*802 MARKET STREET","ZELIENOPLE","16063"},
{"Sensus359","129 MCCARRELL LANE","ZELIENOPLE","16063"}
};
public string SensusInOut(string addr, string city, string addr2, string city2)
{
	string retVal = "Not Found";
	addr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	addr2 = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city2 = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	
	for (int row = 0; row < 359; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListSensus.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city)
			{
				if (Regex.Replace(addrListSensus.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr)
				{
					retVal = "O";
					break;
				}
			}
		}
	}
	if (retVal == "Not Found")
	{
		for (int row = 0; row < 359; row++)
		{
			for (int col = 0; col < 4; col++)
			{
				if (Regex.Replace(addrListSensus.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city2)
				{
					if (Regex.Replace(addrListSensus.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr2)
					{
						retVal = "I";
						break;
					}
				}
			}
		}
	}
	return retVal;
}


public string SensusLocCode(string addr, string city, string addr2, string city2, string inOut)
{
	string vAddr;
	string vCity;
	string retVal = "Not Found";
	
	if (inOut == "O")
	{
		vAddr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	else
	{
		vAddr = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	
	for (int row = 0; row < 359; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListSensus.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vCity)
			{
				if (Regex.Replace(addrListSensus.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vAddr)
				{
					retVal = addrListSensus.GetValue(row, col-2).ToString();
					break;
				}
			}
		}
	}
	return retVal;
}

  string[,] addrListHenkel = new string[189, 4] {
{"ADA","7575 FULTON ST EAST","ADA","49355"},
{"ADA","7575 FULTON ST E","ADA","49355"},
{"ALLIA","12155 FISHER AVE NE","ALLIANCE","44601"},
{"ALLIAB","1250 ASBESTOS DR NE","ALLIANCE","44601"},
{"AMSTE","2970 GUSTAVMAHLERLAAN","AMSTERDAM","1081"},
{"ANAHE","1208 NORTH PATT ST","ANAHEIM","92801"},
{"ATLAN","100 EAGLE VISTA PKWY","ATLANTA","30336"},
{"ATLANA","C/O SADDLE CREEK CORPORATION","ATLANTA","60336"},
{"ATLANB","100 EAGLE VISTA PKWY SW","ATLANTA","30336"},
{"AUBURA","909 MAGNOLIA AVE","AUBURNDALE","33823"},
{"AUBURB","909 MAGNOLIA AVE","AUBURNDALE","33823"},
{"AUBURC","909 MAGNOLIA AVE","AUBURNDALE","33823"},
{"AUBURD","909 MAGNOLIA AVE","AUBURNDALE","33823"},
{"BARBE","361 FAIRVIEW AVE","BARBERTON","44203"},
{"BATAV","5055 STATE ROUTE 276","BATAVIA","45103"},
{"BATAVA","4053 CLOUGH WOODS DR","BATAVIA","45103"},
{"BAYON","100 PULASKI ST","BAYONNE","14456"},
{"BENSE","560 SUPREME DR","BENSENVILLE","60106"},
{"BENSEA","560 SUPREME DR","BENSENVILLE","60106"},
{"BENTO","805 S WALTON BLVD","BENTONVILLE","72712"},
{"BERWI","910 7TH AVE","BERWICK","18603"},
{"BOAZ","1506 INDUSTRIAL BLVD","BOAZ","35957"},
{"BOWLI","487 CENTRAL AVE","BOWLING GREEN","42101"},
{"BOWLIA","215 TECHNOLOGY WAY","BOWLING GREEN","42101"},
{"BOWLIB","385 SOUTHWOOD CT","BOWLING GREEN","42101"},
{"BOWLIC","496 CENTRAL AVE","BOWLING GREEN","42101"},
{"BOWLID","550 CAL BATSEL BUILDING 1","BOWLING GREEN","42101"},
{"BOWLIE","254 DISHMAN LANE","BOWLING GREEN","42101"},
{"BOWLIF","2901 INDUSTRIAL DRIVE","BOWLING GREEN","42101"},
{"BOWLIG","458 CENTURY ST","BOWLING GREEN","42101"},
{"BREIN","8400 INDUSTRIAL BLVD","BREINIGSVILLE","18031"},
{"BREINA","C/O CUSTOMIZED DISTRIBUTION SER","BREINIGSVILLE","18031 H"},
{"BRIDGA","305 ROCK NW INDUSTRIAL DR","BRIDGETON","63044"},
{"BURLI","1400 PRODUCTION DR","BURLINGTON","41005"},
{"CHATS","20721 SUPERIOR ST","CHATSWORTH","91311"},
{"CHICA","6200 WEST 51ST ST","CHICAGO","60638"},
{"CHICAB","340 E 138TH ST","CHICAGO","60827"},
{"CHICAC","340 EAST 138TH ST","CHICAGO","60827"},
{"CHINO","14570 MONTE VISTA AVE","CHINO","91710"},
{"CINCI","8485 BROADWELL RD","CINCINNATI","45244"},
{"CINCIA","5177 SPRING GROVE AVE","CINCINAATI","45217"},
{"CINCIE","5177 SPRING GROVE AVE","CINCINNATI","45217"},
{"CINCIF","5380 VINE STREET","CINCINNATI","45217"},
{"CINCIG","8485 BROADWELL ROAD","CINCINNATI","45244"},
{"CLEVE","1300 E 45TH ST","CLEVELAND","4414"},
{"CLEVEA","4721 HINCKLEY INDUSTRIAL PKWY","CLEVELAND","44109"},
{"CORTL","17 HUNTINGTON ST","CORTLAND","13045"},
{"CORTLA","106 CENTRAL AVE","CORTLAND","13054"},
{"COVIN","14481 LOCHRIDGE BLVD","COVINGTON","30014"},
{"DANVI","608 HIGHLAND BLVD","DANVILLE","61832"},
{"DANVIA","3401 LYNCH CREEK DR","DANVILLE","61834"},
{"DANVIB","3401 LYNCH CREEK DR","DANVILLE","61834"},
{"DANVIC","1 WEST HEGELER LN","DANVILLE","61832"},
{"DAYTO","11C NICHOLAS CT","DAYTON","8810"},
{"DAYTOA","7 NICHOLAS COURT","DAYTON","08810"},
{"EDISO","10 DISTRIBUTION BLVD","EDISON","08817"},
{"EDWAR","1 GATEWAY COMMERCE CENTER DR","EDWARDSVILLE","62025"},
{"EDWARA","C/O CUSTOMIZED DISTRIBUTION","EDWARDSVILLE","62025 H"},
{"EDWARB","349 GATEWAY COMMERCE","EDWARDSVILLE","62025"},
{"ELGIN","1345 GASKET DR","ELGIN","60120"},
{"ELKHAC","1919 SUPERIOR ST","ELKHART","46516"},
{"ELWOO","22500 STEPAN RD","ELWOOD","60421"},
{"ENID","1200 N 54TH ST","ENID","73701 M"},
{"ETNA","167 HERITAGE DR","ETNA","43062"},
{"ETOBIB","78 TITAN ROAD","ETOBICOKE","M8Z2J8"},
{"FIELD","201 4TH STREET","FIELDSBORO","8505"},
{"GAINE","1248 PALMOUR DR","GAINESVILLE","30501"},
{"GAINSA","1120 PURINA DRIVE","GAINSVILLE","30501"},
{"GENEV","300 FORGE AVE","GENEVA","14456"},
{"GRAND","4459 40TH ST SE","GRAND RAPIDS","49512"},
{"HAZLE","125 JAYCEE DR","HAZLETON","18202"},
{"HAZLEA","125 JAYCEE DR","HAZLETON","18202"},
{"HAZLEB","125 JAYCEE DR","HAZLETON","18202"},
{"HAZLEC","125 JAYCEE DR","HAZLETON","18202"},
{"HAZLED","125 JAYCEE DR","HAZLETON","18202"},
{"HAZLEE","425 JAYCEE DR","HAZLETON","18202"},
{"HEBRO","2200 GATEWAY BOULEVARD","HEBRON","41048"},
{"HENRI","2300 DARBYTOWN ROAD","HENRICO","23231"},
{"HENRIA","2248 DARBYTOWN ROAD","HENRICO","23231"},
{"INDIA","7445 COMPANY DR","INDIANAPOLIS","46222"},
{"IRWIN","4832 AZUSA CANYON ROAD","IRWINDALE","60677 R"},
{"IVORY","5177 SPRING GROVE AVE","IVORYDALE","45217"},
{"JERSE","202 PORT JERSEY BLVD","JERSEY CITY","07305"},
{"JOHNS","9005 SMITHS MILL ROAD","JOHNSTOWN","43031"},
{"JOLIE","2900 MILLSDALE RD","JOLIET","60436"},
{"KANSA","1705 KANSAS AVE","KANSAS CITY","66105"},
{"KNOWL","315 CHEMIN KNOWLTON","KNOWLTON","J0E1V0"},
{"KNOWLA","315 KNOWLTON RD","KNOWLTON","J0E1V0"},
{"LAVER","400 NEW SANFORD RD","LAVERGNE","37086"},
{"LAVERA","400 N SANFORD RD","LA VERGNE","37126"},
{"LAVERB","400 N SANFORD RD","LA VERGNE","37126"},
{"LAVERC","400 NEW SANFORD RD","LA VERGNE","37126"},
{"LAVERD","USE 680971935 400 NEW SANFORD","LAVERGNE","37086"},
{"LIMA","3320 FORT SHAWNEE INDUSTRIAL DR","LIMA","45806"},
{"LINDO","1353 W 300 S","LINDON","84042"},
{"LOSAN","9172 ETON AVE BLDG #5","LOS ANGELES","91311"},
{"LOUIS","1729 MCCLOSKEY AVE","LOUISVILLE","40210"},
{"LOUISG","2501 PLANTSIDE DR","LOUISVILLE","40299"},
{"LYNCH","314 JEFFERSON","LYNCHBURG","24501"},
{"MARYL","13300 INTERSTATE DR","MARYLAND HEIGHTS","63043"},
{"MIDDL","3439 YANKEE RD","MIDDLETOWN","45044"},
{"MILTO","8690 ESCARPMENT WAY","MILTON","L9TOM1"},
{"MINNE","2300 E 26TH ST","MINNEAPOLIS","55406"},
{"MISSI","6200 MILLCREEK DR","MISSISSAUGA","L4V1K2"},
{"MODES","4500 FINCH ROAD","MODESTO","95357"},
{"MONTG","2000 AUCUTT RD","MONTGOMERY","60538"},
{"MOUNT","1804 WEST CENTRAL RD","MOUNT PROSPECT","60056"},
{"NEWAL","9200 SMITHS MILL RD N","NEW ALBANY","43054"},
{"NEWALA","12240 EMMET ST","NEW ALBANY","43054"},
{"NEWALB","9200 SMITHS MILL RD N","NEW ALBANY","43054"},
{"NEWALC","9200 SMITHS MILL RD N","NEW ALBANY","43054"},
{"NEWALD","9200 SMITHS MILL RD N","NEW ALBANY","43054"},
{"NEWYO","1732 1ST AVENUE #20795","NEW YORK","10128"},
{"OAKVI","1485 SPEERS ROAD","OAKVILLE","L6L2X5"},
{"ONTAR","3355 E CEDAR STREET SUITE","ONTARIO","91761"},
{"ONTARA","SUITE A","ONTARIO","91761"},
{"OVERL","11725 W 85TH ST","OVERLAND   PARK","66214"},
{"PARKB","4087 LOWER VALLEY","PARKESBURG","19365"},
{"PORTA","5900 CARLSON AVE","PORTAGE","46368"},
{"PORTL","1171 VAUGHN DR","PORTLAND","37148"},
{"PORTLA","1171 VAUGHN PARKWAY","PORTLAND","37148"},
{"PORTW","1681 SUNSET ROAD","PORT WASHINGTON","53074"},
{"PORTWA","603 MOORE ROAD","PORT WASHINGTON","53074"},
{"PORTWB","1671 S SUNSET RD","PORT WASHINGTON","53074"},
{"RANTO","205 SHELLHOUSE DR","RANTOUL",""},
{"RIVER","13607 S HALSTED ST","RIVERDALE","60827"},
{"RIVERA","13607 S HALSTED ST","RIVERDALE","60827"},
{"RIVERB","340 E 138TH ST","RIVERDALE","60827"},
{"ROCKY","ONE HENKEL WAY","ROCKY HILL","06067"},
{"SAINT","6901 MCKISSOCK AVE","SAINT LOUIS","63147"},
{"SAINTA","6901 MCKISSOCK AVE","SAINT LOUIS","63147"},
{"SAINTC","105 BOLTE LN","SAINT CLAIR","63077"},
{"SAINTD","105 BOLTE LN","SAINT CLAIR","63077"},
{"SAINTE","9 CERMAK BLVD","SAINT PETERS","63376"},
{"SAINTF","7110 NORTH BROADWAY","ST LOUIS","63147"},
{"SAINTG","9 CERMAK BLVD","SAINT PETERS","63376"},
{"SAINTP","200 TRADE CENTER DRIVE W","SAINT PETERS","63376"},
{"SAINTQ","1 GERBER IND CT","SAINT PETERS","63376"},
{"SAINTT","423 JAYCEE DRIVE","HAZELTOWNSHIP","18202"},
{"SALTE","1950 WEST 3600 S","SALT LAKE CITY","84104"},
{"SALTL","3540 WEST 1987 S","SALT LAKE CITY","84104"},
{"SALTLA","1470 S 5070 W","SALT LAKE CITY","84104"},
{"SALTLB","1820 SOUTH 3600 W","SALT LAKE CITY","84106"},
{"SALTLC","3540 WEST 1987 S","SALT LAKE CITY","84104"},
{"SALTLD","1820 SOUTH 3570 W","SALT LAKE CITY","84104"},
{"SALTLE","1950 WEST 3600 S","SALT LAKE CITY","84104"},
{"SALTLF","3570 WEST 1870 S","SALT LAKE CITY","84104"},
{"SALTLG","1987 WEST 3600 S","SALT LAKE CITY","84104"},
{"SALTLH","1897 SOUTH 3600 W","SALT LAKE CITY","84104 S"},
{"SALTLI","1820 SOUTH 3570 W","SALT LAKE CITY","84104"},
{"SALTLJ","3480 WEST 1850 S","SALT LAKE CITY","84104"},
{"SALTLK","4324 W COMMERICAL WAY","SALT LAKE",""},
{"SALTM","1850 S 3600 WEST","SALT LAKE CITY","84104"},
{"SALTN","1850 S 3600 W","SALT LAKE CITY","84104"},
{"SALTO","1900 S 3480 W","SALT LAKE CITY","84104"},
{"SANTA","3300 WEST SEGERSTROM ST","SANTA ANA","92704"},
{"SANTAA","26455 RUETHER AVE","SANTA CALRITA","91350"},
{"SANTAB","26421 RUETHER AVE","SANTA CALRITA","91350"},
{"SANTAC","26421 RUETHER AVE","SANTA CLARITA","91350"},
{"SCOTT","8970 E. BAHIA DR STE 1000","SCOTTSDALE","85260"},
{"SCOTTB","2281 SOUTH US 31","SCOTTSBURG","47170"},
{"SIMIV","2280 WARD AVE","SIMI VALLEY","93065"},
{"STAMF","200 ELM STREET","STAMFORD","6902"},
{"STCHA","39 CHARBONNEAU DR","ST CHARLES","63301"},
{"STCHAB","39 CHARBONNEAU DR","ST CHARLES","63301"},
{"TEMPE","405 WEST GENEVA DR","TEMPE","85282"},
{"TORON","78 TITAN RD","TORONTO","M8Z2J8"},
{"TRUMB","30 TREEFOIL DR","TRUMBULL","6611"},
{"VAUGH","1 ROYAL GATE BLVD","VAUGHN","4L48ZY"},
{"WARRE","23343 SHERWOOD AVE","WARREN","48091"},
{"WAUKE","1275 BRIDGE DR","WAUKEGAN","60085"},
{"WESTE","125 JAYCEE DRIVE","WEST HAZELTON","18202"},
{"WESTH","125 JAYCEE DR","WEST HAZLETON","18202"},
{"WESTHA","125 JAYCEE DR","WEST HAZLETON","18202"},
{"WESTHB","103 ROTARY DR","WEST HAZLETON","18202"},
{"WESTHC","75 JAYCEE DR","WEST HAZELTON","18202"},
{"WESTHD","75 JAYCEE DR","WEST HAZELTON","18202"},
{"WESTHE","25 JAYCEE DR","WEST HAZELTON","18202"},
{"WESTHF","425 JAYCEE DR","WEST HAZLETON","18202"},
{"WESTV","1987 W 3600S","WEST VALLEY","84119"},
{"WESTVA","4750 W 2100 S ST 200","WEST VALLEY CITY","84120"},
{"WESTVB","2404 S 6505 W","WEST VALLEY CITY","84120"},
{"WESTVC","1950 W3600 S","WEST VALLEY CITY","84119"},
{"WESTW","200 PROVIDENCE ST","WEST WARICK","2893"},
{"WHITE","2885 HIGHWAY 47 N","WHITE BLUFF","37187"},
{"WINDE","951 BANKHEAD HWY","WINDER","30680"},
{"WIXOM","5000 PONTIAC TRL","WIXOM","48393"},
{"YORK","500 WINDSOR ST","YORK","17403"},
{"WIXOM","5000 PONTIAC TR","WIXOM","48393"}
};
public string HenkelInOut(string addr, string city, string addr2, string city2)
{
	string retVal = "Not Found";
	addr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	addr2 = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city2 = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	
	for (int row = 0; row < 189; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListHenkel.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city)
			{
				if (Regex.Replace(addrListHenkel.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr)
				{
					retVal = "O";
					break;
				}
			}
		}
	}
	if (retVal == "Not Found")
	{
		for (int row = 0; row < 189; row++)
		{
			for (int col = 0; col < 4; col++)
			{
				if (Regex.Replace(addrListHenkel.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city2)
				{
					if (Regex.Replace(addrListHenkel.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr2)
					{
						retVal = "I";
						break;
					}
				}
			}
		}
	}
	return retVal;
}

public string HenkelLocCode(string addr, string city, string addr2, string city2, string inOut)
{
	string vAddr;
	string vCity;
	string retVal = "Not Found";
	
	if (inOut == "O")
	{
		vAddr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	else
	{
		vAddr = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	
	for (int row = 0; row < 189; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListHenkel.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vCity)
			{
				if (Regex.Replace(addrListHenkel.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vAddr)
				{
					retVal = addrListHenkel.GetValue(row, col-2).ToString();
					break;
				}
			}
		}
	}
	return retVal;
}

  string[,] addrListTessco = new string[12, 4] {
{"Tessco1","10999 MCCORMICK ROAD","HUNT VALLEY","21031"},
{"Tessco2","11111 GILROY ROAD","HUNT VALLEY","21031"},
{"Tessco3","11126 MCCORMICK ROAD","HUNT VALLEY","21031"},
{"Tessco4","4775 AIRCENTER CIRCLE","RENO","89502"},
{"Tessco5","5250 PRUE ROAD","SAN ANTONIO","78240"},
{"Tessco6","375 WEST PADONIA ROAD","TIMONIUM","21093"},
{"Tessco1","10999 MCCORMICK RD","HUNT VALLEY","21031"},
{"Tessco2","11111 GILROY RD","HUNT VALLEY","21031"},
{"Tessco3","11126 MCCORMICK RD","HUNT VALLEY","21031"},
{"Tessco4","4775 AIRCENTER CIR","RENO","89502"},
{"Tessco5","5250 PRUE RD","SAN ANTONIO","78240"},
{"Tessco6","375 WEST PADONIA RD","TIMONIUM","21093"}
};
public string TesscoInOut(string addr, string city, string addr2, string city2)
{
	string retVal = "Not Found";
	addr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	addr2 = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	city2 = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	
	for (int row = 0; row < 12; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListTessco.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city)
			{
				if (Regex.Replace(addrListTessco.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr)
				{
					retVal = "O";
					break;
				}
			}
		}
	}
	if (retVal == "Not Found")
	{
		for (int row = 0; row < 12; row++)
		{
			for (int col = 0; col < 4; col++)
			{
				if (Regex.Replace(addrListTessco.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == city2)
				{
					if (Regex.Replace(addrListTessco.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == addr2)
					{
						retVal = "I";
						break;
					}
				}
			}
		}
	}
	return retVal;
}

public string TesscoLocCode(string addr, string city, string addr2, string city2, string inOut)
{
	string vAddr;
	string vCity;
	string retVal = "Not Found";
	
	if (inOut == "O")
	{
		vAddr = Regex.Replace(addr, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	else
	{
		vAddr = Regex.Replace(addr2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
		vCity = Regex.Replace(city2, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
	
	for (int row = 0; row < 12; row++)
	{
		for (int col = 0; col < 4; col++)
		{
			if (Regex.Replace(addrListTessco.GetValue(row,col).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vCity)
			{
				if (Regex.Replace(addrListTessco.GetValue(row , col -1).ToString(), "[^0-9a-zA-Z]+", "").ToUpper().Trim() == vAddr)
				{
					retVal = addrListTessco.GetValue(row, col-2).ToString();
					break;
				}
			}
		}
	}
	return retVal;
}

public string delegator(string account, string func, string addr, string city, string addr2, string city2)
{
	string retVal = "Not Found";

	if (func == "IO")
	{
		switch(account)
		{
			case "SunMed LLC":
				retVal = SunMedInOut(addr, city, addr2, city2);
				break;
       case "TEKNOR APEX":
				retVal = MaclinInOut(addr, city, addr2, city2);
				break;
       case "Controlled Products System Group":
				retVal = ControlledInOut(addr, city, addr2, city2);
				break;
       case "XYLEM INC C/O CASS INFORMATION SYSTEMS":
				retVal = SensusInOut(addr, city, addr2, city2);
				break;
       case "The J.M. Smucker Company c/o Cass Information Systems":
				retVal = SmuckersInOut(addr, city, addr2, city2);
				break;
       case "Henkel Adhesives c/o Cass information":
				retVal = HenkelInOut(addr, city, addr2, city2);
				break;
       case "Henkel Global Supply chain B. V.C/O Cass":
				retVal = HenkelInOut(addr, city, addr2, city2);
				break;
       case "Macy's Retail Holdings, Inc.":
				retVal = MacyInOut(addr, city, addr2, city2);
				break;
       case "TESSCO Technologies Inc. C/O Cass Information Systems":
				retVal = TesscoInOut(addr, city, addr2, city2);
				break;
		}
	}
  else
	{
		switch(account)
		{
			case "SunMed LLC":
				retVal = SunMedLocCode(addr, city, addr2, city2, func);
				break;
      case "Macy's Retail Holdings, Inc.":
				retVal = MacyLocCode(addr, city, addr2, city2, func);
				break;
      case "TEKNOR APEX":
				retVal = MaclinLocCode(addr, city, addr2, city2, func);
				break;
      case "Controlled Products System Group":
				retVal = ControlledLocCode(addr, city, addr2, city2, func);
				break;
      case "XYLEM INC C/O CASS INFORMATION SYSTEMS":
				retVal = SensusLocCode(addr, city, addr2, city2, func);
				break;
      case "The J.M. Smucker Company c/o Cass Information Systems":
				retVal = SmuckersLocCode(addr, city, addr2, city2, func);
				break;
      case "Henkel Adhesives c/o Cass information":
				retVal = HenkelLocCode(addr, city, addr2, city2, func);
				break;
      case "Henkel Global Supply chain B. V.C/O Cass":
				retVal = HenkelLocCode(addr, city, addr2, city2, func);
				break;
     case "TESSCO Technologies Inc. C/O Cass Information Systems":
				retVal =TesscoLocCode(addr, city, addr2, city2, func);
				break;
		}
	}
	return retVal;
}

]]>
	</msxsl:script>
	<!-- Set default if empty template end -->
</xsl:stylesheet>
