<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" exclude-result-prefixes="msxsl var s0" version="1.0" xmlns:s0="http://Echo.BSSR.Internal.Canonical.TendorResponse.TenderResponseOut" xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00401.EDI990/v1.0">
	<xsl:output omit-xml-declaration="yes" method="xml" version="1.0" />
	<xsl:template match="/">
		<xsl:apply-templates select="/s0:TenderResponse" />
	</xsl:template>
	<xsl:template match="/s0:TenderResponse">
		<xsl:variable name="vCustomerId" select="@CustomerId" />
		<xsl:variable name="vCompanyId" select="@CompanyId" />
		<xsl:variable name="vDefaultSCAC" select="'ECHS'" />
		<xsl:variable name="vBOL" select="Transaction/Header/BOL/text()" />
		<xsl:variable name="vRefSCAC" select="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='7J']/RefValue/text()" />
		<xsl:variable name="vRefMBOL" select="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='MB']/RefValue/text()" />
		<xsl:variable name="vMode" select="Transaction/Header/Mode/text()" />
		<xsl:variable name="vBookingDateRaw" select="Transaction/Header/BookingDate/text()" />
		<xsl:variable name="vReservationCode" select="Transaction/Header/ReservationCode/text()" />
		<xsl:variable name="vRemarks" select="Transaction/Header/Remarks/text()" />

		<xsl:variable name="vBookingDate" select="substring-before($vBookingDateRaw,'T')" />
		<xsl:variable name="vBookingYear" select="substring-before($vBookingDate, '-')" />
		<xsl:variable name="vBookingMonthDay" select="substring-after($vBookingDate,'-')" />
		<xsl:variable name="vBookingMonth" select="substring-before($vBookingMonthDay,'-')" />
		<xsl:variable name="vBookingDay" select="substring-after($vBookingMonthDay,'-')" />
		<ns0:X12_00401_990>
			<ST>
				<ST01>990</ST01>
				<ST02>0001</ST02>
				<!--<ST03></ST03>-->
			</ST>
			<ns0:B1>
				<xsl:choose>
					<xsl:when test="$vRefSCAC!=''">
						<B101>EGAJ</B101>
					</xsl:when>
					<xsl:otherwise>
						<B101>ECHS</B101>
					</xsl:otherwise>
				</xsl:choose>
				<B102>
					<xsl:value-of select="Transaction/Header/BOL/text()" />
				</B102>
				<B103>
					<xsl:value-of select="$vBookingYear"/>
					<xsl:value-of select="$vBookingMonth"/>
					<xsl:value-of select="$vBookingDay"/>
				</B103>
				<B104>
					<xsl:value-of select="$vReservationCode"/>
				</B104>
			</ns0:B1>
			<ns0:N9>
				<N901>
					<xsl:value-of select="'CN'"/>
				</N901>
				<N902>
					<xsl:value-of select="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='CN']/RefValue/text()"/>
				</N902>
				<!--<N903>
					<xsl:value-of select="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='2I']/RefValue/text()"/>
				</N903>
				<xsl:if test="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='SH']/RefValue/text()!=''">
					<ns0:C040>
						<C04001>8M</C04001>
						<C04002>
							<xsl:value-of select ="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='SH']/RefValue/text()"/>
						</C04002>
					</ns0:C040>
				</xsl:if>-->
			</ns0:N9>
		</ns0:X12_00401_990>
	</xsl:template>
	<!-- CleanAlphaField start  -->
	<xsl:template name="CleanAlphaField">
		<xsl:param name="inputText" />
		<xsl:param name="maxLength" />
		<xsl:variable name="singleQuote" select='"&apos;"' />
		<xsl:variable name="doubleQuote" select="'&quot;'" />
		<xsl:variable name="vAllowedSymbolsPart1" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}\?/#'"/>
		<xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
		<xsl:variable name="vCleanedText" select="translate($inputText,translate($inputText, $vAllowedSymbols, ''),'')"/>
		<xsl:value-of select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
	</xsl:template>
	<!-- Clean AlphaField end -->
</xsl:stylesheet>
