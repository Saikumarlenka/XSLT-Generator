<?xml version="1.0" encoding="UTF-16"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" exclude-result-prefixes="msxsl var s0 userCSharp" version="1.0" xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00401.EDI214/v1.0" xmlns:s0="http://Echo.BSSR.Internal.Canonical.Status/v1.0" xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp">
  <xsl:output omit-xml-declaration="yes" method="xml" version="1.0" />
  <xsl:template match="/">
    <xsl:apply-templates select="/s0:Status" />
  </xsl:template>
  <xsl:template match="/s0:Status">

    <ns0:X12_00401_214>
      <ST>
        <ST01>214</ST01>
        <ST02>12345</ST02>
      </ST>
      <xsl:for-each select="StatusList">
        <xsl:for-each select="ShipmentStatus">
          <xsl:for-each select="ReferenceData">
            <ns0:B10>
              <xsl:if test="LoadId/text() != ''">
                <B1001>
                  <xsl:call-template name="CleanAlphaField" >
                    <xsl:with-param name="inputText" select="LoadId/text()" />
                    <xsl:with-param name="maxLength" select="30" />
                  </xsl:call-template>
                </B1001>
              </xsl:if>
              <xsl:if test="Bol/text()  != ''">
                <B1002>
                  <xsl:call-template name="CleanAlphaField" >
                    <xsl:with-param name="inputText" select="Bol/text()" />
                    <xsl:with-param name="maxLength" select="30" />
                  </xsl:call-template>
                </B1002>
              </xsl:if>

              <B1003>
			    <xsl:choose>
				    <xsl:when test="/s0:Status/@CustomerId='16666'">EGBF</xsl:when>
				    <xsl:otherwise>ECHS</xsl:otherwise>
			    </xsl:choose>
			  </B1003>

            </ns0:B10>
          </xsl:for-each>
        </xsl:for-each>
      </xsl:for-each>
      
      <xsl:for-each select="StatusList">
        <xsl:for-each select="ShipmentStatus">
          <xsl:for-each select="BusinessReferences">
            <xsl:for-each select="BusinessReference">
            <xsl:if test="(@referenceId != '') and (@referenceType  != '')">
            <ns0:L11>
              <xsl:if test="@referenceId != ''">
                <L1101>
                  <xsl:call-template name="CleanAlphaField" >
                    <xsl:with-param name="inputText" select="@referenceId" />
                    <xsl:with-param name="maxLength" select="30" />
                  </xsl:call-template>
                </L1101>
              </xsl:if>
              <xsl:if test="@referenceType  != ''">
                <L1102>
                  <xsl:call-template name="CleanAlphaField" >
                    <xsl:with-param name="inputText" select="@referenceType" />
                    <xsl:with-param name="maxLength" select="3" />
                  </xsl:call-template>
                </L1102>
              </xsl:if>
            </ns0:L11>
            </xsl:if>
            </xsl:for-each>
          </xsl:for-each>
        </xsl:for-each>
      </xsl:for-each>
      
      <xsl:for-each select="StatusList">
          <xsl:for-each select="ShipmentStatus">
            <xsl:for-each select="Statuses">
              <xsl:for-each select="Status">
                <xsl:for-each select="Details/Detail[@stopType='Pick' or @stopType='Drop']">
                  <xsl:for-each select="Addresses">
                    <xsl:for-each select="Address">
                      <!--first one-->
                      <ns0:N1Loop1> 
                        <ns0:N1>
                        <xsl:if test="../../@stopType">
                          <N101>
                              <xsl:call-template name="StopTypeMapValue">
                                <xsl:with-param name="ValueToConvert" select="../../@stopType" />
                              </xsl:call-template>
                          </N101>
                        </xsl:if>
                        <xsl:if test="@name != ''">
                          <N102>
                            <xsl:call-template name="CleanAlphaField" >
                              <xsl:with-param name="inputText" select="@name" />
                              <xsl:with-param name="maxLength" select="30" />
                            </xsl:call-template>
                          </N102>
                        </xsl:if>
                        <!-- Removed by design. Node not available by default.
                        <xsl:if test="@locationIdentifier != ''">
                          <N103>
                            <xsl:call-template name="SetDefaultIfEmpty">
                              <xsl:with-param name="node" select="@locationIdentifier"/>
                              <xsl:with-param name="pDefaultValue" select="93"/>
                            </xsl:call-template>
                          </N103>
                        </xsl:if>
                        -->
                      </ns0:N1>
                      <xsl:if test="@address1 != '' or @address2 != ''">   
                      <ns0:N3>
                        <xsl:if test="@address1 != ''">
                            <N301>
                              <xsl:call-template name="CleanAlphaField" >
                                <xsl:with-param name="inputText" select="@address1" />
                                <xsl:with-param name="maxLength" select="30" />
                              </xsl:call-template>
                            </N301>
                          </xsl:if>
                        <xsl:if test="@address2 != ''">
                            <N302>
                              <xsl:call-template name="CleanAlphaField" >
                                <xsl:with-param name="inputText" select="@address2" />
                                <xsl:with-param name="maxLength" select="30" />
                              </xsl:call-template>
                            </N302>
                          </xsl:if>
                      </ns0:N3>
                      </xsl:if>  
                      <ns0:N4>
                          <xsl:if test="@city != ''">
                            <N401>
                              <xsl:call-template name="CleanAlphaField" >
                                <xsl:with-param name="inputText" select="@city" />
                                <xsl:with-param name="maxLength" select="30" />
                              </xsl:call-template>
                            </N401>
                          </xsl:if>
						  <xsl:if test="@stateProvince != ''">	
                          <N402>
                           <xsl:call-template name="StateCodetranslationMapValue">
                                <xsl:with-param name="ValueToConvert" select="@stateProvince" />
                              </xsl:call-template>
                          </N402>
                          </xsl:if>
                          <xsl:if test="@postalCode != ''">
                            <N403>
                              <xsl:value-of select="@postalCode" />
                            </N403>
                          </xsl:if>
                          <xsl:if test="@country != ''">
                            <N404>
                              <xsl:value-of select="@country" />
                            </N404>
                          </xsl:if>
                        </ns0:N4>
						  <xsl:if test="/s0:Status/@CustomerId='16666'">
							  <ns0:G62>
								  <xsl:choose>
									  <xsl:when test="//Details/Detail/@statusCode = 'AA'">
										  <G6201>69</G6201>
									  </xsl:when>
									  <xsl:when test="//Details/Detail/@statusCode = 'AB'">
										  <G6201>70</G6201>
									  </xsl:when>
									  <xsl:when test="//Details/Detail/@statusCode = 'X3'">
										  <G6201>11</G6201>
									  </xsl:when>
									  <xsl:when test="//Details/Detail/@statusCode = 'AF'">
										  <G6201>86</G6201>
									  </xsl:when>
									  <xsl:when test="//Details/Detail/@statusCode = 'D1'">
										  <G6201>82</G6201>
									  </xsl:when>
									  <xsl:when test="//Details/Detail/@statusCode = 'X1'">
										  <G6201>35</G6201>
									  </xsl:when>
									  <xsl:otherwise>
										  <G6201>07</G6201>
									  </xsl:otherwise>
								  </xsl:choose>
								  <G6202>
									  <xsl:value-of select="concat(
													substring(//Details/Detail/@statusdatetime, 1, 4),
													substring(//Details/Detail/@statusdatetime, 6, 2),
													substring(//Details/Detail/@statusdatetime, 9, 2))" />
								  </G6202>

								  <xsl:choose>
									  <xsl:when test="//Details/Detail/@statusCode = 'AA'">
										  <G6203>2</G6203>
									  </xsl:when>
									  <xsl:when test="//Details/Detail/@statusCode = 'AB'">
										  <G6203>3</G6203>
									  </xsl:when>
									  <xsl:when test="(//Details/Detail/@statusCode = 'X3' or //Details/Detail/@statusCode = 'D1')">
										  <G6203>R</G6203>
									  </xsl:when>
									  <xsl:when test="(//Details/Detail/@statusCode = 'AF' or //Details/Detail/@statusCode = 'X1')">
										  <G6203>A</G6203>
									  </xsl:when>
									  <xsl:otherwise>
										  <G6203>W</G6203>
									  </xsl:otherwise>
								  </xsl:choose>

								  <G6204>
									  <xsl:value-of select="concat(
													substring(//Details/Detail/@statusdatetime, 12, 2),
													substring(//Details/Detail/@statusdatetime, 15, 2))" />
								  </G6204>
								  <G6205>
									  <xsl:value-of select="../../@statusTimeZone"/>
								  </G6205>
							  </ns0:G62>
						  </xsl:if>
                      </ns0:N1Loop1>
                    </xsl:for-each>
                  </xsl:for-each>
                </xsl:for-each>
              </xsl:for-each>
            </xsl:for-each>
          </xsl:for-each>
        </xsl:for-each>
		
		<xsl:if test="/s0:Status/@CustomerId='16666'">
		<ns0:MS3>
            <xsl:if test="//EquipmentLocation/@equipmentScac != ''">
                <MS301>
				    <xsl:choose>
					    <xsl:when test="/s0:Status/@CustomerId='16666'">EGBF</xsl:when>
					    <xsl:otherwise>ECHS</xsl:otherwise>
				    </xsl:choose>
				</MS301>
            </xsl:if>
            <MS302>O</MS302>
			<MS303>
				<xsl:value-of select="//EquipmentLocation/@cityName"/>
			</MS303>
            <MS304>
            <xsl:for-each select="//StatusList/ShipmentStatus/ReferenceData">
	            <xsl:choose>
		            <xsl:when test="@Mode='LTL'">LT</xsl:when>
		            <xsl:when test="@Mode='TL'">M</xsl:when>
		            <xsl:otherwise>M</xsl:otherwise>
	            </xsl:choose>
            </xsl:for-each>
            </MS304>
			<MS305>
		        <xsl:call-template name="StateCodetranslationMapValue">
                   <xsl:with-param name="ValueToConvert" select="//EquipmentLocation/@stateOrProvince" />
                </xsl:call-template>
		</MS305>
        </ns0:MS3>
	    </xsl:if>
			
        <xsl:for-each select="StatusList">
          <xsl:for-each select="ShipmentStatus">
            <xsl:for-each select="Statuses">
              <xsl:for-each select="Status[Details/Detail/@statusCode !='']">
              <ns0:LXLoop1>
                <ns0:LX>
                  <xsl:if test="@assignedNumber != ''">
                    <LX01>
                      <xsl:value-of select="@assignedNumber" />
                    </LX01>
                  </xsl:if>
                </ns0:LX>
                <xsl:for-each select="Details/Detail">
                    <ns0:AT7Loop1>
                      <ns0:AT7>
                        <xsl:if test="(@statusCode = 'X3' or @statusCode = 'AF' or @statusCode = 'CP' or @statusCode = 'X6' or @statusCode = 'X1' or @statusCode = 'D1' or @statusCode = 'AG')">
                          <AT701>
                            <xsl:value-of select="@statusCode" />
                          </AT701>                     
                            <AT702>
                              <xsl:choose>
                                <xsl:when test ="//StatusList/ShipmentStatus/BusinessReferences/BusinessReference[@referenceType = 'RC']/@referenceId">
                                  <xsl:value-of select="substring(//StatusList/ShipmentStatus/BusinessReferences/BusinessReference[@referenceType = 'RC']/@referenceId, 1,2)" />
                                </xsl:when>
                                <xsl:otherwise>NS</xsl:otherwise>
                              </xsl:choose>
                            </AT702>
                        </xsl:if>
                          <xsl:if test="(@statusCode = 'AA' or @statusCode = 'AB')">
                          <AT703>
                            <xsl:value-of select="@statusCode" />
                          </AT703>
						     <AT704>
                              <xsl:choose>
                                <xsl:when test ="//StatusList/ShipmentStatus/BusinessReferences/BusinessReference[@referenceType = 'RC']/@referenceId">
                                  <xsl:value-of select="substring(//StatusList/ShipmentStatus/BusinessReferences/BusinessReference[@referenceType = 'RC']/@referenceId, 1,2)" />
                                </xsl:when>
                                <xsl:otherwise>NA</xsl:otherwise>
                              </xsl:choose>
                            </AT704>
                        </xsl:if>
                        <xsl:if test="@statusdatetime != ''">
                        <AT705>
                          <xsl:value-of select="concat(substring(@statusdatetime, 1, 4), substring(@statusdatetime, 6, 2), substring(@statusdatetime, 9, 2))" />
                        </AT705>
                        </xsl:if>
                        <xsl:if test="@statusdatetime != ''">
                        <AT706>
                          <xsl:value-of select="concat(substring(@statusdatetime, 12, 2), substring(@statusdatetime, 15, 2))" />
                        </AT706>
                        </xsl:if>
                        <xsl:if test="@statusTimeZone != ''">
                        <AT707>
                            <xsl:choose>
                            <xsl:when test="/s0:Status/@CustomerId='16666' and @statusCode='AB'">LT</xsl:when>
                            <xsl:otherwise><xsl:value-of select="@statusTimeZone" /></xsl:otherwise>
                            </xsl:choose>
                        </AT707>
                        </xsl:if>
                      </ns0:AT7>
                      <xsl:if test="(EquipmentLocation/@cityName != '') or (EquipmentLocation/@stateOrProvince != '') ">
                      <ns0:MS1>
                        <xsl:if test="EquipmentLocation/@cityName != ''">
                          <MS101>
                            <xsl:call-template name="CleanAlphaField" >
                              <xsl:with-param name="inputText" select="EquipmentLocation/@cityName" />
                              <xsl:with-param name="maxLength" select="30" />
                            </xsl:call-template>
                          </MS101>
                        </xsl:if>
                        <xsl:if test="EquipmentLocation/@stateOrProvince != ''">
                          <MS102>
							   <xsl:call-template name="StateCodetranslationMapValue">
                                <xsl:with-param name="ValueToConvert" select="EquipmentLocation/@stateOrProvince" />
                              </xsl:call-template>
                          </MS102>
                        </xsl:if>
                        <MS103>US</MS103>
                      </ns0:MS1>
                      </xsl:if>

                      <xsl:if test="EquipmentLocation/@equipmentNumber != '' ">
                        <ns0:MS2>
                          <MS201>
							<xsl:choose>
								<xsl:when test="/s0:Status/@CustomerId='16666'">EGBF</xsl:when>
								<xsl:otherwise>ECHS</xsl:otherwise>
							</xsl:choose>
						  </MS201>
                          <MS202>
                            <xsl:call-template name="CleanAlphaField" >
                              <xsl:with-param name="inputText" select="EquipmentLocation/@equipmentNumber" />
                              <xsl:with-param name="maxLength" select="10" />
                            </xsl:call-template>
                          </MS202>
                          <xsl:if test="EquipmentLocation/@equipmentDescriptionCode != ''">
                            <MS203>
                              <xsl:value-of select="EquipmentLocation/@equipmentDescriptionCode" />
                            </MS203>
                          </xsl:if>
                        </ns0:MS2>
                      </xsl:if>
                      
                    </ns0:AT7Loop1>
                </xsl:for-each>
				  
                <xsl:for-each select="../../ReferenceData">
					<xsl:choose>
						<!-- Highest Piority, if header stop sequence number is not empty and non 0, it will be mapped-->
						<xsl:when test="(StopSequenceNumber/text()  != '') and (StopSequenceNumber/text()  > 0)">
							<ns0:L11_3>
								<L1101>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="StopSequenceNumber/text()" />
										<xsl:with-param name="maxLength" select="30" />
									</xsl:call-template>
								</L1101>
								<L1102>QN</L1102>
							</ns0:L11_3>
						</xsl:when>
						<!--  Custom change: Checking if stop sequence number is empty and 0 (done above) and check if it the status is != X6 (as X6 is expected to have it 0 or empty)
						                     then apply this following template:
							 
							    Pick: AA, AF, X3 and CP
                                Drop: AB, X1, A3, D1 and CD

                                Pass parameters to template: Equipment City Name and Equipment StateOrProvince.  The template will:

                                For pick statuses:
                                Confirm that canonical stop type is also Pick and Canonical //Address/City matches the equipment city and //Address/StateOrProvince matches the Equipment StateOrProvince.  If it matches, it selects the Status Assigned Number. If this is !=0 , then it will return this value.
                                Else return 1.  

                                For Drop statuses:
                                Confirm that canonical stop type is also Drop and Canonical //Address/City matches the equipment city and //Address/StateOrProvince matches the Equipment StateOrProvince.  If it matches, it selects the Status Assigned Number. If this is !=0 , then it will return this value.
                                Else return 2.   (Confirmed with Mark Anderson if that this should be 2)


                                If the conditions for pick and drop are not satisfied (mismatched), it simply returns 1 (Confirmed with Mark Anderson if this is safe to return 1)
							-->
						<xsl:when test="(string-length(../Statuses/Status/Details/Detail[1]/@statusCode) !=0) and (../Statuses/Status/Details/Detail[1]/@statusCode != 'X6')">
							<ns0:L11_3>
								<L1101>
									<xsl:call-template name="StopSequenceTypeMapValue">
										<xsl:with-param name="StatusCodeToConvert" select="../Statuses/Status/Details/Detail[1]/@statusCode"/>
										<xsl:with-param name="vStatuscityName" select="../Statuses/Status[Details/Detail[@statusCode]]/Details/Detail[@statusCode]/EquipmentLocation/@cityName"/>
										<xsl:with-param name="vStatusstateOrProvince" select="../Statuses/Status[Details/Detail[@statusCode]]/Details/Detail[@statusCode]/EquipmentLocation/@stateOrProvince"/>
									</xsl:call-template>
								</L1101>
								<L1102>QN</L1102>
							</ns0:L11_3>
						</xsl:when>
						<xsl:otherwise>
							<!-- Note: X6 will still have the entire L11 - L1101/L1102 as empty-->
						</xsl:otherwise>
					</xsl:choose>
                </xsl:for-each>
				<xsl:if test="/s0:Status/@CustomerId != '16666'">
					<xsl:for-each select="Remarks">
						<xsl:for-each select="Remark">
							<ns0:K1_2>
								<xsl:if test="@remarkMessage2 != ''">
									<K101>
										<xsl:value-of select="@remarkMessage2" />
									</K101>
								</xsl:if>
								<K102>Notes</K102>
							</ns0:K1_2>
						</xsl:for-each>
					</xsl:for-each>
				</xsl:if>
                <xsl:for-each select="../../ShipmentTotals">
                    <ns0:AT8>
                      <xsl:if test="ShipmentTotal/@totalTypeQualifier != ''">
                        <AT801>
                          <xsl:value-of select="ShipmentTotal/@totalTypeQualifier" />
                        </AT801>
                      </xsl:if>
                      <xsl:if test="ShipmentTotal/@totalUnitOfMeasure != ''">
                        <AT802>
                          <xsl:value-of select="ShipmentTotal/@totalUnitOfMeasure" />
                        </AT802>
                      </xsl:if>
                      <xsl:if test="TotalWeight != ''">
                        <AT803>
                          <xsl:value-of select="format-number(TotalWeight/text(), '#.00')" />
                        </AT803>
                      </xsl:if>
                      <xsl:if test="TotalHandlingQty > 0">
                        <AT804>
                          <xsl:value-of select="TotalHandlingQty/text()" />
                        </AT804>
                      </xsl:if>
                    </ns0:AT8>
                </xsl:for-each>
              </ns0:LXLoop1>
              </xsl:for-each>
            </xsl:for-each>
          </xsl:for-each>
        </xsl:for-each>
      <SE>
        <SE01>214</SE01>
        <SE02>12345</SE02>
      </SE>
    </ns0:X12_00401_214>
  </xsl:template>
  
  <!--Custom Templates-->
  <!--Value mapping template-->
  <xsl:template name="StopTypeMapValue">
    <xsl:param name="ValueToConvert" select="0" />
    <xsl:variable name="StopTypeMap" >
      <map>
        <entry key="Pick">SH</entry>
        <entry key="Drop">CN</entry>
      </map>
    </xsl:variable>
    <xsl:value-of select="msxsl:node-set($StopTypeMap)/map/entry[@key=$ValueToConvert]"/>
  </xsl:template>
  <!--Value mapping template-->
  <!--Set default if empty template start-->
  <xsl:template name="SetDefaultIfEmpty">
    <xsl:param name="pNode"/>
    <xsl:param name="pDefaultValue"/>
    <xsl:if test="$pNode">
      <xsl:value-of select="$pNode" />
    </xsl:if>
    <xsl:if test="not($pNode)">
      <xsl:value-of select="$pDefaultValue"/>
    </xsl:if>
  </xsl:template>
  <!--Set default if empty template end-->
  
  <!-- CleanAlphaField start  -->
  <xsl:template name="CleanAlphaField">
    <xsl:param name="inputText" />
    <xsl:param name="maxLength" />
    <xsl:variable name="singleQuote" select='"&apos;"' />
    <xsl:variable name="doubleQuote" select="'&quot;'" />
    <xsl:variable name="vAllowedSymbolsPart1" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}\?/#'"/>
    <xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
    <xsl:variable name="vCleanedText" select="translate($inputText,translate($inputText, $vAllowedSymbols, ''),'')"/>
    <xsl:value-of select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
  </xsl:template>
  <!-- Clean AlphaField end -->

  <xsl:template name="StateCodetranslationMapValue">
    <xsl:param name="ValueToConvert" select="0" />
    <xsl:variable name="StateCodetranslationMap" >
      <map>
		<entry key="AGS">AG</entry>
		<entry key="BCS">BS</entry>
		<entry key="CAM">CP</entry>
		<entry key="CHIH">CI</entry>
		<entry key="CHIS">CS</entry>
		<entry key="COAH">CH</entry>
		<entry key="COL">CL</entry>
		<entry key="DGO">DG</entry>
		<entry key="GRO">GE</entry>
		<entry key="GTO">GJ</entry>
		<entry key="HGO">HD</entry>
		<entry key="JAL">JA</entry>
		<entry key="MEX">MX</entry>
		<entry key="MICH">MC</entry>
		<entry key="MOR">MR</entry>
		<entry key="NAY">NA</entry>
		<entry key="OAX">OA</entry>
		<entry key="PUE">PU</entry>
		<entry key="QRO">QE</entry>
		<entry key="QROO">QI</entry>
		<entry key="SIN">SI</entry>
		<entry key="SLP">SL</entry>
		<entry key="SON">SO</entry>
		<entry key="TAB">TB</entry>
		<entry key="TAM">TA</entry>
		<entry key="TLAX">TL</entry>
		<entry key="VER">VC</entry>
		<entry key="YUC">YU</entry>
		<entry key="ZAC">ZA</entry>
	 </map>
  </xsl:variable>
    <xsl:variable name="ValueConverted" select="msxsl:node-set($StateCodetranslationMap)/map/entry[@key=$ValueToConvert]"/>
   <xsl:choose>
      <xsl:when test="$ValueConverted">
        <xsl:value-of select="$ValueConverted"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$ValueToConvert"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

	<!--StopSequenceTypeMapValue template-->
	<xsl:template name="StopSequenceTypeMapValue">
		<xsl:param name="StatusCodeToConvert" />
		<xsl:param name="vStatuscityName" />
		<xsl:param name="vStatusstateOrProvince" />
		<xsl:variable name="StopSequenceTypeMap" >
			<map>
				<entry key="AA">Pick</entry>
				<entry key="AF">Pick</entry>
				<entry key="X3">Pick</entry>
				<entry key="CP">Pick</entry>
				<entry key="AB">Drop</entry>
				<entry key="X1">Drop</entry>
				<entry key="A3">Drop</entry>
				<entry key="D1">Drop</entry>
				<entry key="CD">Drop</entry>
			</map>
		</xsl:variable>
		<xsl:variable name="StatusCodeConverted" select="msxsl:node-set($StopSequenceTypeMap)/map/entry[@key=$StatusCodeToConvert]"/>
		<xsl:choose>
			<xsl:when test="$StatusCodeConverted='Pick'">
				<xsl:variable name="vPickStopSequenceNumber" select="../Statuses/Status/Details/Detail[@stopType='Pick' and Addresses/Address[@city=$vStatuscityName and @stateProvince=$vStatusstateOrProvince]]/../../@assignedNumber"/>
				<xsl:choose>
					<xsl:when test="(string-length($vPickStopSequenceNumber) != 0)  and ($vPickStopSequenceNumber > 0)">
						<xsl:value-of select="$vPickStopSequenceNumber"/>
					</xsl:when>
					<xsl:otherwise>1</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:when test="$StatusCodeConverted='Drop'">
				<xsl:variable name="vDropStopSequenceNumber" select="../Statuses/Status/Details/Detail[@stopType='Drop' and Addresses/Address[@city=$vStatuscityName and @stateProvince=$vStatusstateOrProvince]]/../../@assignedNumber"/>
				<xsl:choose>
					<xsl:when test="(string-length($vDropStopSequenceNumber) !=0 ) and ($vDropStopSequenceNumber > 0) ">
						<xsl:value-of select="$vDropStopSequenceNumber"/>
					</xsl:when>
					<xsl:otherwise>2</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:otherwise>1</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<!--StopSequenceTypeMapValue template-->
	
	
</xsl:stylesheet>