<?xml version="1.0" encoding="UTF-16"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" exclude-result-prefixes="msxsl var s0" version="1.0" xmlns:ns0="http://schemas.microsoft.com/BizTalk/EDI/X12/2006" xmlns:s0="http://Azure214.schema-definition">
  <xsl:output omit-xml-declaration="yes" method="xml" version="1.0" />
  <xsl:template match="/">
    <xsl:apply-templates select="/s0:StatusList" />
  </xsl:template>
  <xsl:template match="/s0:StatusList">
    <ns0:X12_00401_214>
      <ST>
        <ST01>214</ST01>
        <ST02>12345</ST02>
      </ST>
      <ns0:B10>
        <B1001>
          <xsl:value-of select="ShipmentStatus/ReferenceData/LoadId/text()" />
        </B1001>
        <B1002>
          <xsl:value-of select="ShipmentStatus/ReferenceData/Bol/text()"/>
        </B1002>
        <B1003>
          <xsl:value-of select="ShipmentStatus/ReferenceData/Scac/text()"/>
        </B1003>
      </ns0:B10>
      <xsl:for-each select="ShipmentStatus/BusinessReferences/BusinessReference">
        <ns0:L11>
          <L1101>
            <xsl:value-of select="@referenceId"/>
          </L1101>
          <L1102>
            <xsl:value-of select="@referenceType"/>
          </L1102>
        </ns0:L11>
      </xsl:for-each>
      <xsl:for-each select="ShipmentStatus/Statuses/Status/Details/Detail/Addresses/Address">
        <ns0:N1Loop1>
          <ns0:N1>
            <N101>
              <xsl:choose>
                <xsl:when test="../../@stopType='Pick'">SF</xsl:when>
                <xsl:when test="../../@stopType='Drop'">CN</xsl:when>
                <xsl:otherwise>ZZ</xsl:otherwise>
              </xsl:choose>
            </N101>
            <N102>
              <xsl:value-of select="@name"/>
            </N102>
            <N103>
              <xsl:value-of select="@locationIdentifier"/>
            </N103>
            <N104>
              <xsl:value-of select="//BusinessReferences/BusinessReference/@referenceId"/>
            </N104>
          </ns0:N1>
          <ns0:N2>
            <N201>
              <xsl:value-of select="@name"/>
            </N201>
          </ns0:N2>
          <ns0:N3>
            <N301>
              <xsl:value-of select="@address1"/>
            </N301>
            <N302>
              <xsl:value-of select="@address2"/>
            </N302>
          </ns0:N3>
          <ns0:N4>
            <N401>
              <xsl:value-of select="@city"/>
            </N401>
            <N402>
              <xsl:value-of select="@stateProvince"/>
            </N402>
            <N403>
              <xsl:value-of select="@postalCode"/>
            </N403>
            <N404>
              <xsl:value-of select="@country"/>
            </N404>
          </ns0:N4>
        </ns0:N1Loop1>
      </xsl:for-each>
      <xsl:for-each select="ShipmentStatus/Statuses/Status/Details/Detail">
        <ns0:LXLoop1>
          <ns0:LX>
            <LX01>
              <xsl:value-of select="../../@assignedNumber"/>
            </LX01>
          </ns0:LX>
          <ns0:AT7Loop1>
            <ns0:AT7>
             <!-- <AT701>
                  <xsl:if test="@statusCode = 'X3' or @statusCode = 'AF' or @statusCode = 'CP' or @statusCode = 'X6' or @statusCode = 'X1' or @statusCode = 'D1'">
                    <xsl:value-of select="@statusCode"/>
                  </xsl:if>
              </AT701>
              <AT702>
                  <xsl:if test="@statusCode = 'X3' or @statusCode = 'AF' or @statusCode = 'CP' or @statusCode = 'X6' or @statusCode = 'X1' or @statusCode = 'D1'">NS</xsl:if>
              </AT702>
              <AT703>
                  <xsl:if test="@statusCode = 'AA' or @statusCode = 'AB' ">
                    <xsl:value-of select="@statusCode"/>
                  </xsl:if>
              </AT703>
              <AT704>
                  <xsl:if test="@statusCode = 'AA' or @statusCode = 'AB' ">NA</xsl:if>
              </AT704> -->
              <xsl:if test="@statusCode = 'X3' or @statusCode = 'AF' or @statusCode = 'CP' or @statusCode = 'X6' or @statusCode = 'X1' or @statusCode = 'D1'">
                <AT701>
                  <xsl:value-of select="@statusCode"/>
                </AT701>
                <AT702>NS</AT702>
              </xsl:if>
              <xsl:if test="@statusCode = 'AA' or @statusCode = 'AB'">
                <AT703>
                  <xsl:value-of select="@statusCode"/>
                </AT703>
                <AT704>NA</AT704>
              </xsl:if>
              <AT705>
                <xsl:value-of select="concat(substring(@statusdatetime,1,4),
                                             substring(@statusdatetime,6,2),
                                             substring(@statusdatetime,9,2))"/>
              </AT705>
              <AT706>
                <xsl:value-of select="concat(substring(@statusdatetime,12,2),
                                             substring(@statusdatetime,15,2))"/>
              </AT706>
              <AT707>
                <xsl:value-of select="@statusTimeZone"/>
              </AT707>
            </ns0:AT7>
            <ns0:MS1>
              <MS101>
                <xsl:value-of select="EquipmentLocation/@cityName"/>
              </MS101>
              <MS102>
                <xsl:value-of select="EquipmentLocation/@stateOrProvince"/>
              </MS102>
            </ns0:MS1>
            <ns0:MS2>
              <MS201>
                <xsl:value-of select="EquipmentLocation/@equipmentScac"/>
              </MS201>
              <MS202>
                <xsl:value-of select="EquipmentLocation/@equipmentNumber"/>
              </MS202>
              <MS203>
                <xsl:value-of select="EquipmentLocation/@equipmentDescriptionCode"/>
              </MS203>
            </ns0:MS2>
          </ns0:AT7Loop1>
          <ns0:L11_3>
            <L1101>
              <xsl:value-of select="//ReferenceData/StopSequenceNumber"/>
            </L1101>
            <L1102>QN</L1102>
          </ns0:L11_3>
          <ns0:K1_2>
            <K101>
              <xsl:value-of select="//ShipmentStatus/Remarks"/>
            </K101>
            <K102>Notes</K102>
          </ns0:K1_2>
          <ns0:AT8>
            <AT801>
              <xsl:value-of select="//ShipmentTotals/ShipmentTotal/@totalTypeQualifier"/>
            </AT801>
            <AT802>
              <xsl:value-of select="//ShipmentTotals/ShipmentTotal/@totalUnitOfMeasure"/>
            </AT802>
            <AT803>
              <xsl:value-of select="format-number(number(//ShipmentTotals/TotalWeight),'0.00')"/>
            </AT803>
            <AT804>
              <xsl:value-of select="//ShipmentTotals/TotalHandlingQty"/>
            </AT804>
          </ns0:AT8>
        </ns0:LXLoop1>
      </xsl:for-each>
      <SE>
        <SE01>214</SE01>
        <SE02>12345</SE02>
      </SE>
    </ns0:X12_00401_214>
  </xsl:template>
</xsl:stylesheet>