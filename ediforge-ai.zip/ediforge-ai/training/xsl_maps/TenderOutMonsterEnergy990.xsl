<?xml version="1.0" encoding="UTF-16"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
				xmlns:msxsl="urn:schemas-microsoft-com:xslt" 
				xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" 
				exclude-result-prefixes="msxsl var s0" version="1.0" 
				xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_Custom401.EDI990/v1.0" 
				xmlns:s0="http://Echo.BSSR.Internal.Canonical.TendorResponse.TenderResponseOut">
	<xsl:output omit-xml-declaration="yes" method="xml" version="1.0" />
	<xsl:template match="/">
		<xsl:apply-templates select="/s0:TenderResponse" />
	</xsl:template>
	<xsl:template match="/s0:TenderResponse">

		<xsl:variable name="vBookingDateRaw" select="Transaction/Header/BookingDate/text()" />
		<xsl:variable name="vReservationCode" select="Transaction/Header/ReservationCode/text()" />

		<xsl:variable name="vBookingDate" select="substring-before($vBookingDateRaw,'T')" />
		<xsl:variable name="vBookingYear" select="substring-before($vBookingDate, '-')" />
		<xsl:variable name="vBookingMonthDay" select="substring-after($vBookingDate,'-')" />
		<xsl:variable name="vBookingMonth" select="substring-before($vBookingMonthDay,'-')" />
		<xsl:variable name="vBookingDay" select="substring-after($vBookingMonthDay,'-')" />


		<ns0:X12_00401_990>
			<ST>
				<ST01>990</ST01>
				<ST02>0001</ST02>
			</ST>
			<ns0:B1>
				<B101>
					<xsl:value-of select="'ECHS'"/>
				</B101>
				<B102>
					<xsl:value-of select="Transaction/Header/BOL/text()" />
				</B102>
				<B103>
					<xsl:value-of select="$vBookingYear"/>
					<xsl:value-of select="$vBookingMonth"/>
					<xsl:value-of select="$vBookingDay"/>
				</B103>
				<B104>
					<xsl:value-of select="$vReservationCode"/>
				</B104>

			</ns0:B1>

			<ns0:N9>
				<N901>
					<xsl:value-of select="'06'"/>
				</N901>
				<N902>
					<xsl:value-of select="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='06'][1]/RefValue/text()"/>
				</N902>
			</ns0:N9>
				<ns0:N9>
				<N901>
					<xsl:value-of select="'CN'"/>
				</N901>
				<N902>
					<xsl:value-of select="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='CN'][1]/RefValue/text()"/>
				</N902>
				<xsl:if test="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='IX'][1]/RefValue/text()!=''">
					<ns0:C040>
						<C04001>
							<xsl:value-of select ="'IX'"/>
						</C04001>
						<C04002>
							<xsl:value-of select ="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='IX'][1]/RefValue/text()"/>
						</C04002>

					</ns0:C040>
				</xsl:if>


			</ns0:N9>
			<xsl:if test="Transaction/Header/EquipmentNumber!=''">
				<ns0:N7>
					<N702>
						<xsl:value-of select="Transaction/Header/EquipmentNumber"/>
					</N702>
				</ns0:N7>
			</xsl:if>
		</ns0:X12_00401_990>
	</xsl:template>




</xsl:stylesheet>
