<?xml version="1.0" encoding="UTF-16"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt"
xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var"
exclude-result-prefixes="msxsl var s0 userCSharp" version="1.0"
xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00401.EDIOB210V2.0"
xmlns:s0="http://Echo.BSSR.Internal.Canonical.InvoiceV2"
xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp">
	<xsl:output omit-xml-declaration="yes" method="xml" version="1.0" />
	<xsl:template match="/">
		<xsl:apply-templates select="/s0:Invoice" />
	</xsl:template>
	<xsl:template match="/s0:Invoice">
		<ns0:X12_00401_210>
			<ST>
				<ST01>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetIdentifierCode" />
				</ST01>
				<ST02>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber" />
				</ST02>
			</ST>
			<xsl:variable name="SM" select="Header/ReferenceList/ReferenceInformation[@EDICode = 'SM']/@ReferenceInformation"/>
			<ns0:B3>
				<B302>
					<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber" />
				</B302>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@ShipmentIdentificationNumber">
					<B303>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentIdentificationNumber" />
					</B303>
				</xsl:if>
				<B304>
					<xsl:value-of select="'CC'" />
				</B304>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@WeightUnitCode">
					<B305>
						<xsl:value-of select="'L'" />
					</B305>
				</xsl:if>
				<xsl:variable name="InvoiceDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='InvoiceDate']" />
				<xsl:variable name="DeliveryDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='DeliveryDate']" />
				<xsl:variable name="BillingDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='BillingDate']" />
				<xsl:variable name="PickupDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='PickupDate']" />
				<B306>
					<xsl:value-of select="concat(substring($InvoiceDate, 1, 4), substring($InvoiceDate, 6, 2), substring($InvoiceDate, 9, 2))" />
				</B306>
				<B307>
					<xsl:value-of select="translate(Header/BeginningSegmentForCarriersInvoice/@NetAmountDue,'.','')" />
				</B307>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@DeliveryDate">
					<B309>
						<xsl:value-of select="concat(substring($DeliveryDate, 1, 4), substring($DeliveryDate, 6, 2), substring($DeliveryDate, 9, 2))" />
					</B309>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@DateTimeQualifier">
					<B310>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@DateTimeQualifier" />
					</B310>
				</xsl:if>
				<B311>
					<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@StandardCarrierAlphaCode" />
				</B311>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@PickupDate">
					<B312>
						<xsl:value-of select="concat(substring($PickupDate, 1, 4), substring($PickupDate, 6, 2), substring($PickupDate, 9, 2))" />
					</B312>
				</xsl:if>
			</ns0:B3>
			<!--<xsl:for-each select="Header/Currency">
        <ns0:C3>
          <xsl:choose>
          <xsl:when test="@BillingCurrencyCode">
            <C301>
              <xsl:value-of select="@BillingCurrencyCode" />
            </C301>
          </xsl:when>
            <xsl:otherwise>
              <C301>
              <xsl:value-of select="'USD'" />
              </C301>
            </xsl:otherwise>
          </xsl:choose>
        </ns0:C3>
      </xsl:for-each>-->
			<xsl:for-each select="Header/ReferenceList/ReferenceInformation[@EDICode='BM' or @EDICode='OI' or @EDICode='FD' or @EDICode='PID']">
				<ns0:N9>
					<N901>
						<xsl:value-of select="@EDICode" />
					</N901>
					<N902>
						<xsl:value-of select="@ReferenceInformation" />
					</N902>
				</ns0:N9>
			</xsl:for-each>
			<xsl:variable name="InvoiceDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@InvoiceDate" />
			<xsl:variable name="DeliveryDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@DeliveryDate" />
			<xsl:variable name="PickupDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@PickupDate" />
			<ns0:G62>
				<G6201>
					<xsl:value-of select="86" />
				</G6201>
				<G6202>
					<xsl:value-of select="concat(substring($PickupDate, 1, 4), substring($PickupDate, 6, 2), substring($PickupDate, 9, 2))" />
				</G6202>
			</ns0:G62>
			<ns0:G62>
				<G6201>
					<xsl:value-of select="35" />
				</G6201>
				<G6202>
					<xsl:value-of select="concat(substring($DeliveryDate, 1, 4), substring($DeliveryDate, 6, 2), substring($DeliveryDate, 9, 2))" />
				</G6202>
			</ns0:G62>
			<ns0:R3>
				<R301>ECHS</R301>
				<R302>Z</R302>
				<R304>
					<xsl:choose>
						<xsl:when test="Header/ReferenceList/ReferenceInformation[@EDICode='MD']/@ReferenceInformation='LTL'">LT</xsl:when>
						<xsl:otherwise>M</xsl:otherwise>
					</xsl:choose>
				</R304>
			</ns0:R3>

			<!--<xsl:for-each select="Header/PartyList/Party">
        <xsl:if test="Name[@EntityIdentifierCode='BT']">
        <ns0:N1Loop1>
            <ns0:N1>
              <N101>
                <xsl:value-of select="Name/@EntityIdentifierCode" />
              </N101>
              <N102>
                <xsl:value-of select="Name/@Name" />
              </N102>
            </ns0:N1>
            <ns0:N3>
              <xsl:if test="AddressInformation/@AddressInformationLine1">
              <N301>
                <xsl:value-of select="AddressInformation/@AddressInformationLine1" />
              </N301>
              </xsl:if>
              <xsl:if test="AddressInformation/@AddressInformationLine2">
                <N302>
                  <xsl:value-of select="AddressInformation/@AddressInformationLine2" />
                </N302>
              </xsl:if>
            </ns0:N3>
            <ns0:N4>
              <xsl:if test="GeographicLocation/@CityName !=''">
                <N401>
                  <xsl:value-of select="GeographicLocation/@CityName" />
                </N401>
              </xsl:if>
              <xsl:if test="GeographicLocation/@StateOrProvinceCode !=''">
                <N402>
                  <xsl:value-of select="GeographicLocation/@StateOrProvinceCode" />
                </N402>
              </xsl:if>
              <xsl:if test="GeographicLocation/@PostalCode !=''">
                <N403>
                  <xsl:value-of select="GeographicLocation/@PostalCode" />
                </N403>
              </xsl:if>
              <xsl:if test="GeographicLocation/@CountryCode !=''">
                <N404>
                  <xsl:value-of select="GeographicLocation/@CountryCode" />
                </N404>
              </xsl:if>
            </ns0:N4>
          </ns0:N1Loop1>
        </xsl:if>
      </xsl:for-each>-->
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH']">
				<xsl:if test="position()=1">
					<ns0:N1Loop1>
						<ns0:N1>
							<N101>
								<xsl:value-of select="Name/@EntityIdentifierCode" />
							</N101>
							<N102>
								<xsl:value-of select="Name/@Name" />
							</N102>
						</ns0:N1>
						<ns0:N3>
							<xsl:if test="AddressInformation/@AddressInformationLine1">
								<N301>
									<xsl:value-of select="AddressInformation/@AddressInformationLine1" />
								</N301>
							</xsl:if>
							<xsl:if test="AddressInformation/@AddressInformationLine2">
								<N302>
									<xsl:value-of select="AddressInformation/@AddressInformationLine2" />
								</N302>
							</xsl:if>
						</ns0:N3>
						<ns0:N4>
							<xsl:if test="GeographicLocation/@CityName !=''">
								<N401>
									<xsl:value-of select="GeographicLocation/@CityName" />
								</N401>
							</xsl:if>
							<xsl:if test="GeographicLocation/@StateOrProvinceCode !=''">
								<N402>
									<xsl:value-of select="GeographicLocation/@StateOrProvinceCode" />
								</N402>
							</xsl:if>
							<xsl:if test="GeographicLocation/@PostalCode !=''">
								<N403>
									<xsl:value-of select="GeographicLocation/@PostalCode" />
								</N403>
							</xsl:if>
							<xsl:if test="GeographicLocation/@CountryCode !=''">
								<N404>
									<xsl:value-of select="GeographicLocation/@CountryCode" />
								</N404>
							</xsl:if>
						</ns0:N4>
					</ns0:N1Loop1>
				</xsl:if>
			</xsl:for-each>
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN']">
				<xsl:if test="position()=1">
					<ns0:N1Loop1>
						<ns0:N1>
							<N101>
								<xsl:value-of select="Name/@EntityIdentifierCode" />
							</N101>
							<N102>
								<xsl:value-of select="Name/@Name" />
							</N102>
						</ns0:N1>
						<ns0:N3>
							<xsl:if test="AddressInformation/@AddressInformationLine1">
								<N301>
									<xsl:value-of select="AddressInformation/@AddressInformationLine1" />
								</N301>
							</xsl:if>
							<xsl:if test="AddressInformation/@AddressInformationLine2">
								<N302>
									<xsl:value-of select="AddressInformation/@AddressInformationLine2" />
								</N302>
							</xsl:if>
						</ns0:N3>
						<ns0:N4>
							<xsl:if test="GeographicLocation/@CityName !=''">
								<N401>
									<xsl:value-of select="GeographicLocation/@CityName" />
								</N401>
							</xsl:if>
							<xsl:if test="GeographicLocation/@StateOrProvinceCode !=''">
								<N402>
									<xsl:value-of select="GeographicLocation/@StateOrProvinceCode" />
								</N402>
							</xsl:if>
							<xsl:if test="GeographicLocation/@PostalCode !=''">
								<N403>
									<xsl:value-of select="GeographicLocation/@PostalCode" />
								</N403>
							</xsl:if>
							<xsl:if test="GeographicLocation/@CountryCode !=''">
								<N404>
									<xsl:value-of select="GeographicLocation/@CountryCode" />
								</N404>
							</xsl:if>
						</ns0:N4>
					</ns0:N1Loop1>
				</xsl:if>
			</xsl:for-each>
			<xsl:variable name="NumberOfN7" select="count (Header/EquipmentList/Equipment[@EquipmentNumber != ''])"/>
			<xsl:if test="$NumberOfN7 > 0">
				<xsl:for-each select="Header/EquipmentList/Equipment">
					<ns0:N7Loop1>
						<ns0:N7>
							<N701>
								<xsl:value-of select="'ECHS'" />
							</N701>
							<N702>
								<xsl:value-of select="@EquipmentNumber" />
							</N702>
							<N711>
								<xsl:value-of select="'CN'" />
							</N711>
							<N715>
								<xsl:value-of select="@EquipmentLength" />
							</N715>
						</ns0:N7>
					</ns0:N7Loop1>
				</xsl:for-each>
			</xsl:if>
			<xsl:for-each select="Detail/LineItemList/LineItem">
				<xsl:variable name="LXPosition" select="position()" />
				<xsl:if test="RateAndCharges">
					<ns0:LXLoop1>
						<ns0:LX>
							<LX01>
								<xsl:value-of select="AssignedNumber/@AssignedNumber" />
							</LX01>
						</ns0:LX>
						<!--<ns0:L5>
            <xsl:if test="DescriptionMarksAndNumbers/@LadingLineItemNumber != ''">
              <L501>
                <xsl:value-of select="DescriptionMarksAndNumbers/@LadingLineItemNumber" />
              </L501>
            </xsl:if>
            <xsl:if test="DescriptionMarksAndNumbers/@LadingDescription != ''">
              <L502>
                <xsl:value-of select="DescriptionMarksAndNumbers/@LadingDescription" />
              </L502>
            </xsl:if>
          </ns0:L5>-->

						<xsl:if test="$LXPosition=1">
							<xsl:for-each select="LineItemQuantityAndWeight">
								<ns0:L0>
									<xsl:if test="@LadingLineItemNumber !=''">
										<L001>
											<xsl:value-of select="@LadingLineItemNumber" />
										</L001>
									</xsl:if>
									<xsl:if test="@BilledRatedAsQuantity !=''">
										<L002>
											<xsl:value-of select="@BilledRatedAsQuantity" />
										</L002>
									</xsl:if>
									<xsl:if test="@BilledRatedAsQualifier !=''">
										<L003>
											<xsl:value-of select="@BilledRatedAsQualifier" />
										</L003>
									</xsl:if>
									<xsl:if test="@Weight !=''">
										<L004>
											<xsl:value-of select="@Weight" />
										</L004>
									</xsl:if>
									<xsl:if test="@WeightQualifier !=''">
										<L005>G</L005>
									</xsl:if>
									<xsl:if test="@LadingQuantity !=''">
										<L008>
											<xsl:value-of select="@LadingQuantity !=''" />
										</L008>
									</xsl:if>
									<xsl:if test="@LadingQuantityPackagingFormCode !=''">
										<L009>
											<xsl:value-of select="@LadingQuantityPackagingFormCode" />
										</L009>
									</xsl:if>
									<xsl:if test="@WeightUnitCode !=''">
										<L011>
											<xsl:value-of select="@WeightUnitCode" />
										</L011>
									</xsl:if>
								</ns0:L0>
							</xsl:for-each>
						</xsl:if>
						<xsl:for-each select="RateAndCharges">
							<xsl:variable name="chargeCode" select="@SpecialChargeOrAllowanceCode" />
							<ns0:L1>
								<xsl:if test="@LadingLineItemNumber !=''">
									<L101>
										<xsl:value-of select="@LadingLineItemNumber" />
									</L101>
								</xsl:if>
								<xsl:if test="@FreightRate !=''">
									<L102>
										<xsl:value-of select="@FreightRate" />
									</L102>
								</xsl:if>
								<xsl:if test="@RateValueQualifier !=''">
									<L103>
										<xsl:choose>
											<xsl:when test="$chargeCode = 'SSF'">OT</xsl:when>
											<xsl:otherwise>
												<xsl:value-of select="@RateValueQualifier" />
											</xsl:otherwise>
										</xsl:choose>
									</L103>
								</xsl:if>
								<xsl:choose>
									<xsl:when test="$chargeCode = 'SSF' or $chargeCode ='806' ">
										<L104>0</L104>
									</xsl:when>
									<xsl:otherwise>
										<L104>
											<xsl:value-of select="@Charge" />
										</L104>
									</xsl:otherwise>

								</xsl:choose>
								<xsl:if test="@RateCombinationPointCode !=''">
									<L107>
										<xsl:value-of select="@RateCombinationPointCode" />
									</L107>
								</xsl:if>
								<L108>
									<xsl:if test="@SpecialChargeOrAllowanceCode!=''">
										<xsl:call-template name="L108Value">
											<xsl:with-param name="ValueToConvert" select="@SpecialChargeOrAllowanceCode" />
										</xsl:call-template>
									</xsl:if>
									<!--<xsl:value-of select="@SpecialChargeOrAllowanceCode" />-->
								</L108>
							</ns0:L1>
						</xsl:for-each>
					</ns0:LXLoop1>
				</xsl:if>
			</xsl:for-each>
			<xsl:for-each select="Summary/TotalWeightAndCharges">
				<ns0:L3>
					<xsl:if test="@Weight">
						<L301>
							<xsl:value-of select="@Weight" />
						</L301>
					</xsl:if>

					<L302>
						<xsl:value-of select="'G'" />
					</L302>

					<xsl:if test="@TotalCharges">
						<L305>
							<xsl:value-of select="translate(@TotalCharges,'.','')" />
						</L305>
					</xsl:if>
					<!--<xsl:if test="@LadingQuantity">
            <L311>
              <xsl:value-of select="@LadingQuantity" />
            </L311>
          </xsl:if>-->
				</ns0:L3>
			</xsl:for-each>
		</ns0:X12_00401_210>
	</xsl:template>
	<xsl:template name="L108Value">
		<xsl:param name="ValueToConvert" select="0" />
		<xsl:variable name="L108Map" >
			<map>
				<entry key="LHS">LHS</entry>
				<entry key="405">FUE</entry>
				<entry key="LYT">LYC</entry>
				<entry key="PSC">PFF</entry>
				<entry key="ACL">DLO</entry>
				<entry key="UNL">LUM</entry>
				<entry key="SSF">LHS</entry>
				<entry key="400">LHS</entry>
				<entry key="LYC">LAY</entry>
				<entry key="320">LAY</entry>
				<entry key="270">VOR</entry>
				<entry key="VIP">NYP</entry>
				<entry key="806">LHS</entry>
				<entry key="MUL">SOC</entry>
				<entry key="ACH">NYP</entry>
				<entry key="CON">NYP</entry>
				<entry key="WTV">IFC</entry>
				<entry key="CBL">LAC</entry>
				<entry key="TDT">DEP</entry>
			</map>
		</xsl:variable>
		<xsl:variable name="ValueConverted" select="msxsl:node-set($L108Map)/map/entry[@key=$ValueToConvert]" />
		<xsl:choose>
			<xsl:when test="$ValueConverted">
				<xsl:value-of select="$ValueConverted"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="$ValueToConvert"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>