<?xml version="1.0" encoding="UTF-16"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" exclude-result-prefixes="msxsl var s0 userCSharp" version="1.0" xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00401.EDI214/v1.0" xmlns:s0="http://Echo.BSSR.Internal.Canonical.Status/v1.0" xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp">
	<xsl:output omit-xml-declaration="yes" method="xml" version="1.0" />
	<xsl:template match="/">
		<xsl:apply-templates select="/s0:Status" />
	</xsl:template>
	<xsl:template match="/s0:Status">

		<ns0:X12_00401_214>
			<xsl:variable name="ENum" select="/s0:Status/@CustomerId"/>
			<ST>
				<ST01>214</ST01>
				<ST02>12345</ST02>
			</ST>
			<xsl:for-each select="StatusList">
				<xsl:for-each select="ShipmentStatus">
					<xsl:for-each select="ReferenceData">
						<ns0:B10>
							<xsl:if test="LoadId/text() != ''">
								<B1001>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="LoadId/text()" />
										<xsl:with-param name="maxLength" select="30" />
									</xsl:call-template>
								</B1001>
							</xsl:if>
							<xsl:if test="Bol/text()  != ''">
								<B1002>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="Bol/text()" />
										<xsl:with-param name="maxLength" select="30" />
									</xsl:call-template>
								</B1002>
							</xsl:if>
							<xsl:if test="Scac/text() != ''">
								<B1003>
									<xsl:value-of select="Scac/text()"/>
								</B1003>
							</xsl:if>
						</ns0:B10>
					</xsl:for-each>
				</xsl:for-each>
			</xsl:for-each>

			<xsl:variable name="altStatus" select="/s0:Status/StatusList/ShipmentStatus/BusinessReferences/BusinessReference[@referenceType = 'BC']/@referenceId"/>

			<xsl:for-each select="StatusList">
				<xsl:for-each select="ShipmentStatus">
					<xsl:for-each select="BusinessReferences">
						<xsl:for-each select="BusinessReference">
							<xsl:if test="($ENum != '157157') and (@referenceId != '') and (@referenceType  != '' and @referenceType  != 'BC')">
								<ns0:L11>
									<xsl:if test="(@referenceId != '')">
										<L1101>
											<xsl:call-template name="CleanAlphaField" >
												<xsl:with-param name="inputText" select="@referenceId" />
												<xsl:with-param name="maxLength" select="30" />
											</xsl:call-template>
										</L1101>
									</xsl:if>
									<xsl:if test="(@referenceType  != '')">
										<L1102>
											<xsl:call-template name="CleanAlphaField" >
												<xsl:with-param name="inputText" select="@referenceType" />
												<xsl:with-param name="maxLength" select="3" />
											</xsl:call-template>
										</L1102>
									</xsl:if>
								</ns0:L11>
							</xsl:if>
							<xsl:if test="($ENum = '157157') and (@referenceId != '') and (@referenceType  != '' and @referenceType  != 'BC' and @referenceType  != 'CC' and @referenceType  != 'ZZ' and @referenceType  != 'P8' and @referenceType  != 'SI')">
								<ns0:L11>
									<xsl:if test="(@referenceId != '')">
										<L1101>
											<xsl:call-template name="CleanAlphaField" >
												<xsl:with-param name="inputText" select="@referenceId" />
												<xsl:with-param name="maxLength" select="30" />
											</xsl:call-template>
										</L1101>
									</xsl:if>
									<xsl:if test="(@referenceType  != '')">
										<L1102>
											<xsl:call-template name="CleanAlphaField" >
												<xsl:with-param name="inputText" select="@referenceType" />
												<xsl:with-param name="maxLength" select="3" />
											</xsl:call-template>
										</L1102>
									</xsl:if>
								</ns0:L11>
							</xsl:if>
						</xsl:for-each>
					</xsl:for-each>
				</xsl:for-each>
			</xsl:for-each>
			<xsl:for-each select="StatusList/ShipmentStatus/ReferenceData">
				<ns0:L11>
					<xsl:if test="Bol!=''">
						<L1101>
							<xsl:call-template name="CleanAlphaField" >
								<xsl:with-param name="inputText" select="Bol" />
								<xsl:with-param name="maxLength" select="30" />
							</xsl:call-template>
						</L1101>
					</xsl:if>
					<L1102>LO</L1102>
				</ns0:L11>
			</xsl:for-each>
			<xsl:for-each select="StatusList/ShipmentStatus/ReferenceData">
				<ns0:L11>
					<xsl:choose>
						<xsl:when test="SStopSequenceNumber!='' and StopSequenceNumber &gt; 0">
							<L1101>
								<xsl:call-template name="CleanAlphaField" >
									<xsl:with-param name="inputText" select="StopSequenceNumber" />
									<xsl:with-param name="maxLength" select="30" />
								</xsl:call-template>
							</L1101>
						</xsl:when>
						<xsl:otherwise>
							<L1101>2</L1101>
						</xsl:otherwise>
					</xsl:choose>
					<L1102>QN</L1102>
				</ns0:L11>
			</xsl:for-each>

			<xsl:for-each select="StatusList">
				<xsl:for-each select="ShipmentStatus">
					<xsl:for-each select="Statuses">
						<xsl:for-each select="Status">
							<xsl:for-each select="Details/Detail[@stopType='Pick' or @stopType='Drop']">
								<xsl:for-each select="Addresses">
									<xsl:for-each select="Address">
										<!--first one-->
										<ns0:N1Loop1>
											<ns0:N1>
												<xsl:if test="../../@stopType">
													<N101>
														<xsl:call-template name="StopTypeMapValue">
															<xsl:with-param name="ValueToConvert" select="../../@stopType" />
														</xsl:call-template>
													</N101>
												</xsl:if>
												<xsl:if test="@name != ''">
													<N102>
														<xsl:call-template name="CleanAlphaField" >
															<xsl:with-param name="inputText" select="@name" />
															<xsl:with-param name="maxLength" select="30" />
														</xsl:call-template>
													</N102>
												</xsl:if>
												<!-- Removed by design. Node not available by default.
                        <xsl:if test="@locationIdentifier != ''">
                          <N103>
                            <xsl:call-template name="SetDefaultIfEmpty">
                              <xsl:with-param name="node" select="@locationIdentifier"/>
                              <xsl:with-param name="pDefaultValue" select="93"/>
                            </xsl:call-template>
                          </N103>
                        </xsl:if>
                        -->
											</ns0:N1>
											<xsl:if test="@address1 != '' or @address2 != ''">
												<ns0:N3>
													<xsl:if test="@address1 != ''">
														<N301>
															<xsl:call-template name="CleanAlphaField" >
																<xsl:with-param name="inputText" select="@address1" />
																<xsl:with-param name="maxLength" select="30" />
															</xsl:call-template>
														</N301>
													</xsl:if>
													<xsl:if test="@address2 != ''">
														<N302>
															<xsl:call-template name="CleanAlphaField" >
																<xsl:with-param name="inputText" select="@address2" />
																<xsl:with-param name="maxLength" select="30" />
															</xsl:call-template>
														</N302>
													</xsl:if>
												</ns0:N3>
											</xsl:if>
											<ns0:N4>
												<xsl:if test="@city != ''">
													<N401>
														<xsl:call-template name="CleanAlphaField" >
															<xsl:with-param name="inputText" select="@city" />
															<xsl:with-param name="maxLength" select="30" />
														</xsl:call-template>
													</N401>
												</xsl:if>
												<xsl:if test="@stateProvince != ''">
													<N402>
														<xsl:call-template name="StateCodetranslationMapValue">
															<xsl:with-param name="ValueToConvert" select="@stateProvince" />
														</xsl:call-template>
													</N402>
												</xsl:if>
												<xsl:if test="@postalCode != ''">
													<N403>
														<xsl:value-of select="@postalCode" />
													</N403>
												</xsl:if>
												<xsl:if test="@country != ''">
													<N404>
														<xsl:value-of select="@country" />
													</N404>
												</xsl:if>
											</ns0:N4>
										</ns0:N1Loop1>
									</xsl:for-each>
								</xsl:for-each>
							</xsl:for-each>
						</xsl:for-each>
					</xsl:for-each>
				</xsl:for-each>
			</xsl:for-each>
			<xsl:for-each select="StatusList">
				<xsl:for-each select="ShipmentStatus">
					<xsl:for-each select="Statuses">
						<xsl:for-each select="Status[Details/Detail/@statusCode !='']">
							<ns0:LXLoop1>
								<ns0:LX>
									<xsl:if test="@assignedNumber != ''">
										<LX01>
											<xsl:value-of select="@assignedNumber" />
										</LX01>
									</xsl:if>
								</ns0:LX>
								<xsl:for-each select="Details/Detail">
									<ns0:AT7Loop1>
										<ns0:AT7>
											<xsl:if test="(@statusCode = 'X3' or @statusCode = 'AF' or @statusCode = 'CP' or @statusCode = 'X6' or @statusCode = 'X1' or @statusCode = 'D1')">
												<AT701>
													<xsl:choose>
														<xsl:when test="//BusinessReferences/BusinessReference/@referenceType = 'RC'">SD</xsl:when>
														<xsl:when test = "$altStatus = 'Y'">BC</xsl:when>
														<xsl:otherwise>
															<xsl:value-of select="@statusCode" />
														</xsl:otherwise>
													</xsl:choose>
												</AT701>
												<AT702>
													<xsl:variable name="reasonCode" select="//BusinessReferences/BusinessReference[@referenceType = 'RC']/@referenceId"/>
													<xsl:choose>
														<xsl:when test="(//BusinessReferences/BusinessReference/@referenceType = 'RC' and ($ENum = '16417'))">
															<xsl:value-of select="substring($reasonCode, 1,2)" />
														</xsl:when>
														<xsl:otherwise>NS</xsl:otherwise>
													</xsl:choose>
												</AT702>
											</xsl:if>
											<xsl:if test="(@statusCode = 'AA' or @statusCode = 'AB')">
												<AT703>
													<xsl:value-of select="@statusCode" />
												</AT703>
												<AT704>NA</AT704>
											</xsl:if>
											<xsl:if test="@statusdatetime != ''">
												<AT705>
													<xsl:value-of select="concat(substring(@statusdatetime, 1, 4), substring(@statusdatetime, 6, 2), substring(@statusdatetime, 9, 2))" />
												</AT705>
											</xsl:if>
											<xsl:if test="@statusdatetime != ''">
												<AT706>
													<xsl:value-of select="concat(substring(@statusdatetime, 12, 2), substring(@statusdatetime, 15, 2))" />
												</AT706>
											</xsl:if>
											<xsl:if test="@statusTimeZone != ''">
												<AT707>
													<xsl:value-of select="@statusTimeZone" />
												</AT707>
											</xsl:if>
										</ns0:AT7>
										<xsl:if test="(EquipmentLocation/@cityName != '') or (EquipmentLocation/@stateOrProvince != '') ">
											<ns0:MS1>
												<xsl:if test="EquipmentLocation/@cityName != ''">
													<MS101>
														<xsl:call-template name="CleanAlphaField" >
															<xsl:with-param name="inputText" select="EquipmentLocation/@cityName" />
															<xsl:with-param name="maxLength" select="30" />
														</xsl:call-template>
													</MS101>
												</xsl:if>
												<xsl:if test="EquipmentLocation/@stateOrProvince != ''">
													<MS102>
														<xsl:call-template name="StateCodetranslationMapValue">
															<xsl:with-param name="ValueToConvert" select="EquipmentLocation/@stateOrProvince" />
														</xsl:call-template>
													</MS102>
												</xsl:if>
												<xsl:if test="EquipmentLocation/@longitudeCode != ''">
													<MS104>
														<xsl:call-template name="FormatDecimalDegreesLongitude">
															<xsl:with-param name="longitudecode" select="EquipmentLocation/@longitudeCode"/>
														</xsl:call-template>
													</MS104>
												</xsl:if>
												<xsl:if test="EquipmentLocation/@latitudeCode != ''">
													<MS105>
														<xsl:call-template name="FormatDecimalDegreesLatitude">
															<xsl:with-param name="latitudecode" select="EquipmentLocation/@latitudeCode"/>
														</xsl:call-template>
													</MS105>
												</xsl:if>
												<xsl:if test="EquipmentLocation/@longitudeCode != ''">
													<MS106>
														<xsl:choose>
															<xsl:when test="contains(EquipmentLocation/@longitudeCode,'-')">W</xsl:when>
															<xsl:otherwise>E</xsl:otherwise>
														</xsl:choose>
													</MS106>
												</xsl:if>
												<xsl:if test="EquipmentLocation/@latitudeCode != ''">
													<MS107>
														<xsl:choose>
															<xsl:when test="contains(EquipmentLocation/@latitudeCode,'-')">S</xsl:when>
															<xsl:otherwise>N</xsl:otherwise>
														</xsl:choose>
													</MS107>
												</xsl:if>
											</ns0:MS1>
										</xsl:if>
										<xsl:if test="(EquipmentLocation/@equipmentDescriptionCode != '') or (EquipmentLocation/@equipmentNumber != '')">
											<ns0:MS2>
												<xsl:if test="EquipmentLocation/@equipmentScac != ''">
													<MS201>
														<xsl:value-of select="EquipmentLocation/@equipmentScac" />
													</MS201>
												</xsl:if>
												<xsl:if test="EquipmentLocation/@equipmentNumber != ''">
													<MS202>
														<xsl:call-template name="CleanAlphaField" >
															<xsl:with-param name="inputText" select="EquipmentLocation/@equipmentNumber" />
															<xsl:with-param name="maxLength" select="10" />
														</xsl:call-template>
													</MS202>
												</xsl:if>
												<xsl:if test="EquipmentLocation/@equipmentDescriptionCode != ''">
													<MS203>
														<xsl:value-of select="EquipmentLocation/@equipmentDescriptionCode" />
													</MS203>
												</xsl:if>
											</ns0:MS2>
										</xsl:if>
									</ns0:AT7Loop1>
								</xsl:for-each>
								<!--<xsl:for-each select="../../ReferenceData">
									<xsl:if test="(StopSequenceNumber/text()  != '') and (StopSequenceNumber/text()  > 0)">
										<ns0:L11_3>
											<L1101>
												<xsl:call-template name="CleanAlphaField" >
													<xsl:with-param name="inputText" select="StopSequenceNumber/text()" />
													<xsl:with-param name="maxLength" select="30" />
												</xsl:call-template>
											</L1101>
											<L1102>QN</L1102>
										</ns0:L11_3>
									</xsl:if>
								</xsl:for-each>

								<xsl:for-each select="Remarks">
									<xsl:for-each select="Remark">
										<ns0:K1_2>
											<xsl:if test="@remarkMessage2 != ''">
												<K101>
													<xsl:value-of select="@remarkMessage2" />
												</K101>
											</xsl:if>
											<K102>Notes</K102>
										</ns0:K1_2>
									</xsl:for-each>
								</xsl:for-each>-->
								<xsl:for-each select="../../ShipmentTotals">
									<ns0:AT8>
										<xsl:if test="ShipmentTotal/@totalTypeQualifier != ''">
											<AT801>
												<xsl:value-of select="ShipmentTotal/@totalTypeQualifier" />
											</AT801>
										</xsl:if>
										<xsl:if test="ShipmentTotal/@totalUnitOfMeasure != ''">
											<AT802>
												<xsl:value-of select="ShipmentTotal/@totalUnitOfMeasure" />
											</AT802>
										</xsl:if>
										<xsl:if test="TotalWeight != ''">
											<AT803>
												<xsl:value-of select="format-number(TotalWeight/text(), '#.00')" />
											</AT803>
										</xsl:if>
										<xsl:if test="TotalHandlingQty > 0">
											<AT804>
												<xsl:value-of select="TotalHandlingQty/text()" />
											</AT804>
										</xsl:if>
									</ns0:AT8>
								</xsl:for-each>
							</ns0:LXLoop1>
						</xsl:for-each>
					</xsl:for-each>
				</xsl:for-each>
			</xsl:for-each>
			<SE>
				<SE01>214</SE01>
				<SE02>12345</SE02>
			</SE>
		</ns0:X12_00401_214>
	</xsl:template>

	<!--Custom Templates-->
	<!--Value mapping template-->
	<xsl:template name="StopTypeMapValue">
		<xsl:param name="ValueToConvert" select="0" />
		<xsl:variable name="StopTypeMap" >
			<map>
				<entry key="Pick">SH</entry>
				<entry key="Drop">CN</entry>
			</map>
		</xsl:variable>
		<xsl:value-of select="msxsl:node-set($StopTypeMap)/map/entry[@key=$ValueToConvert]"/>
	</xsl:template>
	<!--Value mapping template-->
	<!--Set default if empty template start-->
	<xsl:template name="SetDefaultIfEmpty">
		<xsl:param name="pNode"/>
		<xsl:param name="pDefaultValue"/>
		<xsl:if test="$pNode">
			<xsl:value-of select="$pNode" />
		</xsl:if>
		<xsl:if test="not($pNode)">
			<xsl:value-of select="$pDefaultValue"/>
		</xsl:if>
	</xsl:template>
	<!--Set default if empty template end-->




	<!-- CleanAlphaField start  -->
	<xsl:template name="CleanAlphaField">
		<xsl:param name="inputText" />
		<xsl:param name="maxLength" />
		<xsl:variable name="singleQuote" select='"&apos;"' />
		<xsl:variable name="doubleQuote" select="'&quot;'" />
		<xsl:variable name="vAllowedSymbolsPart1" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}\?/#'"/>
		<xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
		<xsl:variable name="vCleanedText" select="translate($inputText,translate($inputText, $vAllowedSymbols, ''),'')"/>
		<xsl:variable name="vTrimmedCleanValue" select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
		<xsl:value-of select="normalize-space($vTrimmedCleanValue)"/>
	</xsl:template>
	<!-- Clean AlphaField end -->


	<!--FormatDecimalDegreesLatitude  Pad with Leading Zero if less than 7 Characters-->
	<xsl:template name="FormatDecimalDegreesLatitude">
		<xsl:param name="latitudecode"/>
		<xsl:variable name="DDlatitudecode" select="translate(translate($latitudecode, '-', ''), '+', '')"/>
		<xsl:choose>
			<xsl:when test="string-length($DDlatitudecode) &gt; 7">
				<xsl:value-of select="substring($DDlatitudecode, 1, 7)" />
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="substring(concat('0000000', $DDlatitudecode), string-length(concat('0000000', $DDlatitudecode)) - 6)" />
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<!--convertDecimalDegreesLatitude End-->

	<!-- FormatDecimalDegreesLongitude Pad with Leading Zero if less than 7 Characters-->
	<xsl:template name="FormatDecimalDegreesLongitude">
		<xsl:param name="longitudecode"/>
		<xsl:variable name="DDlongitudecode" select="translate(translate($longitudecode, '-', ''), '+', '')"/>
		<xsl:choose>
			<xsl:when test="string-length($DDlongitudecode) &gt; 7">
				<xsl:value-of select="substring($DDlongitudecode, 1, 7)" />
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="substring(concat('0000000', $DDlongitudecode), string-length(concat('0000000', $DDlongitudecode)) - 6)" />
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<!-- convertDecimalDegreesLongitude End  -->


	<!-- convertDecimalDegreesLatitudeToDMS start  Degrees (3 positions), Minutes (2 positions), and seconds (2 positions) Pad with Leading Zero if less than 7 Characters-->
	<xsl:template name="convertDecimalDegreesLatitudeToDMS">
		<xsl:param name="latitudecode"/>
		<xsl:variable name="abslatitudecode" select="translate(translate($latitudecode, '-', ''), '+', '')"/>
		<xsl:variable name="degrees" select="floor($abslatitudecode)"/>
		<xsl:variable name="Rawminutes" select="(60 * ($abslatitudecode - floor($abslatitudecode)))"/>
		<xsl:variable name="minutes" select="format-number(floor(60 * ($abslatitudecode - floor($abslatitudecode))), '00')"/>
		<xsl:variable name="seconds" select="format-number(floor(60 * ($Rawminutes - floor($Rawminutes))), '00')"/>
		<xsl:variable name="DMSlongitudecode" select="concat($degrees,$minutes,$seconds)"/>
		<xsl:value-of select="format-number($DMSlongitudecode, '0000000')"/>
	</xsl:template>
	<!-- convertDecimalDegreesLatitudeToDMS End  -->


	<!-- convertDecimalDegreesLongitudeDMS start  Degrees (3 positions), Minutes (2 positions), and seconds (2 positions) Pad with Leading Zero if less than 7 Characters-->
	<xsl:template name="convertDecimalDegreesLongitudeDMS">
		<xsl:param name="longitudecode"/>
		<xsl:variable name="abslongitudecode" select="translate(translate($longitudecode, '-', ''), '+', '')"/>
		<xsl:variable name="degrees" select="floor($abslongitudecode)"/>
		<xsl:variable name="Rawminutes" select="(60 * ($abslongitudecode - floor($abslongitudecode)))"/>
		<xsl:variable name="minutes" select="format-number(floor(60 * ($abslongitudecode - floor($abslongitudecode))), '00')"/>
		<xsl:variable name="seconds" select="format-number(floor(60 * ($Rawminutes - floor($Rawminutes))), '00')"/>
		<xsl:variable name="DMSlongitudecode" select="concat($degrees,$minutes,$seconds)"/>
		<xsl:value-of select="format-number($DMSlongitudecode, '0000000')"/>
	</xsl:template>
	<!-- convertDecimalDegreesLongitudeDMS End -->

	<xsl:template name="StateCodetranslationMapValue">
		<xsl:param name="ValueToConvert" select="0" />
		<xsl:variable name="StateCodetranslationMap" >
			<map>
				<entry key="AGS">AG</entry>
				<entry key="BCS">BS</entry>
				<entry key="CAM">CP</entry>
				<entry key="CHIH">CI</entry>
				<entry key="CHIS">CS</entry>
				<entry key="COAH">CH</entry>
				<entry key="COL">CL</entry>
				<entry key="DGO">DG</entry>
				<entry key="GRO">GE</entry>
				<entry key="GTO">GJ</entry>
				<entry key="HGO">HD</entry>
				<entry key="JAL">JA</entry>
				<entry key="MEX">MX</entry>
				<entry key="MICH">MC</entry>
				<entry key="MOR">MR</entry>
				<entry key="NAY">NA</entry>
				<entry key="OAX">OA</entry>
				<entry key="PUE">PU</entry>
				<entry key="QRO">QE</entry>
				<entry key="QROO">QI</entry>
				<entry key="SIN">SI</entry>
				<entry key="SLP">SL</entry>
				<entry key="SON">SO</entry>
				<entry key="TAB">TB</entry>
				<entry key="TAM">TA</entry>
				<entry key="TLAX">TL</entry>
				<entry key="VER">VC</entry>
				<entry key="YUC">YU</entry>
				<entry key="ZAC">ZA</entry>
			</map>
		</xsl:variable>
		<xsl:variable name="ValueConverted" select="msxsl:node-set($StateCodetranslationMap)/map/entry[@key=$ValueToConvert]"/>
		<xsl:choose>
			<xsl:when test="$ValueConverted">
				<xsl:value-of select="$ValueConverted"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="$ValueToConvert"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>

