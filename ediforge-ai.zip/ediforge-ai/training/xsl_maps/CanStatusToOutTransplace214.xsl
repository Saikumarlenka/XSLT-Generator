<?xml version="1.0" encoding="UTF-16"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
                xmlns:msxsl="urn:schemas-microsoft-com:xslt" 
                xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" 
                exclude-result-prefixes="msxsl var s0 userCSharp" version="1.0" 
                xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00401.EDI214/v1.0" 
                xmlns:s0="http://Echo.BSSR.Internal.Canonical.Status/v1.0" 
                xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp">
	<xsl:output omit-xml-declaration="yes" method="xml" version="1.0" />
	<xsl:template match="/">
		<xsl:apply-templates select="/s0:Status" />
	</xsl:template>
	<xsl:template match="/s0:Status">
    <xsl:variable name="vX6LoadActivityNotes" select="StatusList/ShipmentStatus/Remarks/Remark[@remarkMessage1='X6']/@remarkMessage2" />
		<ns0:X12_00401_214>
			<ST>
				<ST01>214</ST01>
				<ST02>
					<!-- <xsl:value-of select="//Status/StatusList/@transactionControlNumber" /> -->
					<xsl:value-of select="12345" />
				</ST02>
			</ST>
			<xsl:variable name="account" select="//StatusList/ShipmentStatus/BusinessReferences/BusinessReference[@referenceType = '11']/@referenceId"/>
			<xsl:variable name="ENum" select="/s0:Status/@CustomerId"/>
			<xsl:for-each select="StatusList">
				<xsl:for-each select="ShipmentStatus">
					<xsl:for-each select="ReferenceData">
						<ns0:B10>
							<xsl:if test="LoadId/text() != ''">
								<B1001>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="LoadId/text()" />
										<xsl:with-param name="maxLength" select="30" />
									</xsl:call-template>
								</B1001>
							</xsl:if>
							<xsl:if test="Bol/text()  != ''">
								<B1002>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="Bol/text()" />
										<xsl:with-param name="maxLength" select="30" />
									</xsl:call-template>
								</B1002>
							</xsl:if>
							<xsl:if test="Scac/text() != ''">
								<B1003>
									<xsl:choose>
										<xsl:when test="$ENum = '198805'">ECHS</xsl:when>
										<xsl:when test="$ENum = '198804'">ECH4</xsl:when>
										<xsl:when test="$ENum = '89330'">ECL3</xsl:when>
										<xsl:when test="$ENum = '200486'">ECH7</xsl:when>
										<xsl:when test="$ENum = '80414'">EGBF</xsl:when>
										<xsl:otherwise>ECHS</xsl:otherwise>
									</xsl:choose>
								</B1003>
							</xsl:if>
						</ns0:B10>
					</xsl:for-each>
				</xsl:for-each>
			</xsl:for-each>
			<!--
      <xsl:for-each select="StatusList">
        <xsl:for-each select="ShipmentStatus">
          <xsl:for-each select="BusinessReferences">
            <xsl:for-each select="BusinessReference">
            <xsl:if test="(@referenceId != '') and (@referenceType  != '')">
            <ns0:L11>
              <xsl:if test="@referenceId != ''">
                <L1101>
                  <xsl:call-template name="CleanAlphaField" >
                    <xsl:with-param name="inputText" select="@referenceId" />
                    <xsl:with-param name="maxLength" select="30" />
                  </xsl:call-template>
                </L1101>
              </xsl:if>
              <xsl:if test="@referenceType  != ''">
                <L1102>
                  <xsl:call-template name="CleanAlphaField" >
                    <xsl:with-param name="inputText" select="@referenceType" />
                    <xsl:with-param name="maxLength" select="3" />
                  </xsl:call-template>
                </L1102>
              </xsl:if>
            </ns0:L11>
            </xsl:if>
            </xsl:for-each>
          </xsl:for-each>
        </xsl:for-each>
      </xsl:for-each>
-->
			<xsl:for-each select="StatusList">
				<xsl:for-each select="ShipmentStatus">
					<xsl:for-each select="Statuses">
						<xsl:for-each select="Status[Details/Detail/@statusCode !='']">
							<ns0:LXLoop1>
								<ns0:LX>
									<xsl:if test="@assignedNumber != ''">
										<LX01>
											<xsl:value-of select="@assignedNumber" />
										</LX01>
									</xsl:if>
								</ns0:LX>
								<xsl:for-each select="Details/Detail">
									<ns0:AT7Loop1>
										<ns0:AT7>
                      <xsl:if test="(@statusCode != 'AA' and  @statusCode != 'AB' )">
											<!--<xsl:if test="(@statusCode = 'X3' or @statusCode = 'AF' or @statusCode = 'CP' or @statusCode = 'X6' or @statusCode = 'X1' or @statusCode = 'D1' or @statusCode = 'CD' or @statusCode = 'X5')">-->
												<AT701>
													<xsl:choose>
														<!-- for exception status codes -->
														<xsl:when test ="$ENum = '85818' or $ENum = '98115' or $ENum = '157401'  or $ENum = '105067' or $ENum = '193090' or $ENum = '184398' or $ENum = '89330' or $ENum = '16675' or $ENum = '135232' or $ENum = '128008' or $ENum = '162070' or $ENum = '198905' or $ENum = '168658' or $ENum = '5489' or $ENum = '201739'">
															<!--Body Armor, True Value, GenuineParts, Wahl Clipper, Alphia, LowTemp, CreativeFoam, Bagcraft, Burrows, Pixelle, Loreal, Campbells Meals-->
															<xsl:choose>
																<xsl:when test="@statusCode = 'AF'">CP</xsl:when>
																<xsl:when test="@statusCode = 'D1'">CD</xsl:when>
																<xsl:otherwise>
																	<xsl:value-of select="@statusCode" />
																</xsl:otherwise>
															</xsl:choose>
														</xsl:when>
														<xsl:when test ="$ENum = '144742' or $ENum = '153638' or $ENum = '93539'  or $ENum = '191922' or $ENum = '141626' or $ENum = '197986' or $ENum = '151974' or $ENum = '14266' or $ENum = '198805' or $ENum = '198804' or $ENum =  '153063' or $ENum =  '177388' or $ENum =  '200486' or $ENum =  '80414' or $ENum =  '198530' or $ENum =  '20852' or $ENum =  '149013' or $ENum =  '146745'">
															<!--Think Thin, Mars, Walmart, HilexPoly, WhiteRiver, Campbells, Rockline, UnileverTL, UnileverLTL, Novolex, Saputo, UnileverECH7, BerlinEGBF, Evonik Foams, Eco Products-->
															<xsl:choose>
																<xsl:when test="@statusCode = 'AF'">CP</xsl:when>
																<xsl:otherwise>
																	<xsl:value-of select="@statusCode" />
																</xsl:otherwise>
															</xsl:choose>
														</xsl:when>
														<xsl:when test ="$ENum = '159665' or $ENum = '156930' or $ENum = '176290' or $ENum = '137794' or $ENum = '146607' or $ENum = '85200'  or $ENum = '85350' or $ENum = '183420' or $ENum = '158388' or $ENum = '6791' or $ENum = '79048' or $ENum = '201538' or $ENum = '106031' or $ENum = '163742' or $ENum = '6796'">
															<!--Tosca, Target, Target again, Edgewell/Energizer, Bluestar, JwAluminum, Canam, First Brands, Slumberland, General Packaging, Nippon-->
															<xsl:choose>
																<xsl:when test="@statusCode = 'D1'">CD</xsl:when>
																<xsl:otherwise>
																	<xsl:value-of select="@statusCode" />
																</xsl:otherwise>
															</xsl:choose>
														</xsl:when>
														<xsl:otherwise>
															<!--all others -->
															<xsl:value-of select="@statusCode" />
														</xsl:otherwise>
													</xsl:choose>
												</AT701>
												<!-- Adding Reason Codes -->
												<AT702>
													<xsl:variable name="reasonCode" select="//BusinessReferences/BusinessReference[@referenceType = 'RL']/@referenceId"/>
													<xsl:choose>
														<xsl:when test="//BusinessReferences/BusinessReference[@referenceType = 'RC']">
															<!-- Commented by Syed 10/17/2024 Take first 2 charactersfor reason code regardless there are 2 or more characters.
																<xsl:choose>
																<xsl:when test="$ENum = '195615'">
																	<xsl:value-of select="substring(//BusinessReferences/BusinessReference[@referenceType = 'RC']/@referenceId, 1,2)" />
																</xsl:when>
																<xsl:otherwise>
																	<xsl:value-of select="//BusinessReferences/BusinessReference[@referenceType = 'RC']/@referenceId" />
																</xsl:otherwise>
															</xsl:choose>-->
															<xsl:value-of select="substring(//BusinessReferences/BusinessReference[@referenceType = 'RC']/@referenceId, 1,2)" />
														</xsl:when>
														<xsl:when test="//BusinessReferences/BusinessReference/@referenceType = 'RL'">
															<xsl:value-of select="substring($reasonCode, 1,2)" />
														</xsl:when>
														<xsl:otherwise>NS</xsl:otherwise>
													</xsl:choose>
												</AT702>
											</xsl:if>
											<xsl:if test="(@statusCode = 'AA' or @statusCode = 'AB')">
												<xsl:choose>
													<xsl:when test="($ENum = '194796' and @statusCode = 'AB') or ($ENum = '6796' and @statusCode = 'AB') or ($ENum = '6796' and @statusCode = 'AA')">
														<AT701>AG</AT701>
														<AT702>
															<xsl:variable name="reasonCode" select="//BusinessReferences/BusinessReference[@referenceType = 'RL']/@referenceId"/>
															<xsl:choose>
																<xsl:when test="//BusinessReferences/BusinessReference[@referenceType = 'RC']">
																	<!-- Commented by Syed 10/17/2024 Take first 2 charactersfor reason code regardless there are 2 or more characters.
																		<xsl:value-of select="//BusinessReferences/BusinessReference[@referenceType = 'RC']/@referenceId" />
																	-->
																	<xsl:value-of select="substring(//BusinessReferences/BusinessReference[@referenceType = 'RC']/@referenceId, 1,2)" />
																</xsl:when>
																<xsl:when test="//BusinessReferences/BusinessReference/@referenceType = 'RL'">
																	<xsl:value-of select="substring($reasonCode, 1,2)" />
																</xsl:when>
																<xsl:otherwise>NS</xsl:otherwise>
															</xsl:choose>
														</AT702>
													</xsl:when>
													<xsl:otherwise>
														<AT703>
															<xsl:value-of select="@statusCode"/>
														</AT703>
														<AT704>
															<xsl:choose>
																<xsl:when test="//BusinessReferences/BusinessReference[@referenceType = 'RL'] and ($ENum = '153638' or $ENum = '141626')">
																	<xsl:value-of select="substring(//BusinessReferences/BusinessReference[@referenceType = 'RL']/@referenceId, 1,2)" />
																</xsl:when>
																<xsl:when test="//BusinessReferences/BusinessReference[@referenceType = 'RC']">
																	<xsl:value-of select="substring(//BusinessReferences/BusinessReference[@referenceType = 'RC']/@referenceId, 1,2)" />
																	<!-- commented by Syed 9/4/2024 
																	<xsl:choose>
																		<xsl:when test="$ENum = '195615' ">
																			<xsl:value-of select="substring(//BusinessReferences/BusinessReference[@referenceType = 'RC']/@referenceId, 1,2)" />
																		</xsl:when>
																		<xsl:otherwise>
																			<xsl:value-of select="//BusinessReferences/BusinessReference[@referenceType = 'RC']/@referenceId" />
																		</xsl:otherwise>
																	</xsl:choose>-->
																</xsl:when>
																<xsl:otherwise>NA</xsl:otherwise>
															</xsl:choose>
														</AT704>
													</xsl:otherwise>
												</xsl:choose>

											</xsl:if>
											<xsl:if test="@statusdatetime != ''">
												<AT705>
													<xsl:value-of select="concat(substring(@statusdatetime, 1, 4), substring(@statusdatetime, 6, 2), substring(@statusdatetime, 9, 2))" />
												</AT705>
											</xsl:if>
											<xsl:if test="@statusdatetime != ''">
												<AT706>
													<xsl:value-of select="concat(substring(@statusdatetime, 12, 2), substring(@statusdatetime, 15, 2))" />
												</AT706>
											</xsl:if>
											<AT707>LT</AT707>
										</ns0:AT7>
                    <xsl:choose>
                      <xsl:when test="(EquipmentLocation/@longitudeCode != '') and (EquipmentLocation/@latitudeCode != '') ">
                        <ns0:MS1>
                          <!--<xsl:if test="EquipmentLocation/@cityName != ''">
                            <MS101>
                              <xsl:call-template name="CleanAlphaField" >
                                <xsl:with-param name="inputText" select="EquipmentLocation/@cityName" />
                                <xsl:with-param name="maxLength" select="30" />
                              </xsl:call-template>
                            </MS101>
                          </xsl:if>
                          <xsl:if test="EquipmentLocation/@stateOrProvince != ''">
                            <MS102>
                              <xsl:call-template name="StateCodetranslationMapValue">
                                <xsl:with-param name="ValueToConvert" select="EquipmentLocation/@stateOrProvince" />
                              </xsl:call-template>
                            </MS102>
                          </xsl:if>-->
                          <xsl:if test="EquipmentLocation/@longitudeCode != ''">
                            <MS104>
                              <xsl:call-template name="FormatDecimalDegreesLongitude">
                                <xsl:with-param name="longitudecode" select="EquipmentLocation/@longitudeCode"/>
                              </xsl:call-template>
                            </MS104>
                          </xsl:if>
                          <xsl:if test="EquipmentLocation/@latitudeCode != ''">
                            <MS105>
                              <xsl:call-template name="FormatDecimalDegreesLatitude">
                                <xsl:with-param name="latitudecode" select="EquipmentLocation/@latitudeCode"/>
                              </xsl:call-template>
                            </MS105>
                          </xsl:if>
                          <xsl:if test="EquipmentLocation/@longitudeCode != ''">
                            <MS106>
                              <xsl:choose>
                                <xsl:when test="contains(EquipmentLocation/@longitudeCode,'-')">W</xsl:when>
                                <xsl:otherwise>E</xsl:otherwise>
                              </xsl:choose>
                            </MS106>
                          </xsl:if>
                          <xsl:if test="EquipmentLocation/@latitudeCode != ''">
                            <MS107>
                              <xsl:choose>
                                <xsl:when test="contains(EquipmentLocation/@latitudeCode,'-')">S</xsl:when>
                                <xsl:otherwise>N</xsl:otherwise>
                              </xsl:choose>
                            </MS107>
                          </xsl:if>
                        </ns0:MS1>
                      </xsl:when>
                      <xsl:when test=" contains($vX6LoadActivityNotes, 'Longitude') and contains($vX6LoadActivityNotes, 'Latitude')">
                        <xsl:variable name="vlongitudecode">
                          <xsl:call-template name="FormatDecimalDegreesLongitude">
                            
                            <xsl:with-param name="longitudecode" select="userCSharp:GetLongitude($vX6LoadActivityNotes)" />
                          </xsl:call-template>
                        </xsl:variable>
                        <xsl:variable name="vlatitudecode">
                          <xsl:call-template name="FormatDecimalDegreesLatitude">
                            <xsl:with-param name="latitudecode" select="userCSharp:GetLatitude($vX6LoadActivityNotes)" />
                          </xsl:call-template>
                        </xsl:variable>
                        <ns0:MS1>
                          <!--<xsl:if test="EquipmentLocation/@cityName != ''">
                            <MS101>
                              <xsl:call-template name="CleanAlphaField" >
                                <xsl:with-param name="inputText" select="EquipmentLocation/@cityName" />
                                <xsl:with-param name="maxLength" select="30" />
                              </xsl:call-template>
                            </MS101>
                          </xsl:if>
                          <xsl:if test="EquipmentLocation/@stateOrProvince != ''">
                            <MS102>
                              <xsl:call-template name="StateCodetranslationMapValue">
                                <xsl:with-param name="ValueToConvert" select="EquipmentLocation/@stateOrProvince" />
                              </xsl:call-template>
                            </MS102>
                          </xsl:if>-->
                          <xsl:if test="$vlongitudecode!=''">
                            <MS104>
                              <xsl:value-of select="$vlongitudecode" />
                            </MS104>
                          </xsl:if>
                          <xsl:if test="$vlatitudecode!=''">
                            <MS105>
                              <xsl:value-of select="$vlatitudecode" />
                            </MS105>
                          </xsl:if>
                          <xsl:if test="$vlongitudecode != ''">
                            <MS106>
                              <xsl:choose>
                                <xsl:when test="contains($vlongitudecode,'-')">W</xsl:when>
                                <xsl:otherwise>E</xsl:otherwise>
                              </xsl:choose>
                            </MS106>
                          </xsl:if>
                          <xsl:if test="$vlatitudecode != ''">
                            <MS107>
                              <xsl:choose>
                                <xsl:when test="contains($vlatitudecode,'-')">S</xsl:when>
                                <xsl:otherwise>N</xsl:otherwise>
                              </xsl:choose>
                            </MS107>
                          </xsl:if>
                        </ns0:MS1>
                      </xsl:when>
                      <xsl:otherwise>
                        <xsl:if test="(EquipmentLocation/@cityName != '') or (EquipmentLocation/@stateOrProvince != '') ">
                          <ns0:MS1>

                            <xsl:if test="EquipmentLocation/@cityName != ''">
                              <MS101>
                                <xsl:call-template name="CleanAlphaField" >
                                  <xsl:with-param name="inputText" select="EquipmentLocation/@cityName" />
                                  <xsl:with-param name="maxLength" select="30" />
                                </xsl:call-template>
                              </MS101>
                            </xsl:if>
                            <xsl:if test="EquipmentLocation/@stateOrProvince != ''">
                              <MS102>
                                <xsl:call-template name="StateCodetranslationMapValue">
                                  <xsl:with-param name="ValueToConvert" select="EquipmentLocation/@stateOrProvince" />
                                </xsl:call-template>
                              </MS102>
                            </xsl:if>
                          </ns0:MS1>
                        </xsl:if>
                      </xsl:otherwise>
                    </xsl:choose>

                    <!--<xsl:if test="(EquipmentLocation/@cityName != '') or (EquipmentLocation/@stateOrProvince != '') ">
											<ns0:MS1>
												<xsl:if test="EquipmentLocation/@cityName != ''">
													<MS101>
														<xsl:call-template name="CleanAlphaField" >
															<xsl:with-param name="inputText" select="EquipmentLocation/@cityName" />
															<xsl:with-param name="maxLength" select="30" />
														</xsl:call-template>
													</MS101>
												</xsl:if>
												<xsl:if test="EquipmentLocation/@stateOrProvince != ''">
													<MS102>
														<xsl:value-of select="EquipmentLocation/@stateOrProvince" />
													</MS102>
												</xsl:if>
											</ns0:MS1>
										</xsl:if>-->

										<xsl:if test="EquipmentLocation/@equipmentNumber != '' and $ENum != '183443'">
											<ns0:MS2>
												<xsl:if test="EquipmentLocation/@equipmentScac != ''">
													<MS201>
														<xsl:choose>
															<xsl:when test ="$ENum = '146115'">ECHS</xsl:when>
															<xsl:when test ="$ENum = '198804'">ECH4</xsl:when>
															<xsl:when test ="$ENum = '198805'">ECHS</xsl:when>
															<xsl:when test="$ENum = '89330'">ECL3</xsl:when>
															<xsl:when test ="$ENum = '200486'">ECH7</xsl:when>
															<xsl:when test="$ENum = '80414'">EGBF</xsl:when>
															<xsl:when test="$ENum = '219499'">ECHS</xsl:when>
															<xsl:otherwise>
																<xsl:value-of select="EquipmentLocation/@equipmentScac" />
															</xsl:otherwise>
														</xsl:choose>
													</MS201>
												</xsl:if>
												<xsl:if test="EquipmentLocation/@equipmentNumber != ''">
													<MS202>
														<xsl:call-template name="CleanAlphaField" >
															<xsl:with-param name="inputText" select="EquipmentLocation/@equipmentNumber" />
															<xsl:with-param name="maxLength" select="10" />
														</xsl:call-template>
													</MS202>
												</xsl:if>
												<xsl:if test="EquipmentLocation/@equipmentDescriptionCode != ''">
													<MS203>
														<xsl:value-of select="EquipmentLocation/@equipmentDescriptionCode" />
													</MS203>
												</xsl:if>
											</ns0:MS2>
										</xsl:if>
									</ns0:AT7Loop1>
								</xsl:for-each>

								<xsl:for-each select="../../ReferenceData">
									<xsl:choose>
										<!-- Highest Piority, if header stop sequence number is not empty and non 0, it will be mapped-->
										<xsl:when test="(StopSequenceNumber/text()  != '') and (StopSequenceNumber/text()  > 0)">
											<ns0:L11_3>
												<L1101>
													<xsl:call-template name="CleanAlphaField" >
														<xsl:with-param name="inputText" select="StopSequenceNumber/text()" />
														<xsl:with-param name="maxLength" select="30" />
													</xsl:call-template>
												</L1101>
												<L1102>QN</L1102>
											</ns0:L11_3>
										</xsl:when>
										<!--  Custom change: Checking if stop sequence number is empty and 0 (done above) and check if it the status is != X6 (as X6 is expected to have it 0 or empty)
						                     then apply this following template:
							 
												Pick: AA, AF, X3 and CP
												Drop: AB, X1, A3, D1 and CD

												Pass parameters to template: Equipment City Name and Equipment StateOrProvince.  The template will:

												For pick statuses:
												Confirm that canonical stop type is also Pick and Canonical //Address/City matches the equipment city and //Address/StateOrProvince matches the Equipment StateOrProvince.  If it matches, it selects the Status Assigned Number. If this is !=0 , then it will return this value.
												Else return 1.  

												For Drop statuses:
												Confirm that canonical stop type is also Drop and Canonical //Address/City matches the equipment city and //Address/StateOrProvince matches the Equipment StateOrProvince.  If it matches, it selects the Status Assigned Number. If this is !=0 , then it will return this value.
												Else return 2.   (Confirmed with Mark Anderson if that this should be 2)


												If the conditions for pick and drop are not satisfied (mismatched), it simply returns 1 (Confirmed with Mark Anderson if this is safe to return 1)
										-->
										<xsl:when test="(string-length(../Statuses/Status/Details/Detail[1]/@statusCode) !=0) and (../Statuses/Status/Details/Detail[1]/@statusCode != 'X6')">
											<ns0:L11_3>
												<L1101>
													<xsl:call-template name="StopSequenceTypeMapValue">
														<xsl:with-param name="StatusCodeToConvert" select="../Statuses/Status/Details/Detail[1]/@statusCode"/>
														<xsl:with-param name="vStatuscityName" select="../Statuses/Status[Details/Detail[@statusCode]]/Details/Detail[@statusCode]/EquipmentLocation/@cityName"/>
														<xsl:with-param name="vStatusstateOrProvince" select="../Statuses/Status[Details/Detail[@statusCode]]/Details/Detail[@statusCode]/EquipmentLocation/@stateOrProvince"/>
													</xsl:call-template>
												</L1101>
												<L1102>QN</L1102>
											</ns0:L11_3>
										</xsl:when>
										<xsl:otherwise>
											<!-- Note: X6 will still have the entire L11 - L1101/L1102 as empty-->
										</xsl:otherwise>
									</xsl:choose>

									<!-- Shipbob wants the OID02 from the Pick and the Drop to be populated on the correspondig stop in the 214 -->
									<xsl:if test="StopSequenceNumber/text() = 1 and $ENum = '157541'">
										<xsl:if test="//BusinessReferences/BusinessReference[@referenceType = 'PN'][@referenceId != '']/@referenceId">
											<ns0:L11_3>
												<L1101>
													<xsl:call-template name="CleanAlphaField" >
														<xsl:with-param name="inputText" select="//BusinessReferences/BusinessReference[@referenceType = 'PN'][@referenceId != '']/@referenceId" />
														<xsl:with-param name="maxLength" select="30" />
													</xsl:call-template>
												</L1101>
												<L1102>AO</L1102>
											</ns0:L11_3>
										</xsl:if>
									</xsl:if>
									<xsl:if test="StopSequenceNumber/text() = 2 and $ENum = '157541'">
										<xsl:if test="//BusinessReferences/BusinessReference[@referenceType = 'DN'][@referenceId != '']/@referenceId">
											<ns0:L11_3>
												<L1101>
													<xsl:call-template name="CleanAlphaField" >
														<xsl:with-param name="inputText" select="//BusinessReferences/BusinessReference[@referenceType = 'DN'][@referenceId != '']/@referenceId" />
														<xsl:with-param name="maxLength" select="30" />
													</xsl:call-template>
												</L1101>
												<L1102>AO</L1102>
											</ns0:L11_3>
										</xsl:if>
									</xsl:if>

								</xsl:for-each>

								<!--<xsl:for-each select="Remarks">
									<xsl:for-each select="Remark">
										<ns0:K1_2>
											<xsl:if test="@remarkMessage2 != ''">
												<K101>
													<xsl:value-of select="@remarkMessage2" />
												</K101>
											</xsl:if>
											<K102>Notes</K102>
										</ns0:K1_2>
									</xsl:for-each>
								</xsl:for-each>-->
								<xsl:for-each select="../../ShipmentTotals">
									<ns0:AT8>
										<xsl:if test="ShipmentTotal/@totalTypeQualifier != ''">
											<AT801>
												<xsl:value-of select="ShipmentTotal/@totalTypeQualifier" />
											</AT801>
										</xsl:if>
										<xsl:if test="ShipmentTotal/@totalUnitOfMeasure != ''">
											<AT802>
												<xsl:value-of select="ShipmentTotal/@totalUnitOfMeasure" />
											</AT802>
										</xsl:if>
										<xsl:if test="TotalWeight != ''">
											<AT803>
												<xsl:value-of select="format-number(TotalWeight/text(), '#.00')" />
											</AT803>
										</xsl:if>
										<xsl:if test="TotalHandlingQty > 0">
											<AT804>
												<xsl:value-of select="TotalHandlingQty/text()" />
											</AT804>
										</xsl:if>
									</ns0:AT8>
								</xsl:for-each>
							</ns0:LXLoop1>
						</xsl:for-each>
					</xsl:for-each>
				</xsl:for-each>
			</xsl:for-each>
			<SE>
				<SE01>214</SE01>
				<SE02>
					<!-- <xsl:value-of select="//Status/StatusList/@transactionControlNumber" /> -->
					<xsl:value-of select="12345" />
				</SE02>
			</SE>
		</ns0:X12_00401_214>
	</xsl:template>

	<!--Custom Templates-->
	<!--Value mapping template-->
	<xsl:template name="StopTypeMapValue">
		<xsl:param name="ValueToConvert" select="0" />
		<xsl:variable name="StopTypeMap" >
			<map>
				<entry key="Pick">SF</entry>
				<entry key="Drop">ST</entry>
			</map>
		</xsl:variable>
		<xsl:value-of select="msxsl:node-set($StopTypeMap)/map/entry[@key=$ValueToConvert]"/>
	</xsl:template>
	<!--Value mapping template-->
	<!--Set default if empty template start-->
	<xsl:template name="SetDefaultIfEmpty">
		<xsl:param name="pNode"/>
		<xsl:param name="pDefaultValue"/>
		<xsl:if test="$pNode">
			<xsl:value-of select="$pNode" />
		</xsl:if>
		<xsl:if test="not($pNode)">
			<xsl:value-of select="$pDefaultValue"/>
		</xsl:if>
	</xsl:template>
	<!--Set default if empty template end-->

	<!-- CleanAlphaField start  -->
	<xsl:template name="CleanAlphaField">
		<xsl:param name="inputText" />
		<xsl:param name="maxLength" />
		<xsl:variable name="singleQuote" select='"&apos;"' />
		<xsl:variable name="doubleQuote" select="'&quot;'" />
		<xsl:variable name="vAllowedSymbolsPart1" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}\?/#'"/>
		<xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
		<xsl:variable name="vCleanedText" select="translate($inputText,translate($inputText, $vAllowedSymbols, ''),'')"/>
		<xsl:value-of select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
	</xsl:template>
	<!-- Clean AlphaField end -->

  <!--FormatDecimalDegreesLatitude  Pad with Leading Zero if less than 7 Characters-->
  <xsl:template name="FormatDecimalDegreesLatitude">
    <xsl:param name="latitudecode"/>
    <xsl:choose>
      <xsl:when test="string-length($latitudecode) &gt; 7">
        <xsl:value-of select="substring($latitudecode, 1, 7)" />
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="substring(concat('0000000', $latitudecode), string-length(concat('0000000', $latitudecode)) - 6)" />
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>
  <!-- FormatDecimalDegreesLongitude Pad with Leading Zero if less than 7 Characters-->
  <xsl:template name="FormatDecimalDegreesLongitude">
    <xsl:param name="longitudecode"/>
    <xsl:choose>
      <xsl:when test="string-length($longitudecode) &gt; 7">
        <xsl:value-of select="substring($longitudecode, 1, 7)" />
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="substring(concat('0000000', $longitudecode), string-length(concat('0000000', $longitudecode)) - 6)" />
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>


  <!-- convertDecimalDegreesLatitudeToDMS start  Degrees (3 positions), Minutes (2 positions), and seconds (2 positions) Pad with Leading Zero if less than 7 Characters-->
  <xsl:template name="convertDecimalDegreesLatitudeToDMS">
    <xsl:param name="latitudecode"/>
    <xsl:variable name="abslatitudecode" select="translate(translate($latitudecode, '-', ''), '+', '')"/>
    <xsl:variable name="degrees" select="floor($abslatitudecode)"/>
    <xsl:variable name="Rawminutes" select="(60 * ($abslatitudecode - floor($abslatitudecode)))"/>
    <xsl:variable name="minutes" select="format-number(floor(60 * ($abslatitudecode - floor($abslatitudecode))), '00')"/>
    <xsl:variable name="seconds" select="format-number(floor(60 * ($Rawminutes - floor($Rawminutes))), '00')"/>
    <xsl:variable name="DMSlongitudecode" select="concat($degrees,$minutes,$seconds)"/>
    <xsl:value-of select="format-number($DMSlongitudecode, '0000000')"/>
  </xsl:template>
  <!-- convertDecimalDegreesLatitudeToDMS End  -->


  <!-- convertDecimalDegreesLongitudeDMS start  Degrees (3 positions), Minutes (2 positions), and seconds (2 positions) Pad with Leading Zero if less than 7 Characters-->
  <xsl:template name="convertDecimalDegreesLongitudeDMS">
    <xsl:param name="longitudecode"/>
    <xsl:variable name="abslongitudecode" select="translate(translate($longitudecode, '-', ''), '+', '')"/>
    <xsl:variable name="degrees" select="floor($abslongitudecode)"/>
    <xsl:variable name="Rawminutes" select="(60 * ($abslongitudecode - floor($abslongitudecode)))"/>
    <xsl:variable name="minutes" select="format-number(floor(60 * ($abslongitudecode - floor($abslongitudecode))), '00')"/>
    <xsl:variable name="seconds" select="format-number(floor(60 * ($Rawminutes - floor($Rawminutes))), '00')"/>
    <xsl:variable name="DMSlongitudecode" select="concat($degrees,$minutes,$seconds)"/>
    <xsl:value-of select="format-number($DMSlongitudecode, '0000000')"/>
  </xsl:template>
  <!-- convertDecimalDegreesLongitudeDMS End -->

  <!-- CleanAlphaField end  -->
  <xsl:template name="StateCodetranslationMapValue">
    <xsl:param name="ValueToConvert" select="0" />
    <xsl:variable name="StateCodetranslationMap" >
      <map>
        <entry key="AGS">AG</entry>
        <entry key="BCS">BS</entry>
        <entry key="CAM">CP</entry>
        <entry key="CHIH">CI</entry>
        <entry key="CHIS">CS</entry>
        <entry key="COAH">CH</entry>
        <entry key="COL">CL</entry>
        <entry key="DGO">DG</entry>
        <entry key="GRO">GE</entry>
        <entry key="GTO">GJ</entry>
        <entry key="HGO">HD</entry>
        <entry key="JAL">JA</entry>
        <entry key="MEX">MX</entry>
        <entry key="MICH">MC</entry>
        <entry key="MOR">MR</entry>
        <entry key="NAY">NA</entry>
        <entry key="OAX">OA</entry>
        <entry key="PUE">PU</entry>
        <entry key="QRO">QE</entry>
        <entry key="QROO">QI</entry>
        <entry key="SIN">SI</entry>
        <entry key="SLP">SL</entry>
        <entry key="SON">SO</entry>
        <entry key="TAB">TB</entry>
        <entry key="TAM">TA</entry>
        <entry key="TLAX">TL</entry>
        <entry key="VER">VC</entry>
        <entry key="YUC">YU</entry>
        <entry key="ZAC">ZA</entry>
      </map>
    </xsl:variable>
    <xsl:variable name="ValueConverted" select="msxsl:node-set($StateCodetranslationMap)/map/entry[@key=$ValueToConvert]"/>
    <xsl:choose>
      <xsl:when test="$ValueConverted">
        <xsl:value-of select="$ValueConverted"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$ValueToConvert"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>
  
	<!--StopSequenceTypeMapValue template-->
	<xsl:template name="StopSequenceTypeMapValue">
		<xsl:param name="StatusCodeToConvert" />
		<xsl:param name="vStatuscityName" />
		<xsl:param name="vStatusstateOrProvince" />
		<xsl:variable name="StopSequenceTypeMap" >
			<map>
				<entry key="AA">Pick</entry>
				<entry key="AF">Pick</entry>
				<entry key="X3">Pick</entry>
				<entry key="CP">Pick</entry>
				<entry key="AB">Drop</entry>
				<entry key="X1">Drop</entry>
				<entry key="A3">Drop</entry>
				<entry key="D1">Drop</entry>
				<entry key="CD">Drop</entry>
			</map>
		</xsl:variable>
		<xsl:variable name="StatusCodeConverted" select="msxsl:node-set($StopSequenceTypeMap)/map/entry[@key=$StatusCodeToConvert]"/>
		<xsl:choose>
			<xsl:when test="$StatusCodeConverted='Pick'">
				<xsl:variable name="vPickStopSequenceNumber" select="../Statuses/Status/Details/Detail[@stopType='Pick' and Addresses/Address[@city=$vStatuscityName and @stateProvince=$vStatusstateOrProvince]]/../../@assignedNumber"/>
				<xsl:choose>
					<xsl:when test="(string-length($vPickStopSequenceNumber) != 0)  and ($vPickStopSequenceNumber > 0)">
						<xsl:value-of select="$vPickStopSequenceNumber"/>
					</xsl:when>
					<xsl:otherwise>1</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:when test="$StatusCodeConverted='Drop'">
				<xsl:variable name="vDropStopSequenceNumber" select="../Statuses/Status/Details/Detail[@stopType='Drop' and Addresses/Address[@city=$vStatuscityName and @stateProvince=$vStatusstateOrProvince]]/../../@assignedNumber"/>
				<xsl:choose>
					<xsl:when test="(string-length($vDropStopSequenceNumber) !=0 ) and ($vDropStopSequenceNumber > 0) ">
						<xsl:value-of select="$vDropStopSequenceNumber"/>
					</xsl:when>
					<xsl:otherwise>2</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:otherwise>1</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<!--StopSequenceTypeMapValue template-->
  <msxsl:script language="C#" implements-prefix="userCSharp">
    <![CDATA[public string StringUpperCase(string str)
{
	if (str == null)
	{
		return "";
	}
	return str.ToUpper(System.Globalization.CultureInfo.InvariantCulture);
}

public string StringConcat(string param0)
{
   return param0;
}




  public bool IsNullOrEmpty(string str)
      {
	        return System.String.IsNullOrEmpty(str);
      }
      
      
       public  string GetLongitude(string str)
        {

            string stringOut = "";
            string str1 = "Longitude";
            string str2 = ",";


            if (str.Contains(str1) && str.Contains(str2))
            {
                str = str.Replace(str1, "").Replace("[", "").Replace("]", "").Replace(":", "").Replace(" ", "");

                stringOut = str.Split(new[] { "," }, StringSplitOptions.None)[1];

            }
            return stringOut;
        }

      
        public  string GetLatitude(string str)
        {
   
            string stringOut = "";
            string str1 = "Latitude";
            string str2 = ",";


            if (str.Contains(str1) && str.Contains(str2))
            {
                   str = str.Replace(str1, "").Replace("[", "").Replace("]", "").Replace(":", "").Replace(" ", "");

                 stringOut = str.Split(new[] { "," }, StringSplitOptions.None)[0];

            }
            return stringOut;
        }
				public  string ReplaceSubstring(string input, string oldValue, string newValue)
				{
      
						if (!input.Contains(oldValue))
						{
       
								return input;
						}

						string result = input.Replace(oldValue, newValue);
						return result;
				}
  ]]>
  </msxsl:script>
</xsl:stylesheet>