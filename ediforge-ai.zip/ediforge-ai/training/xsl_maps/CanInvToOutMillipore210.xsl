<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" exclude-result-prefixes="msxsl var s0 userCSharp" version="1.0" xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00401.EDIOB210V2.0" xmlns:s0="http://Echo.BSSR.Internal.Canonical.InvoiceV2" xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp">
	<xsl:variable name="vLowercaseChars_CONST" select="'abcdefghijklmnopqrstuvwxyz'"/>
	<xsl:variable name="vUppercaseChars_CONST" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'"/>
	<xsl:output omit-xml-declaration="yes" method="xml" version="1.0"/>
	<xsl:template match="/">
		<xsl:apply-templates select="/s0:Invoice"/>
	</xsl:template>
	<xsl:template match="/s0:Invoice">
		<ns0:X12_00401_210>
			<ST>
				<ST01>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetIdentifierCode"/>
				</ST01>
				<ST02>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber"/>
				</ST02>
			</ST>

			<xsl:variable name="addrSH" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH'][1]/AddressInformation/@AddressInformationLine1"/>
			<xsl:variable name="citySH" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH'][1]/GeographicLocation/@CityName"/>
			<xsl:variable name="zipSH" select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH'][1]/GeographicLocation/@PostalCode"/>
			<xsl:variable name="addrCN" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN'][1]/AddressInformation/@AddressInformationLine1"/>
			<xsl:variable name="cityCN" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN'][1]/GeographicLocation/@CityName"/>
			<xsl:variable name="zipCN" select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN'][1]/GeographicLocation/@PostalCode"/>
			<xsl:variable name="isInbound" select="userCSharp:GetLocationCode($addrSH, $citySH)"/>
			<xsl:variable name="isOutbound" select="userCSharp:GetLocationCode($addrCN, $cityCN)"/>

			<ns0:B3>
				<!-- Segment not mapped by default
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@ShipmentQualifier != '' ">      
					<B301><xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentQualifier" /></B301>
				</xsl:if>
        -->
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber!=''">
					<B302>
						<xsl:call-template name="CleanAlphaField" >
							<xsl:with-param name="inputText" select="translate(Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber, '-', '')" />
							<xsl:with-param name="maxLength" select="30" />
						</xsl:call-template>
					</B302>
					<B303>
						<xsl:call-template name="CleanAlphaField" >
							<xsl:with-param name="inputText" select="Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber" />
							<xsl:with-param name="maxLength" select="30" />
						</xsl:call-template>
					</B303>
				</xsl:if>
				<B304>
					<xsl:choose>
						<xsl:when test="$isInbound != 'Not Found'">PP</xsl:when>
						<xsl:when test="$isOutbound != 'Not Found'">CC</xsl:when>
						<xsl:otherwise>
							<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentMethodOfPayment"/>
						</xsl:otherwise>
					</xsl:choose>
				</B304>
				<!-- Custom Change for Dexcom 
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@ShipmentMethodOfPayment != '' and 
				          (Header/BeginningSegmentForCarriersInvoice/@ShipmentMethodOfPayment = 'CC' or 
				            Header/BeginningSegmentForCarriersInvoice/@ShipmentMethodOfPayment = 'PP' or 
				            Header/BeginningSegmentForCarriersInvoice/@ShipmentMethodOfPayment = 'TP'
				            )">
					<B304>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentMethodOfPayment"/>
					</B304>
				</xsl:if>
				April 12, 2024 Change:  Specs updated to pull value from referenct PT
				-->


				<!-- Custom Change for Dexcom -->
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@WeightUnitCode != '' and
						        (Header/BeginningSegmentForCarriersInvoice/@WeightUnitCode = 'L' or 
						         Header/BeginningSegmentForCarriersInvoice/@WeightUnitCode = 'K')">
					<B305>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@WeightUnitCode"/>
					</B305>
				</xsl:if>
				<xsl:variable name="InvoiceDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='InvoiceDate']"/>
				<xsl:variable name="DeliveryDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='DeliveryDate']"/>
				<xsl:variable name="BillingDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='BillingDate']"/>
				<xsl:variable name="PickupDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='PickupDate']"/>
				<xsl:if test="$BillingDate != '' ">
					<B306>
						<xsl:value-of select="concat(substring($BillingDate, 1, 4), substring($BillingDate, 6, 2), substring($BillingDate, 9, 2))"/>
					</B306>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@NetAmountDue != '' ">
					<B307>
						<xsl:value-of select="translate(Header/BeginningSegmentForCarriersInvoice/@NetAmountDue,'.','')"/>
					</B307>
				</xsl:if>
				<!-- Segment not mapped by default
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@CorrectionIndicator != '' and 
						        (Header/BeginningSegmentForCarriersInvoice/@CorrectionIndicator = 'AD' or
						         Header/BeginningSegmentForCarriersInvoice/@CorrectionIndicator = 'BD')">
					<B308><xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@CorrectionIndicator" /></B308>
				</xsl:if>
				-->
				<xsl:if test="$DeliveryDate != '' ">
					<B309>
						<xsl:value-of select="concat(substring($DeliveryDate, 1, 4), substring($DeliveryDate, 6, 2), substring($DeliveryDate, 9, 2))"/>
					</B309>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@DateTimeQualifier != '' ">
					<B310>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@DateTimeQualifier"/>
					</B310>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@StandardCarrierAlphaCode != '' ">
					<B311>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@StandardCarrierAlphaCode"/>
					</B311>
				</xsl:if>
				<!--  Custom Change: Client requested they want Pickup date mapped in this field instead of Billing Date -->
				<!--<xsl:if test="$BillingDate != '' ">
					<B312>
						<xsl:value-of select="concat(substring($BillingDate, 1, 4), substring($BillingDate, 6, 2), substring($BillingDate, 9, 2))"/>
					</B312>
				</xsl:if>-->

				<xsl:if test="$PickupDate != '' ">
					<B312>
						<xsl:value-of select="concat(substring($PickupDate, 1, 4), substring($PickupDate, 6, 2), substring($PickupDate, 9, 2))"/>
					</B312>
				</xsl:if>
				<!--  Not mapped by default
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@TariffServiceCode != '' ">
					<B313>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@TariffServiceCode" />
					</B313>
				</xsl:if>
				<xsl:if test="Header/BeginningSegmentForCarriersInvoice/@TransportationTermsCode != '' ">
					<B314>
						<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@TransportationTermsCode" />
					</B314>
				</xsl:if>
        -->
			</ns0:B3>
			<!-- Not mapped by default
			  <ns0:C2>
				<C201>E</C201>
			  </ns0:C2>
			-->
			<!-- Custom Change for Dexcom -->
			<xsl:if test="Header/Currency/@BillingCurrencyCode != '' and 
			        (Header/Currency/@BillingCurrencyCode = 'USD' or
			         Header/Currency/@BillingCurrencyCode = 'CAD')">
				<ns0:C3>
					<C301>
						<xsl:value-of select="Header/Currency/@BillingCurrencyCode"/>
					</C301>
					<!--<xsl:if test="Header/Currency/@PaymentCurrencyCode != '' ">
						<C303>
							<xsl:value-of select="Header/Currency/@PaymentCurrencyCode"/>
						</C303>
					</xsl:if>-->

				</ns0:C3>
			</xsl:if>
			<xsl:for-each select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='ReferenceList']/*[local-name()='ReferenceInformation']">
				<xsl:if test="(@ReferenceInformationQualifier != '') or (@ReferenceInformation != '') ">
					<xsl:if test="(@EDICode ='CR' ) or (@EDICode ='PO') or (@EDICode='SO') or (@EDICode='Q1') or (@EDICode='BM')">
						<ns0:N9>
							<xsl:if test="@EDICode != '' ">
								<N901>
									<xsl:value-of select="@EDICode"/>
								</N901>
							</xsl:if>
							<xsl:if test="@ReferenceInformation != '' ">
								<N902>
									<xsl:call-template name="CleanAlphaField">
										<xsl:with-param name="inputText" select="@ReferenceInformation"/>
										<xsl:with-param name="maxLength" select="30"/>
									</xsl:call-template>
								</N902>
							</xsl:if>
						</ns0:N9>
					</xsl:if>
				</xsl:if>
			</xsl:for-each>
			<!-- processing the PO references - Commented out till TBA Responds
			<xsl:variable name="NumberOfPORef" select="count (/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='ReferenceList']/*[local-name()='ReferenceInformation'][@EDICode='PO'])"/>
			<xsl:for-each select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='ReferenceList']/*[local-name()='ReferenceInformation'][@EDICode='PO']">
				<xsl:if test="(@ReferenceInformationQualifier != '') or (@ReferenceInformation != '') ">
					<ns0:N9>
						<xsl:if test="@EDICode != '' ">
							<N901>
								<xsl:value-of select="@EDICode" />
							</N901>
						</xsl:if>
						<xsl:if test="@ReferenceInformation != '' ">
							<N902>
								<xsl:call-template name="CleanAlphaField" >
									<xsl:with-param name="inputText" select="@ReferenceInformation" />
									<xsl:with-param name="maxLength" select="30" />
								</xsl:call-template>
							</N902>
						</xsl:if>
						<xsl:if test="$NumberOfPORef > 1">
							<N907>
								<xsl:value-of select="position()"/>
							</N907>
						</xsl:if>
					</ns0:N9>
				</xsl:if>
			</xsl:for-each>
	-->

			<xsl:variable name="DeliveryDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='DeliveryDate']"/>
			<xsl:variable name="PickupDate" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@*[local-name()='PickupDate']"/>
			<!--Custom Change for Dexcom, Not required by client-->
			<ns0:G62>
				<G6201>86</G6201>
				<G6202>
					<xsl:value-of select="concat(substring($PickupDate, 1, 4), substring($PickupDate, 6, 2), substring($PickupDate, 9, 2))"/>
				</G6202>
			</ns0:G62>
			<ns0:G62>
				<G6201>35</G6201>
				<G6202>
					<xsl:value-of select="concat(substring($DeliveryDate, 1, 4), substring($DeliveryDate, 6, 2), substring($DeliveryDate, 9, 2))"/>
				</G6202>
			</ns0:G62>
			<ns0:R3>
				<R301>ECHS</R301>
				<R302>B</R302>
				<R304>J</R304>
				<!-- Custom Change for Dexcom 
				<R306>
					<xsl:value-of select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='BeginningSegmentForCarriersInvoice']/@InvoiceNumber"/>
				</R306>
				<R310>G2</R310>
				-->
			</ns0:R3>
			<!--  K1 Segment mapping
			<ns0:K1>
				<xsl:variable name="BMRefInfo" select="/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='ReferenceList']/*[local-name()='ReferenceInformation'][@EDICode='BM']" />
				<K101>
					<xsl:choose>
						<xsl:when test="$BMRefInfo &gt; ' ' ">
							<xsl:value-of select="$BMRefInfo" /> 
						</xsl:when>
						<xsl:otherwise>
							<xsl:value-of select="Header/BeginningSegmentForCarriersInvoice/@ShipmentIdentificationNumber" />
						</xsl:otherwise> 
					</xsl:choose> 
				</K101>
			</ns0:K1>
			-->

			<!--Template not used for a code below due to expected changes to mappings from one code to another-->
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='SH'][1]">
				<ns0:N1Loop1>
					<ns0:N1>
						<N101>
							<xsl:value-of select="Name/@EntityIdentifierCode" />
						</N101>
						<N102>
							<xsl:call-template name="CleanAlphaField" >
								<xsl:with-param name="inputText" select="Name/@Name" />
								<xsl:with-param name="maxLength" select="60" />
							</xsl:call-template>
						</N102>
						<xsl:if test="$isInbound !='Not Found'">
							<N103>93</N103>
							<N104>
								<xsl:value-of select="$isInbound"/>
							</N104>
						</xsl:if>
					</ns0:N1>
					<!-- 
					<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
					-->
					<xsl:if test="AddressInformation/@AddressInformationLine1 != '' ">
						<ns0:N3>
							<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
								<N301>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1" />
										<xsl:with-param name="maxLength" select="55" />
									</xsl:call-template>
								</N301>
							</xsl:if>
							<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
								<N302>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2" />
										<xsl:with-param name="maxLength" select="55" />
									</xsl:call-template>
								</N302>
							</xsl:if>
						</ns0:N3>
					</xsl:if>
					<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
						<ns0:N4>
							<xsl:if test="GeographicLocation/@CityName != ''">
								<N401>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="GeographicLocation/@CityName" />
										<xsl:with-param name="maxLength" select="55" />
									</xsl:call-template>
								</N401>
							</xsl:if>
							<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
								<N402>
									<xsl:value-of select="GeographicLocation/@StateOrProvinceCode" />
								</N402>
							</xsl:if>
							<xsl:if test="GeographicLocation/@PostalCode != ''">
								<N403>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode" />
										<xsl:with-param name="maxLength" select="55" />
									</xsl:call-template>
								</N403>
							</xsl:if>
							<xsl:if test="GeographicLocation/@CountryCode != ''">
								<N404>
									<xsl:value-of select="GeographicLocation/@CountryCode" />
								</N404>
							</xsl:if>
						</ns0:N4>
					</xsl:if>
				</ns0:N1Loop1>
			</xsl:for-each>

			<!--Template not used for a code below due to expected changes to mappings from one code to another-->
			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='CN'][1]">
				<ns0:N1Loop1>
					<ns0:N1>
						<N101>
							<xsl:value-of select="Name/@EntityIdentifierCode" />
						</N101>
						<N102>
							<xsl:call-template name="CleanAlphaField" >
								<xsl:with-param name="inputText" select="Name/@Name" />
								<xsl:with-param name="maxLength" select="60" />
							</xsl:call-template>
						</N102>
						<xsl:if test="$isOutbound !='Not Found'">
							<N103>93</N103>
							<N104>
								<xsl:value-of select="$isOutbound"/>
							</N104>
						</xsl:if>
					</ns0:N1>
					<!-- 
					<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
					-->
					<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
						<ns0:N3>
							<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
								<N301>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1" />
										<xsl:with-param name="maxLength" select="55" />
									</xsl:call-template>
								</N301>
							</xsl:if>
							<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
								<N302>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2" />
										<xsl:with-param name="maxLength" select="55" />
									</xsl:call-template>
								</N302>
							</xsl:if>
						</ns0:N3>
					</xsl:if>
					<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
						<ns0:N4>
							<xsl:if test="GeographicLocation/@CityName != ''">
								<N401>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="GeographicLocation/@CityName" />
										<xsl:with-param name="maxLength" select="55" />
									</xsl:call-template>
								</N401>
							</xsl:if>
							<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
								<N402>
									<xsl:value-of select="GeographicLocation/@StateOrProvinceCode" />
								</N402>
							</xsl:if>
							<xsl:if test="GeographicLocation/@PostalCode != ''">
								<N403>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode" />
										<xsl:with-param name="maxLength" select="55" />
									</xsl:call-template>
								</N403>
							</xsl:if>
							<xsl:if test="GeographicLocation/@CountryCode != ''">
								<N404>
									<xsl:value-of select="GeographicLocation/@CountryCode" />
								</N404>
							</xsl:if>
						</ns0:N4>
					</xsl:if>
				</ns0:N1Loop1>
			</xsl:for-each>

			<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode='BT']">
				<ns0:N1Loop1>
					<ns0:N1>
						<N101>
							<xsl:value-of select="Name/@EntityIdentifierCode" />
						</N101>
						<N102>
							<xsl:call-template name="CleanAlphaField" >
								<xsl:with-param name="inputText" select="Name/@Name" />
								<xsl:with-param name="maxLength" select="60" />
							</xsl:call-template>
						</N102>
						<!--<xsl:variable name="addrBT" select="AddressInformation/@AddressInformationLine1"/>
						<xsl:variable name="cityBT" select="GeographicLocation/@CityName"/>
						<xsl:variable name="zipBT" select="GeographicLocation/@PostalCode"/>-->

						<!--<xsl:variable name="vLookupN104BT" select="userCSharp:GetLocationCode($addrBT, $cityBT)"></xsl:variable>-->
						<!--<xsl:if test="$vLookupN104BT != 'Not Found'">
							<N103>25</N103>
							<N104>
								<xsl:value-of select="$vLookupN104BT"/>
							</N104>
						</xsl:if>-->
					</ns0:N1>
					<!-- 
					<xsl:if test="(AddressInformation/@AddressInformationLine1 != '') or (AddressInformation/@AddressInformationLine2 != '') ">
					-->
					<xsl:if test="AddressInformation/@AddressInformationLine1 != '' ">
						<ns0:N3>
							<xsl:if test="AddressInformation/@AddressInformationLine1 != ''">
								<N301>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1" />
										<xsl:with-param name="maxLength" select="55" />
									</xsl:call-template>
								</N301>
							</xsl:if>
							<xsl:if test="AddressInformation/@AddressInformationLine2 != ''">
								<N302>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2" />
										<xsl:with-param name="maxLength" select="55" />
									</xsl:call-template>
								</N302>
							</xsl:if>

						</ns0:N3>
					</xsl:if>
					<xsl:if test="(GeographicLocation/@CityName != '') or (GeographicLocation/@StateOrProvinceCode != '') or (GeographicLocation/@PostalCode != '')">
						<ns0:N4>
							<xsl:if test="GeographicLocation/@CityName != ''">
								<N401>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="GeographicLocation/@CityName" />
										<xsl:with-param name="maxLength" select="55" />
									</xsl:call-template>
								</N401>
							</xsl:if>
							<xsl:if test="GeographicLocation/@StateOrProvinceCode != ''">
								<N402>
									<xsl:value-of select="GeographicLocation/@StateOrProvinceCode" />
								</N402>
							</xsl:if>
							<xsl:if test="GeographicLocation/@PostalCode != ''">
								<N403>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode" />
										<xsl:with-param name="maxLength" select="55" />
									</xsl:call-template>
								</N403>
							</xsl:if>
							<xsl:if test="GeographicLocation/@CountryCode != ''">
								<N404>
									<xsl:value-of select="GeographicLocation/@CountryCode" />
								</N404>
							</xsl:if>
						</ns0:N4>
					</xsl:if>
				</ns0:N1Loop1>
			</xsl:for-each>

			<xsl:variable name="NumberOfN7" select="count (Header/EquipmentList/Equipment[@EquipmentNumber != ''])"/>
			<xsl:if test="$NumberOfN7 > 0">
				<ns0:N7Loop1>
					<xsl:for-each select="Header/EquipmentList/Equipment">
						<ns0:N7>
							<xsl:if test="@EquipmentNumber != ''">
								<N702>
									<xsl:value-of select="@EquipmentNumber" />
								</N702>
							</xsl:if>
							<N711>
								<xsl:choose>
									<xsl:when test="//Header/ReferenceList/ReferenceInformation[@EDICode='EQ']/@ReferenceInformation !=''">
										<xsl:value-of select="substring(//Header/ReferenceList/ReferenceInformation[@EDICode='EQ']/@ReferenceInformation,1,2)" />
									</xsl:when>
									<xsl:otherwise>
										<xsl:value-of select="@EquipmentDescriptionCode"/>
									</xsl:otherwise>
								</xsl:choose>
							</N711>
						</ns0:N7>
					</xsl:for-each>
				</ns0:N7Loop1>
			</xsl:if>

			<xsl:for-each select="Detail/LineItemList/LineItem">
				<ns0:LXLoop1>
					<ns0:LX>
						<LX01>
							<xsl:value-of select="position()"/>
						</LX01>
					</ns0:LX>
					<ns0:L5>
						<L501>
							<xsl:value-of select="position()"/>
						</L501>
						<xsl:if test="DescriptionMarksAndNumbers/@LadingDescription != ''">
							<L502>
								<!-- Convert to UpperCase <xsl:value-of select="translate(DescriptionMarksAndNumbers/@LadingDescription,  $vLowercaseChars_CONST, $vUppercaseChars_CONST)" />-->
								<xsl:call-template name="CleanAlphaField">
									<xsl:with-param name="inputText" select="DescriptionMarksAndNumbers/@LadingDescription"/>
									<xsl:with-param name="maxLength" select="50"/>
								</xsl:call-template>
							</L502>
						</xsl:if>
					</ns0:L5>
					<ns0:L0>
						<L001>
							<xsl:value-of select="position()"/>
						</L001>
						<xsl:if test="LineItemQuantityAndWeight/@BilledRatedAsQuantity != ''">
							<L002>
								<xsl:value-of select="LineItemQuantityAndWeight/@BilledRatedAsQuantity"/>
							</L002>
						</xsl:if>
						<xsl:if test="LineItemQuantityAndWeight/@BilledRatedAsQualifier != ''">
							<L003>
								<xsl:value-of select="LineItemQuantityAndWeight/@BilledRatedAsQualifier"/>
							</L003>
						</xsl:if>
						<xsl:if test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'LHS' and //Summary/TotalWeightAndCharges/@Weight!=''">
							<L004>
								<xsl:value-of select="//Summary/TotalWeightAndCharges/@Weight"/>
							</L004>
							<L005>N</L005>
						</xsl:if>
						<xsl:choose>
							<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'LHS' or DescriptionMarksAndNumbers/@LadingDescription = 'Line Haul'">
								<xsl:if test="//Summary/TotalWeightAndCharges/@LadingQuantity!=''">
									<L008>
										<xsl:value-of select="//Summary/TotalWeightAndCharges/@LadingQuantity"/>
									</L008>
								</xsl:if>
							</xsl:when>
							<xsl:otherwise>
								<xsl:if test="LineItemQuantityAndWeight/@LadingQuantity!=''">
									<L008>
										<xsl:value-of select="LineItemQuantityAndWeight/@LadingQuantity" />
									</L008>
								</xsl:if>
							</xsl:otherwise>
						</xsl:choose>
						<xsl:choose>
							<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'LHS' or DescriptionMarksAndNumbers/@LadingDescription = 'Line Haul'">
								<L009>PLT</L009>
							</xsl:when>
							<xsl:otherwise>
								<xsl:if test="LineItemQuantityAndWeight/@LadingQuantityPackagingFormCode!=''">
									<L009>
										<xsl:value-of select="LineItemQuantityAndWeight/@LadingQuantityPackagingFormCode" />
									</L009>
								</xsl:if>
							</xsl:otherwise>
						</xsl:choose>
						<xsl:choose>
							<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = 'LHS'or  DescriptionMarksAndNumbers/@LadingDescription = 'Line Haul'">
								<L011>L</L011>
							</xsl:when>
							<xsl:otherwise>
								<xsl:if test="LineItemQuantityAndWeight/@WeightUnitCode!=''">
									<L011>
										<xsl:value-of select="LineItemQuantityAndWeight/@WeightUnitCode" />
									</L011>
								</xsl:if>
							</xsl:otherwise>
						</xsl:choose>
					</ns0:L0>
					<xsl:if test="RateAndCharges/@Charge != '' ">
						<ns0:L1>
							<L101>
								<xsl:value-of select="position()"/>
							</L101>
							<!-- Custom Change for Dexcom , not needed by client - Now they want it so remapping it-->
							<xsl:if test="RateAndCharges/@FreightRate != ''">
								<L102>
									<xsl:value-of select="RateAndCharges/@FreightRate"/>
								</L102>
							</xsl:if>

							<xsl:if test="RateAndCharges/@RateValueQualifier != ''">
								<L103>
									<xsl:value-of select="RateAndCharges/@RateValueQualifier"/>
								</L103>
							</xsl:if>

							<xsl:if test="RateAndCharges/@Charge != ''">
								<L104>
									<xsl:value-of select="RateAndCharges/@Charge"/>
								</L104>
							</xsl:if>
							<!--L107 not mapped by default-->
							<!--
								<xsl:if test="RateAndCharges/@RateCombinationPointCode != ''">
											  <L107>
												  <xsl:value-of select="RateAndCharges/@RateCombinationPointCode" />
											  </L107>
								</xsl:if>
							 -->
							<xsl:if test="RateAndCharges/@SpecialChargeOrAllowanceCode != ''">
								<L108>
									<xsl:value-of select="RateAndCharges/@SpecialChargeOrAllowanceCode"/>
								</L108>
							</xsl:if>
							<!-- Custom Change for Dexcom needed by client -->
							<!--<xsl:if test="RateAndCharges/@SpecialChargeDescription != ''">
								<L112>
									<xsl:call-template name="CleanAlphaField" >
										<xsl:with-param name="inputText" select="RateAndCharges/@SpecialChargeDescription" />
										<xsl:with-param name="maxLength" select="25" />
									</xsl:call-template>
								</L112>
							</xsl:if>-->
						</ns0:L1>
					</xsl:if>
					<!-- Custom Change for Dexcom needed by client -->
					<!--<xsl:if test="TariffReference/@FreightClassCode != ''">
						<ns0:L7>
							<L707>
								<xsl:value-of select="TariffReference/@FreightClassCode" />
							</L707>
						</ns0:L7>
					</xsl:if>-->
				</ns0:LXLoop1>
			</xsl:for-each>
			<xsl:for-each select="Summary/TotalWeightAndCharges">
				<ns0:L3>
					<xsl:if test="@Weight">
						<L301>
							<xsl:value-of select="@Weight"/>
						</L301>
					</xsl:if>
					<xsl:if test="@WeightQualifier">
						<L302>G</L302>
					</xsl:if>
					<xsl:variable name="TotalCharges" select="@TotalCharges"/>
					<xsl:variable name="TotalChargesLength" select="string-length(@TotalCharges)"/>
					<xsl:if test="$TotalChargesLength > 2">
						<L305>
							<xsl:value-of select="translate(@TotalCharges,',','')"/>
							<!--<xsl:value-of select="concat(substring($TotalCharges, 1, $TotalChargesLength - 2), '.',  substring($TotalCharges, $TotalChargesLength - 2 , 2))" />-->
						</L305>
					</xsl:if>
					<xsl:if test="@LadingQuantity">
						<L311>
							<xsl:value-of select="@LadingQuantity"/>
						</L311>
					</xsl:if>
					<xsl:if test="@WeightUnitCode">
						<L312>
							<xsl:value-of select="@WeightUnitCode"/>
						</L312>
					</xsl:if>
				</ns0:L3>
			</xsl:for-each>
			<SE>
				<SE01>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetIdentifierCode"/>
				</SE01>
				<SE02>
					<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber"/>
				</SE02>
			</SE>
		</ns0:X12_00401_210>
	</xsl:template>
	<!--Custom Templates-->

	<!--Value mapping template for L108-->
	<xsl:template name="L108MapValue">
		<xsl:param name="ValueToConvert" select="0" />
		<xsl:variable name="L108Transform" >
			<map>
				<entry key="455">INC</entry>
				<entry key="CBL">LAC</entry>
				<entry key="520">OVR</entry>
				<entry key="GRD">EXD</entry>
				<entry key="LHS">400</entry>

			</map>
		</xsl:variable>
		<xsl:variable name="ConvertedValue" select="msxsl:node-set($L108Transform)/map/entry[@key=$ValueToConvert]"/>
		<xsl:choose>
			<xsl:when test="$ConvertedValue != ''">
				<xsl:value-of select="$ConvertedValue"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="$ValueToConvert"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>


	<!-- Created by Neal, not specific to L108-->
	<!-- CleanAlphaField start  -->
	<xsl:template name="CleanAlphaField">
		<xsl:param name="inputText"/>
		<xsl:param name="maxLength"/>
		<xsl:variable name="singleQuote" select='"&apos;"'/>
		<xsl:variable name="doubleQuote" select="'&quot;'"/>
		<xsl:variable name="vAllowedSymbolsPart1" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}\?/#'"/>
		<xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
		<xsl:variable name="vCleanedText" select="translate($inputText,translate($inputText, $vAllowedSymbols, ''),'')"/>
		<xsl:value-of select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
	</xsl:template>
	<!-- Clean AlphaField end -->
	<!--Value mapping template-->
	<xsl:template name="StopTypeMapValue">
		<xsl:param name="ValueToConvert" select="0"/>
		<xsl:variable name="StopTypeMap">
			<map>
				<entry key="Pick">SF</entry>
				<entry key="Drop">CN</entry>
			</map>
		</xsl:variable>
		<xsl:value-of select="msxsl:node-set($StopTypeMap)/map/entry[@key=$ValueToConvert]"/>
	</xsl:template>
	<!--Value mapping template-->
	<!--Set default if empty template start-->
	<xsl:template name="SetDefaultIfEmpty">
		<xsl:param name="pNode"/>
		<xsl:param name="pDefaultValue"/>
		<xsl:if test="$pNode">
			<xsl:value-of select="$pNode"/>
		</xsl:if>
		<xsl:if test="not($pNode)">
			<xsl:value-of select="$pDefaultValue"/>
		</xsl:if>
	</xsl:template>
	<!--Set default if empty template end-->
	<msxsl:script language="C#" implements-prefix="userCSharp">
		<msxsl:using namespace="System.Text.RegularExpressions" />
		<msxsl:using namespace="System.Collections.Generic" />
		<![CDATA[
public class LoadAddress
{
	public String LocationCode;
	public String Addr;
	public String City;
	public String ZipCode;

	public LoadAddress (String locationCode, String addr, String city, String zipCode)
	{
		LocationCode = locationCode;
    	Addr = SanitizeInput(addr);
		City = SanitizeInput(city);
		ZipCode = SanitizeInput(zipCode);
	}
	
	// Matches if either address is a match for the account
	public bool isMatch(String addr1, String city1)
	{
		if (SanitizeInput(city1) == City && SanitizeInput(addr1) == Addr)
		{
			return true;
		}
		return false;
	}
	
	private String SanitizeInput(String input)
	{
		return Regex.Replace(input, "[^0-9a-zA-Z]+", "").ToUpper().Trim();
	}
}

	// Used by xslt to get N104 value for BY line
	public String GetLocationCode(String addr1, String city1)
	{
		foreach(LoadAddress lad in LOAD_ADDRESSES)
		{
			if(lad.isMatch(addr1, city1))
			{
				return lad.LocationCode;
			}
		}
		return "Not Found";
	}
	
	
	//Column 2 for Address code is required additionally on some accounts - it is an additional code associated with the address and is returned on the pick/drop. Leave NULL if not in use. 
	public List<LoadAddress> LOAD_ADDRESSES = new List<LoadAddress>()
{ 
// 1st column is LocationCode, 2nd column is Address, 3rd column is City, 4th column is ZipCode,
new LoadAddress("Shaw1","1 BEAUFLOR WAY","WHITE","30184"),
new LoadAddress("Shaw2","1 KNOWLTON WAY","PORT WENTWORTH","31407"),
new LoadAddress("Shaw3","1 KRONOSPAN WAY","EASTABOGA","36260"),
new LoadAddress("Shaw4","1 QUALITY CIRCLE","CLINTON","37716"),
new LoadAddress("Shaw5","10 CUPLER DR","LAVALE","21502"),
new LoadAddress("Shaw6","1000 V.D. PARROT PKWY","DALTON","30721"),
new LoadAddress("Shaw7","1001 BOND ST STE A","CHARLOTTE","28208"),
new LoadAddress("Shaw8","1001 CHAMBERS AVE","JEANNETTE","15644"),
new LoadAddress("Shaw9","1001 CHATTANOOGA AVE","DALTON","30722"),
new LoadAddress("Shaw10","1001 MARCELLA AVE","LAREDO","78040"), 
new LoadAddress("ALABA","700 INDUSTRIAL PARK DR","ALABASTER","35007"), 
new LoadAddress("ALLEN","6950 AMBASSADOR DR","ALLENTOWN","18106"), 
new LoadAddress("ALLENA","6950 AMBASSADOR DR","ALLENTOWN","18106"), 
new LoadAddress("ALLENB","7034 AMBASSADOR DR","ALLENTOWN","18106"), 
new LoadAddress("ALLENB","7034 AMBASSADOR DRIVE","ALLENTOWN","18106"), 
new LoadAddress("ALLENC","7034 AMBASSADOR DR","ALLENTOWN","18106"), 
new LoadAddress("ALLENC","7034 AMBASSADOR DRIVE","ALLENTOWN","18106"), 
new LoadAddress("AUSTI","11044 RESEARCH BLVD STE B210","AUSTIN","78759"), 
new LoadAddress("AUSTIB","12212 TECHNOLOGY BLVD","AUSTIN","78727"), 
new LoadAddress("BATAV","1051 N KIRK ROAD","BATAVIA","60510"), 
new LoadAddress("BATAV","1051 N KIRK RD","BATAVIA","60510"), 
new LoadAddress("BATHA","7378 AIRPORT RD","BATH","18014"), 
new LoadAddress("BEDFO","80 ASHBY RD","BEDFORD","01730"), 
new LoadAddress("BEDFO","80 ASHBY RD","BEDFORD","01730"), 
new LoadAddress("BEDFOA","75 WIGGINS AVE","BEDFORD","01730"), 
new LoadAddress("BEDFOB","32 WIGGINS AVE","BEDFORD","17302"), 
new LoadAddress("BELLE","595 N HARRISON RD","BELLEFONTE","16823"), 
new LoadAddress("BELLEA","12822 SOUTH EAST 32ND ST","BELLEVUE","98005"), 
new LoadAddress("BELLEA","12822 SOUTH E 32ND ST","BELLEVUE","98005"), 
new LoadAddress("BILLE","900 MIDDLESEX TPKE","BILLERICA","01821"), 
new LoadAddress("BILLEA","290 CONCORD ROAD","BILLERICA","01821"), 
new LoadAddress("BILLEA","290 CONCORD RD","BILLERICA","01821"), 
new LoadAddress("BILLEB","90 SALEM ROAD","BILLERICA","01821"), 
new LoadAddress("BILLEB","90 SALEM RD","BILLERICA","01821"), 
new LoadAddress("BRAMP","70 DRIVER ROAD UNIT 1","BRAMPTON","L6T5V2"), 
new LoadAddress("BRIDG","45 SCOTLAND BLVD","BRIDGEWATER","02324"), 
new LoadAddress("BROOK","58 VALE ROAD","BROOKFIELD","06804"), 
new LoadAddress("BURLI","400 SUMMIT DRIVE","BURLINGTON","01805"), 
new LoadAddress("BURLI","400 SUMMIT DR","BURLINGTON","01805"), 
new LoadAddress("BURLIA","186 MIDDLESEX TPKE","BURLINGTON","18034"), 
new LoadAddress("BURLIB","400 WHEELER RD","BURLINGTON","01803"), 
new LoadAddress("BURLIC","5295 JOHN LUCAS DR  UNIT 6","BURLINGTON","L7L6A8"), 
new LoadAddress("CARLS","6211 EL CAMINO REAL","CARLSBAD","92010"), 
new LoadAddress("CARLSA","6219 EL CAMINO REAL","CARLSBAD","92009"), 
new LoadAddress("CARLSD","6195 El Camino Real","Carlsbad","92009"), 
new LoadAddress("CINCI","2909 HIGHLAND AVE","CINCINNATI","45212"), 
new LoadAddress("CLEVE","4353 E  49TH ST","CLEVELAND","44125"), 
new LoadAddress("COLUM","N4335 TEMKIN ROAD","COLUMBUS","53925"), 
new LoadAddress("COLUM","N4335 TEMKIN RD","COLUMBUS","53925"),
new LoadAddress("CRANB","324 HALF ACRE RD","CRANBURY","08512"),
new LoadAddress("DANVE","17 CHERRY HILL DRIVE","DANVERS","01923"), 
new LoadAddress("DANVE","17 CHERRY HILL DR","DANVERS","01923"), 
new LoadAddress("DANVEA","75 SYLVAN STREET","DANVERS","01923"), 
new LoadAddress("DANVEA","75 SYLVAN ST","DANVERS","01923"), 
new LoadAddress("DANVEB","54 Cherry Hill Drive","Danvers","01923"), 
new LoadAddress("DANVEB","54 Cherry Hill Dr","Danvers","01923"), 
new LoadAddress("DENVE","320 SWAMP BRIDGE RD","DENVER","17517"), 
new LoadAddress("DORVA","10525 COTE DE LIESSE","DORVAL","H9P1A7"), 
new LoadAddress("EARTH","13145 LAKEFRONT DR","EARTH CITY","63045"), 
new LoadAddress("EAST","2601 MCCASLAND AVE","EAST ST LOUIS","62207"), 
new LoadAddress("EASTB","122 Harborside Drive  Bl","East Boston","02128"), 
new LoadAddress("EASTS","2601 MCCASLAND AVE","EAST ST LOUIS","62207"), 
new LoadAddress("ESAIN","2601 MCCASLAND AVE","EAST ST LOIUS","62207"), 
new LoadAddress("ESCON","425 N ANDREASEN DR","ESCONDIDO","92029"), 
new LoadAddress("ESTLO","2601 MCCASLAND AVE","EAST ST LOUIS","62207"), 
new LoadAddress("ETOBI","109 WOODBINE DOWNS BLVD  UNIT 5","ETOBICOKE","M9W6Y1"), 
new LoadAddress("ETOBIA","1151 MARTIN GROVE ROAD","ETOBICOKE","M9W4W7"), 
new LoadAddress("FRESN","SOUTH CHESTNUT AVENUE","FRESNO","93650"), 
new LoadAddress("FRESN","SOUTH CHESTNUT AVE","FRESNO","93650"), 
new LoadAddress("GAITH","7841 AIRPARK RD","GAITHERSBURG","20879"), 
new LoadAddress("GOLDS","106 SOUTH US 117 HWY BYPASS","GOLDSBORO","27533"), 
new LoadAddress("HAVERA","22 COMPUTER DRIVE","HAVERHILL","01832"), 
new LoadAddress("HAVERA","22 COMPUTER DRE","HAVERHILL","01832"), 
new LoadAddress("HAYWA","25801 INDUSTRIAL BLVD","HAYWARD","94545"), 
new LoadAddress("HOLLI","2301 BERT DR","HOLLISTER","95023"), 
new LoadAddress("HUNTS","2852 WALL TRIANA HWY","HUNTSVILLE","35824"), 
new LoadAddress("HUNTSA","2852 WALL TRIANA HWY","HUNTSVILLE","35824"), 
new LoadAddress("HUNTSB","2852 WALL TRIANA HWY","HUNTSVILLE","35824"), 
new LoadAddress("INDEP","16400 EAST TRUMAN ROAD","INDEPENDENCE","64050"), 
new LoadAddress("INDEP","16400 EAST TRUMAN RD","INDEPENDENCE","64050"), 
new LoadAddress("INDEP","16400 E TRUMAN ROAD","INDEPENDENCE","64050"), 
new LoadAddress("INDEP","16400 E TRUMAN RD","INDEPENDENCE","64050"), 
new LoadAddress("INDEPA","16500 EAST TRUMAN ROAD","INDEPENDENCE","64050"), 
new LoadAddress("INDEPA","16500 EAST TRUMAN RD","INDEPENDENCE","64050"), 
new LoadAddress("INDEPA","16500 E TRUMAN ROAD","INDEPENDENCE","64050"), 
new LoadAddress("INDEPA","16500 E TRUMAN RD","INDEPENDENCE","64050"), 
new LoadAddress("INDIA","6925 GUION RD","INDIANAPOLIS","46268"), 
new LoadAddress("JAFFR1446","11 PRESCOTT ROAD","JAFFREY","03452"), 
new LoadAddress("JAFFR1446","11 PRESCOTT RD","JAFFREY","03452"), 
new LoadAddress("JAFFRA","81 FITZGERALD DRIVE","JAFFREY","03452"), 
new LoadAddress("JAFFRA","81 FITZGERALD DR","JAFFREY","03452"), 
new LoadAddress("KANKA","195 W  BIRCH STREET","KANKAKEE","60901"), 
new LoadAddress("KANKA","195 W  BIRCH ST","KANKAKEE","60901"), 
new LoadAddress("KANKAA","2407 EASTGATE PARKWAY","KANKAKEE","60901"), 
new LoadAddress("KANKAA","2407 EASTGATE PKWY","KANKAKEE","60901"), 
new LoadAddress("KANKAB","70 MEADOWVIEW CENTER","KANKAKEE","60901"), 
new LoadAddress("LARAM","2931 SOLDIER SPRINGS ROAD","LARAMIE","82070"), 
new LoadAddress("LARAM","2931 SOLDIER SPRINGS RD","LARAMIE","82070"), 
new LoadAddress("LENEX","13804 W 107TH ST","LENEXA","66215"), 
new LoadAddress("LENEXA","11296 RENNER BLVD","LENEXA","66219"), 
new LoadAddress("LENEXB","9900 PFLUMM RD UNIT #61","LENEXA","66215"),
new LoadAddress("LENEXB","9900 PFLUMM RD","LENEXA","66215"),
new LoadAddress("LEVIT","41 RUNWAY DR","LEVITTOWN","19057"), 
new LoadAddress("LOWEL","263 INDUSTRIAL AVENUE  E","LOWELL","01850"), 
new LoadAddress("LOWEL","263 INDUSTRIAL AVE  E","LOWELL","01850"), 
new LoadAddress("MADIS","645 SCIENCE DR","MADISON","53711"), 
new LoadAddress("MEMPH","3400 PLAYERS CLUB PKWY","MEMPHIS","38125"), 
new LoadAddress("MEMPHA","3400 PLAYERS CLUB PKWY","MEMPHIS","38125"), 
new LoadAddress("MEMPHB","3400 PLAYERS CLUB PKWY","MEMPHIS","38125"), 
new LoadAddress("MEMPHC","3400 PLAYERS CLUB PKWY","MEMPHIS","38125"), 
new LoadAddress("MEMPHD","3400 PLAYERS CLUB PKWY STE 300","MEMPHIS","38125"), 
new LoadAddress("MIAMI","3858 BENNER RD","MIAMISBURG","45342"), 
new LoadAddress("MILWA","230 S EMMBER LN","MILWAUKEE","53233"), 
new LoadAddress("MILWAA","6000 N TEUTONIA AVE","MILWAUKEE","53209"), 
new LoadAddress("MILWAC","2905 W HOPE AVE","MILWAUKEE","53210"), 
new LoadAddress("MISSI","415 TRADERS BLVD","MISSISSAUGA","L4Z2E5"), 
new LoadAddress("MISSIA","5901 TOMKEN ROAD UNIT J","MISSISSAUGA","L4W4K3"),
new LoadAddress("MISSIF","7035 ORDAN DR","MISSISSAUGA","L5T 1T1"),
new LoadAddress("NASHU","27 AIRPORT ROAD","NASHUA","03064"), 
new LoadAddress("NASHU","27 AIRPORT RD","NASHUA","03064"), 
new LoadAddress("NATIC","3 STRATHMORE  RD","NATICK","01760"), 
new LoadAddress("NORTH","90 SALEM RD","NORTH BILLERICA","18622"), 
new LoadAddress("NORTHA","1560 OSGOOD STREET","NORTH ANDOVER","08145"), 
new LoadAddress("NORTHA","1560 OSGOOD ST","NORTH ANDOVER","08145"), 
new LoadAddress("NORWO","2828 HIGHLAND AVENUE","NORWOOD","45209"), 
new LoadAddress("NORWO","2828 HIGHLAND AVE","NORWOOD","45209"), 
new LoadAddress("NORWOA","2909 HIGHLAND AVENUE","NORWOOD","45209"), 
new LoadAddress("NORWOA","2909 HIGHLAND AVE","NORWOOD","45209"), 
new LoadAddress("OAKVI","2149 WINSTON PARK DR","OAKVILLE","L6H6J8"), 
new LoadAddress("PEABO","THREE TECHNOLOGY DRIVE","PEABODY","01960"), 
new LoadAddress("PEABO","THREE TECHNOLOGY DR","PEABODY","01960"), 
new LoadAddress("PORTW","690 WEST OAKLAND AVENUE","PORT WASHINGTON","53074"), 
new LoadAddress("PORTW","690 WEST OAKLAND AVE","PORT WASHINGTON","53074"), 
new LoadAddress("PORTW","690 W OAKLAND AVENUE","PORT WASHINGTON","53074"), 
new LoadAddress("PORTW","690 W OAKLAND AVE","PORT WASHINGTON","53074"), 
new LoadAddress("RAMON","26578 OLD JULIAN HIGHWAY","RAMONA","92065"), 
new LoadAddress("RAMONA","3065 HIGHWAY 67","RAMONA","92065"), 
new LoadAddress("READI","5 DUTCH CT","READING","19608"), 
new LoadAddress("ROCKLA","6600 SIERRA COLLEGE BLVD","ROCKLIN","95677"), 
new LoadAddress("ROCKV","14920 BROSCHART RD","ROCKVILLE","20850"), 
new LoadAddress("ROCKVA","9610 MEDICAL CENTER DR","ROCKVILLE","20850"), 
new LoadAddress("ROCKVB","9630 MEDICAL CENTER DR","ROCKVILLE","20850"), 
new LoadAddress("ROCKVC","9900 BLACKWELL RD","ROCKVILLE","20850"), 
new LoadAddress("ROUND","811 PALOMA DRIVE","ROUND ROCK","98665"), 
new LoadAddress("ROUND","811 PALOMA DR","ROUND ROCK","98665"), 
new LoadAddress("SAINT","3506 S BROADWAY","SAINT LOUIS","63118"), 
new LoadAddress("SAINTA","3523 S 2ND ST","SAINT LOUIS","63118"), 
new LoadAddress("SAINTB","3300 S 2ND ST","SAINT LOUIS","63118"), 
new LoadAddress("SAINTC","2425 S 2ND ST","SAINT LOUIS","63104"), 
new LoadAddress("SAINTD","2909 LACLEDE AVE","SAINT LOUIS","63103"), 
new LoadAddress("SAINTE","3460 S BROADWAY","SAINT LOUIS","63118"), 
new LoadAddress("SAINTF","3500 DEKALB ST","SAINT LOUIS","63118"), 
new LoadAddress("SAINTG","545 S EWING AVE","SAINT LOUIS","63103"), 
new LoadAddress("SAINTH","3050 SPRUCE ST","SAINT LOUIS","63103"), 
new LoadAddress("SAINTI","2838 OLIVE ST","SAINT LOUIS","63103"), 
new LoadAddress("SAINTJ","PO BOX 14508","SAINT LOUIS","63178"), 
new LoadAddress("SAINTK","165 CHEROKEE ST","SAINT LOUIS","63118"), 
new LoadAddress("SAINTL","6 RESEARCH PARK","ST  CHARLES","63304"), 
new LoadAddress("SAINTM","14 RESEARCH PARK DRIVE","ST  CHARLES","63304"), 
new LoadAddress("SAINTM","14 RESEARCH PARK DR","ST  CHARLES","63304"), 
new LoadAddress("SAINTN","15 RESEARCH PARK","ST  CHARLES","63304"), 
new LoadAddress("SAINTV","5000 COTE VERTU","SAINT LAURENT","H4S2E7"), 
new LoadAddress("SAINTW","5000 COTE VERTU","Saint Laurent","H4S2E7"), 
new LoadAddress("SAINTX","2601 MCCASLAND AVE","EAST ST LOUIS","62207"), 
new LoadAddress("SAINTY","3700 CLEON ST","SAINT LOUIS","63118"), 
new LoadAddress("SANDIA","10394 PACIFIC CENTER CT","SAN DIEGO","92121"), 
new LoadAddress("SANTA","1230 EAST SAINT GERTRUDGE PL","SANTA ANA","92707"), 
new LoadAddress("SANTAA","2121 S STANDARD AVE","SANTA ANA","92707"), 
new LoadAddress("SEATT","645 ELLIOTT AVE W  SUITE","SEATTLE","98119"), 
new LoadAddress("SHEBO","5485 COUNTY ROAD V","SHEBOYGAN FALLS","53085"),
new LoadAddress("SHEBO","5485 County V","SHEBOYGAN FALLS","53085"), 
new LoadAddress("SHELB","1101 ISAAC SHELBY DR","SHELBYVILLE","40065"), 
new LoadAddress("SHREW","905 HARTFORD AVENUE","SHREWSBURY","01546"), 
new LoadAddress("SHREW","905 HARTFORD AVE","SHREWSBURY","01546"), 
new LoadAddress("SINKI","5 DUTCH CT","SINKING SPRING","19608"),
new LoadAddress("SINKI","5 Dutch Ct","SINKING SPG","19608"),
new LoadAddress("SOLON","28600 FOUNTAIN PKWY","SOLON","44139"), 
new LoadAddress("SPRIN","9186 SIX PINES DRIVE","SPRING","77380"), 
new LoadAddress("SPRINA","3601 Main Street","SPRINGFIELD","01199"), 
new LoadAddress("STCHA","6 RESEARCH PARK","ST  CHARLES","63304"), 
new LoadAddress("STCHAA","14 RESEARCH PARK DRIVE","ST  CHARLES","63304"), 
new LoadAddress("STCHAA","14 RESEARCH PARK DR","ST  CHARLES","63304"), 
new LoadAddress("STCHAB","15 RESEARCH PARK","ST  CHARLES","63304"), 
new LoadAddress("STLOU","3506 S BROADWAY","SAINT LOUIS","63118"), 
new LoadAddress("STLOUA","3523 S 2ND ST","SAINT LOUIS","63118"), 
new LoadAddress("STLOUB","3300 S 2ND ST","SAINT LOUIS","63118"), 
new LoadAddress("STLOUC","2425 S 2ND ST","SAINT LOUIS","63104"), 
new LoadAddress("STLOUD","2909 LACLEDE AVE","SAINT LOUIS","63103"), 
new LoadAddress("STLOUE","3460 S BROADWAY","SAINT LOUIS","63118"), 
new LoadAddress("STLOUF","3500 DEKALB ST","SAINT LOUIS","63118"), 
new LoadAddress("STLOUG","545 S EWING AVE","SAINT LOUIS","63103"), 
new LoadAddress("STLOUH","3050 SPRUCE ST","SAINT LOUIS","63103"), 
new LoadAddress("STLOUI","2838 OLIVE ST","SAINT LOUIS","63103"), 
new LoadAddress("STLOUJ","PO BOX 14508","SAINT LOUIS","63178"), 
new LoadAddress("STLOUK","165 CHEROKEE ST","SAINT LOUIS","63118"), 
new LoadAddress("STLOUL","111 WINNEBAGO STREET","SAINT LOUIS","63118"), 
new LoadAddress("STLOUL","111 WINNEBAGO ST","SAINT LOUIS","63118"), 
new LoadAddress("STONE","85 MAPLE STREET, FLOOR 1","STONEHAM","02180"), 
new LoadAddress("STOUG","139 SHUMAN AVE","STOUGHTON","02072"), 
new LoadAddress("TAUNT","530 JOHN HANCOCK ROAD","TAUNTON","02780"), 
new LoadAddress("TAUNT","530 JOHN HANCOCK RD","TAUNTON","02780"), 
new LoadAddress("TAUNTC","54 CHERRY HILL DRIVE","TAUNTON","02780"), 
new LoadAddress("TAUNTC","54 CHERRY HILL DR","TAUNTON","02780"), 
new LoadAddress("TAUNTD","1133 COUNTY ST","TAUNTON","02780"), 
new LoadAddress("TEMEC","28820 SINGLE OAK DRIVE","TEMECULA","92563"), 
new LoadAddress("TEMEC","28820 SINGLE OAK DR","TEMECULA","92590"), 
new LoadAddress("THEWO","9186 SIX PINES DR","THE WOODLANDS","77380"), 
new LoadAddress("URBAN","1302 WEST ANTHONY DR","URBANA","61802"), 
new LoadAddress("VERON","1101 KETTLE MORAINE TRL","VERONA","53593"), 
new LoadAddress("VISAL","8511 WEST RIGGIN AVENUE","VISALIA","93291"), 
new LoadAddress("VISAL","8511 WEST RIGGIN AVE","VISALIA","93291"),
new LoadAddress("VISALA","8511 WEST RIGGIN AVE","VISALIA","93291"),
new LoadAddress("WESTS","11 INTERSTATE DRIVE SUITE 200","WEST SPRINGFIELD","01089"), 
new LoadAddress("WESTS","11 INTERSTATE DRIVE SUITE 200","WEST SPRINGFIELD","01089"), 
new LoadAddress("WILBR","380 Main St","WILBRAHAM","01095"), 
new LoadAddress("WILBRA","380 MAIN STREET","Wilbraham","01095"), 
new LoadAddress("WILMI","25 INDUSTRIAL WAY","WILMINGTON","01887"), 
new LoadAddress("WILMIB","235F Andover Street","Wilmington","01887"), 
new LoadAddress("WILMIB","235F Andover St","Wilmington","01887"), 
new LoadAddress("WOODL","1242 COMMERCE AVE SUITE D","WOODLAND","95776"),
new LoadAddress("WOODL","1242 COMMERCE AVE","WOODLAND","95776") 
};

		]]>
	</msxsl:script>
</xsl:stylesheet>