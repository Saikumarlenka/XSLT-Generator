<?xml version="1.0" encoding="UTF-16"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var" exclude-result-prefixes="msxsl var s0" version="1.0" xmlns:s0="http://Echo.BSSR.Internal.Canonical.TendorResponse.TenderResponseOut" xmlns:ns0="http://Echo.BSSR.Schemas.EDI.X12_00503.EDI990/v1.0">
  <xsl:output omit-xml-declaration="yes" method="xml" version="1.0" />
  <xsl:template match="/">
    <xsl:apply-templates select="/s0:TenderResponse" />
  </xsl:template>
  <xsl:template match="/s0:TenderResponse">
    <xsl:variable name="vCustomerId" select="@CustomerId" />
    <xsl:variable name="vCompanyId" select="@CompanyId" />
    <xsl:variable name="vDefaultSCAC" select="'ECHS'" />
    <xsl:variable name="vBOL" select="Transaction/Header/BOL/text()" />
    <xsl:variable name="vRefSCAC" select="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='SC']/RefValue/text()" />
    <xsl:variable name="vRefMBOL" select="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='MB']/RefValue/text()" />
    <xsl:variable name="vMode" select="Transaction/Header/Mode/text()" />
    <xsl:variable name="vBookingDateRaw" select="Transaction/Header/BookingDate/text()" />
    <xsl:variable name="vReservationCode" select="Transaction/Header/ReservationCode/text()" />
    <xsl:variable name="vRemarks" select="Transaction/Header/Remarks/text()" />

    <xsl:variable name="vBookingDate" select="substring-before($vBookingDateRaw,'T')" />
    <xsl:variable name="vBookingYear" select="substring-before($vBookingDate, '-')" />
    <xsl:variable name="vBookingMonthDay" select="substring-after($vBookingDate,'-')" />
    <xsl:variable name="vBookingMonth" select="substring-before($vBookingMonthDay,'-')" />
    <xsl:variable name="vBookingDay" select="substring-after($vBookingMonthDay,'-')" />
    <ns0:X12_00503_990>
      <ST>
        <ST01>990</ST01>
        <ST02>0001</ST02>
      </ST>
      <ns0:B1>
        <B101>
          <xsl:value-of select ="'10026765'"/>
        </B101>
        <B102>
          <xsl:choose>
            <xsl:when test="$vRefMBOL!=''">
              <xsl:value-of select="$vRefMBOL"/>
            </xsl:when>
            <xsl:otherwise>
             <xsl:value-of select="Transaction/Header/BOL/text()" />
            </xsl:otherwise>
          </xsl:choose>
          
        </B102>
        <B103>
          <xsl:value-of select="$vBookingYear"/>
          <xsl:value-of select="$vBookingMonth"/>
          <xsl:value-of select="$vBookingDay"/>
        </B103>
        <B104>
          <xsl:value-of select="$vReservationCode"/>
        </B104>
      </ns0:B1>
      <!--<ns0:N9>
        <N901>CN</N901>
        <N902>
          <xsl:value-of select="Transaction/ReferenceNumbers/ReferenceNumber[EDICode='CN']/RefValue/text()" />
        </N902>
      </ns0:N9>
      <ns0:K1>
        <xsl:choose>
          <xsl:when test="$vReservationCode='D'">
            <xsl:choose>
              <xsl:when test="$vRemarks='Credit'">
                <K101>PRNA</K101>
                <K102>Price Not Acceptable</K102>
              </xsl:when>
              <xsl:when test="$vRemarks='Capacity Constraints'">
                <K101>NODA</K101>
                <K102>No Driver Available</K102>
              </xsl:when>
              <xsl:when test="$vRemarks='Capacity Type'">
                <K101>INLT</K101>
                <K102>Insufficient Lead Time</K102>
              </xsl:when>
              <xsl:when test="$vRemarks='Delivery'">
                <K101>ODLT</K101>
                <K102>Over Commitment</K102>
              </xsl:when>
              <xsl:when test="$vRemarks='Duplicate'">
                <K101>REJD</K101>
                <K102>Tender Rejected</K102>
              </xsl:when>
              <xsl:when test="$vRemarks='Equipment Constraints'">
                <K101>NEQA</K101>
                <K102>No Equipment</K102>
              </xsl:when>
              <xsl:otherwise>
                <K101>REJD</K101>
                <K102>Tender Rejected</K102>
              </xsl:otherwise>
            </xsl:choose>
          </xsl:when>
          <xsl:otherwise>
            <K101>AB</K101>
            <K102>ECHS</K102>
          </xsl:otherwise>
        </xsl:choose>
      </ns0:K1>-->
      <xsl:value-of select="./text()" />
    </ns0:X12_00503_990>
  </xsl:template>

  <xsl:template name="RejectReasonMapValue">
    <xsl:param name="ValueToConvert" select="0" />
    <xsl:variable name="vRejectReasonMap" >
      <map>
        <entry key="Capacity Constraints">CPU</entry>
        <entry key="Credit">CPU</entry>
        <entry key="Capacity Type">CPT</entry>
        <entry key="Cancelled By Customer">CPU</entry>
        <entry key="Delivery">CPU</entry>
        <entry key="Duplicate">CPU</entry>
        <entry key="Equipment">EQT</entry>
        <entry key="Equipment Constraints">EQU</entry>
        <entry key="Destination/Flows">CPU</entry>
        <entry key="Pickup">CPU</entry>
        <entry key="Same Day Release">CPU</entry>
        <entry key="Service Failure">EQU</entry>
      </map>
    </xsl:variable>
    <xsl:variable name="ValueConverted" select="msxsl:node-set($vRejectReasonMap)/map/entry[@key=$ValueToConvert]"/>
    <xsl:choose>
      <xsl:when test="$ValueConverted!=''">
        <xsl:value-of select="$ValueConverted"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="'CPU'"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

</xsl:stylesheet>