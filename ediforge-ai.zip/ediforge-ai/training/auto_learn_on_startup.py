"""
EDIForge AI v4 -- Auto-Learn on Startup
Run once after installing v4 to build initial knowledge base from all XSL maps.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from backend.schema.reference_template_engine import auto_populate_base_maps
from backend.mapping.self_learning_engine import learn_all_maps

if __name__ == "__main__":
    print("=" * 60)
    print(" EDIForge AI v4 -- Building Knowledge Base")
    print("=" * 60)
    print()
    print("[1/2] Auto-populating base maps from training/xsl_maps/ ...")
    auto_populate_base_maps()
    print("  Done.")
    print()
    print("[2/2] Learning mappings from all XSL maps ...")
    result = learn_all_maps()
    print(f"  Maps processed:    {result['maps_processed']}")
    print(f"  Transaction sets:  {result.get('transaction_sets',[])}")
    print(f"  Mappings learned:  {result.get('total_mappings',0)}")
    print()
    print("Knowledge base ready. Restart server to apply.")

def learn_xslt_patterns_from_training_maps():
    """
    FIX 14: Mine all training XSL maps for reusable patterns.
    Runs once; subsequent calls are fast (patterns already stored).
    """
    from pathlib import Path
    import re

    xsl_dir = Path(__file__).parent / "xsl_maps"
    if not xsl_dir.exists():
        return {"status": "skipped", "reason": "xsl_maps directory not found"}

    try:
        from backend.engine.reference_learning import learn_from_xslt
    except Exception as e:
        return {"status": "skipped", "reason": str(e)}

    ts_map = {"210": [], "214": [], "204": [], "990": []}
    for xsl_file in xsl_dir.glob("*.xsl"):
        for ts in ts_map:
            if ts in xsl_file.name:
                ts_map[ts].append(xsl_file)
                break

    total_learned = 0
    results = {}
    for ts, files in ts_map.items():
        ts_learned = {"xpaths": 0, "loops": 0, "qualifiers": 0}
        for f in files:
            try:
                content = f.read_text(encoding="utf-16", errors="replace")
            except Exception:
                try:
                    content = f.read_text(encoding="utf-8", errors="replace")
                except Exception:
                    continue
            try:
                learned = learn_from_xslt(ts, content)
                for k in ts_learned:
                    ts_learned[k] += learned.get(k, 0)
            except Exception:
                pass
        total_learned += sum(ts_learned.values())
        results[ts] = ts_learned

    print(f"  [FIX 14] Learned {total_learned} patterns from training XSL maps: {results}")
    return {"status": "ok", "total": total_learned, "by_transaction": results}
