"""
EDIForge AI - Training Manager v2
Auto-detects new/changed XSL files and rebuilds index + knowledge base automatically.
"""
import os, json, threading
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
load_dotenv()

TRAINING_DIR  = Path(__file__).parent
KNOWLEDGE_DIR = TRAINING_DIR / "knowledge"
MAPS_DIR      = TRAINING_DIR / "xsl_maps"
INDEX_FILE    = TRAINING_DIR / "vector_store" / "index.json"
MANIFEST_FILE = TRAINING_DIR / "xsl_manifest.json"

KNOWLEDGE_DIR.mkdir(exist_ok=True)
MAPS_DIR.mkdir(exist_ok=True)

_rebuild_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Change detection  (fingerprint every XSL file)
# ---------------------------------------------------------------------------

def _fingerprint(path: Path) -> str:
    s = path.stat()
    return f"{s.st_size}:{s.st_mtime_ns}"

def _load_manifest() -> dict:
    if MANIFEST_FILE.exists():
        try:
            return json.loads(MANIFEST_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}

def _save_manifest(manifest: dict):
    MANIFEST_FILE.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

def _current_fingerprints() -> dict:
    files = list(MAPS_DIR.glob("**/*.xsl")) + list(MAPS_DIR.glob("**/*.xslt"))
    return {f.name: _fingerprint(f) for f in files}

def needs_rebuild() -> bool:
    """Return True if any XSL file was added, removed, or changed."""
    if not INDEX_FILE.exists():
        return True
    current  = _current_fingerprints()
    manifest = _load_manifest()
    if set(current.keys()) != set(manifest.keys()):
        return True
    for fname, fp in current.items():
        if manifest.get(fname) != fp:
            return True
    return False


# ---------------------------------------------------------------------------
# Full rebuild  (index + knowledge base)
# ---------------------------------------------------------------------------

def rebuild_index(force: bool = False) -> dict:
    """Rebuild XSL index AND knowledge base. Thread-safe."""
    with _rebuild_lock:
        if not force and not needs_rebuild():
            print("[Training] No changes detected, skipping rebuild.")
            return {"status": "skipped"}

        print("[Training] Changes detected — rebuilding index and knowledge base...")

        # Step 1: rebuild vector index
        from training.xsl_indexer import build_index
        result = build_index()

        # Step 2: rebuild knowledge base (patterns, loops, conditions)
        try:
            from training.xsl_pattern_extractor import build_knowledge_base
            build_knowledge_base()
            print("[Training] Knowledge base rebuilt successfully.")
        except Exception as e:
            print(f"[Training] Knowledge base rebuild warning: {e}")

        # Step 3: update manifest so we don't rebuild again unnecessarily
        _save_manifest(_current_fingerprints())

        print("[Training] Rebuild complete.")
        return result


# ---------------------------------------------------------------------------
# Auto-sync  (called before every generation)
# ---------------------------------------------------------------------------

def auto_sync():
    """
    Called silently before every XSLT generation.
    If new or changed XSL files are detected in training/xsl_maps/,
    rebuilds the index and knowledge base automatically.
    Does nothing if nothing changed.
    """
    if needs_rebuild():
        print("[Training] New/changed XSL files detected — auto-syncing...")
        try:
            rebuild_index(force=False)
        except Exception as e:
            print(f"[Training] Auto-sync warning: {e}")
    else:
        print("[Training] Training data up-to-date.")


# ---------------------------------------------------------------------------
# Startup initializer  (background thread, does not block first request)
# ---------------------------------------------------------------------------

def initialize():
    """Run once at app startup in a background thread."""
    def _bg():
        try:
            if needs_rebuild():
                print("[Training] Startup: changes detected, rebuilding...")
                rebuild_index(force=True)
            else:
                stats = get_training_stats()
                print(f"[Training] Startup: up-to-date "
                      f"({stats.get('total', 0)} maps, "
                      f"{stats.get('kb_mappings', 0)} patterns)")
        except Exception as e:
            print(f"[Training] Startup warning: {e}")

    t = threading.Thread(target=_bg, daemon=True, name="training-init")
    t.start()


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------

def is_training_enabled() -> bool:
    return MAPS_DIR.exists() and any(MAPS_DIR.glob("**/*.xsl"))

def get_training_stats() -> dict:
    try:
        from training.xsl_indexer import get_index_stats
        stats = get_index_stats()
        kb_file = KNOWLEDGE_DIR / "mapping_patterns.json"
        if kb_file.exists():
            kb = json.loads(kb_file.read_text())
            stats["kb_mappings"] = kb.get("total_mappings", 0)
            stats["kb_loops"]    = kb.get("total_loops", 0)
            stats["kb_files"]    = kb.get("total_files", 0)
        stats["pending_changes"] = needs_rebuild()
        return stats
    except Exception as e:
        return {"total": 0, "indexed": False, "error": str(e)}


# ---------------------------------------------------------------------------
# Prompt enrichment  (called during generation)
# ---------------------------------------------------------------------------

def enrich_prompt_with_training(
    base_prompt: str,
    mapping_rows: list,
    raw_mapping_text: str,
    transaction_set: str = "",
    use_rag: bool = True,
    use_few_shot: bool = True,
    use_knowledge: bool = True
) -> tuple:
    """
    Auto-syncs training data then enriches the AI prompt with:
      - Layer 1: RAG (most similar XSL maps injected as examples)
      - Layer 2: Few-shot examples from knowledge base
      - Layer 3: Learned source->target patterns for this transaction set
    Returns (enriched_prompt, model_override_or_None, info_dict)
    """
    # Always auto-sync before enriching so new maps are picked up
    auto_sync()

    enriched = base_prompt
    model_override = None
    info = {"rag_maps": 0, "few_shot": False, "finetuned": False, "knowledge": False}

    # Fine-tuned model override (optional)
    try:
        from training.finetune_upload import get_finetuned_model
        ft_model = get_finetuned_model()
        if ft_model:
            model_override = ft_model
            info["finetuned"] = True
            info["finetuned_model"] = ft_model
            print(f"  Using fine-tuned model: {ft_model}")
    except Exception:
        pass

    # Layer 3: Knowledge base patterns
    if use_knowledge and transaction_set:
        try:
            from training.rag_retriever import build_knowledge_context
            kb_ctx = build_knowledge_context(transaction_set)
            if kb_ctx:
                enriched = kb_ctx + "\n\n" + enriched
                info["knowledge"] = True
                print(f"  Knowledge base: injected patterns for X12 {transaction_set}")
        except Exception as e:
            print(f"  Knowledge base skipped: {e}")

    # Layer 1: RAG similar maps
    if use_rag:
        try:
            from training.rag_retriever import retrieve_similar_maps, build_rag_context, infer_query_features
            query   = infer_query_features(mapping_rows, raw_mapping_text, transaction_set)
            similar = retrieve_similar_maps(query, top_k=3)
            if similar:
                rag_ctx = build_rag_context(similar, max_chars=5000)
                enriched = rag_ctx + "\n\n" + enriched
                info["rag_maps"]  = len(similar)
                info["rag_files"] = [m["filename"] for m in similar]
                print(f"  RAG: injected {len(similar)} similar map(s)")
        except Exception as e:
            print(f"  RAG skipped: {e}")

    # Layer 2: Few-shot examples
    if use_few_shot:
        try:
            from training.few_shot_builder import build_few_shot_section
            fs = build_few_shot_section(transaction_set, max_chars=3000)
            if fs:
                enriched = enriched + "\n\n" + fs
                info["few_shot"] = True
                print(f"  Few-shot: injected pattern examples")
        except Exception as e:
            print(f"  Few-shot skipped: {e}")

    return enriched, model_override, info

