"""
EDIForge AI v5 -- Structural XSLT Matcher
==========================================
Replaces SequenceMatcher (raw text) with structural skeleton comparison.
Skeleton = {segments, loops, qualifiers, transforms, namespaces}
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple


def extract_xslt_skeleton(xslt_text: str) -> dict:
    skeleton: dict = {
        "segments": set(), "loops": [], "qualifiers": set(),
        "transforms": set(), "ns0_uri": "", "s0_uri": "", "transaction_set": "",
    }
    if not xslt_text:
        return skeleton
    ns0 = re.search(r'xmlns:ns0="([^"]+)"', xslt_text)
    s0  = re.search(r'xmlns:s0="([^"]+)"', xslt_text)
    if ns0: skeleton["ns0_uri"] = ns0.group(1)
    if s0:  skeleton["s0_uri"]  = s0.group(1)
    segs = re.findall(r'<(?:ns0:)?([A-Z][A-Z0-9]{1,3})\b', xslt_text)
    skeleton["segments"] = set(s for s in segs if s not in ("XSL","ROOT","NS0"))
    for m in re.finditer(r'<xsl:for-each\s+select="([^"]+)">(.*?)</xsl:for-each>', xslt_text, re.DOTALL):
        xpath    = m.group(1).strip()
        inner    = m.group(2)
        children = re.findall(r'<(?:ns0:)?([A-Z][A-Z0-9]{1,3})\b', inner)
        skeleton["loops"].append({"xpath": xpath, "edi_loop": _guess_loop_name(xpath),
                                   "children": list(dict.fromkeys(c for c in children if c != "XSL"))})
    quals = re.findall(r"@(?:EntityIdentifierCode|EDICode)='([^']+)'", xslt_text)
    skeleton["qualifiers"] = set(quals)
    if re.search(r'concat\(substring\(', xslt_text): skeleton["transforms"].add("date_yyyymmdd")
    if re.search(r"translate\([^,]+,['\"][\.,]['\"]", xslt_text): skeleton["transforms"].add("decimal")
    if re.search(r'CleanAlphaField', xslt_text): skeleton["transforms"].add("clean_alpha")
    ts_m = re.search(r'X12_00401_(\d{3})', xslt_text)
    if ts_m: skeleton["transaction_set"] = ts_m.group(1)
    skeleton["segments"]   = sorted(skeleton["segments"])
    skeleton["qualifiers"] = sorted(skeleton["qualifiers"])
    skeleton["transforms"] = sorted(skeleton["transforms"])
    return skeleton


def _guess_loop_name(xpath: str) -> str:
    xl = xpath.lower()
    if "partylist" in xl or "party" in xl: return "N1Loop1"
    if "lineitem"  in xl:                  return "LXLoop1"
    if "equipment" in xl:                  return "N7Loop1"
    if "reference" in xl:                  return "N9Loop1"
    if "status"    in xl:                  return "AT7Loop1"
    if "stop"      in xl:                  return "S5Loop1"
    if "charge"    in xl:                  return "L1Loop1"
    return "GenericLoop"


def score_structural_similarity(skel_a: dict, skel_b: dict) -> float:
    if not skel_a or not skel_b:
        return 0.0
    def _jaccard(a: list, b: list) -> float:
        sa, sb = set(a), set(b)
        if not sa and not sb: return 1.0
        return len(sa & sb) / len(sa | sb)
    seg_score  = _jaccard(skel_a["segments"], skel_b["segments"])
    loops_a    = [lp["edi_loop"] for lp in skel_a["loops"]]
    loops_b    = [lp["edi_loop"] for lp in skel_b["loops"]]
    loop_score = _jaccard(loops_a, loops_b)
    qual_score = _jaccard(skel_a["qualifiers"], skel_b["qualifiers"])
    ts_score   = 1.0 if (skel_a["transaction_set"] and
                         skel_a["transaction_set"] == skel_b["transaction_set"]) else 0.0
    return 0.40 * seg_score + 0.30 * loop_score + 0.20 * qual_score + 0.10 * ts_score


def find_best_reference_structural(
    transaction_set: str, mapping_text: str,
    reference_dir: Optional[Path] = None,
) -> Tuple[Optional[str], float]:
    if reference_dir is None:
        reference_dir = Path(__file__).parent / "reference_maps" / transaction_set
    if not reference_dir.exists():
        return None, 0.0
    target_skel = _skeleton_from_mapping_text(mapping_text, transaction_set)
    best_text: Optional[str] = None
    best_score: float        = -1.0
    for xsl_file in reference_dir.glob("*.xsl"):
        content = ""
        for enc in ("utf-16", "utf-8"):
            try: content = xsl_file.read_text(encoding=enc, errors="replace"); break
            except Exception: pass
        if not content: continue
        score = score_structural_similarity(target_skel, extract_xslt_skeleton(content))
        if score > best_score:
            best_score = score; best_text = content
    return best_text, best_score


def _skeleton_from_mapping_text(mapping_text: str, transaction_set: str) -> dict:
    segs    = re.findall(r'\b([A-Z][A-Z0-9]{1,3})\b', mapping_text)
    seg_set = set(s for s in segs if len(s) >= 2 and not s.isalpha())
    quals   = re.findall(r"'([A-Z]{2,4})'", mapping_text)
    return {"segments": sorted(seg_set), "loops": [], "qualifiers": sorted(set(quals)),
            "transforms": [], "ns0_uri": "", "s0_uri": "", "transaction_set": transaction_set}
