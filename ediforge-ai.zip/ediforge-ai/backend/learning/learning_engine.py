"""EDIForge AI v5 — Learning Engine (3-tier lookup: corrections -> knowledge base -> patterns)."""
import json, os, time
from pathlib import Path
from typing import Dict, List, Optional

_DEFAULT_DB_PATH = Path(__file__).parent.parent.parent / "training" / "knowledge" / "learned_mappings.json"
_PATTERNS_PATH   = Path(__file__).parent.parent.parent / "training" / "knowledge" / "mapping_patterns.json"


class LearningEngine:
    def __init__(self, db_path=None):
        self.db_path      = Path(db_path) if db_path else _DEFAULT_DB_PATH
        self.db: Dict[str, dict] = {}
        self.patterns: Dict[str, list] = {}
        self._load()
        self._load_patterns()

    def _load(self):
        if self.db_path.exists():
            try:
                self.db = json.loads(self.db_path.read_text(encoding="utf-8"))
            except Exception:
                self.db = {}
        else:
            self.db = {}

    def _save(self):
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.db_path.write_text(json.dumps(self.db, indent=2, ensure_ascii=False), encoding="utf-8")

    def _load_patterns(self):
        if _PATTERNS_PATH.exists():
            try:
                self.patterns = json.loads(_PATTERNS_PATH.read_text(encoding="utf-8"))
            except Exception:
                self.patterns = {}
        else:
            self.patterns = {}

    def learn(self, field: str, source: str, confidence: float = 1.0):
        from backend.mapping.field_normalizer import normalize_field
        key = normalize_field(field)
        if not key:
            return
        entry = self.db.get(key, {})
        if entry.get("confidence", 0) <= confidence:
            self.db[key] = {
                "field": field, "source": source, "confidence": confidence,
                "learned_at": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "use_count": entry.get("use_count", 0),
            }
        self._save()

    def lookup(self, field: str) -> Optional[str]:
        from backend.mapping.field_normalizer import normalize_field
        # Priority 1: user corrections
        key = normalize_field(field)
        entry = self.db.get(key)
        if entry:
            entry["use_count"] = entry.get("use_count", 0) + 1
            self._save()
            return entry["source"]
        # Priority 2: EDI knowledge base
        source = self._lookup_from_knowledge_base(field)
        if source:
            return source
        # Priority 3: learned XSL patterns
        return self._lookup_from_patterns(field)

    def _lookup_from_knowledge_base(self, field: str) -> Optional[str]:
        try:
            from backend.mapping.edi_knowledge_base import EDI_SEGMENT_FIELDS
            field_lower = field.lower().replace(" ", "").replace("_", "")
            for segment, fields in EDI_SEGMENT_FIELDS.items():
                for code, canonical in fields.items():
                    if canonical.lower().replace(" ", "") == field_lower:
                        return f"{segment}/{code}"
        except Exception:
            pass
        return None

    def _lookup_from_patterns(self, field: str) -> Optional[str]:
        field_lower = field.lower()
        for txn_patterns in self.patterns.values():
            if isinstance(txn_patterns, list):
                for p in txn_patterns:
                    if isinstance(p, dict):
                        target = p.get("target", "").lower()
                        if field_lower in target or target in field_lower:
                            return p.get("source", "")
        return None

    def enrich_mappings(self, mappings: List[dict]) -> List[dict]:
        enriched = []
        for m in mappings:
            m2 = dict(m)
            if not m2.get("source") and m2.get("target"):
                leaf = m2["target"].split("/")[-1].lstrip("@")
                learned = self.lookup(leaf)
                if learned:
                    m2["source"]   = learned
                    m2["_learned"] = True
            try:
                from backend.mapping.edi_knowledge_base import enrich_mapping_with_semantics
                m2 = enrich_mapping_with_semantics(m2)
            except Exception:
                pass
            enriched.append(m2)
        return enriched

    def learn_from_validated_map(self, mappings: List[dict]):
        for m in mappings:
            tgt = m.get("target", "")
            src = m.get("source", "")
            if tgt and src:
                leaf = tgt.split("/")[-1].lstrip("@")
                self.learn(leaf, src, confidence=0.9)

    def learn_from_xsl_patterns(self, patterns: List[dict]):
        for p in patterns:
            tgt = p.get("target", "")
            src = p.get("source", "")
            if tgt and src:
                leaf = tgt.split("/")[-1].lstrip("@")
                self.learn(leaf, src, confidence=0.8)

    def record_correction(self, field: str, wrong_source: str, correct_source: str):
        self.learn(field, correct_source, confidence=1.0)
        from backend.mapping.field_normalizer import normalize_field
        key = normalize_field(field)
        if key in self.db:
            self.db[key]["corrections"] = self.db[key].get("corrections", 0) + 1
        self._save()

    def get_all(self) -> Dict[str, dict]:
        return dict(self.db)

    def stats(self) -> dict:
        return {
            "total_learned":   len(self.db),
            "total_patterns":  sum(len(v) for v in self.patterns.values() if isinstance(v, list)),
            "high_confidence": sum(1 for e in self.db.values() if e.get("confidence", 0) >= 0.9),
        }

# =============================================================================
# EDIForge AI v4 -- Hallucination guard added to enrich_mappings
# HALLUCINATION_GUARD_V4
# =============================================================================
_original_enrich_mappings = LearningEngine.enrich_mappings

def _safe_enrich_mappings(self, mappings):
    """v4 override: skip enrichment for rows that are hardcoded literals."""
    enriched = []
    for m in mappings:
        if m.get("_is_literal") or m.get("literal"):
            enriched.append(m)   # literal rows: never invent a source
        else:
            enriched.extend(_original_enrich_mappings(self, [m]))
    return enriched

LearningEngine.enrich_mappings = _safe_enrich_mappings
