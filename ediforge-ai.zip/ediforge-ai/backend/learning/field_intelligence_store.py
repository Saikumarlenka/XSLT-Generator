"""
EDIForge AI v5 -- Field Intelligence Store
==========================================
Stores field-level mappings as structured intelligence.
Per-field: {canonical_xpath, transform, confidence, source_files, use_count}
Bootstraps from training/xsl_maps/ on first run.
"""
from __future__ import annotations
import json, time, re
from pathlib import Path
from typing import Dict, List, Optional

STORE_DIR = Path(__file__).parent.parent.parent / "training" / "knowledge"
STORE_DIR.mkdir(parents=True, exist_ok=True)


class FieldIntelligenceStore:
    def __init__(self, transaction_set: str):
        self.transaction_set = transaction_set
        self._path = STORE_DIR / f"{transaction_set}_field_intelligence.json"
        self._db: Dict[str, dict] = {}
        self._load()

    def _load(self):
        if self._path.exists():
            try: self._db = json.loads(self._path.read_text(encoding="utf-8"))
            except Exception: self._db = {}

    def _save(self):
        self._path.write_text(json.dumps(self._db, indent=2, ensure_ascii=False), encoding="utf-8")

    def learn(self, edi_element: str, canonical_xpath: str,
              transform: Optional[str] = None, confidence: float = 0.9, source_file: str = ""):
        if not edi_element or not canonical_xpath: return
        existing = self._db.get(edi_element, {})
        if existing.get("canonical_xpath") == canonical_xpath:
            existing["use_count"]  = existing.get("use_count", 0) + 1
            existing["confidence"] = min(1.0, existing.get("confidence", 0) + 0.02)
        elif confidence >= existing.get("confidence", 0):
            existing["canonical_xpath"] = canonical_xpath
            existing["transform"]       = transform or existing.get("transform")
            existing["confidence"]      = confidence
        sources = existing.get("source_files", [])
        if source_file and source_file not in sources: sources.append(source_file)
        existing["source_files"] = sources[-10:]
        existing["last_seen"]    = time.strftime("%Y-%m-%dT%H:%M:%SZ")
        existing.setdefault("use_count", 1)
        self._db[edi_element] = existing

    def lookup(self, edi_element: str) -> Optional[dict]:
        entry = self._db.get(edi_element)
        if entry: entry["use_count"] = entry.get("use_count", 0) + 1
        return entry

    def get_xpath(self, edi_element: str) -> Optional[str]:
        entry = self.lookup(edi_element)
        return entry["canonical_xpath"] if entry else None

    def enrich_mappings(self, mappings: List[dict]) -> List[dict]:
        enriched = []
        for m in mappings:
            m2 = dict(m)
            if m2.get("_is_literal") or m2.get("literal"):
                enriched.append(m2); continue
            if not m2.get("source"):
                tgt  = m2.get("target", "")
                leaf = re.sub(r"^ns0:", "", tgt.split("/")[-1]).lstrip("@")
                hit  = self.lookup(leaf)
                if hit and hit.get("confidence", 0) >= 0.7:
                    m2["source"]      = hit["canonical_xpath"]
                    m2["_from_store"] = True
                    m2["_confidence"] = hit["confidence"]
                    if hit.get("transform") and not m2.get("transform"):
                        m2["transform"] = hit["transform"]
            enriched.append(m2)
        self._save()
        return enriched

    def bulk_learn_from_xsl(self, xslt_text: str, source_file: str = "") -> int:
        learned = 0
        for m in re.finditer(r'<([A-Z][A-Z0-9]{1,5})>\s*<xsl:value-of\s+select="([^"]+)"', xslt_text):
            elem, xpath = m.group(1), m.group(2).strip()
            if elem in ("XSL","ROOT") or not xpath: continue
            transform = None
            if "concat(substring(" in xpath: transform = "date_yyyymmdd"
            elif "translate(" in xpath and "','" in xpath: transform = "decimal"
            self.learn(elem, xpath, transform=transform, confidence=0.85, source_file=source_file)
            learned += 1
        for m in re.finditer(
            r'<([A-Z][A-Z0-9]{1,5})>.*?xsl:with-param[^"]*"inputText"\s+select="([^"]+)"',
            xslt_text, re.DOTALL
        ):
            self.learn(m.group(1), m.group(2).strip(), transform="clean_alpha",
                       confidence=0.85, source_file=source_file); learned += 1
        if learned > 0: self._save()
        return learned

    def stats(self) -> dict:
        total  = len(self._db)
        high   = sum(1 for e in self._db.values() if e.get("confidence", 0) >= 0.9)
        medium = sum(1 for e in self._db.values() if 0.7 <= e.get("confidence", 0) < 0.9)
        return {"transaction_set": self.transaction_set, "total_fields": total,
                "high_confidence": high, "medium_confidence": medium, "low_confidence": total-high-medium}

    def all_mappings(self) -> Dict[str, str]:
        return {k: v["canonical_xpath"] for k, v in self._db.items()
                if v.get("confidence", 0) >= 0.7 and v.get("canonical_xpath")}


def bootstrap_all_transaction_sets(force: bool = False) -> dict:
    maps_dir = Path(__file__).parent.parent.parent / "training" / "xsl_maps"
    if not maps_dir.exists(): return {"error": "training/xsl_maps/ not found"}
    stores: Dict[str, FieldIntelligenceStore] = {}
    results: Dict[str, int] = {}
    for xsl_file in list(maps_dir.glob("*.xsl")) + list(maps_dir.glob("*.xslt")):
        ts = next((t for t in ("210","214","990","204") if t in xsl_file.name), "")
        if not ts: continue
        if ts not in stores:
            p = STORE_DIR / f"{ts}_field_intelligence.json"
            if p.exists() and not force: continue
            stores[ts] = FieldIntelligenceStore(ts)
        content = ""
        for enc in ("utf-16","utf-8"):
            try: content = xsl_file.read_text(encoding=enc, errors="replace"); break
            except Exception: pass
        if content:
            n = stores[ts].bulk_learn_from_xsl(content, source_file=xsl_file.name)
            results[ts] = results.get(ts, 0) + n
    return {"transaction_sets": list(results.keys()), "fields_learned": results,
            "total": sum(results.values())}


_stores: Dict[str, FieldIntelligenceStore] = {}

def get_store(transaction_set: str) -> FieldIntelligenceStore:
    if transaction_set not in _stores:
        _stores[transaction_set] = FieldIntelligenceStore(transaction_set)
    return _stores[transaction_set]
