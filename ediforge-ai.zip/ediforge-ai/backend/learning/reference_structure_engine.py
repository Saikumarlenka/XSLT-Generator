"""
EDIForge AI - Reference Structure Engine
Extracts loop patterns, segment order, and literals from training XSL maps.
"""
from __future__ import annotations
import os, re, json
from functools import lru_cache

_BASE_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "training", "xsl_maps")

def _read_xsl(path):
    try: return open(path, encoding="utf-8", errors="replace").read()
    except: return ""

def extract_loop_patterns(xsl):
    return [{"xpath": m.group(1)} for m in re.finditer(r'<xsl:for-each\s+select="([^"]+)"', xsl)]

def extract_segment_order(xsl):
    seen, order = set(), []
    for m in re.finditer(r"<(?:ns0:)?([A-Z][A-Z0-9]{1,3})[\s>]", xsl):
        seg = m.group(1)
        skip = {"FOR","IF","WHEN","OTHERWISE","CHOOSE","PARAM","WITH","CALL",
                "TEMPLATE","VARIABLE","VALUE","APPLY","OUTPUT","STYLESHEET"}
        if seg not in skip and seg not in seen:
            seen.add(seg); order.append(seg)
    return order

def extract_literals(xsl):
    lits = []
    for m in re.finditer(r"<([A-Z][A-Z0-9]{2,3})>([A-Z0-9]{1,6})</\1>", xsl):
        lits.append({"element": m.group(1), "value": m.group(2)})
    return lits

@lru_cache(maxsize=8)
def get_reference_structures(transaction_set):
    structs = []
    if not os.path.isdir(_BASE_DIR): return structs
    for fname in os.listdir(_BASE_DIR):
        if not fname.endswith(".xsl") or transaction_set not in fname: continue
        xsl = _read_xsl(os.path.join(_BASE_DIR, fname))
        if xsl:
            structs.append({
                "source_file":    fname,
                "loops":          extract_loop_patterns(xsl),
                "segment_order":  extract_segment_order(xsl),
                "literals":       extract_literals(xsl)[:15],
            })
    return structs

def get_common_loops(transaction_set):
    from collections import Counter
    structs = get_reference_structures(transaction_set)
    if not structs: return []
    counts = Counter()
    for s in structs:
        for lp in s.get("loops", []): counts[lp["xpath"]] += 1
    threshold = max(1, len(structs) // 3)
    return [xp for xp, c in counts.items() if c >= threshold]

def get_prompt_excerpt(transaction_set, max_chars=2000):
    structs = get_reference_structures(transaction_set)
    if not structs: return ""
    loops = get_common_loops(transaction_set)
    lines = [
        f"=== REFERENCE STRUCTURE ({len(structs)} production maps for {transaction_set}) ===",
        "Common loop patterns (use these for-each selects):",
    ]
    for lp in loops[:8]:
        lines.append(f'  <xsl:for-each select="{lp}">')
    base_path = os.path.join(_BASE_DIR, f"{transaction_set}_base.xsl")
    if os.path.exists(base_path):
        lits = extract_literals(_read_xsl(base_path))
        if lits:
            lines.append("Hardcoded literals from base map:")
            for lit in lits[:8]:
                lines.append(f"  <{lit['element']}>{lit['value']}</{lit['element']}>")
    return "\n".join(lines)[:max_chars]