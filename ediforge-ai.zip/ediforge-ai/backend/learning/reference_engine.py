"""
EDIForge AI v5 -- Reference Engine  (UPGRADED)
Structural skeleton comparison replaces SequenceMatcher.
Backward-compatible: save_reference_map() and similarity() still available.
"""
import os
from pathlib import Path
from typing import Optional, Tuple

BASE_DIR = Path(__file__).parent / "reference_maps"


def get_transaction_folder(transaction_set: str) -> Path:
    folder = BASE_DIR / transaction_set
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def save_reference_map(transaction_set: str, xslt: str) -> str:
    folder     = get_transaction_folder(transaction_set)
    file_count = len(list(folder.glob("*.xsl")))
    file_path  = folder / f"map_{file_count + 1}.xsl"
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(xslt)
    return str(file_path)


def find_best_reference(transaction_set: str, mapping_text: str) -> Tuple[Optional[str], float]:
    """Structural skeleton comparison -- replaces SequenceMatcher."""
    try:
        from backend.learning.structural_matcher import find_best_reference_structural
        return find_best_reference_structural(
            transaction_set=transaction_set,
            mapping_text=mapping_text,
            reference_dir=get_transaction_folder(transaction_set),
        )
    except ImportError:
        from difflib import SequenceMatcher
        folder = get_transaction_folder(transaction_set)
        best_score, best_map = 0.0, None
        for file in folder.glob("*.xsl"):
            try:
                content = file.read_text(encoding="utf-8")
                score   = SequenceMatcher(None, mapping_text, content).ratio()
                if score > best_score: best_score, best_map = score, content
            except Exception: continue
        return best_map, best_score


def similarity(a: str, b: str) -> float:
    """Structural similarity -- replaces SequenceMatcher.ratio()."""
    try:
        from backend.learning.structural_matcher import extract_xslt_skeleton, score_structural_similarity
        return score_structural_similarity(extract_xslt_skeleton(a), extract_xslt_skeleton(b))
    except ImportError:
        from difflib import SequenceMatcher
        return SequenceMatcher(None, a, b).ratio()


