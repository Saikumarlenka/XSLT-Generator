"""
EDIForge AI - Mapping Document Parser (FIXED v2)
Correctly extracts source, target, literal, condition, transform, value_map.
All IF/THEN rules, hardcoded literals, and value translation tables handled.
"""
import re
from typing import List, Optional, Dict

TRANSFORM_KEYWORDS = {
    "yyyymmdd":    "date_yyyymmdd",
    "format date": "date_yyyymmdd",
    "mmddyyyy":    "date_mmddyyyy",
    "remove comma":"decimal_no_comma",
    "no comma":    "decimal_no_comma",
    "uppercase":   "upper",
    "upper case":  "upper",
    "clean":       "clean_alpha",
    "normalize":   "clean_alpha",
}

_LITERAL_PATTERNS = [
    re.compile(r"hardcoded\s*[:\-=]?\s*['\u2019]?([A-Za-z0-9_\-./]+)['\u2019]?", re.IGNORECASE),
    re.compile(r"constant\s*[:\-=]?\s*['\u2019]?([A-Za-z0-9_\-./]+)['\u2019]?",  re.IGNORECASE),
    re.compile(r"literal\s*[:\-=]?\s*['\u2019]?([A-Za-z0-9_\-./]+)['\u2019]?",   re.IGNORECASE),
    re.compile(r"always\s+['\u2019]?([A-Za-z0-9_\-./]+)['\u2019]?",               re.IGNORECASE),
    re.compile(r"^['\"]([A-Za-z0-9_\-./]+)['\"]$"),
]


def normalize_target(target):
    if not target:
        return ""
    target = target.strip()
    if ":" in target:
        target = target.split(":")[-1]
    if "/" in target:
        target = target.split("/")[-1]
    return target.strip()


def extract_literal(source, rule=""):
    combined = (source or "") + " " + (rule or "")
    for pat in _LITERAL_PATTERNS:
        m = pat.search(combined)
        if m:
            val = m.group(1).strip().strip("'\"")
            if val:
                return val
    return None


def is_literal_row(source, rule=""):
    combined = ((source or "") + " " + (rule or "")).lower()
    return any(kw in combined for kw in ("hardcoded", "constant", "literal", "always "))


def clean_source(raw_source):
    if not raw_source:
        return ""
    s = raw_source.strip()
    if "/" in s or s.startswith("@"):
        return s
    for pat in _LITERAL_PATTERNS:
        if pat.match(s):
            return ""
    return s


def parse_condition(rule, source=""):
    if not rule:
        return None
    r_up = rule.strip().upper()
    if "IF" not in r_up:
        return None
    mv = re.search(r"IF\s+(\w+)\s*=\s*([A-Za-z0-9]+)\s+OR\s+([A-Za-z0-9]+)", r_up)
    if mv:
        field, v1, v2 = mv.group(1), mv.group(2), mv.group(3)
        return "@%s='%s' or @%s='%s'" % (field, v1, field, v2)
    sv = re.search(r"IF\s+([\w./]+)\s*[=!<>]+\s*['\"]?([A-Za-z0-9_.\-]+)['\"]?", r_up)
    if sv:
        field, val = sv.group(1), sv.group(2)
        return ("%s='%s'" % (source, val)) if source else ("@%s='%s'" % (field, val))
    if any(x in r_up for x in ("NOT EMPTY", "NOT NULL", "REQUIRED", "MANDATORY")):
        if source:
            return "%s != ''" % source
    return None


def extract_value_map(notes, rule):
    combined = ((notes or "") + " " + (rule or "")).strip()
    result = {}
    for m in re.finditer(r"([A-Za-z0-9_]+)\s*(?:->|=>|=|:)\s*([A-Za-z0-9_]+)", combined):
        k, v = m.group(1).strip(), m.group(2).strip()
        if k.lower() not in ("if","then","else","or","and","select","from"):
            result[k] = v
    return result


def detect_transform(rule, notes):
    combined = ((rule or "") + " " + (notes or "")).lower()
    for key, val in TRANSFORM_KEYWORDS.items():
        if key in combined:
            return val
    return None


def extract_mapping_rows_extended(parsed):
    rows = []
    for table in parsed.get("tables", []):
        table_rows = table.get("rows", [])
        if len(table_rows) < 2:
            continue
        header = [c.lower().strip() for c in table_rows[0]]
        source_idx = target_idx = rule_idx = notes_idx = -1
        for i, h in enumerate(header):
            if any(x in h for x in ("source", "canonical", "from")):
                source_idx = i
            elif any(x in h for x in ("target", "edi", "node name", "x12", "element")):
                target_idx = i
            elif any(x in h for x in ("rule", "logic", "ba comment", "comment", "mapping rule")):
                rule_idx = i
            elif "note" in h:
                notes_idx = i
        for row in table_rows[1:]:
            def cell(i):
                return row[i].strip() if 0 <= i < len(row) else ""
            raw_source = cell(source_idx)
            target     = cell(target_idx)
            rule       = cell(rule_idx)
            notes      = cell(notes_idx)
            if not target:
                continue
            if target.strip().lower() in ("node name","none","n/a","target","edi element",""):
                continue
            if re.match(r"^[\-=_\s]+$", target):
                continue
            target = normalize_target(target)
            if not target or not re.match(r"^[A-Za-z]", target):
                continue
            _is_literal = is_literal_row(raw_source, rule)
            literal     = extract_literal(raw_source, rule) if _is_literal else None
            source      = None if _is_literal else clean_source(raw_source)
            condition   = parse_condition(rule, source or "")
            transform   = detect_transform(rule, notes)
            value_map   = extract_value_map(notes, rule)
            rows.append({
                "source":      source or None,
                "target":      target,
                "literal":     literal,
                "_is_literal": _is_literal,
                "condition":   condition,
                "transform":   transform,
                "value_map":   value_map if value_map else None,
                "rule":        rule,
                "notes":       notes,
            })
    return rows


def build_transform_xpath(source, transform, condition=None):
    if not source:
        return ""
    source = source.strip()
    if not transform:
        return '<xsl:value-of select="%s"/>' % source
    t = transform.lower().strip()
    if t in ("date_yyyymmdd", "date"):
        expr = "concat(substring(%s,1,4),substring(%s,6,2),substring(%s,9,2))" % (source, source, source)
        return '<xsl:value-of select="%s"/>' % expr
    if t == "date_mmddyyyy":
        expr = "concat(substring(%s,6,2),substring(%s,9,2),substring(%s,1,4))" % (source, source, source)
        return '<xsl:value-of select="%s"/>' % expr
    if t in ("decimal_no_comma", "remove_comma"):
        return "<xsl:value-of select=\"translate(%s, ',', '')\"/>" % source
    if t == "decimal_nodot":
        return "<xsl:value-of select=\"translate(%s, '.', '')\"/>" % source
    if t == "upper":
        return ("<xsl:value-of select=\"translate(%s,"
                "'abcdefghijklmnopqrstuvwxyz',"
                "'ABCDEFGHIJKLMNOPQRSTUVWXYZ')\"/>" % source)
    if t == "clean_alpha":
        return ('<xsl:call-template name="CleanAlphaField">'
                '<xsl:with-param name="inputText" select="%s"/>'
                '<xsl:with-param name="maxLength" select="50"/>'
                '</xsl:call-template>' % source)
    return '<xsl:value-of select="%s"/>' % source