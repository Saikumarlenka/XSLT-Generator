"""EDIForge AI â€” Document Parser. Supports: .docx, .pdf, .xlsx, .csv, .txt, .xml"""
from pathlib import Path

def parse_file(file_path):
    path = Path(file_path)
    ext = path.suffix.lower()
    if ext == ".docx": return parse_docx(file_path)
    elif ext == ".pdf": return parse_pdf(file_path)
    elif ext in [".xlsx",".xls"]: return parse_excel(file_path)
    elif ext == ".csv": return parse_csv(file_path)
    else: return {"raw_text": path.read_text(encoding="utf-8",errors="replace"), "tables":[], "type":ext}

def _cell_is_struck(cell):
    """Return True if ALL text runs in a cell have strikethrough formatting."""
    from docx.oxml.ns import qn
    runs = []
    for para in cell.paragraphs:
        runs.extend(para.runs)
    if not runs:
        return False
    struck = 0
    for run in runs:
        rpr = run._r.find(qn("w:rPr"))
        if rpr is not None:
            strike = rpr.find(qn("w:strike"))
            dstrike = rpr.find(qn("w:dstrike"))
            if (strike is not None and strike.get(qn("w:val"), "true") != "false") or \
               (dstrike is not None and dstrike.get(qn("w:val"), "true") != "false"):
                struck += 1
    return struck > 0 and struck == len(runs)

def parse_docx(file_path):
    from docx import Document
    doc = Document(file_path)
    paragraphs = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
    tables = []
    for i, table in enumerate(doc.tables):
        rows = []
        for row in table.rows:
            cells = []
            for c in row.cells:
                text = c.text.strip().replace("\n", " ")
                if text and _cell_is_struck(c):
                    text = "[STRUCK] " + text
                cells.append(text)
            if any(c for c in cells): rows.append(cells)
        if rows: tables.append({"table_index":i,"rows":rows})
    return {"type":"docx","paragraphs":paragraphs,"tables":tables,
            "raw_text":"\n".join(paragraphs)+"\n"+_tables_to_text(tables)}

def parse_pdf(file_path):
    try: import pdfplumber
    except ImportError: raise ImportError("pip install pdfplumber")
    pages_text, tables = [], []
    with pdfplumber.open(file_path) as pdf:
        for pn, page in enumerate(pdf.pages):
            txt = page.extract_text() or ""
            if txt.strip(): pages_text.append(txt.strip())
            for ti, tbl in enumerate(page.extract_tables() or []):
                rows = [[str(c or "").strip() for c in row] for row in tbl if row]
                rows = [r for r in rows if any(c for c in r)]
                if rows: tables.append({"page":pn+1,"table_index":ti,"rows":rows})
    return {"type":"pdf","pages_text":pages_text,"tables":tables,
            "raw_text":"\n\n".join(pages_text)+"\n"+_tables_to_text(tables)}

def parse_excel(file_path):
    try: import openpyxl
    except ImportError: raise ImportError("pip install openpyxl")
    wb = openpyxl.load_workbook(file_path, data_only=True)
    tables = []
    for sheet in wb.sheetnames:
        ws = wb[sheet]
        rows = [[str(c or "").strip() for c in row] for row in ws.iter_rows(values_only=True)]
        rows = [r for r in rows if any(c for c in r)]
        if rows: tables.append({"sheet":sheet,"rows":rows})
    return {"type":"excel","tables":tables,"raw_text":_tables_to_text(tables)}

def parse_csv(file_path):
    import csv
    rows = []
    with open(file_path,"r",encoding="utf-8",errors="replace") as f:
        for row in csv.reader(f):
            if any(c.strip() for c in row): rows.append([c.strip() for c in row])
    return {"type":"csv","tables":[{"rows":rows}],"raw_text":_tables_to_text([{"rows":rows}])}

def _tables_to_text(tables):
    lines = []
    for t in tables:
        for row in t.get("rows",[]):
            lines.append(" | ".join(str(c) for c in row))
    return "\n".join(lines)

def extract_mapping_rows(parsed):
    """Smart extraction of mapping rows from parsed document."""
    rows = []
    for table in parsed.get("tables",[]):
        table_rows = table.get("rows",[])
        if len(table_rows) < 2: continue
        header = [c.lower() for c in table_rows[0]]
        src_col = tgt_col = rule_col = notes_col = -1
        for i, h in enumerate(header):
            if any(k in h for k in ["source","canonical","internal","node name"]) and src_col==-1: src_col=i
            elif any(k in h for k in ["target","x12","edi","segment"]) and tgt_col==-1: tgt_col=i
            elif any(k in h for k in ["comment","ba comment","rule"]): rule_col=i
            elif any(k in h for k in ["note","description"]): notes_col=i
        # Fallback for 5-column EDI matrix format
        if src_col==-1 and len(table_rows[0])>=5:
            tgt_col,rule_col,src_col,notes_col = 1,2,3,4
        for row in table_rows[1:]:
            s = row[src_col].strip() if src_col>=0 and src_col<len(row) else ""
            t = row[tgt_col].strip() if tgt_col>=0 and tgt_col<len(row) else ""
            r = row[rule_col].strip() if rule_col>=0 and rule_col<len(row) else ""
            n = row[notes_col].strip() if notes_col>=0 and notes_col<len(row) else ""
            if s or t: rows.append({"source":s,"target":t,"rule":r,"notes":n})
    return rows


# ---- Full Rule Pipeline integration (FIX 05) ----
def extract_mapping_rules_from_docx(file_path: str,
                                     transaction_set: str = "") -> list:
    """
    High-level entry point: parse DOCX mapping doc â†’ normalised rule list.
    Returns list of dicts with target/source/transform/condition/value_map.
    """
    try:
        from backend.engine.full_rule_pipeline import FullRulePipeline
        pipeline = FullRulePipeline()
        return pipeline.process_docx(file_path, transaction_set)
    except Exception as e:
        print(f"  Rule pipeline failed: {e}")
        return []
# ---- end full rule pipeline integration ----

