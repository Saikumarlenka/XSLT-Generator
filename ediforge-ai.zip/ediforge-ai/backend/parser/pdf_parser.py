"""EDIForge AI — PDF EDI Spec Parser. Extracts segments/elements from EDI spec PDFs."""
import sys, os, re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
from backend.core.ai_engine import call_ai, clean_json, ANALYSIS_SYSTEM

def parse_edi_spec_pdf(pdf_path: str) -> dict:
    """Parse an EDI specification PDF and extract segment/element definitions."""
    try:
        import pdfplumber
    except ImportError:
        raise ImportError("pip install pdfplumber")

    pages_text = []
    all_tables = []

    with pdfplumber.open(pdf_path) as pdf:
        for pn, page in enumerate(pdf.pages):
            txt = page.extract_text() or ""
            if txt.strip():
                pages_text.append({"page": pn+1, "text": txt.strip()})
            for ti, tbl in enumerate(page.extract_tables() or []):
                rows = [[str(c or "").strip() for c in row] for row in tbl if row]
                rows = [r for r in rows if any(c for c in r)]
                if rows:
                    all_tables.append({"page": pn+1, "table_index": ti, "rows": rows})

    # Extract EDI segments from tables
    segments = extract_edi_segments(all_tables)
    loops = detect_loops_from_spec(segments, pages_text)
    full_text = "\n\n".join(p["text"] for p in pages_text)

    # Use AI to enhance understanding
    ai_analysis = ai_analyze_spec(full_text[:5000], segments[:20])

    return {
        "type": "edi_spec_pdf",
        "page_count": len(pages_text),
        "raw_text": full_text,
        "segments": segments,
        "loops": loops,
        "ai_analysis": ai_analysis,
        "tables": all_tables
    }


def extract_edi_segments(tables: list) -> list:
    """Extract EDI segment definitions from PDF tables."""
    segments = {}

    for table in tables:
        rows = table.get("rows", [])
        if not rows: continue

        header = [c.lower() for c in rows[0]]
        seg_col = el_col = name_col = req_col = -1

        for i, h in enumerate(header):
            if any(k in h for k in ["seg","segment","id"]): seg_col = i
            elif any(k in h for k in ["element","elem","data element"]): el_col = i
            elif any(k in h for k in ["name","description","data name"]): name_col = i
            elif any(k in h for k in ["req","mandatory","usage","m/o"]): req_col = i

        if seg_col == -1: continue

        current_seg = ""
        for row in rows[1:]:
            seg_val = row[seg_col].strip() if seg_col < len(row) else ""
            if seg_val and re.match(r'^[A-Z0-9]{2,4}$', seg_val):
                current_seg = seg_val
            elif not seg_val and current_seg:
                seg_val = current_seg

            el_val   = row[el_col].strip() if el_col >= 0 and el_col < len(row) else ""
            name_val = row[name_col].strip() if name_col >= 0 and name_col < len(row) else ""
            req_val  = row[req_col].strip() if req_col >= 0 and req_col < len(row) else ""

            if current_seg:
                if current_seg not in segments:
                    segments[current_seg] = {"segment": current_seg, "elements": [], "required": req_val=="M"}
                if el_val:
                    segments[current_seg]["elements"].append({
                        "id": el_val,
                        "name": name_val,
                        "required": req_val in ["M","R","1"]
                    })

    return list(segments.values())


def detect_loops_from_spec(segments: list, pages_text: list) -> list:
    """Detect loop structures from spec text."""
    loops = []
    loop_pattern = re.compile(r'(LOOP[:\s]+([A-Z0-9]+))|([A-Z0-9]+)\s+LOOP', re.IGNORECASE)
    for page in pages_text:
        for match in loop_pattern.finditer(page["text"]):
            loop_name = match.group(2) or match.group(3)
            if loop_name and {"name": loop_name+"Loop"} not in loops:
                loops.append({"name": loop_name+"Loop", "segment": loop_name, "page": page["page"]})
    return loops


def ai_analyze_spec(spec_text: str, segments: list) -> dict:
    """Use AI to analyze the EDI spec and extract structured information."""
    prompt = f"""Analyze this EDI specification document excerpt.

EDI SPEC TEXT:
{spec_text}

SEGMENTS EXTRACTED: {[s['segment'] for s in segments]}

Return JSON:
{{
  "transaction_set": "e.g. 210",
  "transaction_name": "e.g. Motor Carrier Freight Details",
  "version": "e.g. X12_00401",
  "loops_detected": ["N1Loop","LXLoop"],
  "key_segments": ["ST","B3","N1","LX","L3","SE"],
  "source_format": "detected source system",
  "notes": "any important rules or conditions"
}}"""
    result = call_ai(prompt, ANALYSIS_SYSTEM)
    return clean_json(result)
