﻿"""EDIForge AI - Flask API Backend"""
import os, sys, tempfile
from pathlib import Path
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS

# v5 patches -- MUST be imported before any route uses MapGenerationPipeline
try:
    import backend.mapping.pipeline_v5_patches  # noqa -- applies accuracy patches on import
    print("  [app.py] v5 pipeline patches loaded")
except Exception as _v5_err:
    print(f"  [app.py] v5 patches not loaded: {_v5_err}")

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from backend.parser.doc_parser import parse_file
from backend.parser.mapping_doc_parser import extract_mapping_rows_extended
from backend.parser.pdf_parser import parse_edi_spec_pdf
from backend.schema.schema_reader import analyze_xsd_content, extract_from_xml
from backend.schema.schema_registry import (
    get_available_schemas, load_schema, get_schema_summary,
    detect_transaction_from_mapping
)
from backend.generator.xslt_generator import (
    generate_xslt, modify_xslt, analyze_mapping, generate_xslt_with_registry
)
from backend.validator.xslt_validator import validate_xslt_syntax, auto_fix_xslt
from backend.tester.transformation_runner import run_transformation

# FIX 15: Run all startup learning before Flask starts
try:
    from training.auto_learn_on_startup import learn_xslt_patterns_from_training_maps
    learn_xslt_patterns_from_training_maps()
    print("  [app.py] Startup XSLT pattern learning complete")
except Exception as _sle:
    print(f"  [app.py] Startup learning skipped: {_sle}")

app = Flask(__name__,
    static_folder=str(Path(__file__).parent.parent.parent / "frontend"),
    static_url_path="")
CORS(app)

OUTPUT_DIR = Path(__file__).parent.parent.parent / "output"
OUTPUT_DIR.mkdir(exist_ok=True)


# ---------------------------------------------------------------------------
# Core routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return send_file(Path(__file__).parent.parent.parent / "frontend" / "index.html")


@app.route("/health")
def health():
    from dotenv import load_dotenv
    load_dotenv()
    schemas = get_available_schemas()
    return jsonify({
        "status": "ok",
        "provider": os.getenv("AI_PROVIDER", "openrouter"),
        "model": os.getenv("AI_MODEL", "deepseek/deepseek-chat"),
        "fallback": os.getenv("FALLBACK_MODEL", "llama-3.3-70b-versatile"),
        "schemas_loaded": len(schemas),
        "available_schemas": [s["transaction"] for s in schemas],
        "version": "2.1.0"
    })


@app.route("/api/schemas")
def list_schemas():
    return jsonify({"schemas": get_available_schemas(), "count": len(get_available_schemas())})


@app.route("/api/schemas/<transaction_set>")
def get_schema(transaction_set):
    schema = load_schema(transaction_set)
    if "error" in schema:
        return jsonify(schema), 404
    return jsonify({
        "transaction_set": transaction_set,
        "segment_count": schema.get("segment_count", 0),
        "loop_count": schema.get("loop_count", 0),
        "loops": schema.get("loops", [])[:20],
        "segments": list(schema.get("segments", {}).keys())[:30]
    })


def _save_temp(file_storage, suffix=""):
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    file_storage.save(tmp.name)
    return tmp.name


def _read_text(file_storage):
    return file_storage.read().decode("utf-8", errors="replace")


def _safe_parse_schema(content, is_xsd=False):
    try:
        result = analyze_xsd_content(content) if is_xsd else extract_from_xml(content)
        if isinstance(result.get("elements"), list):
            result["elements"] = {
                e["path"]: e for e in result["elements"]
                if isinstance(e, dict) and "path" in e
            }
        return result
    except Exception as e:
        print(f"Schema parse error: {e}")
        return None


@app.route("/api/analyze", methods=["POST"])
def analyze():
    mapping_file = request.files.get("mapping_file")
    if not mapping_file:
        data = request.get_json(silent=True) or {}
        raw_text = data.get("content", "")
        mapping_rows = []
    else:
        suffix = Path(mapping_file.filename).suffix
        tmp = _save_temp(mapping_file, suffix)
        parsed = parse_file(tmp)
        raw_text = parsed.get("raw_text", "")
        mapping_rows = extract_mapping_rows_extended(parsed)
        os.unlink(tmp)

    if not raw_text:
        return jsonify({"error": "No content provided"}), 400

    result = analyze_mapping(raw_text, mapping_rows)
    result["mapping_rows_extracted"] = len(mapping_rows)

    ts = detect_transaction_from_mapping(raw_text)
    if ts:
        result["detected_transaction_set"] = ts
        schema = load_schema(ts)
        result["schema_info"] = {
            "segments": schema.get("segment_count", 0),
            "loops": schema.get("loop_count", 0),
            "loop_names": [l["name"] for l in schema.get("loops", [])[:10]]
        }
    return jsonify(result)


@app.route("/api/generate", methods=["POST"])
def generate():
    mapping_file    = request.files.get("mapping_file")
    canonical_file  = request.files.get("canonical_file")
    sample_xml_file = request.files.get("sample_xml_file")
    edi_spec_pdf    = request.files.get("edi_spec_pdf")

    source_ns       = request.form.get("source_ns", "")
    target_format   = request.form.get("target_format", "")
    transaction_set  = request.form.get("transaction_set", "")
    customer_profile = request.form.get("customer_profile", None)
    raw_content      = request.form.get("content", "")

    mapping_rows = []
    raw_mapping_text = ""
    source_schema = None

    if mapping_file:
        suffix = Path(mapping_file.filename).suffix
        tmp = _save_temp(mapping_file, suffix)
        parsed = parse_file(tmp)
        raw_mapping_text = parsed.get("raw_text", "")
        mapping_rows = extract_mapping_rows_extended(parsed)
        os.unlink(tmp)
    elif raw_content:
        raw_mapping_text = raw_content

    if not raw_mapping_text:
        return jsonify({"error": "No mapping document provided"}), 400

    if canonical_file:
        content = _read_text(canonical_file)
        source_schema = _safe_parse_schema(content, canonical_file.filename.lower().endswith(".xsd"))
    elif sample_xml_file:
        content = _read_text(sample_xml_file)
        source_schema = _safe_parse_schema(content, False)

    spec_info = None
    if edi_spec_pdf:
        suffix = Path(edi_spec_pdf.filename).suffix
        tmp = _save_temp(edi_spec_pdf, suffix)
        try:
            spec_info = parse_edi_spec_pdf(tmp)
            if not transaction_set and spec_info.get("ai_analysis"):
                transaction_set = spec_info["ai_analysis"].get("transaction_set", "")
        except Exception as e:
            print(f"PDF parse error: {e}")
        finally:
            os.unlink(tmp)

    if not transaction_set:
        transaction_set = detect_transaction_from_mapping(raw_mapping_text)

    try:
        print(f"Generating XSLT for transaction set: {transaction_set or 'unknown'}")

        # Training auto-sync happens inside generate_xslt_with_registry -> get_rag_context
        xslt, detected_ts, schema_info = generate_xslt_with_registry(
            mapping_rows=mapping_rows,
            source_schema=source_schema,
            raw_mapping_text=raw_mapping_text,
            source_ns=source_ns,
            target_format=target_format,
            transaction_set=transaction_set,
            customer_profile=customer_profile
        )

        validation = validate_xslt_syntax(xslt)

        fix_result = None
        if not validation["valid"]:
            print(f"XSLT invalid, auto-fixing: {validation['error']}")
            fix_result = auto_fix_xslt(xslt)
            if fix_result["success"]:
                xslt = fix_result["xslt"]
                validation = fix_result["validation"]

        (OUTPUT_DIR / "generated.xsl").write_text(xslt, encoding="utf-8")

        # Run sample XML test if provided
        sample_test = None
        _ts_final = detected_ts or transaction_set
        if sample_xml_file and xslt:
            try:
                from backend.tester.transformation_runner import run_and_validate
                sample_xml_file.stream.seek(0)
                _sx = sample_xml_file.read().decode("utf-8", errors="replace")
                sample_test = run_and_validate(xslt, _sx, transaction_set=_ts_final)
                print("Sample XML test: %s" % sample_test.get("summary",""))
            except Exception as _te:
                sample_test = {"passed": False, "summary": "Test error: %s" % str(_te)}

        # Quality validation against training patterns
        quality_report = None
        if xslt and _ts_final:
            try:
                from backend.validator.xslt_quality_validator import validate_generated_xslt
                quality_report = validate_generated_xslt(xslt, _ts_final)
                print("Quality check: %s" % quality_report.get("summary",""))
            except Exception as _qe:
                quality_report = {"passed": False, "summary": "Quality check error: %s" % str(_qe)}

        return jsonify({
            "xslt":            xslt,
            "validation":      validation,
            "fix_applied":     fix_result is not None and fix_result.get("success"),
            "fix_attempts":    fix_result.get("attempts", 0) if fix_result else 0,
            "fix_history":     fix_result.get("fix_history", []) if fix_result else [],
            "mapping_rows":    len(mapping_rows),
            "schema_source":   "uploaded" if canonical_file else ("inferred" if sample_xml_file else "none"),
            "transaction_set": _ts_final,
            "edi_schema_used": bool(_ts_final),
            "edi_schema_info": {
                "segments": schema_info.get("segment_count", 0),
                "loops":    schema_info.get("loop_count", 0),
            } if schema_info else None,
            "spec_info":       spec_info.get("ai_analysis") if spec_info else None,
            "sample_xml_test": sample_test,
            "quality_report":  quality_report,
            "status":          "success",
        })

    except Exception as e:
        import traceback
        print(traceback.format_exc())
        return jsonify({"error": str(e)}), 500


@app.route("/api/modify", methods=["POST"])
def modify():
    data = request.get_json(silent=True) or {}
    existing_xslt    = data.get("existing_xslt", "")
    change_doc       = data.get("change_doc", "")
    canonical_schema = data.get("canonical_schema", "")
    edi_schema       = data.get("edi_schema", "")
    transaction_set  = data.get("transaction_set", "")

    if not existing_xslt:
        return jsonify({"error": "existing_xslt required"}), 400
    if not change_doc:
        return jsonify({"error": "change_doc required"}), 400

    source_schema = _safe_parse_schema(canonical_schema, False) \
        if canonical_schema and "<" in canonical_schema else None

    if not transaction_set:
        transaction_set = detect_transaction_from_mapping(change_doc)

    edi_schema_text = get_schema_summary(transaction_set) if transaction_set else ""

    try:
        from backend.core.ai_engine import call_ai, clean_xslt, XSLT_SYSTEM
        prompt = f"""Update the existing XSLT based on the change document.

=== EXISTING XSLT (keep everything not mentioned in changes) ===
{existing_xslt}

=== CHANGE DOCUMENT ===
{change_doc}

{edi_schema_text[:3000] if edi_schema_text else ''}

RULES:
- Keep ALL existing templates not mentioned
- Apply ALL new/changed mappings
- Mark changes: <!-- UPDATED: reason -->
- Output complete XSLT only"""

        xslt = clean_xslt(call_ai(prompt, XSLT_SYSTEM))
        validation = validate_xslt_syntax(xslt)

        fix_result = None
        if not validation["valid"]:
            fix_result = auto_fix_xslt(xslt)
            if fix_result["success"]:
                xslt = fix_result["xslt"]
                validation = fix_result["validation"]

        return jsonify({
            "xslt": xslt,
            "validation": validation,
            "fix_applied": fix_result is not None and fix_result.get("success"),
            "status": "success"
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/validate", methods=["POST"])
def validate():
    data = request.get_json(silent=True) or {}
    xslt = data.get("xslt", "")
    if not xslt:
        return jsonify({"error": "xslt required"}), 400
    return jsonify(validate_xslt_syntax(xslt))


@app.route("/api/fix", methods=["POST"])
def fix():
    data = request.get_json(silent=True) or {}
    xslt = data.get("xslt", "")
    max_retries = int(data.get("max_retries", 3))
    if not xslt:
        return jsonify({"error": "xslt required"}), 400
    return jsonify(auto_fix_xslt(xslt, max_retries))


@app.route("/api/test", methods=["POST"])
def test():
    data = request.get_json(silent=True) or {}
    xslt = data.get("xslt", "")
    xml  = data.get("xml", "")
    if not xslt: return jsonify({"error": "xslt required"}), 400
    if not xml:  return jsonify({"error": "xml required"}), 400
    return jsonify(run_transformation(xslt, xml))


@app.route("/api/parse-spec", methods=["POST"])
def parse_spec():
    pdf_file = request.files.get("pdf_file")
    if not pdf_file:
        return jsonify({"error": "pdf_file required"}), 400
    tmp = _save_temp(pdf_file, ".pdf")
    try:
        result = parse_edi_spec_pdf(tmp)
        return jsonify({
            "segments": result.get("segments", []),
            "loops": result.get("loops", []),
            "ai_analysis": result.get("ai_analysis", {}),
            "page_count": result.get("page_count", 0),
            "status": "success"
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        os.unlink(tmp)


# ---------------------------------------------------------------------------
# Internal Training API  (background use - not linked in the UI)
# ---------------------------------------------------------------------------

@app.route("/api/training/status")
def training_status():
    """Returns current index stats. Used internally."""
    try:
        from training.training_manager import get_status
        return jsonify(get_status())
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/training/upload", methods=["POST"])
def training_upload():
    """
    Accept new XSL training maps, save them, and rebuild the index.
    Files can be dropped directly into training/xsl_maps/ on the server
    instead of uploading through this endpoint - the auto-sync will pick
    them up automatically on the next generation request.
    """
    try:
        from training.training_manager import save_xsl_map, rebuild_index
        files = request.files.getlist("xsl_files")
        if not files:
            return jsonify({"error": "No xsl_files provided"}), 400

        saved = []
        for f in files:
            result = save_xsl_map(f.filename, f.read())
            saved.append(result["saved"])

        # Rebuild index with the newly added files
        stats = rebuild_index(force=True)
        return jsonify({
            "status":       "success",
            "saved":        saved,
            "maps_indexed": stats["maps_indexed"],
            "built_at":     stats["built_at"],
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/training/rebuild", methods=["POST"])
def training_rebuild():
    """Force a full index rebuild."""
    try:
        from training.training_manager import rebuild_index
        stats = rebuild_index(force=True)
        return jsonify(stats)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/training/delete/<path:filename>", methods=["DELETE"])
def training_delete(filename):
    """Remove a training map and rebuild the index."""
    try:
        from training.training_manager import delete_xsl_map
        result = delete_xsl_map(filename)
        if "error" in result:
            return jsonify(result), 404
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/training/preview", methods=["POST"])
def training_preview():
    """Preview which training maps would be retrieved for a given mapping snippet."""
    try:
        from training.training_manager import get_top_matches
        data = request.get_json(silent=True) or {}
        text = data.get("text", "")
        txn  = data.get("transaction_set", "")
        if not text:
            return jsonify({"error": "text required"}), 400
        matches = get_top_matches(text, txn, top_k=5)
        return jsonify({"matches": matches, "count": len(matches)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ---------------------------------------------------------------------------
# App entry point
# ---------------------------------------------------------------------------

# =============================================================================
# EDIForge AI v2 -- Schema-driven pipeline endpoints
# =============================================================================

@app.route("/api/v2/generate", methods=["POST"])
def generate_v2():
    """v2 endpoint -- full schema-driven pipeline with accuracy score."""
    mapping_file    = request.files.get("mapping_file")
    canonical_file  = request.files.get("canonical_file")
    sample_xml_file = request.files.get("sample_xml_file")
    source_ns       = request.form.get("source_ns", "")
    target_format   = request.form.get("target_format", "")
    transaction_set  = request.form.get("transaction_set", "")
    customer_profile = request.form.get("customer_profile", None)
    raw_content      = request.form.get("content", "")
    mapping_rows = []; raw_mapping_text = ""; source_schema = None
    if mapping_file:
        suffix = Path(mapping_file.filename).suffix
        tmp = _save_temp(mapping_file, suffix)
        parsed = parse_file(tmp); raw_mapping_text = parsed.get("raw_text", "")
        mapping_rows = extract_mapping_rows_extended(parsed); os.unlink(tmp)
    elif raw_content:
        raw_mapping_text = raw_content
    if not raw_mapping_text:
        return jsonify({"error": "No mapping document provided"}), 400
    if canonical_file:
        content = _read_text(canonical_file)
        source_schema = _safe_parse_schema(content, canonical_file.filename.lower().endswith(".xsd"))
    elif sample_xml_file:
        content = _read_text(sample_xml_file)
        source_schema = _safe_parse_schema(content, False)
    if not transaction_set:
        transaction_set = detect_transaction_from_mapping(raw_mapping_text)
    try:
        from backend.mapping.pipeline import MapGenerationPipeline
        result = MapGenerationPipeline().run(
            mapping_rows=mapping_rows, raw_mapping_text=raw_mapping_text,
            source_schema=source_schema, source_ns=source_ns,
            target_format=target_format, transaction_set=transaction_set,
        )
        xslt = result["xslt"]
        validation = validate_xslt_syntax(xslt)
        fix_result = None
        if not validation["valid"]:
            fix_result = auto_fix_xslt(xslt)
            if fix_result["success"]:
                xslt = fix_result["xslt"]; validation = fix_result["validation"]
        (OUTPUT_DIR / "generated.xsl").write_text(xslt, encoding="utf-8")
        return jsonify({
            "xslt": xslt, "validation": validation,
            "fix_applied": fix_result is not None and fix_result.get("success"),
            "mapping_rows": len(mapping_rows),
            "schema_source": "uploaded" if canonical_file else ("inferred" if sample_xml_file else "none"),
            "transaction_set": result["transaction_set"],
            "accuracy": result["accuracy"],
            "pipeline_log": result["pipeline_log"],
            "consistency": result["consistency_report"],
            "loops_detected": result["loop_map"],
            "engine": "v5-deterministic",
            "used_base_map": result.get("used_base_map", False),
            "xslt_errors":   result.get("xslt_errors", []),
        })
    except Exception as e:
        import traceback; print(traceback.format_exc())
        return jsonify({"error": str(e)}), 500


@app.route("/api/v2/learn", methods=["POST"])
def learn():
    """Record a correction: {"field": "BillOfLading", "source": "B3/B303"}"""
    data = request.get_json(silent=True) or {}
    field = (data.get("field") or "").strip(); source = (data.get("source") or "").strip()
    confidence = float(data.get("confidence", 1.0))
    if not field or not source:
        return jsonify({"error": "field and source are required"}), 400
    try:
        from backend.learning.learning_engine import LearningEngine
        learner = LearningEngine()
        learner.learn(field, source, confidence)
        return jsonify({"status": "learned", "field": field, "source": source, "stats": learner.stats()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/v2/learn/stats")
def learn_stats():
    try:
        from backend.learning.learning_engine import LearningEngine
        learner = LearningEngine()
        return jsonify({"stats": learner.stats(), "knowledge": learner.get_all()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/v2/schema/inspect", methods=["POST"])
def schema_inspect():
    """Upload schema -- get full path index and tree, no 120-element cap."""
    schema_file = request.files.get("schema_file")
    if schema_file:
        content = _read_text(schema_file); is_xsd = schema_file.filename.lower().endswith(".xsd")
    else:
        data = request.get_json(silent=True) or {}
        content = data.get("content", ""); is_xsd = data.get("is_xsd", False)
    if not content:
        return jsonify({"error": "schema_file or content required"}), 400
    try:
        schema = _safe_parse_schema(content, is_xsd)
        from backend.schema.canonical_index import get_all_canonical_paths, build_canonical_index
        from backend.schema.canonical_tree import build_tree, print_tree
        all_paths = get_all_canonical_paths(schema)
        index = build_canonical_index(schema)
        tree = build_tree(schema)
        return jsonify({
            "total_paths": len(all_paths), "paths": all_paths,
            "index_keys": list(index.keys()),
            "loops": schema.get("loops", []) if schema else [],
            "tree_preview": print_tree(tree)[:3000],
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/v2/consistency", methods=["POST"])
def check_consistency_endpoint():
    """Validate mapping rows against canonical schema without generating XSLT."""
    data = request.get_json(silent=True) or {}
    mapping_rows = data.get("mapping_rows", []); canonical_paths = data.get("canonical_paths", [])
    if not mapping_rows:
        return jsonify({"error": "mapping_rows required"}), 400
    try:
        from backend.mapping.consistency_checker import check_consistency
        return jsonify(check_consistency(mapping_rows, canonical_paths or None))
    except Exception as e:
        return jsonify({"error": str(e)}), 500



@app.route("/api/v2/correct", methods=["POST"])
def correct_mapping():
    """User correction -> self-learning engine with max confidence."""
    data           = request.get_json(silent=True) or {}
    field          = data.get("field", "").strip()
    wrong_source   = data.get("wrong_source", "").strip()
    correct_source = data.get("correct_source", "").strip()
    if not field or not correct_source:
        return jsonify({"error": "field and correct_source are required"}), 400
    try:
        from backend.learning.learning_engine import LearningEngine
        learner = LearningEngine()
        learner.record_correction(field, wrong_source, correct_source)
        return jsonify({
            "status":  "learned",
            "field":   field,
            "source":  correct_source,
            "message": f"Correction recorded - future maps will use {correct_source} for {field}",
            "stats":   learner.stats(),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()

    # Kick off background training auto-sync before serving requests
    try:
        from training.training_manager import initialize
        initialize()
    except Exception as e:
        print(f"[Training] Could not start background init: {e}")

    port = int(os.getenv("PORT", 5000))
    schemas = get_available_schemas()
    print(f"""
EDIForge AI v2.1
URL: http://localhost:{port}
Provider: {os.getenv('AI_PROVIDER','openrouter').upper()}
Schemas: {', '.join(s['transaction'] for s in schemas)}
Training: background auto-sync enabled
    """)
    app.run(host="0.0.0.0", port=port, debug=os.getenv("FLASK_DEBUG","false")=="true")







# =============================================================================
# EDIForge AI v4 -- API Routes
# =============================================================================

@app.route("/api/v4/basemaps")
def v4_list_basemaps():
    from backend.schema.reference_template_engine import list_available_base_maps
    maps = list_available_base_maps()
    return jsonify({"base_maps": maps, "count": len(maps),
                    "tip": "Add 210_base.xsl/214_base.xsl/990_base.xsl to training/base_maps/"})


@app.route("/api/v4/learn", methods=["POST"])
def v4_trigger_learning():
    from backend.mapping.self_learning_engine import learn_all_maps
    return jsonify({"status":"ok","result": learn_all_maps()})


@app.route("/api/v4/dual-schema/<transaction_set>")
def v4_dual_schema(transaction_set):
    from backend.schema.dual_schema_index import (
        build_canonical_index_from_xsd, build_edi_index, detect_repeating_nodes
    )
    can_index  = build_canonical_index_from_xsd(transaction_set)
    edi_index  = build_edi_index(transaction_set)
    loops      = detect_repeating_nodes(transaction_set)
    return jsonify({
        "transaction_set":   transaction_set,
        "canonical_fields":  len(can_index),
        "edi_elements":      len(edi_index),
        "repeating_nodes":   loops,
        "canonical_sample":  dict(list(can_index.items())[:10]),
        "edi_sample":        dict(list(edi_index.items())[:10]),
    })


@app.route("/api/v4/generate", methods=["POST"])
def v4_generate():
    import tempfile, os as _os
    from pathlib import Path as _Path
    from backend.parser.doc_parser import parse_file
    from backend.parser.mapping_doc_parser import extract_mapping_rows_extended
    from backend.schema.schema_reader import analyze_xsd_content
    from backend.schema.schema_registry import detect_transaction_from_mapping
    from backend.mapping.pipeline import MapGenerationPipeline
    from backend.validator.xslt_validator import validate_xslt_syntax, auto_fix_xslt

    mapping_file       = request.files.get("mapping_file")
    canonical_file     = request.files.get("canonical_file")
    transaction_set    = request.form.get("transaction_set","")
    source_ns          = request.form.get("source_ns","")
    target_format      = request.form.get("target_format","")
    use_ai             = request.form.get("use_ai","true").lower() != "false"

    if not mapping_file:
        return jsonify({"error":"mapping_file required"}), 400

    suffix = _Path(mapping_file.filename).suffix
    tmp    = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    mapping_file.save(tmp.name)
    parsed = parse_file(tmp.name)
    _os.unlink(tmp.name)

    raw_text     = parsed.get("raw_text","")
    mapping_rows = extract_mapping_rows_extended(parsed)

    source_schema = None
    if canonical_file:
        content       = canonical_file.read().decode("utf-8", errors="replace")
        source_schema = analyze_xsd_content(content)

    if not transaction_set and raw_text:
        transaction_set = detect_transaction_from_mapping(raw_text)

    result = MapGenerationPipeline().run(
        mapping_rows=mapping_rows, raw_mapping_text=raw_text,
        source_schema=source_schema, source_ns=source_ns,
        target_format=target_format, transaction_set=transaction_set,
        use_ai_for_pairs=use_ai, use_ai_scaffold=use_ai,
    )
    xslt       = result["xslt"]
    validation = validate_xslt_syntax(xslt)
    fix_result = None
    if not validation["valid"]:
        fix_result = auto_fix_xslt(xslt)
        if fix_result["success"]:
            xslt = fix_result["xslt"]; validation = fix_result["validation"]

    out_path = _Path("output") / "generated_v4.xsl"
    out_path.parent.mkdir(exist_ok=True)
    out_path.write_text(xslt, encoding="utf-8")

    return jsonify({
        "xslt":               xslt[:3000]+"..." if len(xslt)>3000 else xslt,
        "xslt_length":        len(xslt),
        "pipeline_log":       result["pipeline_log"],
        "accuracy":           result["accuracy"],
        "transaction_set":    result["transaction_set"],
        "loops_detected":     result["loop_map"],
        "reference_template": result["reference_template"],
        "validation":         validation,
        "fix_applied":        bool(fix_result and fix_result.get("success")),
        "download_url":       "/api/download/generated_v4.xsl",
        "status":             "success",
    })


# ---- EDIForge v4 accuracy patch: send XSLT as UTF-8 ----
from flask import make_response as _make_response

def _wrap_xslt_response(xsl_str):
    """Return XSLT as UTF-8 bytes with correct Content-Type."""
    if isinstance(xsl_str, str):
        data = xsl_str.encode("utf-8")
    else:
        data = xsl_str
    resp = _make_response(data)
    resp.headers["Content-Type"] = "application/xml; charset=utf-8"
    return resp
# ---- end accuracy patch ----


# =============================================================================
# EDIForge AI v5 -- Additional API Endpoints
# =============================================================================

@app.route("/api/v5/bootstrap", methods=["POST"])
def v5_bootstrap():
    """
    Bootstrap field intelligence from all training XSL maps.
    Call once after install or after adding new training maps.
    POST /api/v5/bootstrap
    POST /api/v5/bootstrap  body: {"force": true}  -- re-bootstrap even if already done
    """
    try:
        from backend.learning.field_intelligence_store import bootstrap_all_transaction_sets
        data  = request.get_json(silent=True) or {}
        force = bool(data.get("force", False))
        result = bootstrap_all_transaction_sets(force=force)
        return jsonify({"status": "ok", "result": result,
                        "tip": "Field intelligence now active -- accuracy improved"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/v5/intelligence/<transaction_set>")
def v5_intelligence_stats(transaction_set):
    """Inspect field intelligence store stats for a transaction set."""
    try:
        from backend.learning.field_intelligence_store import get_store
        store    = get_store(transaction_set)
        mappings = store.all_mappings()
        return jsonify({
            "transaction_set": transaction_set,
            "stats":    store.stats(),
            "mappings": mappings,
            "count":    len(mappings),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/v5/validate-xslt", methods=["POST"])
def v5_validate_xslt():
    """Validate an XSLT against required EDI segment rules."""
    try:
        from backend.generator.deterministic_generator import validate_xslt_structure
        data  = request.get_json(silent=True) or {}
        xslt  = data.get("xslt","")
        ts    = data.get("transaction_set","210")
        if not xslt:
            return jsonify({"error": "xslt required"}), 400
        errors = validate_xslt_structure(xslt, ts)
        return jsonify({"valid": len(errors)==0, "errors": errors, "transaction_set": ts})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/v5/loop-model/<transaction_set>")
def v5_loop_model(transaction_set):
    """Return the expected loop model for a transaction set."""
    try:
        from backend.mapping.loop_hierarchy_engine import build_loop_model
        model = build_loop_model([], transaction_set)
        return jsonify({"transaction_set": transaction_set, "loops": model})
    except Exception as e:
        return jsonify({"error": str(e)}), 500




