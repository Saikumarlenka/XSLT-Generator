"""
EDIForge AI - Condition Engine (FIXED v2)
Wraps XSL content with xsl:if / xsl:choose based on mapping rules.
"""
from __future__ import annotations
import re
from typing import Optional


class ConditionEngine:

    def wrap_if_not_empty(self, xpath, inner_xml, indent="\t\t\t\t"):
        return '%s<xsl:if test="%s != \'\'">\n%s\t%s\n%s</xsl:if>' % (
            indent, xpath, indent, inner_xml, indent)

    def wrap_if(self, test_expr, inner_xml, indent="\t\t\t\t"):
        return '%s<xsl:if test="%s">\n%s\t%s\n%s</xsl:if>' % (
            indent, test_expr, indent, inner_xml, indent)

    def wrap_if_length(self, xpath, min_len, inner_xml, indent="\t\t\t\t"):
        return '%s<xsl:if test="string-length(%s) &gt;= %d">\n%s\t%s\n%s</xsl:if>' % (
            indent, xpath, min_len, indent, inner_xml, indent)

    def wrap_if_positive(self, xpath, inner_xml, indent="\t\t\t\t"):
        return ('%s<xsl:if test="%s != \'\' and %s &gt; 0">\n%s\t%s\n%s</xsl:if>' %
                (indent, xpath, xpath, indent, inner_xml, indent))

    def auto_wrap(self, xpath, transform, inner_xml, indent="\t\t\t\t"):
        t = (transform or "").lower()
        if t in ("date_yyyymmdd", "date", "date_mmddyyyy"):
            return self.wrap_if_length(xpath, 8, inner_xml, indent)
        if t in ("decimal", "decimal_nodot", "remove_comma", "decimal_no_comma"):
            return self.wrap_if_length(xpath, 1, inner_xml, indent)
        return self.wrap_if_not_empty(xpath, inner_xml, indent)

    @staticmethod
    def parse_condition_from_rule(rule, xpath):
        if not rule:
            return None
        r_up = rule.strip().upper()
        if any(x in r_up for x in ("NOT EMPTY", "NOT NULL", "REQUIRED", "MANDATORY")):
            return "%s != ''" % xpath if xpath else None
        if "> 0" in r_up or "POSITIVE" in r_up:
            return "%s != '' and %s &gt; 0" % (xpath, xpath) if xpath else None
        mv = re.search(
            r"IF\s+([\w@./]+)\s*=\s*([A-Za-z0-9]+)\s+OR\s+([A-Za-z0-9]+)", r_up)
        if mv:
            field, v1, v2 = mv.group(1), mv.group(2), mv.group(3)
            return "@%s='%s' or @%s='%s'" % (field, v1, field, v2)
        sv = re.search(
            r"IF\s+([\w@./]+)\s*[=!<>]+\s*['\"]?([A-Za-z0-9_.\-]+)['\"]?", r_up)
        if sv:
            field, val = sv.group(1), sv.group(2)
            return ("%s='%s'" % (xpath, val)) if xpath else ("@%s='%s'" % (field, val))
        return None

    @staticmethod
    def build_condition_test(xpath, transform, explicit_condition=None):
        if explicit_condition:
            return explicit_condition
        t = (transform or "").lower()
        if t in ("date_yyyymmdd", "date", "date_mmddyyyy"):
            return "string-length(%s) &gt;= 8" % xpath
        if t in ("decimal", "decimal_nodot", "remove_comma", "decimal_no_comma"):
            return "string-length(%s) &gt;= 1" % xpath
        return "%s != ''" % xpath


_condition_engine = ConditionEngine()


def auto_wrap_condition(xpath, transform, inner_xml, indent="\t\t\t\t"):
    return _condition_engine.auto_wrap(xpath, transform, inner_xml, indent)


def build_condition_test(xpath, transform, explicit_condition=None):
    return ConditionEngine.build_condition_test(xpath, transform, explicit_condition)