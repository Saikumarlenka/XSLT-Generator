"""
EDIForge AI â€” Rule Normalizer
Cleans and standardises raw rules extracted from mapping documents.
Handles inconsistencies introduced by AI or OCR parsing.
"""
from __future__ import annotations
import re
from typing import List, Optional


# Canonical transform names
TRANSFORM_ALIASES = {
    "date":           "date_yyyymmdd",
    "yyyymmdd":       "date_yyyymmdd",
    "format date":    "date_yyyymmdd",
    "mmddyyyy":       "date_mmddyyyy",
    "remove comma":   "decimal",
    "no comma":       "decimal",
    "remove decimal": "decimal_nodot",
    "clean":          "clean_alpha",
    "alpha":          "clean_alpha",
    "upper":          "uppercase",
    "lower":          "lowercase",
    "trim":           "trim",
    "normalize":      "trim",
}

# Canonical condition names
CONDITION_ALIASES = {
    "not empty":   "not_empty",
    "not null":    "not_empty",
    "required":    "not_empty",
    "mandatory":   "not_empty",
    "if exists":   "not_empty",
    "always":      "always",
    "optional":    "optional",
}


def _norm_transform(val: Optional[str]) -> Optional[str]:
    if not val:
        return None
    v = val.strip().lower()
    return TRANSFORM_ALIASES.get(v, v if v else None)


def _norm_condition(val: Optional[str]) -> str:
    if not val:
        return "not_empty"
    v = val.strip().lower()
    return CONDITION_ALIASES.get(v, "not_empty")


def _norm_target(val: Optional[str]) -> str:
    if not val:
        return ""
    # Remove ns0: prefix
    v = re.sub(r'^ns0:', '', str(val).strip())
    # Keep only last segment if "/" present
    if "/" in v:
        v = v.split("/")[-1]
    return v.strip()


def _norm_source(val: Optional[str]) -> str:
    if not val:
        return ""
    v = str(val).strip()
    # Remove surrounding quotes
    v = v.strip().strip('"').strip("'")
    # Reject obviously invalid values
    bad = ("hardcoded", "constant", "literal", "n/a", "tbd", "see notes")
    if any(b in v.lower() for b in bad):
        return ""
    return v


def normalize_rule(raw: dict) -> dict:
    """
    Normalise a single raw rule dict into the canonical format:
    {target, source, condition, transform, loop, segment, qualifier, value_map, literal}
    """
    rule: dict = {}

    # target
    rule["target"] = _norm_target(
        raw.get("target") or raw.get("edi field") or raw.get("edi_field")
        or raw.get("element") or ""
    )

    # source
    raw_src = (
        raw.get("source") or raw.get("canonical") or raw.get("xpath")
        or raw.get("canonical path") or raw.get("source path") or ""
    )
    rule["source"] = _norm_source(str(raw_src))

    # literal detection
    lit_keys = ("hardcoded", "constant", "literal", "hard coded value")
    lit_val = None
    for k in lit_keys:
        if k in raw:
            lit_val = raw[k]
            break
    if not rule["source"] and raw.get("notes"):
        notes_up = str(raw.get("notes", "")).upper()
        if "HARDCODED" in notes_up or "CONSTANT" in notes_up:
            m = re.search(r"[\"'\"](.*?)[\"'\"]", raw["notes"])
            if m:
                lit_val = m.group(1)
    rule["literal"] = lit_val

    # condition
    rule["condition"] = _norm_condition(
        raw.get("condition") or raw.get("rule") or raw.get("notes")
    )

    # transform
    rule["transform"] = _norm_transform(
        raw.get("transform") or raw.get("format") or raw.get("conversion")
    )
    # Auto-detect transform from notes
    if not rule["transform"] and raw.get("notes"):
        notes_l = str(raw.get("notes", "")).lower()
        for alias, canon in TRANSFORM_ALIASES.items():
            if alias in notes_l:
                rule["transform"] = canon
                break

    # loop
    rule["loop"] = raw.get("loop") or raw.get("loop name") or None

    # segment
    rule["segment"] = (raw.get("segment") or "").strip() or None

    # qualifier
    rule["qualifier"] = (raw.get("qualifier") or raw.get("qualifier code") or "").strip() or None

    # value_map
    vm = raw.get("value_map") or raw.get("value map") or {}
    if isinstance(vm, str):
        try:
            import json
            vm = json.loads(vm)
        except Exception:
            vm = {}
    rule["value_map"] = vm if isinstance(vm, dict) else {}

    return rule


def normalize_rules(raw_rules: list) -> list:
    """Normalise a list of raw rule dicts."""
    normalized = []
    for r in raw_rules:
        try:
            n = normalize_rule(r)
            # Skip completely empty rules
            if n.get("target") or n.get("source") or n.get("literal"):
                normalized.append(n)
        except Exception:
            pass
    return normalized
