"""
EDIForge AI â€” Rule Interpreter
Converts structured JSON rules into XSL XML fragments.
Used by the full_rule_pipeline to assemble the final XSLT.
"""
from __future__ import annotations
from typing import Optional


class RuleInterpreter:

    def interpret(self, rule: dict, indent: str = "\t\t\t\t") -> str:
        """Convert a single normalised rule into an XSL XML fragment string."""
        from backend.mapping.transform_engine import build_xslt_expression, build_condition
        from backend.engine.value_mapping_engine import ValueMappingEngine
        from backend.engine.qualifier_engine import qualify_xpath

        target    = rule.get("target", "")
        source    = rule.get("source", "")
        literal   = rule.get("literal")
        transform = rule.get("transform")
        condition = rule.get("condition", "not_empty")
        value_map = rule.get("value_map") or {}
        qualifier = rule.get("qualifier")
        segment   = rule.get("segment")

        if not target:
            return ""

        i = indent

        # â”€â”€ Literal (hardcoded) value â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        if literal is not None:
            return f"{i}<{target}>{literal}</{target}>"

        if not source:
            return ""

        # Apply qualifier to source if needed
        if qualifier and segment:
            source = qualify_xpath(segment, qualifier, source)

        # Build value expression
        if value_map:
            vme = ValueMappingEngine()
            val_xml = vme.build_choose(source, value_map, indent=i + "\t")
        else:
            val_xml = build_xslt_expression(source, transform)

        # Build condition test
        if condition == "always":
            return (
                f"{i}<{target}>\n"
                f"{i}\t{val_xml}\n"
                f"{i}</{target}>"
            )
        else:
            cond_test = build_condition(source, transform)
            return (
                f'{i}<xsl:if test="{cond_test}">\n'
                f"{i}\t<{target}>\n"
                f"{i}\t\t{val_xml}\n"
                f"{i}\t</{target}>\n"
                f"{i}</xsl:if>"
            )

    def interpret_loop(self, loop_name: str, loop_xpath: str,
                        rules: list, indent: str = "\t\t\t") -> str:
        """Build a complete xsl:for-each block for a loop."""
        i  = indent
        i1 = i + "\t"
        i2 = i + "\t\t"
        lines = [
            f'{i}<!-- {loop_name} loop -->',
            f'{i}<xsl:for-each select="{loop_xpath}">',
            f'{i1}<ns0:{loop_name}>',
        ]
        for rule in rules:
            fragment = self.interpret(rule, indent=i2)
            if fragment:
                lines.append(fragment)
        lines += [
            f'{i1}</ns0:{loop_name}>',
            f'{i}</xsl:for-each>',
        ]
        return "\n".join(lines)
