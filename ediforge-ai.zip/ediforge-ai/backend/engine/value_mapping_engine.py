"""
EDIForge AI â€” Value Mapping Engine
Generates xsl:choose/when/otherwise blocks for code-lookup mappings.
"""
from __future__ import annotations
from typing import Dict, List, Optional


class ValueMappingEngine:

    def build_choose(
        self,
        xpath: str,
        value_map: Dict[str, str],
        suppress_others: Optional[List[str]] = None,
        passthrough_default: bool = True,
        indent: str = "\t\t\t\t\t",
    ) -> str:
        i  = indent
        i1 = i + "\t"
        lines = [f'{i}<xsl:choose>']
        for src, tgt in value_map.items():
            lines.append(f'{i1}<xsl:when test="{xpath}=\'{src}\'">')
            lines.append(f'{i1}\t{tgt}')
            lines.append(f'{i1}</xsl:when>')
        for sup in (suppress_others or []):
            lines.append(f'{i1}<xsl:when test="{xpath}=\'{sup}\'">')
            lines.append(f'{i1}\t<!-- suppressed -->')
            lines.append(f'{i1}</xsl:when>')
        if passthrough_default:
            lines.append(f'{i1}<xsl:otherwise>')
            lines.append(f'{i1}\t<xsl:value-of select="{xpath}"/>')
            lines.append(f'{i1}</xsl:otherwise>')
        lines.append(f'{i}</xsl:choose>')
        return "\n".join(lines)

    def build_element_with_choose(
        self,
        element: str,
        xpath: str,
        value_map: Dict[str, str],
        suppress_others: Optional[List[str]] = None,
        passthrough_default: bool = True,
        condition: Optional[str] = None,
        indent: str = "\t\t\t\t",
    ) -> str:
        choose = self.build_choose(
            xpath, value_map, suppress_others, passthrough_default,
            indent=indent + "\t"
        )
        inner = f'{indent}<{element}>\n{choose}\n{indent}</{element}>'
        if condition:
            return (
                f'{indent}<xsl:if test="{condition}">\n'
                f'{indent}\t{inner.strip()}\n'
                f'{indent}</xsl:if>'
            )
        return inner

    @staticmethod
    def parse_value_map_from_notes(notes: str) -> Optional[Dict[str, str]]:
        import re
        if not notes:
            return None
        pairs = re.findall(r'([A-Z0-9]{2,6})\s*[=-]+\s*([A-Z0-9a-z]{1,10})', notes)
        if pairs:
            return {k: v for k, v in pairs if v.lower() not in ("omit", "suppress", "skip")}
        return None


_vme = ValueMappingEngine()


def build_value_choose(xpath: str, value_map: Dict[str, str],
                        passthrough: bool = True, indent: str = "\t\t\t\t\t") -> str:
    return _vme.build_choose(xpath, value_map,
                              passthrough_default=passthrough, indent=indent)
