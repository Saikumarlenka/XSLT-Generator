﻿"""
EDIForge AI - Reference Learning Engine (FIX 12)
Learns from correct XSLT maps:
  - Loop XPath patterns
  - Qualifier patterns
  - Condition patterns
  - XPath patterns per EDI element
Stored in training/knowledge/<ts>_patterns.json
"""
from __future__ import annotations
import json
import re
from pathlib import Path
from typing import Dict, List

KNOWLEDGE_DIR = Path(__file__).parent.parent.parent.parent / "training" / "knowledge"


def _load_patterns(transaction_set: str) -> dict:
    path = KNOWLEDGE_DIR / f"{transaction_set}_patterns.json"
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"xpaths": {}, "loops": {}, "qualifiers": {}, "conditions": {}}


def _save_patterns(transaction_set: str, data: dict):
    KNOWLEDGE_DIR.mkdir(parents=True, exist_ok=True)
    path = KNOWLEDGE_DIR / f"{transaction_set}_patterns.json"
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def learn_from_xslt(transaction_set: str, xslt: str) -> dict:
    """
    Extract and store patterns from a correct XSLT map.
    Returns count of patterns learned.
    """
    patterns = _load_patterns(transaction_set)
    learned  = {"xpaths": 0, "loops": 0, "qualifiers": 0}

    # Learn XPath select values per EDI element
    for m in re.finditer(
        r'<([A-Z][A-Z0-9]{1,5})>\s*(?:<xsl:(?:value-of|call-template)[^>]*>'
        r'.*?select="([^"]+)")',
        xslt, re.DOTALL
    ):
        elem  = m.group(1)
        xpath = m.group(2)
        if elem and xpath and xpath not in ("", "'210'", "'214'", "0001"):
            if elem not in patterns["xpaths"]:
                patterns["xpaths"][elem] = xpath
                learned["xpaths"] += 1

    # Learn loop for-each XPaths
    for m in re.finditer(r'<xsl:for-each\s+select="([^"]+)">', xslt):
        xpath = m.group(1)
        if "PartyList" in xpath or "Party" in xpath:
            patterns["loops"].setdefault("N1Loop1", xpath)
            learned["loops"] += 1
        elif "LineItem" in xpath:
            patterns["loops"].setdefault("LXLoop1", xpath)
            learned["loops"] += 1
        elif "StatusList" in xpath or "StatusDetail" in xpath:
            patterns["loops"].setdefault("AT7Loop1", xpath)
            learned["loops"] += 1
        elif "StopList" in xpath or "StopOff" in xpath:
            patterns["loops"].setdefault("S5Loop1", xpath)
            learned["loops"] += 1

    # Learn qualifier patterns (EntityIdentifierCode values)
    for m in re.finditer(r"EntityIdentifierCode='([A-Z]{2})'", xslt):
        q = m.group(1)
        patterns["qualifiers"].setdefault(q, f"Party[Name/@EntityIdentifierCode='{q}']")
        learned["qualifiers"] += 1

    _save_patterns(transaction_set, patterns)
    return learned


def apply_learned_patterns(mappings: List[dict],
                             transaction_set: str) -> List[dict]:
    """
    Fill in missing XPaths using learned patterns.
    Safe: only fills if source is empty and a learned pattern exists.
    """
    patterns  = _load_patterns(transaction_set)
    xpath_map = patterns.get("xpaths", {})

    for m in mappings:
        if m.get("literal") or m.get("_is_literal"):
            continue
        target = re.sub(r"^ns0:", "", (m.get("target") or "")).split("/")[-1]
        source = (m.get("source") or "").strip()
        if not source and target in xpath_map:
            m["source"]           = xpath_map[target]
            m["_pattern_learned"] = True

    return mappings


def get_learned_loop_xpaths(transaction_set: str) -> Dict[str, str]:
    """Return learned loop XPaths for the given transaction set."""
    return _load_patterns(transaction_set).get("loops", {})
