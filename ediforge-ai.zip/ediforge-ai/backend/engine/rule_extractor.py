"""
EDIForge AI â€” AI-Powered Rule Extractor
Converts parsed DOCX table rows into structured JSON rules using the AI engine.
Falls back to heuristic extraction if AI is unavailable.

Works for ANY mapping document â€” not just 210.
"""
from __future__ import annotations
import json
import re
from typing import List, Optional


AI_RULE_SYSTEM = """You are an expert EDI mapping engineer.
Convert the given mapping table rows into structured JSON rules.

Each rule MUST use this exact format:
{
  "target":    "<EDI element like B302, N102>",
  "source":    "<full canonical XPath like Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber>",
  "condition": "not_empty | always | optional",
  "transform": "date_yyyymmdd | decimal | clean_alpha | uppercase | null",
  "loop":      "<loop name or null>",
  "segment":   "<EDI segment like N1 or null>",
  "qualifier": "<qualifier code like BT, SH or null>",
  "value_map": {}
}

Rules:
- If source has 'hardcoded', 'constant', set source="" and add "literal": "<value>"
- Detect qualifiers: N1*BT â†’ segment="N1", qualifier="BT"
- Detect date transforms: "format YYYYMMDD" â†’ transform="date_yyyymmdd"
- Detect comma removal: "remove comma" â†’ transform="decimal"
- DO NOT invent XPaths. Use only what is in the mapping rows.
- Return ONLY a valid JSON array. No explanation, no markdown.
"""


class AIRuleExtractor:

    def __init__(self):
        self._ai_available = None  # lazy check

    def _check_ai(self) -> bool:
        if self._ai_available is None:
            try:
                from backend.core.ai_engine import call_ai
                self._ai_available = True
            except ImportError:
                self._ai_available = False
        return self._ai_available

    def extract_via_ai(self, table_rows: List[dict],
                        transaction_set: str = "") -> List[dict]:
        """Send table rows to AI and parse the returned JSON rules."""
        if not self._check_ai() or not table_rows:
            return []

        from backend.core.ai_engine import call_ai, clean_json

        # Chunk to avoid token limits (max 30 rows per call)
        chunks = [table_rows[i:i+30] for i in range(0, len(table_rows), 30)]
        all_rules: List[dict] = []

        for idx, chunk in enumerate(chunks):
            prompt = (
                f"Transaction set: {transaction_set or 'unknown'}\n\n"
                f"Mapping rows (chunk {idx+1}/{len(chunks)}):\n"
                f"{json.dumps(chunk, indent=2)}\n\n"
                f"Convert to JSON rule array."
            )
            try:
                raw = call_ai(prompt, AI_RULE_SYSTEM)
                parsed = clean_json(raw)
                if isinstance(parsed, list):
                    all_rules.extend(parsed)
                elif isinstance(parsed, dict) and "rules" in parsed:
                    all_rules.extend(parsed["rules"])
            except Exception as e:
                print(f"  AI rule extraction chunk {idx+1} failed: {e}")

        return all_rules

    def extract_heuristic(self, table_rows: List[dict]) -> List[dict]:
        """
        Fallback heuristic extraction â€” no AI needed.
        Works by analysing column names and values.
        """
        rules = []
        for row in table_rows:
            rule: dict = {}
            # Try to find target/source regardless of column name casing
            for k, v in row.items():
                kl = k.lower().strip()
                if not rule.get("target") and any(
                    x in kl for x in ("edi", "target", "element", "field", "output")
                ):
                    rule["target"] = str(v).strip()
                elif not rule.get("source") and any(
                    x in kl for x in ("source", "canonical", "xpath", "input", "path")
                ):
                    rule["source"] = str(v).strip()
                elif any(x in kl for x in ("note", "rule", "comment", "transform")):
                    rule.setdefault("notes", str(v).strip())
            if rule.get("target") or rule.get("source"):
                rules.append(rule)
        return rules

    def extract(self, table_rows: List[dict],
                 transaction_set: str = "",
                 prefer_ai: bool = True) -> List[dict]:
        """
        Main extraction entry point.
        Tries AI first, falls back to heuristic.
        """
        if prefer_ai and self._check_ai():
            try:
                ai_rules = self.extract_via_ai(table_rows, transaction_set)
                if ai_rules:
                    return ai_rules
            except Exception as e:
                print(f"  AI extraction failed, using heuristic: {e}")

        return self.extract_heuristic(table_rows)


# Singleton
_extractor = AIRuleExtractor()


def extract_rules_from_table(table_rows: List[dict],
                               transaction_set: str = "",
                               prefer_ai: bool = True) -> List[dict]:
    """Module-level shortcut."""
    return _extractor.extract(table_rows, transaction_set, prefer_ai)
