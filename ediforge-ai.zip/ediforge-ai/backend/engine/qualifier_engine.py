"""
EDIForge AI â€” Qualifier Engine
Generates qualifier-filtered XPath expressions for EDI segments that
use a code qualifier in the first sub-element (e.g. N101, REF01, N901).

Examples
--------
>>> QualifierEngine().apply("N1", "BT", "PartyList/Party")
"PartyList/Party[Name/@EntityIdentifierCode='BT']"

>>> QualifierEngine().qualify_for_each("N1", "BT", "Header/PartyList/Party")
"Header/PartyList/Party[Name/@EntityIdentifierCode='BT']"
"""
from __future__ import annotations
import re
from typing import Optional


# Segment -> attribute/element that holds the qualifier code
QUALIFIER_ATTR: dict = {
    "N1":  "Name/@EntityIdentifierCode",   # canonical attribute
    "REF": "@ReferenceQualifier",
    "N9":  "@EDICode",
    "G62": "@DateTimeQualifier",
    "L1":  "@FreightRateQualifier",
    "AT7": "@ShipmentStatusCode",
    "K1":  None,                            # no qualifier
}

# EDI sub-element that holds qualifier (for raw EDI schemas)
EDI_QUALIFIER_ELEMENT: dict = {
    "N1":  "N101",
    "REF": "REF01",
    "N9":  "N901",
    "G62": "G6201",
    "L1":  "L101",
    "AT7": "AT701",
}

# Known qualifier codes â†’ human description (for comments)
QUALIFIER_DESC: dict = {
    "BT": "Bill-To",
    "SH": "Shipper",
    "CN": "Consignee",
    "SF": "Ship-From",
    "ST": "Ship-To",
    "CA": "Carrier",
    "SO": "Sold-To",
    "BM": "Bill of Lading",
    "PO": "Purchase Order",
    "OI": "Order Item",
    "FD": "Free-form Description",
    "10": "Pickup Date",
    "35": "Delivery Date",
}


class QualifierEngine:
    """Generates qualifier-filtered XPath and xsl:for-each selects."""

    def apply(self, segment: str, qualifier: str,
              base_xpath: str, position: Optional[int] = None) -> str:
        """
        Build a qualifier-filtered XPath for canonical schemas.
        E.g. "Header/PartyList/Party[Name/@EntityIdentifierCode='BT']"
        """
        attr = QUALIFIER_ATTR.get(segment.upper())
        if not attr or not qualifier:
            return base_xpath

        filtered = f"{base_xpath}[{attr}='{qualifier}']"
        if position is not None:
            filtered += f"[{position}]"
        return filtered

    def apply_edi(self, segment: str, qualifier: str,
                  base_xpath: str, position: Optional[int] = None) -> str:
        """
        Build qualifier-filtered XPath using EDI sub-element (N101, REF01, etc.).
        E.g. "N1[N101='BT']"
        """
        elem = EDI_QUALIFIER_ELEMENT.get(segment.upper())
        if not elem or not qualifier:
            return base_xpath

        filtered = f"{base_xpath}[{elem}='{qualifier}']"
        if position is not None:
            filtered += f"[{position}]"
        return filtered

    def qualify_for_each(self, segment: str, qualifier: str,
                         canonical_collection_xpath: str) -> str:
        """
        Build the select= value for xsl:for-each with qualifier filtering.
        """
        return self.apply(segment, qualifier, canonical_collection_xpath)

    def build_n1_loops(self, qualifiers: list[str],
                       base: str = "Header/PartyList/Party") -> list[dict]:
        """
        Return a list of loop definitions for each N1 qualifier.
        Each dict has: qualifier, xpath, comment
        """
        loops = []
        for q in qualifiers:
            loops.append({
                "qualifier": q,
                "xpath": self.apply("N1", q, base),
                "comment": QUALIFIER_DESC.get(q, q),
            })
        return loops

    @staticmethod
    def extract_qualifier_from_xslt(xslt_fragment: str) -> Optional[str]:
        """
        Parse an existing xsl:for-each select= and extract the qualifier value.
        """
        m = re.search(r"EntityIdentifierCode='([^']+)'", xslt_fragment)
        if m:
            return m.group(1)
        m = re.search(r"EDICode='([^']+)'", xslt_fragment)
        if m:
            return m.group(1)
        return None


# Convenience singleton
_engine = QualifierEngine()


def qualify_xpath(segment: str, qualifier: str, base_xpath: str,
                  position: Optional[int] = None) -> str:
    """Module-level shortcut."""
    return _engine.apply(segment, qualifier, base_xpath, position)


def build_n1_party_loops(qualifiers: list[str]) -> list[dict]:
    """Module-level shortcut for N1 party loops."""
    return _engine.build_n1_loops(qualifiers)
