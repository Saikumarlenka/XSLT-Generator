﻿"""
EDIForge AI â€" Field-Level Learning Store
Stores and retrieves field-level mapping intelligence:
  {transaction_set} -> {edi_element: canonical_xpath}

This is MORE useful than storing full XSLT because:
  - Field mappings are reusable across customers
  - They survive schema version changes
  - They can be merged and improved over time
"""
from __future__ import annotations
import json
import os
from pathlib import Path
from typing import Dict, Optional

STORE_DIR = Path(__file__).parent.parent.parent / "training" / "knowledge"


def _store_path(transaction_set: str) -> Path:
    return STORE_DIR / f"{transaction_set}_field_intelligence.json"


def _load_store(transaction_set: str) -> Dict[str, str]:
    path = _store_path(transaction_set)
    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {}


def _save_store(transaction_set: str, store: Dict[str, str]) -> None:
    STORE_DIR.mkdir(parents=True, exist_ok=True)
    path = _store_path(transaction_set)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(store, f, indent=2)


def learn_field_mappings(transaction_set: str, mappings: list) -> int:
    """
    Extract and store field-level mappings from a validated mapping list.
    Returns count of new entries learned.
    """
    store   = _load_store(transaction_set)
    learned = 0
    for m in mappings:
        target = (m.get("target") or "").strip()
        source = (m.get("source") or "").strip()
        if (target and source and "/" in source
                and not m.get("_is_literal") and not m.get("literal")):
            if target not in store or not store[target]:
                store[target] = source
                learned += 1
    if learned:
        _save_store(transaction_set, store)
    return learned


def lookup_field(transaction_set: str, edi_element: str) -> Optional[str]:
    """Look up the canonical XPath for an EDI element."""
    store = _load_store(transaction_set)
    return store.get(edi_element)


def lookup_multiple(transaction_set: str,
                     edi_elements: list) -> Dict[str, str]:
    """Look up multiple elements at once."""
    store = _load_store(transaction_set)
    return {e: store[e] for e in edi_elements if e in store}


def enrich_mappings_from_store(mappings: list,
                                 transaction_set: str) -> tuple[list, int]:
    """
    Fill in missing source XPaths for mappings using the field store.
    Returns (enriched_mappings, count_enriched).
    """
    store    = _load_store(transaction_set)
    enriched = 0
    for m in mappings:
        if not m.get("source") and m.get("target"):
            xpath = store.get(m["target"])
            if xpath:
                m["source"]   = xpath
                m["_learned"] = True
                enriched += 1
    return mappings, enriched


def inject_learning(rules: list, memory: dict) -> list:
    """
    FIX 10: Inject best-known XPath from memory into rules missing a source.
    Replaces any missing or unresolved source with the stored XPath.
    Call BEFORE XSLT generation.
    """
    for r in rules:
        if r.get("literal") or r.get("_is_literal"):
            continue
        target = (r.get("target") or "").strip()
        source = (r.get("source") or "").strip()
        if not source and target:
            stored = memory.get(target)
            if stored:
                r["source"]   = stored
                r["_learned"] = True
        elif source and "/" not in source and target:
            # Source is a bare field name â€" try to enrich
            stored = memory.get(target)
            if stored and "/" in stored:
                r["source"]   = stored
                r["_learned"] = True
    return rules


def get_full_memory(transaction_set: str) -> dict:
    """Return entire field store as {edi_element: xpath} dict."""
    return _load_store(transaction_set)
