﻿"""
EDIForge AI - Output Validator (FIXED v3)
Validates generated XSLT by:
  1. Checking required segments are present
  2. Checking required loops are present
  3. Full lxml parse + XSLT compile (syntax check)
  4. Executing against sample XML and doing structural comparison
  5. Detecting missing N1/LX/AT7 loop content
"""
from __future__ import annotations
import re
from typing import Optional, List


def validate_xslt_completeness(xslt: str, transaction_set: str) -> dict:
    """Structural completeness check â€" no XML parsing needed. Fast."""
    from backend.engine.transaction_rules import get_required_segments, get_loops
    from backend.mapping.loop_hierarchy_engine import validate_loop_nesting

    errors   = []
    warnings = []

    if not xslt or not xslt.strip():
        return {"valid": False, "errors": ["Empty XSLT"], "warnings": []}

    # 1. Required segments (accept ns0: prefix too)
    for seg in get_required_segments(transaction_set):
        if f"<{seg}" not in xslt and f"<ns0:{seg}" not in xslt:
            errors.append(f"Missing required segment: {seg}")

    # 2. Required loops
    loop_result = validate_loop_nesting(xslt, transaction_set)
    for loop in loop_result["missing"]:
        warnings.append(f"Loop possibly missing: {loop}")

    # 3. Helper templates
    if "CleanAlphaField" not in xslt:
        warnings.append("CleanAlphaField helper template not found")

    # 4. Namespace
    if "xmlns:xsl" not in xslt:
        errors.append("Missing XSL namespace")

    # 5. xsl:if guards â€" warn if bare xsl:value-of found outside xsl:if
    bare = re.findall(r'(?<!<xsl:if[^>]{0,200})<xsl:value-of', xslt)
    if len(bare) > 5:
        warnings.append(f"{len(bare)} xsl:value-of elements may be missing xsl:if guards")

    return {
        "valid":         len(errors) == 0,
        "errors":        errors,
        "warnings":      warnings,
        "loops_found":   loop_result["found"],
        "loops_missing": loop_result["missing"],
    }


def validate_xslt_syntax(xslt: str) -> dict:
    """Full lxml parse + XSLT compile check."""
    try:
        from lxml import etree
    except ImportError:
        return {"valid": True, "error": "lxml not installed â€ syntax check skipped"}

    try:
        xslt_stripped = re.sub(r'<[?]xml[^?]*[?]>', '', xslt, count=1).strip()
        xslt_bytes    = xslt_stripped.encode("utf-8")
        root          = etree.fromstring(xslt_bytes)
        _xslt         = etree.XSLT(root)
        return {
            "valid":          True,
            "template_count": len(root.findall(
                ".//{http://www.w3.org/1999/XSL/Transform}template")),
            "for_each_count": len(root.findall(
                ".//{http://www.w3.org/1999/XSL/Transform}for-each")),
        }
    except Exception as e:
        return {"valid": False, "error": str(e)}


def execute_xslt(xslt: str, sample_xml: str) -> dict:
    """Execute XSLT against sample XML. Returns {success, output, error}."""
    if not sample_xml:
        return {"success": False, "output": "", "error": "No sample XML provided"}
    try:
        from lxml import etree
        xslt_clean = re.sub(r'<[?]xml[^?]*[?]>', '', xslt, count=1).strip()
        xslt_root  = etree.fromstring(xslt_clean.encode("utf-8"))
        transform  = etree.XSLT(xslt_root)
        xml_root   = etree.fromstring(sample_xml.encode("utf-8"))
        result     = transform(xml_root)
        return {"success": True, "output": str(result), "error": ""}
    except Exception as e:
        return {"success": False, "output": "", "error": str(e)}


def _normalize_xml(xml_str: str) -> Optional[bytes]:
    """Parse + re-serialize XML for structural comparison."""
    try:
        from lxml import etree
        parser = etree.XMLParser(remove_blank_text=True)
        tree   = etree.XML(xml_str.encode("utf-8"), parser)
        return etree.tostring(tree, pretty_print=False)
    except Exception:
        return None


def compare_xml_output(output: str, expected: str) -> dict:
    """
    Deep structural XML comparison.
    Returns {match: bool, reason: str}.
    """
    if not output or not expected:
        return {"match": False, "reason": "Empty output or expected"}

    norm_out = _normalize_xml(output)
    norm_exp = _normalize_xml(expected)

    if norm_out is None:
        return {"match": False, "reason": "Output XML is not valid XML"}
    if norm_exp is None:
        return {"match": False, "reason": "Expected XML is not valid XML"}

    if norm_out == norm_exp:
        return {"match": True, "reason": "Exact structural match"}

    # Partial check: required element presence
    try:
        from lxml import etree
        out_tree = etree.XML(norm_out)
        exp_tree = etree.XML(norm_exp)
        out_tags = {el.tag for el in out_tree.iter()}
        exp_tags = {el.tag for el in exp_tree.iter()}
        missing  = exp_tags - out_tags
        extra    = out_tags - exp_tags
        return {
            "match":   False,
            "reason":  f"Structure differs â€ missing: {missing}, extra: {extra}",
            "missing_elements": list(missing),
            "extra_elements":   list(extra),
        }
    except Exception as e:
        return {"match": False, "reason": f"Comparison error: {e}"}


def detect_healing_issue(output: str, expected: str, transaction_set: str) -> str:
    """
    Identify the specific type of failure for intelligent self-healing.
    Returns a failure code string.
    """
    if not output:
        return "empty_output"
    if "<N1" in (expected or "") and "<N1" not in output:
        return "missing_n1_loop"
    if "<LX" in (expected or "") and "<LX" not in output:
        return "missing_lx_loop"
    if "<AT7" in (expected or "") and "<AT7" not in output:
        return "missing_at7_loop"
    if "xsl:value-of" not in output and "<xsl:stylesheet" in output:
        return "missing_value_mappings"
    if "s0:" not in output and "select=" in output:
        return "missing_namespace_prefix"
    from backend.engine.transaction_rules import get_required_segments
    for seg in get_required_segments(transaction_set):
        if f"<{seg}" not in output and f"<ns0:{seg}" not in output:
            return f"missing_segment_{seg}"
    return "structure_mismatch"


def full_validate(xslt: str, transaction_set: str,
                  sample_xml: Optional[str] = None,
                  expected_xml: Optional[str] = None) -> dict:
    """Run all validation steps. Returns combined report."""
    completeness = validate_xslt_completeness(xslt, transaction_set)
    syntax       = validate_xslt_syntax(xslt)
    execution    = {}
    comparison   = {}

    if sample_xml and syntax.get("valid"):
        execution = execute_xslt(xslt, sample_xml)
        if execution.get("success") and expected_xml:
            comparison = compare_xml_output(execution["output"], expected_xml)

    overall_valid = (
        completeness["valid"]
        and syntax.get("valid", True)
        and (not execution or execution.get("success", True))
        and (not comparison or comparison.get("match", True))
    )

    return {
        "valid":        overall_valid,
        "completeness": completeness,
        "syntax":       syntax,
        "execution":    execution,
        "comparison":   comparison,
        "all_errors":   (
            completeness["errors"]
            + ([syntax.get("error", "")] if not syntax.get("valid") else [])
            + ([execution.get("error", "")] if not execution.get("success") else [])
        ),
        "all_warnings": completeness["warnings"],
    }
