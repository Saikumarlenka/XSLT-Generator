﻿"""
EDIForge AI - Qualifier Enforcer (FIX 02)
Applies qualifier-aware XPath to every rule BEFORE XSLT generation.
This is the missing link between qualifier_engine.py and the pipeline.
Call: enforce_qualifiers(mappings, transaction_set) before generating XSLT.
"""
from __future__ import annotations
import re
from typing import List

# Full qualifier table â€” covers real-world EDI usage
QUALIFIER_XPATH_MAP = {
    # N1 party qualifiers -> canonical attribute filter
    ("N1", "BT"): "Header/PartyList/Party[Name/@EntityIdentifierCode='BT']",
    ("N1", "SH"): "Header/PartyList/Party[Name/@EntityIdentifierCode='SH']",
    ("N1", "CN"): "Header/PartyList/Party[Name/@EntityIdentifierCode='CN']",
    ("N1", "SF"): "Header/PartyList/Party[Name/@EntityIdentifierCode='SF']",
    ("N1", "ST"): "Header/PartyList/Party[Name/@EntityIdentifierCode='ST']",
    ("N1", "CA"): "Header/PartyList/Party[Name/@EntityIdentifierCode='CA']",
    ("N1", "SO"): "Header/PartyList/Party[Name/@EntityIdentifierCode='SO']",
    # REF qualifiers
    ("REF", "BM"): "@ReferenceQualifier='BM'",
    ("REF", "PO"): "@ReferenceQualifier='PO'",
    ("REF", "IA"): "@ReferenceQualifier='IA'",
    ("REF", "OI"): "@ReferenceQualifier='OI'",
    ("REF", "CN"): "@ReferenceQualifier='CN'",
    # N9 EDI code qualifiers
    ("N9", "BM"): "@EDICode='BM'",
    ("N9", "PO"): "@EDICode='PO'",
    ("N9", "OI"): "@EDICode='OI'",
}


def enforce_qualifiers(mappings: List[dict], transaction_set: str = "") -> List[dict]:
    """
    For every mapping that has a qualifier, build the correct XPath filter.
    This REPLACES the vague base XPath with a qualifier-specific one.
    Must be called BEFORE XSLT generation.
    """
    from backend.engine.qualifier_engine import qualify_xpath
    for m in mappings:
        qualifier = (m.get("qualifier") or m.get("_qualifier") or "").strip()
        segment   = (m.get("segment") or "").strip().upper()
        source    = (m.get("source") or "").strip()

        if not qualifier or not segment:
            continue

        # Check pre-built table first (most accurate)
        key = (segment, qualifier)
        if key in QUALIFIER_XPATH_MAP and not m.get("_is_literal"):
            # Only update the for-each xpath, not the leaf attribute xpath
            m["_loop_xpath"] = QUALIFIER_XPATH_MAP[key]
            continue

        # Fall back to qualifier_engine
        if source and "/" in source:
            try:
                qualified = qualify_xpath(segment, qualifier, source)
                if qualified != source:
                    m["source"]    = qualified
                    m["_qualified"] = True
            except Exception:
                pass
    return mappings


def enforce_qualifiers_on_loop_map(loop_map: dict, transaction_set: str) -> dict:
    """
    Ensure every N1Loop has the correct qualifier-specific for-each XPath.
    Returns updated loop_map.
    """
    from backend.engine.transaction_rules import get_rules
    rules = get_rules(transaction_set)
    required_qualifiers = rules.get("required_qualifiers", {})

    n1_qualifiers = required_qualifiers.get("N1", [])
    if n1_qualifiers and "N1Loop1" in loop_map:
        base = loop_map["N1Loop1"]
        # Build per-qualifier sub-loops
        for q in n1_qualifiers:
            loop_key = f"N1Loop1_{q}"
            if loop_key not in loop_map:
                loop_map[loop_key] = f"{base}[Name/@EntityIdentifierCode='{q}']"
    return loop_map
