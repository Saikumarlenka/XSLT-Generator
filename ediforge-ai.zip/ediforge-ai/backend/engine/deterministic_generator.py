"""
EDIForge AI â€” Deterministic XSLT Generator (FIX 04)
====================================================
Replaces the old ad-hoc _deterministic_xslt() in pipeline.py with a
transaction-aware, loop-enforcing, qualifier-correct generator.

Key improvements over old generator
-------------------------------------
1.  Transaction rules drive segment order (not alphabetical sort)
2.  Qualifier-aware N1 loops (BT/SH/CN) with correct EntityIdentifierCode filter
3.  Condition engine wraps every field (no bare xsl:value-of)
4.  Value mapping (xsl:choose) generated from value_map field
5.  Helper templates (CleanAlphaField, date vars) always included
6.  Correct UTF-8 XML declaration + BizTalk namespace pattern
7.  ST segment uses correct TransactionSetIdentifierCode XPath
8.  SE segment always last

How to use
----------
from backend.engine.deterministic_generator import build_deterministic_xslt

xslt_str = build_deterministic_xslt(
    mappings=valid_mappings,
    transaction_set="210",
    source_schema=source_schema,
    source_ns="http://Echo.BSSR.Internal.Canonical.InvoiceV2",
    target_ns="http://Echo.BSSR.Schemas.EDI.X12_00401.EDI210/v1.0",
    loop_map=loop_map,
)
"""
from __future__ import annotations
import re
from collections import defaultdict
from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _pad(n: int) -> str:
    return "\t" * n


def _val(xpath: str, transform: Optional[str] = None,
          max_len: Optional[int] = None) -> str:
    """Generate the correct xsl value expression for a given transform."""
    from backend.mapping.transform_engine import build_xslt_expression
    return build_xslt_expression(xpath, transform, max_len)


def _cond(xpath: str, transform: Optional[str] = None) -> str:
    from backend.mapping.transform_engine import build_condition
    return build_condition(xpath, transform)


def _safe_element(name: str) -> str:
    name = str(name).strip()
    name = re.sub(r'[^a-zA-Z0-9_.\-]', '_', name)
    if not name or name[0].isdigit():
        name = "_" + name
    return name


def _sort_key(target: str, segment_order: List[str]) -> int:
    """Return sort position based on known segment order."""
    seg = re.match(r'^([A-Z][A-Z0-9]{0,2})(?=\d{2})', target)
    if seg:
        s = seg.group(1)
        try:
            return segment_order.index(s) * 1000
        except ValueError:
            pass
    return 9999


# ---------------------------------------------------------------------------
# Header / stylesheet helpers
# ---------------------------------------------------------------------------

def _build_header(source_ns: str, target_ns: str,
                   transaction_set: str) -> List[str]:
    lines = ['<?xml version="1.0" encoding="UTF-8"?>']
    lines.append(
        f'<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"'
    )
    lines.append('\txmlns:msxsl="urn:schemas-microsoft-com:xslt"')
    lines.append('\txmlns:var="http://schemas.microsoft.com/BizTalk/2003/var"')
    lines.append('\texclude-result-prefixes="msxsl var s0 userCSharp"')
    lines.append('\tversion="1.0"')
    if target_ns:
        lines.append(f'\txmlns:ns0="{target_ns}"')
    if source_ns:
        lines.append(f'\txmlns:s0="{source_ns}"')
    lines.append('\txmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp">')
    lines.append("")
    lines.append('\t<xsl:output omit-xml-declaration="yes" method="xml" version="1.0"/>')
    lines.append('\t<xsl:variable name="vLowercaseChars_CONST" select="\'abcdefghijklmnopqrstuvwxyz\'"/>')
    lines.append('\t<xsl:variable name="vUppercaseChars_CONST" select="\'ABCDEFGHIJKLMNOPQRSTUVWXYZ\'"/>')
    return lines


def _build_template_match(source_ns: str, source_root: str,
                            root_output: str) -> List[str]:
    s0_root = f"/s0:{source_root}" if source_ns else f"/{source_root}"
    lines = [
        "",
        '\t<xsl:template match="/">',
        f'\t\t<xsl:apply-templates select="{s0_root}"/>',
        "\t</xsl:template>",
        "",
        f'\t<xsl:template match="{s0_root}">',
        f"\t\t<{root_output}>",
        "",
    ]
    return lines


def _build_st_segment(transaction_set: str = "") -> List[str]:
    ts_code = transaction_set or "210"
    return [
        "			<!-- ST segment -->",
        "			<ST>",
        "				<ST01>" + ts_code + "</ST01>",
        "				<ST02>0001</ST02>",
        "			</ST>",
        "",
    ]


def _build_se_segment() -> List[str]:
    return [
        "",
        "\t\t\t<!-- SE segment â€” always last -->",
        "\t\t\t<SE>",
        "\t\t\t\t<SE01/>",
        "\t\t\t\t<SE02>0001</SE02>",
        "\t\t\t</SE>",
    ]


def _build_helper_templates() -> List[str]:
    return [
        "",
        "\t<!-- CleanAlphaField helper template -->",
        '\t<xsl:template name="CleanAlphaField">',
        '\t\t<xsl:param name="inputText"/>',
        '\t\t<xsl:param name="maxLength"/>',
        "\t\t<xsl:variable name=\"cleaned\" "
        "select=\"translate($inputText,'~*:?|','     ')\"/>",
        '\t\t<xsl:value-of select="substring(normalize-space($cleaned),1,$maxLength)"/>',
        "\t</xsl:template>",
        "",
        "</xsl:stylesheet>",
    ]


# ---------------------------------------------------------------------------
# Segment / loop builders
# ---------------------------------------------------------------------------

def _build_segment(parent: str, pmappings: List[dict],
                    segment_order: List[str], use_ns0: bool = True) -> List[str]:
    """Build one EDI segment with its child elements."""
    tag = f"ns0:{parent}" if use_ns0 else parent
    lines = [
        f"\t\t\t<!-- {parent} segment -->",
        f"\t\t\t<{tag}>",
    ]
    sorted_m = sorted(pmappings,
                       key=lambda x: _sort_key(x.get("target", ""), segment_order))
    for m in sorted_m:
        tgt       = m.get("target", "")
        src       = (m.get("source") or m.get("_resolved_source") or "").strip()
        literal   = m.get("literal")
        transform = m.get("transform")
        value_map = m.get("value_map") or {}
        condition = m.get("condition")
        leaf      = _safe_element(re.sub(r'^ns0:', '', tgt.split("/")[-1]))
        if not leaf:
            continue

        pad4 = _pad(4)  # inside segment

        if literal is not None:
            lines.append(f"{pad4}<{leaf}>{literal}</{leaf}>")

        elif value_map and src:
            from backend.engine.value_mapping_engine import ValueMappingEngine
            vme = ValueMappingEngine()
            cond_test = condition or f"{src} != ''"
            choose_xml = vme.build_choose(src, value_map, indent=pad4 + "\t")
            lines.append(f"{pad4}<xsl:if test=\"{cond_test}\">")
            lines.append(f"{pad4}\t<{leaf}>")
            lines.append(choose_xml)
            lines.append(f"{pad4}\t</{leaf}>")
            lines.append(f"{pad4}</xsl:if>")

        elif src:
            val_xml   = _val(src, transform)
            cond_test = condition or _cond(src, transform)
            lines.append(f"{pad4}<xsl:if test=\"{cond_test}\">")
            lines.append(f"{pad4}\t<{leaf}>")
            lines.append(f"{pad4}\t\t{val_xml}")
            lines.append(f"{pad4}\t</{leaf}>")
            lines.append(f"{pad4}</xsl:if>")

    lines.append(f"\t\t\t</{tag}>")
    lines.append("")
    return lines


def _build_loop(loop_name: str, loop_xpath: str,
                 child_mappings: List[dict],
                 segment_order: List[str],
                 qualifier: Optional[str] = None) -> List[str]:
    """Build xsl:for-each loop with nested segments."""
    from backend.engine.qualifier_engine import qualify_xpath
    if qualifier:
        seg = loop_name.replace("Loop1", "").replace("Loop", "")
        loop_xpath = qualify_xpath(seg, qualifier, loop_xpath)

    comment = f"<!-- {loop_name} loop -->"
    if qualifier:
        comment = f"<!-- {loop_name} loop â€” qualifier {qualifier} -->"

    lines = [
        f"\t\t\t{comment}",
        f'\t\t\t<xsl:for-each select="{loop_xpath}">',
        f'\t\t\t\t<ns0:{loop_name}>',
    ]

    # Group child mappings by their parent segment
    by_seg: Dict[str, List[dict]] = defaultdict(list)
    for m in child_mappings:
        tgt = m.get("target", "")
        seg_m = re.match(r'^([A-Z][A-Z0-9]{0,2})(?=\d{2})', tgt)
        key = seg_m.group(1) if seg_m else tgt.split("/")[0]
        by_seg[key].append(m)

    for seg, segs_m in sorted(by_seg.items(),
                                key=lambda x: _sort_key(x[0], segment_order)):
        for seg_line in _build_segment(seg, segs_m, segment_order, use_ns0=False):
            lines.append("\t" + seg_line)

    lines += [
        f'\t\t\t\t</ns0:{loop_name}>',
        "\t\t\t</xsl:for-each>",
        "",
    ]
    return lines


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_deterministic_xslt(
    mappings: List[dict],
    transaction_set: str = "210",
    source_schema: Optional[dict] = None,
    source_ns: str = "",
    target_ns: str = "",
    loop_map: Optional[Dict[str, str]] = None,
) -> str:
    """
    Build a complete, deterministic XSL map for the given transaction.

    Parameters
    ----------
    mappings        : list of resolved mapping dicts (target, source, transform, â€¦)
    transaction_set : "210", "214", "204", "990"
    source_schema   : parsed canonical schema dict (optional)
    source_ns       : xmlns:s0 URI
    target_ns       : xmlns:ns0 URI
    loop_map        : {loop_name: xpath} â€” overrides defaults
    """
    from backend.engine.transaction_rules import get_rules, get_segment_order

    rules          = get_rules(transaction_set)
    segment_order  = get_segment_order(transaction_set)
    root_output    = rules.get("root_output", f"ns0:X12_00401_{transaction_set}")
    source_root_el = rules.get("source_root", "s0:Invoice").lstrip("s0:")

    # Resolve namespaces from base map if not supplied
    if not source_ns or not target_ns:
        try:
            from backend.schema.base_map_registry import get_base_map_metadata
            meta = get_base_map_metadata(transaction_set) or {}
            source_ns = source_ns or meta.get("s0_uri", "")
            target_ns = target_ns or meta.get("ns0_uri", "")
        except Exception:
            pass

    # Fallback namespace URIs
    if not target_ns:
        target_ns = (f"http://Echo.BSSR.Schemas.EDI.X12_00401."
                     f"EDI{transaction_set}/v1.0")
    if not source_ns:
        source_ns = "http://Echo.BSSR.Internal.Canonical.Invoice"

    # Build effective loop map
    effective_loops = dict(rules.get("loop_xpaths", {}))
    effective_loops.update(loop_map or {})

    # Separate loop mappings from flat mappings
    loop_keywords = {"PartyList", "Party", "LineItem", "LineItemList",
                      "Stop", "StopList", "Status", "StatusList",
                      "Reference", "ReferenceList", "Equipment", "EquipmentList"}
    loop_mappings: Dict[str, List[dict]] = defaultdict(list)
    flat_mappings: List[dict] = []

    _loop_kw = {}
    for lname, lxpath in effective_loops.items():
        parts = lxpath.replace("[","").replace("]","").split("/")
        _loop_kw[lname] = [p.lower() for p in parts if p and "@" not in p and len(p) > 3]

    for m in mappings:
        src = (m.get("source") or "").strip().lower()
        assigned_loop = None
        best_score = 0
        for lname, keywords in _loop_kw.items():
            score = sum(1 for kw in keywords if kw and kw in src)
            if score > best_score:
                best_score = score
                assigned_loop = lname
        if assigned_loop and best_score > 0:
            loop_mappings[assigned_loop].append(m)
        else:
            flat_mappings.append(m)

    # Group flat mappings by segment
    by_parent: Dict[str, List[dict]] = defaultdict(list)
    for m in flat_mappings:
        tgt = m.get("target", "")
        seg_m = re.match(r'^([A-Z][A-Z0-9]{0,2})(?=\d{2})', tgt)
        key = seg_m.group(1) if seg_m else tgt.split("/")[0]
        if key:
            by_parent[key].append(m)

    # â”€â”€ Assemble XSL â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    lines: List[str] = []

    lines += _build_header(source_ns, target_ns, transaction_set)
    lines += _build_template_match(source_ns, source_root_el, root_output)
    lines += _build_st_segment(transaction_set)

    # Flat segments in schema order
    for seg in segment_order:
        if seg in ("ST", "SE"):
            continue
        if seg in by_parent:
            # Check if it's a loop-level segment first
            is_loop_seg = any(
                seg in _lname for _lname in effective_loops
            )
            if not is_loop_seg:
                lines += _build_segment(seg, by_parent[seg], segment_order)

    # Any segments not in segment_order (catch-all)
    ordered_set = set(segment_order)
    for parent, pmappings in sorted(by_parent.items()):
        if parent not in ordered_set and parent not in ("ST", "SE"):
            lines += _build_segment(parent, pmappings, segment_order)

    # Loops
    for loop_name, loop_xpath in effective_loops.items():
        child_m = loop_mappings.get(loop_name, [])
        if child_m or loop_name in rules.get("loops", []):
            # Special N1 qualifier handling
            if "N1Loop" in loop_name:
                qualifiers = rules.get("required_qualifiers", {}).get("N1", [])
                if qualifiers:
                    for q in qualifiers:
                        q_mappings = [
                            m for m in child_m
                            if not m.get("_qualifier") or m.get("_qualifier") == q
                        ]
                        lines += _build_loop(loop_name, loop_xpath,
                                              q_mappings, segment_order,
                                              qualifier=q)
                    continue  # skip unqualified fallback
            lines += _build_loop(loop_name, loop_xpath,
                                   child_m, segment_order)

    lines += _build_se_segment()
    lines.append("")
    lines.append(f"\t\t</{root_output}>")
    lines.append("\t</xsl:template>")
    lines += _build_helper_templates()

    return "\n".join(lines)


