﻿"""
EDIForge AI - Schema Path Validator (NEW â€” FIX 08)
Validates canonical XPaths and EDI element targets against real XSD schemas.
Uses lxml XMLSchema validation + element existence check.
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import List, Optional, Dict

SCHEMA_DIR = Path(__file__).parent.parent.parent / "schemas"


def load_xsd_schema(transaction_set: str, schema_type: str = "canonical"):
    """
    Load and cache an lxml XMLSchema object.
    schema_type: 'canonical' or 'x12'
    """
    try:
        from lxml import etree
    except ImportError:
        return None

    if schema_type == "canonical":
        paths = list((SCHEMA_DIR / "canonical" / transaction_set).glob("*.xsd"))
    else:
        paths = list((SCHEMA_DIR / "x12" / transaction_set).glob("*.xsd"))

    if not paths:
        return None

    try:
        xsd_doc = etree.parse(str(paths[0]))
        return etree.XMLSchema(xsd_doc)
    except Exception:
        return None


def extract_all_element_names(transaction_set: str,
                               schema_type: str = "canonical") -> List[str]:
    """Return all element/attribute names defined in the XSD."""
    try:
        from lxml import etree
    except ImportError:
        return []

    if schema_type == "canonical":
        paths = list((SCHEMA_DIR / "canonical" / transaction_set).glob("*.xsd"))
    else:
        paths = list((SCHEMA_DIR / "x12" / transaction_set).glob("*.xsd"))

    if not paths:
        return []

    names = []
    try:
        tree = etree.parse(str(paths[0]))
        ns   = {"xs": "http://www.w3.org/2001/XMLSchema"}
        for el in tree.xpath("//xs:element | //xs:attribute", namespaces=ns):
            name = el.get("name")
            if name:
                names.append(name)
    except Exception:
        pass
    return names


def validate_xpath_against_schema(xpath: str, transaction_set: str,
                                    schema_type: str = "canonical") -> bool:
    """
    Check if the leaf name of an XPath exists in the schema.
    Returns True if valid (or schema not available â€” fail open).
    """
    if not xpath:
        return False

    # Already a full valid XPath â€” trust it
    if xpath.startswith("/*[local-name") or "/@" in xpath:
        return True

    all_names = extract_all_element_names(transaction_set, schema_type)
    if not all_names:
        return True  # No schema loaded â€” fail open

    # Extract leaf name from XPath
    leaf = xpath.split("/")[-1].lstrip("@").split("[")[0]
    leaf_norm = re.sub(r"[^a-zA-Z0-9]", "", leaf).lower()

    for name in all_names:
        if re.sub(r"[^a-zA-Z0-9]", "", name).lower() == leaf_norm:
            return True

    return False


def filter_mappings_by_schema(mappings: List[dict],
                                transaction_set: str) -> Dict[str, List[dict]]:
    """
    Split mappings into valid/invalid based on schema XPath check.
    Always keeps literals and rows with full XPaths.
    """
    valid   = []
    invalid = []

    for m in mappings:
        if m.get("literal") or m.get("_is_literal"):
            valid.append(m)
            continue
        source = (m.get("source") or "").strip()
        if not source:
            valid.append(m)  # Will be handled by learning store
            continue
        if "/" in source:
            valid.append(m)  # Full XPath â€” trust it
            continue
        if validate_xpath_against_schema(source, transaction_set):
            valid.append(m)
        else:
            invalid.append(m)

    return {"valid": valid, "invalid": invalid}
