﻿"""
EDIForge AI - Self-Healing XSLT Pipeline (FIXED v3)
Generate -> Validate -> Detect failure type -> Targeted fix -> Regenerate
Up to MAX_HEAL_ATTEMPTS iterations.
"""
from __future__ import annotations
import re, os
from typing import Optional, List

MAX_HEAL_ATTEMPTS = int(os.getenv("MAX_HEAL_ATTEMPTS", "3"))


def validate_structure(xslt: str, transaction_set: str) -> List[str]:
    from backend.engine.transaction_rules import get_required_segments
    errors = []
    for seg in get_required_segments(transaction_set):
        if f"<{seg}" not in xslt and f"<ns0:{seg}" not in xslt:
            errors.append(f"MISSING_SEGMENT:{seg}")
    return errors


def validate_xslt_syntax_check(xslt: str) -> List[str]:
    errors = []
    try:
        from lxml import etree
        clean = re.sub(r"<[?]xml[^?]*[?]>", "", xslt, count=1).strip()
        root  = etree.fromstring(clean.encode("utf-8"))
        etree.XSLT(root)
    except Exception as e:
        errors.append(f"SYNTAX:{e}")
    return errors


def validate_for_each_balance(xslt: str) -> List[str]:
    opens  = len(re.findall(r"<xsl:for-each", xslt))
    closes = len(re.findall(r"</xsl:for-each>", xslt))
    if opens != closes:
        return [f"FOR_EACH_IMBALANCE: {opens} open vs {closes} close"]
    return []


def validate_if_balance(xslt: str) -> List[str]:
    opens  = len(re.findall(r"<xsl:if\b", xslt))
    closes = len(re.findall(r"</xsl:if>", xslt))
    if opens != closes:
        return [f"XSL_IF_IMBALANCE: {opens} open vs {closes} close"]
    return []


def _apply_targeted_fix(xslt: str, failure_code: str,
                         transaction_set: str) -> str:
    """
    Apply a targeted fix based on the detected failure type.
    This avoids wasting AI calls on issues we can fix deterministically.
    """
    # Fix unbalanced xsl:for-each
    if "FOR_EACH_IMBALANCE" in failure_code:
        opens  = len(re.findall(r"<xsl:for-each", xslt))
        closes = len(re.findall(r"</xsl:for-each>", xslt))
        diff   = opens - closes
        if diff > 0:
            xslt = xslt.rstrip()
            if xslt.endswith("</xsl:stylesheet>"):
                xslt = xslt[:-len("</xsl:stylesheet>")].rstrip()
                xslt += "\n" + ("</xsl:for-each>\n" * diff)
                xslt += "</xsl:stylesheet>"

    # Fix unbalanced xsl:if
    if "XSL_IF_IMBALANCE" in failure_code:
        opens  = len(re.findall(r"<xsl:if\b", xslt))
        closes = len(re.findall(r"</xsl:if>", xslt))
        diff   = opens - closes
        if diff > 0:
            xslt = xslt.rstrip()
            if xslt.endswith("</xsl:stylesheet>"):
                xslt = xslt[:-len("</xsl:stylesheet>")].rstrip()
                xslt += "\n" + ("</xsl:if>\n" * diff)
                xslt += "</xsl:stylesheet>"

    # Fix missing s0: namespace prefix on select attributes
    if "missing_namespace_prefix" in failure_code:
        from backend.engine.transaction_rules import get_rules
        rules = get_rules(transaction_set)
        source_root = rules.get("source_root", "Invoice").lstrip("s0:")
        xslt = re.sub(
            rf'select="({source_root}/)',
            r'select="s0:\1',
            xslt
        )

    return xslt


def build_correction_prompt(xslt: str, errors: List[str],
                              transaction_set: str) -> str:
    error_block = "\n".join(f"  - {e}" for e in errors)
    return f"""Fix this EDI XSLT map. Address ALL listed errors exactly.

TRANSACTION: {transaction_set}

ERRORS TO FIX:
{error_block}

RULES:
1. Fix every listed error - do not skip any
2. MISSING_SEGMENT: add the segment with correct XPath from canonical schema
3. SYNTAX errors: fix the XML/XSLT syntax
4. FOR_EACH_IMBALANCE: add missing closing </xsl:for-each> tags
5. XSL_IF_IMBALANCE: add missing closing </xsl:if> tags
6. Preserve all correct segments - do NOT remove working content
7. Output the COMPLETE fixed XSLT only. No markdown. No explanation.

BROKEN XSLT:
{xslt}"""


def self_healing_generate(xslt: str, transaction_set: str,
                           canonical_index: dict,
                           sample_xml: Optional[str] = None,
                           expected_xml: Optional[str] = None,
                           max_attempts: int = MAX_HEAL_ATTEMPTS) -> dict:
    from backend.core.ai_engine import call_ai, clean_xslt, FIX_SYSTEM
    heal_log = []
    current  = xslt

    for attempt in range(1, max_attempts + 1):
        errors: List[str] = []
        errors += validate_xslt_syntax_check(current)

        if not errors:
            errors += validate_for_each_balance(current)
            errors += validate_if_balance(current)
            errors += validate_structure(current, transaction_set)

        heal_log.append(f"Attempt {attempt}: {len(errors)} errors")

        if not errors:
            # Also check against expected output if provided
            if sample_xml and expected_xml:
                from backend.engine.output_validator import execute_xslt, compare_xml_output
                exec_r = execute_xslt(current, sample_xml)
                if exec_r.get("success"):
                    cmp_r = compare_xml_output(exec_r["output"], expected_xml)
                    if cmp_r.get("match"):
                        heal_log.append(f"Attempt {attempt}: CLEAN + OUTPUT MATCH")
                        return {"xslt": current, "valid": True, "attempts": attempt,
                                "all_errors": [], "heal_log": heal_log}
                    else:
                        errors.append(f"OUTPUT_MISMATCH: {cmp_r.get('reason','')}")
                        heal_log.append(f"Attempt {attempt}: output mismatch â€" {cmp_r.get('reason','')}")
                else:
                    errors.append(f"EXECUTION_FAILED: {exec_r.get('error','')}")
            else:
                heal_log.append(f"Attempt {attempt}: CLEAN")
                return {"xslt": current, "valid": True, "attempts": attempt,
                        "all_errors": [], "heal_log": heal_log}

        if not errors:
            break

        # Step 1: Try targeted deterministic fix first (no AI call)
        failure_code = "|".join(errors)
        fixed_deterministic = _apply_targeted_fix(current, failure_code, transaction_set)
        if fixed_deterministic != current:
            current = fixed_deterministic
            heal_log.append(f"Attempt {attempt}: deterministic fix applied")
            continue  # re-validate before calling AI

        # Step 2: Use AI for complex fixes
        try:
            prompt = build_correction_prompt(current, errors, transaction_set)
            fixed  = clean_xslt(call_ai(prompt, FIX_SYSTEM))
            if fixed and len(fixed) > 200:
                current = fixed
                heal_log.append(f"Attempt {attempt}: AI correction applied")
            else:
                heal_log.append(f"Attempt {attempt}: AI returned empty â€" keeping current")
        except Exception as e:
            heal_log.append(f"Attempt {attempt}: AI failed: {e}")

    return {"xslt": current, "valid": False, "attempts": max_attempts,
            "all_errors": errors, "heal_log": heal_log}
