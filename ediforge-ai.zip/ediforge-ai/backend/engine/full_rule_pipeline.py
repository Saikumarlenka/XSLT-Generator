"""
EDIForge AI â€” Full Rule Pipeline
DOCX â†’ table rows â†’ AI rule extraction â†’ normalization â†’ XSLT generation.
This is the recommended entry point for mapping document processing.
"""
from __future__ import annotations
from typing import List, Optional


class FullRulePipeline:

    def __init__(self):
        from backend.engine.rule_extractor import AIRuleExtractor
        from backend.engine.rule_normalizer import normalize_rules
        from backend.engine.rule_interpreter import RuleInterpreter

        self._extractor   = AIRuleExtractor()
        self._normalize   = normalize_rules
        self._interpreter = RuleInterpreter()

    def process_docx(self, file_path: str,
                      transaction_set: str = "") -> List[dict]:
        """
        Parse a DOCX mapping document and return normalised rule list.
        Suitable as input to build_deterministic_xslt().
        """
        print(f"Step 1: Parsing DOCX: {file_path}")
        rows = self._parse_docx(file_path)

        print(f"Step 2: Extracted {len(rows)} table rows")
        raw_rules = self._extractor.extract(rows, transaction_set)

        print(f"Step 3: AI extracted {len(raw_rules)} raw rules")
        normalised = self._normalize(raw_rules)

        print(f"Step 4: Normalised to {len(normalised)} rules")
        return normalised

    def process_table_rows(self, table_rows: List[dict],
                            transaction_set: str = "") -> List[dict]:
        """Process pre-parsed table rows (use when DOCX is already parsed)."""
        raw_rules  = self._extractor.extract(table_rows, transaction_set)
        normalised = self._normalize(raw_rules)
        return normalised

    def rules_to_mappings(self, rules: List[dict]) -> List[dict]:
        """
        Convert normalised rules into the mapping dict format expected
        by build_deterministic_xslt() and the main pipeline.
        """
        mappings = []
        for r in rules:
            m = {
                "target":    r.get("target", ""),
                "source":    r.get("source", ""),
                "literal":   r.get("literal"),
                "transform": r.get("transform"),
                "condition": r.get("condition"),
                "value_map": r.get("value_map") or {},
                "loop":      r.get("loop"),
                "_qualifier": r.get("qualifier"),
            }
            if m["target"] or m["source"]:
                mappings.append(m)
        return mappings

    @staticmethod
    def _parse_docx(file_path: str) -> List[dict]:
        """Parse all tables from a DOCX file into list of dicts."""
        try:
            from docx import Document
        except ImportError:
            raise ImportError(
                "python-docx not installed. Run: pip install python-docx"
            )
        doc   = Document(file_path)
        rows  = []
        for table in doc.tables:
            if not table.rows:
                continue
            headers = [c.text.strip().lower() for c in table.rows[0].cells]
            for row in table.rows[1:]:
                cells = [c.text.strip() for c in row.cells]
                if any(cells):
                    rows.append(dict(zip(headers, cells)))
        return rows


# Convenience function
def docx_to_mappings(file_path: str, transaction_set: str = "") -> List[dict]:
    """One-shot: DOCX â†’ mapping dicts ready for the pipeline."""
    pipeline = FullRulePipeline()
    rules    = pipeline.process_docx(file_path, transaction_set)
    return pipeline.rules_to_mappings(rules)
