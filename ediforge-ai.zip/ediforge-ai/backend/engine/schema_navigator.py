﻿"""
EDIForge AI - Schema Navigator (NEW â€” FIX 11)
Builds valid XPaths by reading directly from XSD schema files.
Prevents AI from hallucinating paths that do not exist.
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import List, Optional, Dict

SCHEMA_DIR = Path(__file__).parent.parent.parent / "schemas"


class SchemaNavigator:
    """Reads XSD and provides best-match XPath lookup."""

    def __init__(self, transaction_set: str, schema_type: str = "canonical"):
        self.transaction_set = transaction_set
        self.schema_type     = schema_type
        self._paths: List[str] = []
        self._index: Dict[str, str] = {}
        self._load()

    def _load(self):
        try:
            from lxml import etree
        except ImportError:
            return

        if self.schema_type == "canonical":
            base = SCHEMA_DIR / "canonical" / self.transaction_set
        else:
            base = SCHEMA_DIR / "x12" / self.transaction_set

        xsd_files = list(base.glob("*.xsd")) if base.exists() else []
        if not xsd_files:
            return

        try:
            tree = etree.parse(str(xsd_files[0]))
            ns   = {"xs": "http://www.w3.org/2001/XMLSchema"}
            for el in tree.xpath("//xs:element", namespaces=ns):
                name = el.get("name")
                if name:
                    self._paths.append(name)
                    self._index[name.lower()] = name
            for at in tree.xpath("//xs:attribute", namespaces=ns):
                name = at.get("name")
                if name:
                    self._paths.append("@" + name)
                    self._index[name.lower()] = "@" + name
        except Exception:
            pass

    def get_all_paths(self) -> List[str]:
        return list(self._paths)

    def find_best_match(self, field_name: str) -> Optional[str]:
        """
        Return the best XSD element/attribute name matching the given field.
        Returns None if no XSD loaded (caller should fallback).
        """
        if not self._index:
            return None
        if not field_name:
            return None

        key = re.sub(r"[^a-z0-9]", "", field_name.lower())

        # Exact match
        if key in self._index:
            return self._index[key]

        # Prefix match
        for k, v in self._index.items():
            if k.startswith(key) or key.startswith(k):
                return v

        # Substring match
        for k, v in self._index.items():
            if len(key) >= 4 and (key in k or k in key):
                return v

        return None

    def validate_xpath_leaf(self, xpath: str) -> bool:
        """Check if the leaf of an XPath exists in the schema."""
        if not self._index:
            return True  # No schema â€” fail open
        leaf = xpath.split("/")[-1].lstrip("@").split("[")[0]
        key  = re.sub(r"[^a-z0-9]", "", leaf.lower())
        return key in self._index


# Per-transaction cache
_navigators: Dict[str, SchemaNavigator] = {}


def get_navigator(transaction_set: str,
                   schema_type: str = "canonical") -> SchemaNavigator:
    cache_key = f"{transaction_set}_{schema_type}"
    if cache_key not in _navigators:
        _navigators[cache_key] = SchemaNavigator(transaction_set, schema_type)
    return _navigators[cache_key]
