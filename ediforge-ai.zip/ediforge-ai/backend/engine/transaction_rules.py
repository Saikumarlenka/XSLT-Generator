"""
EDIForge AI â€” Transaction-Specific Rules
Each transaction has: required_segments, loops, qualifiers, segment_order.
Used by BaseMapValidator, LoopValidator, and DeterministicGenerator.
"""
from __future__ import annotations
from typing import Dict, List

TRANSACTION_RULES: Dict[str, dict] = {
    "210": {
        "required_segments": ["ST", "B3", "N1", "LX", "SE"],
        "loops": ["N1Loop1", "LXLoop1", "N9Loop1"],
        "loop_xpaths": {
            "N9Loop1": "Header/ReferenceList/ReferenceInformation[@EDICode != '']",
            "N1Loop1": "Header/PartyList/Party",
            "N7Loop1": "Header/EquipmentList/Equipment",
            "LXLoop1": "Detail/LineItemList/LineItem",
        },
        "segment_order": ["ST", "B3", "C2", "C3", "R3", "G62", "L7", "N9",
                          "N1", "N2", "N3", "N4", "N7", "LX", "L5", "L0",
                          "L1", "L7", "L3", "SE"],
        "required_qualifiers": {"N1": ["BT", "SH", "CN"]},
        "root_output": "ns0:X12_00401_210",
        "source_root": "s0:Invoice",
        "canonical_type": "Invoice",
    },
    "214": {
        "required_segments": ["ST", "B10", "LX", "AT7", "SE"],
        "loops": ["LXLoop1", "AT7Loop1", "L11Loop1", "N1Loop1", "SPOLoop1"],
        # Correct Echo BSS canonical XPaths for 214
        "loop_xpaths": {
            "L11Loop1": "Status/StatusList/ShipmentStatus/BusinessReferences/BusinessReference",
            "N1Loop1": "Statuses/Status/Details/Detail[@stopType='Pick' or @stopType='Drop']",
            "LXLoop1": "Statuses/Status/Details/Detail[@statusCode != '']",
            "AT7Loop1": "Statuses/Status/Details/Detail[@statusCode != '']",
            "SPOLoop1": "Statuses/ShipmentPurcheseOrderInfo/PurchaseOrderDetail",
        },
        "segment_order": ["ST", "B10", "L11", "K1", "N9", "N1", "N2", "N3",
                          "N4", "G62", "LX", "AT7", "MS1", "MS2", "SE"],
        "required_qualifiers": {},
        "root_output": "ns0:X12_00401_214",
        "source_root": "s0:Status",
        "canonical_type": "Status",
    },
    "204": {
        "required_segments": ["ST", "B2", "S5", "SE"],
        "loops": ["S5Loop1", "N1Loop1", "N9Loop1"],
        "loop_xpaths": {
            "N9Loop1": "Header/ReferenceList/ReferenceInformation",
            "N1Loop1": "Header/PartyList/Party",
            "S5Loop1": "Detail/StopList/StopOffDetails",
            "LXLoop1": "Detail/LineItemList/LineItem",
        },
        "segment_order": ["ST", "B2", "L11", "G62", "N9", "N1", "N2", "N3",
                          "N4", "S5", "L11", "G62", "N9", "LAD", "N1", "N2",
                          "N3", "N4", "AT8", "SE"],
        "required_qualifiers": {},
        "root_output": "ns0:ShipmentIn",
        "source_root": "s0:ShipmentOrder",
        "canonical_type": "ShipmentOrder",
    },

    "211": {
        "required_segments": ["ST", "MS3", "SE"],
        "loops": [],
        "loop_xpaths": {},
        "segment_order": ["ST", "MS3", "SE"],
        "required_qualifiers": {},
        "root_output": "ns0:X12_00401_211",
        "source_root": "s0:Status",
        "canonical_type": "Status",
    },
    "940": {
        "required_segments": ["ST", "W05", "SE"],
        "loops": ["N1Loop1", "LXLoop1"],
        "loop_xpaths": {
            "N1Loop1": "Header/PartyList/Party",
            "LXLoop1": "Detail/LineItemList/LineItem",
        },
        "segment_order": ["ST", "W05", "N1", "N2", "N3", "N4", "LX", "W01", "SE"],
        "required_qualifiers": {},
        "root_output": "ns0:X12_00401_940",
        "source_root": "s0:WarehouseShippingOrder",
        "canonical_type": "WarehouseShippingOrder",
    },
    "990": {
        "required_segments": ["ST", "B1", "SE"],
        "loops": ["N1Loop1"],
        "loop_xpaths": {
            "N1Loop1": "Header/PartyList/Party",
        },
        "segment_order": ["ST", "B1", "L11", "K1", "N9", "N1", "N2", "N3",
                          "N4", "SE"],
        "required_qualifiers": {},
        "root_output": "ns0:X12_00401_990",
        "source_root": "s0:TenderResponse",
        "canonical_type": "TenderResponse",
    },
}


def get_rules(transaction_set: str) -> dict:
    """Return rules for a transaction set; falls back to 210 structure if unknown."""
    return TRANSACTION_RULES.get(str(transaction_set), TRANSACTION_RULES["210"])


def get_required_segments(transaction_set: str) -> List[str]:
    return get_rules(transaction_set).get("required_segments", [])


def get_loops(transaction_set: str) -> List[str]:
    return get_rules(transaction_set).get("loops", [])


def get_loop_xpaths(transaction_set: str) -> Dict[str, str]:
    return get_rules(transaction_set).get("loop_xpaths", {})


def get_segment_order(transaction_set: str) -> List[str]:
    return get_rules(transaction_set).get("segment_order", [])


def all_transactions() -> List[str]:
    return list(TRANSACTION_RULES.keys())
