﻿"""
EDIForge AI - Condition Optimizer (NEW â€” FIX 09)
Normalises, deduplicates, and merges conditions on mapping rules.
Prevents condition explosion (every row getting the full condition text).
"""
from __future__ import annotations
import re
from typing import List, Optional


def _simplify_condition(cond: str, xpath: str) -> str:
    """
    Convert verbose condition text to a clean XSLT test expression.
    """
    if not cond:
        return f"{xpath} != ''"

    cond_l = cond.strip().lower()

    # Always-map rows
    if cond_l in ("always", "hardcoded", "constant", "literal"):
        return ""   # empty means no xsl:if wrapper

    # Not-empty variants
    if any(x in cond_l for x in ("not empty", "not null", "required", "mandatory",
                                   "if exists", "not_empty")):
        return f"{xpath} != ''"

    # Positive number check
    if "> 0" in cond_l or "positive" in cond_l or "greater than 0" in cond_l:
        return f"{xpath} != '' and {xpath} &gt; 0"

    # Date length check
    if "date" in cond_l or "yyyymmdd" in cond_l:
        return f"string-length({xpath}) &gt;= 8"

    # Already an XPath expression
    if "!=" in cond or ">" in cond or "<" in cond or "=" in cond:
        return cond

    # Default
    return f"{xpath} != ''"


def optimize_conditions(mappings: List[dict]) -> List[dict]:
    """
    For every mapping, ensure the condition is a clean, minimal XSLT test.
    Removes duplicates and merges compound conditions.
    """
    for m in mappings:
        if m.get("literal") or m.get("_is_literal"):
            m["condition"] = "always"
            continue

        source = (m.get("source") or "").strip()
        raw_cond = m.get("condition") or ""

        if isinstance(raw_cond, list):
            # Deduplicate condition list
            raw_cond = list(dict.fromkeys(c.strip() for c in raw_cond if c.strip()))
            if len(raw_cond) > 1:
                # Merge: take the first meaningful one
                raw_cond = raw_cond[0]
            elif raw_cond:
                raw_cond = raw_cond[0]
            else:
                raw_cond = ""

        if source:
            m["condition"] = _simplify_condition(str(raw_cond), source)
        else:
            m["condition"] = "not_empty"

    return mappings


def deduplicate_conditions(condition_list: List[str]) -> str:
    """
    Merge a list of condition strings into one clean XSLT test expression.
    """
    seen   = []
    unique = []
    for c in condition_list:
        c = c.strip()
        if c and c not in seen:
            seen.append(c)
            unique.append(c)

    if not unique:
        return ""
    if len(unique) == 1:
        return unique[0]

    # Merge with ' and '
    return " and ".join(f"({c})" for c in unique)
