"""
EDIForge AI â€” Base Map Validator
Validates that a base/reference XSL map contains:
  1. All required segments for the transaction set
  2. All required loops
  3. Correct namespace declarations
  4. Valid canonical XPath references (s0: prefix)
Raises descriptive errors so the pipeline can reject bad base maps early.
"""
from __future__ import annotations
import re
from typing import List, Optional


def validate_base_map(xslt: str, transaction_set: str,
                      canonical_paths: Optional[List[str]] = None) -> dict:
    """
    Returns {"valid": bool, "errors": [...], "warnings": [...]}.
    Does NOT raise â€” callers decide how to handle errors.
    """
    from backend.engine.transaction_rules import get_required_segments, get_loops

    errors: List[str] = []
    warnings: List[str] = []

    if not xslt or not xslt.strip():
        return {"valid": False, "errors": ["Base map is empty"], "warnings": []}

    # 1. Required segments
    for seg in get_required_segments(transaction_set):
        # Accept both <ST> and <ns0:ST>
        if not re.search(rf'<(?:ns0:)?{re.escape(seg)}[\s>]', xslt):
            errors.append(f"Missing required segment: {seg}")

    # 2. Required loops (xsl:for-each or loop comment marker)
    for loop in get_loops(transaction_set):
        # strip "Loop1" suffix to match "N1Loop" patterns too
        base = re.sub(r'Loop\d*$', '', loop)
        has_foreach = re.search(r'xsl:for-each', xslt) is not None
        has_marker  = base.lower() in xslt.lower()
        if not (has_foreach and has_marker):
            warnings.append(f"Loop possibly missing: {loop} â€” verify xsl:for-each present")

    # 3. Namespace declarations
    if 'xmlns:xsl="http://www.w3.org/1999/XSL/Transform"' not in xslt:
        errors.append("Missing XSL namespace declaration")
    if 'xmlns:ns0=' not in xslt:
        warnings.append("Missing xmlns:ns0 â€” target namespace may be wrong")
    if 'xmlns:s0=' not in xslt:
        warnings.append("Missing xmlns:s0 â€” source namespace may be wrong")

    # 4. xsl:template match
    if 'xsl:template match' not in xslt:
        errors.append("No xsl:template match found â€” map has no entry point")

    # 5. Canonical XPath check (optional but powerful)
    if canonical_paths:
        # Extract all select= values
        selects = re.findall(r'select="([^"]+)"', xslt)
        for sel in selects:
            # Only validate paths that look like canonical (contain /)
            clean = sel.replace("s0:", "").strip()
            if ("/" in clean and not clean.startswith("$")
                    and not clean.startswith("concat")
                    and not clean.startswith("translate")
                    and not clean.startswith("substring")
                    and not clean.startswith("normalize")
                    and not clean.startswith("position")
                    and not clean.startswith("count")
                    and "!=" not in clean
                    and ">" not in clean):
                # Fuzzy match: if the leaf element exists somewhere in canonical
                leaf = clean.split("/")[-1].lstrip("@")
                if leaf and not any(leaf in p for p in canonical_paths):
                    warnings.append(f"XPath leaf '{leaf}' not found in canonical schema")

    valid = len(errors) == 0
    return {"valid": valid, "errors": errors, "warnings": warnings}


def assert_base_map_valid(xslt: str, transaction_set: str,
                          canonical_paths: Optional[List[str]] = None,
                          strict: bool = False) -> None:
    """
    Raises ValueError if the base map fails hard validation.
    In strict mode also raises on warnings.
    """
    result = validate_base_map(xslt, transaction_set, canonical_paths)
    if not result["valid"]:
        raise ValueError(
            f"Base map invalid for {transaction_set}: "
            + "; ".join(result["errors"])
        )
    if strict and result["warnings"]:
        raise ValueError(
            f"Base map warnings (strict mode) for {transaction_set}: "
            + "; ".join(result["warnings"])
        )
