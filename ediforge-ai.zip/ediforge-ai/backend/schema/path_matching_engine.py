"""
EDIForge AI v4 -- Canonical -> EDI Path Matching Engine
=======================================================
Connects:
  Mapping document field name  (e.g. "InvoiceNumber")
        ->  Canonical XPath    (e.g. "Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber")
        ->  EDI element        (e.g. B302)

3-tier resolution:
  1. Exact normalised match
  2. Fuzzy match (difflib, cutoff 0.70)
  3. EDI knowledge base field description lookup
"""
from __future__ import annotations
import re
from difflib import get_close_matches
from typing import Dict, List, Optional

from backend.schema.dual_schema_index import (
    build_canonical_index_from_schema, resolve_canonical_field, _norm,
)


def resolve_source_to_canonical(
    source_name: str,
    canonical_index: Dict[str, str],
    context_segment: str = "",
) -> Optional[str]:
    if not source_name:
        return None
    # Already a full XPath
    if "/" in source_name or source_name.startswith("@"):
        return source_name
    # Tier 1: exact / synonym / prefix match
    result = resolve_canonical_field(source_name, canonical_index)
    if result:
        if context_segment:
            all_hits = [v for k, v in canonical_index.items()
                        if _norm(source_name) in k or k in _norm(source_name)]
            ctx_hits = [p for p in all_hits if context_segment.lower() in p.lower()]
            if ctx_hits:
                return ctx_hits[0]
        return result
    # Tier 2: fuzzy match
    key = _norm(source_name)
    close = get_close_matches(key, list(canonical_index.keys()), n=1, cutoff=0.70)
    if close:
        return canonical_index[close[0]]
    return None


def resolve_mapping_pairs(
    mapping_rows: List[dict],
    canonical_index: Dict[str, str],
    transaction_set: str = "",
) -> List[dict]:
    resolved = []
    for row in mapping_rows:
        r = dict(row)
        # Literal rows need no source resolution
        if r.get("_is_literal") or r.get("literal"):
            r["_resolved_source"] = None
            resolved.append(r)
            continue
        src = (r.get("source") or "").strip()
        tgt = (r.get("target") or "").strip()
        # Infer context from target (e.g. "B302" -> context "B3")
        ctx_m = re.match(r"^([A-Z][0-9A-Z]{1,2})", tgt)
        context = ctx_m.group(1) if ctx_m else ""
        canonical_path = resolve_source_to_canonical(src, canonical_index, context)
        if not canonical_path and transaction_set:
            canonical_path = _kb_fallback(src, tgt, transaction_set)
        r["_resolved_source"] = canonical_path
        if canonical_path and "/" not in r.get("source", ""):
            r["source"] = canonical_path
        resolved.append(r)
    return resolved


def _kb_fallback(field: str, edi_element: str, transaction_set: str) -> Optional[str]:
    try:
        from backend.mapping.edi_knowledge_base import EDI_SEGMENT_FIELDS
        seg_m = re.match(r"^([A-Z][0-9A-Z]{1,2})", edi_element)
        if seg_m:
            seg = seg_m.group(1)
            desc = EDI_SEGMENT_FIELDS.get(seg, {}).get(edi_element, "")
            if desc:
                return f"*[local-name()='Header']/*/@*[local-name()='{desc}']"
    except ImportError:
        pass
    return None
