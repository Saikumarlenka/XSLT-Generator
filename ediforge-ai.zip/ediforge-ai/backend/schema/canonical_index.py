"""EDIForge AI v2 -- Canonical Index.
Builds a complete, un-capped index of every canonical path from the parsed
schema so the generator can validate targets and resolve loose field names.
"""
import re
from typing import Dict, List, Optional

SYNONYMS: Dict[str, str] = {
    "bol": "billoflading",
    "billofladingno": "billoflading",
    "billofladingnum": "billoflading",
    "billofladingnumber": "billoflading",
    "carrierschac": "scac",
    "carrierscac": "scac",
    "scaccode": "scac",
    "stopno": "stopnumber",
    "stopnum": "stopnumber",
    "shipdate": "shipmentdate",
    "shippingdate": "shipmentdate",
    "pronum": "pronumber",
    "deliverydate": "delivereddate",
    "eta": "estimatedarrivaldate",
    "weight": "totalweight",
    "totalwt": "totalweight",
    "pieces": "totalpieces",
    "chargetype": "chargedescription",
    "chargedesc": "chargedescription",
    "amount": "chargeamount",
    "totalcharge": "chargeamount",
}


def _normalise(name: str) -> str:
    return re.sub(r"[\s_\-]", "", name).lower()


def build_canonical_index(source_schema) -> Dict[str, str]:
    """Return {normalised_leaf_name: full_canonical_path} for every element.
    No 120-element cap -- the full schema is indexed."""
    if not source_schema:
        return {}
    elements = source_schema.get("elements", {})
    if isinstance(elements, list):
        elements = {e["path"]: e for e in elements if isinstance(e, dict) and "path" in e}
    index: Dict[str, str] = {}
    for path in elements:
        leaf = path.split("/")[-1].lstrip("@")
        key = _normalise(leaf)
        if key not in index or path.count("/") < index[key].count("/"):
            index[key] = path
    for alias, canonical_key in SYNONYMS.items():
        if canonical_key in index and alias not in index:
            index[alias] = index[canonical_key]
    return index


def resolve_target(field: str, index: Dict[str, str]):
    return index.get(_normalise(field))


def validate_target_path(path: str, source_schema) -> bool:
    if not source_schema:
        return False
    elements = source_schema.get("elements", {})
    if isinstance(elements, list):
        elements = {e["path"]: e for e in elements if isinstance(e, dict) and "path" in e}
    return path in elements


def get_all_canonical_paths(source_schema) -> List[str]:
    """Return every canonical path -- no cap."""
    if not source_schema:
        return []
    elements = source_schema.get("elements", {})
    if isinstance(elements, list):
        return [e["path"] for e in elements if isinstance(e, dict) and "path" in e]
    return list(elements.keys())
