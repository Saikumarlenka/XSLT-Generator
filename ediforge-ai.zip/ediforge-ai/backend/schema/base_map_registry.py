"""
EDIForge AI v4 -- Base Map Registry
Reads actual XSL base maps and extracts structural metadata:
  - namespace declarations (ns0/s0 URIs)
  - root output element
  - xsl:variable declarations
  - hardcoded literal blocks
  - helper template definitions
  - loop structures with conditions
"""
import os, re, glob

BASE_MAPS_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "training", "base_maps")
XSL_MAPS_DIR  = os.path.join(os.path.dirname(__file__), "..", "..", "training", "xsl_maps")

_cache = {}

def _read_map(transaction_set):
    """Find best XSL base map for a transaction set. Returns file content or None."""
    # Check dedicated base_maps folder first
    for pattern in [f"*{transaction_set}*.xsl", f"*{transaction_set}*.xslt"]:
        hits = glob.glob(os.path.join(BASE_MAPS_DIR, pattern), recursive=False)
        if hits:
            return _decode_xsl(hits[0])
    # Fall back to xsl_maps folder
    for pattern in [f"*{transaction_set}*.xsl", f"*{transaction_set}*.xslt"]:
        hits = glob.glob(os.path.join(XSL_MAPS_DIR, "**", pattern), recursive=True)
        if hits:
            return _decode_xsl(hits[0])
    return None

def _decode_xsl(path):
    with open(path, "rb") as f:
        raw = f.read()
    for enc in ("utf-16", "utf-8-sig", "utf-8"):
        try:
            return raw.decode(enc)
        except Exception:
            pass
    return raw.decode("utf-8", errors="replace")

def get_base_map_metadata(transaction_set):
    """
    Returns dict with structural metadata extracted from the reference XSL map.
    Keys:
      ns0_uri       -- xmlns:ns0 value
      s0_uri        -- xmlns:s0 value
      root_element  -- e.g. "ns0:X12_00401_210"
      namespaces    -- full namespace declaration block for stylesheet element
      variables     -- list of xsl:variable declarations (date vars etc.)
      literals      -- dict of segment -> literal XML block (C2, R3, G62 etc.)
      helper_templates -- full text of all named xsl:template blocks
      loops         -- list of dicts: {name, for_each_select, condition, inner_xml}
      stylesheet_attrs -- full attribute string for <xsl:stylesheet ...>
    """
    global _cache
    if transaction_set in _cache:
        return _cache[transaction_set]

    content = _read_map(transaction_set)
    if not content:
        _cache[transaction_set] = None
        return None

    meta = {
        "ns0_uri": "",
        "s0_uri": "",
        "root_element": f"ns0:X12_00401_{transaction_set}",
        "namespaces": "",
        "variables": [],
        "literals": {},
        "helper_templates": "",
        "loops": [],
        "stylesheet_attrs": "",
        "raw_content": content,
    }

    # -- Extract namespace URIs --
    ns0 = re.search(r'xmlns:ns0="([^"]+)"', content)
    s0  = re.search(r'xmlns:s0="([^"]+)"', content)
    if ns0: meta["ns0_uri"] = ns0.group(1)
    if s0:  meta["s0_uri"]  = s0.group(1)

    # -- Extract full stylesheet open tag --
    st = re.search(r'(<xsl:stylesheet[^>]+>)', content, re.DOTALL)
    if st:
        meta["stylesheet_attrs"] = st.group(1)

    # -- Extract root output element (first element inside xsl:template match="/s0:...") --
    root_m = re.search(r'<xsl:template match="[^"]*">\s*<([\w:]+)', content)
    if root_m:
        meta["root_element"] = root_m.group(1)

    # -- Extract xsl:variable declarations (date vars, count vars) --
    vars_found = re.findall(r'\t*<xsl:variable name="[^"]+" select="[^"]+"\s*/>', content)
    meta["variables"] = list(dict.fromkeys(vars_found))  # deduplicate preserving order

    # -- Extract hardcoded literal blocks --
    # C2: <ns0:C2>...<C201>R</C201>...
    c2 = re.search(r'(<ns0:C2>.*?</ns0:C2>)', content, re.DOTALL)
    if c2: meta["literals"]["C2"] = c2.group(1).strip()

    # G62 blocks (may appear multiple times)
    g62s = re.findall(r'(<ns0:G62>.*?</ns0:G62>)', content, re.DOTALL)
    if g62s: meta["literals"]["G62"] = g62s  # list

    # R3 block (may be commented out)
    r3 = re.search(r'<ns0:R3>(.*?)</ns0:R3>', content, re.DOTALL)
    if r3: meta["literals"]["R3"] = f'<ns0:R3>{r3.group(1)}</ns0:R3>'.strip()

    # -- Extract helper templates --
    helper_matches = re.findall(
        r'(<xsl:template name="(?!CleanAlphaField)[^"]+">.*?</xsl:template>)',
        content, re.DOTALL
    )
    # Also grab CleanAlphaField (full version)
    clean = re.search(r'(<xsl:template name="CleanAlphaField">.*?</xsl:template>)', content, re.DOTALL)
    helpers = helper_matches[:]
    if clean: helpers.append(clean.group(1))
    meta["helper_templates"] = "\n\n\t".join(helpers)

    # -- Extract loop structures --
    for_each_blocks = re.finditer(
        r'<xsl:for-each select="([^"]+)">(.*?)</xsl:for-each>',
        content, re.DOTALL
    )
    for m in for_each_blocks:
        sel = m.group(1)
        inner = m.group(2).strip()
        # Get outer element if present
        outer = re.search(r'<(ns0:\w+)>', inner)
        name = outer.group(1) if outer else sel.split("/")[-1]
        meta["loops"].append({
            "name": name,
            "for_each_select": sel,
            "inner_xml": inner[:2000],  # cap for prompt injection
        })

    _cache[transaction_set] = meta
    return meta


def get_namespace_block(transaction_set):
    """Returns the xmlns declarations needed for the stylesheet element."""
    meta = get_base_map_metadata(transaction_set)
    if not meta:
        return ""
    return meta.get("stylesheet_attrs", "")


def get_literal_block(transaction_set, segment):
    """Returns the hardcoded literal XML for a given segment (e.g. 'C2', 'G62')."""
    meta = get_base_map_metadata(transaction_set)
    if not meta:
        return None
    return meta.get("literals", {}).get(segment)


def get_reference_excerpt(transaction_set, max_chars=6000):
    """
    Returns a condensed excerpt of the base map for injection into the AI prompt.
    Shows the correct structure without overwhelming the token limit.
    """
    meta = get_base_map_metadata(transaction_set)
    if not meta:
        return ""
    raw = meta.get("raw_content", "")
    # Return up to max_chars of the actual base map
    return raw[:max_chars]