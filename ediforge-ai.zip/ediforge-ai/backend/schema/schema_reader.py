"""EDIForge AI — Schema Reader. Fixed for real XSD files."""
import xml.etree.ElementTree as ET
from pathlib import Path

XSD_NS = "http://www.w3.org/2001/XMLSchema"

def read_xsd(xsd_path):
    content = Path(xsd_path).read_text(encoding="utf-8", errors="replace")
    return analyze_xsd_content(content)

def analyze_xsd_content(content):
    try:
        root = ET.fromstring(content)
    except ET.ParseError as e:
        return {"error": str(e), "elements": {}, "loops": [], "namespace": ""}

    target_ns = root.get("targetNamespace", "")
    elements = {}
    loops = []
    ns_prefix = f"{{{XSD_NS}}}"

    def get_tag(node):
        return node.tag.replace(ns_prefix, "")

    def walk(node, path="", depth=0):
        for child in node:
            tag = get_tag(child)
            name = child.get("name", "")
            max_occurs = child.get("maxOccurs", "1")
            min_occurs = child.get("minOccurs", "1")
            xtype = child.get("type", "")

            if tag == "element" and name:
                el_path = f"{path}/{name}" if path else name
                is_repeating = (max_occurs == "unbounded") or \
                               (max_occurs.isdigit() and int(max_occurs) > 1)
                is_optional = min_occurs == "0"

                # Store as dict keyed by path
                if el_path not in elements:
                    elements[el_path] = {
                        "name": name,
                        "path": el_path,
                        "type": xtype,
                        "repeating": is_repeating,
                        "optional": is_optional,
                        "depth": depth,
                        "attributes": {},
                        "children": [],
                        "sample_value": ""
                    }
                else:
                    elements[el_path]["repeating"] = True

                if is_repeating:
                    loops.append({
                        "name": name + "Loop",
                        "element": name,
                        "path": el_path
                    })

                # Go deeper
                walk(child, el_path, depth + 1)

            elif tag == "attribute" and name:
                attr_path = f"{path}/@{name}" if path else f"@{name}"
                if attr_path not in elements:
                    elements[attr_path] = {
                        "name": f"@{name}",
                        "path": attr_path,
                        "type": xtype,
                        "repeating": False,
                        "optional": True,
                        "depth": depth,
                        "is_attr": True,
                        "attributes": {},
                        "children": [],
                        "sample_value": ""
                    }

            elif tag in ["complexType", "sequence", "choice", "all", "group",
                         "complexContent", "simpleContent", "extension", "restriction"]:
                walk(child, path, depth)

    walk(root)

    return {
        "target_namespace": target_ns,
        "elements": elements,      # dict keyed by xpath path
        "loops": loops,
        "element_count": len(elements),
        "loop_count": len(loops),
        "namespace": target_ns
    }


def extract_from_xml(xml_content):
    """Extract all elements and attributes from a sample XML file."""
    elements = {}
    namespace = ""

    def walk(node, path=""):
        tag = node.tag
        if "}" in tag:
            ns = tag[1:tag.index("}")]
            tag = tag[tag.index("}") + 1:]
            nonlocal namespace
            if not namespace and ns:
                namespace = ns

        current = f"{path}/{tag}" if path else tag

        attrs = {}
        for k, v in node.attrib.items():
            k = k.split("}")[-1] if "}" in k else k
            attrs[k] = v

        info = {
            "name": tag,
            "path": current,
            "attributes": attrs,
            "sample_value": (node.text or "").strip()[:80],
            "children": [
                (c.tag.split("}")[-1] if "}" in c.tag else c.tag)
                for c in node
            ],
            "is_repeating": current in elements,
            "repeating": current in elements,
            "optional": True,
            "depth": path.count("/"),
            "type": ""
        }

        if current in elements:
            elements[current]["repeating"] = True
            elements[current]["is_repeating"] = True
        else:
            elements[current] = info

        # Also add attributes as separate entries
        for attr_name, attr_val in attrs.items():
            attr_path = f"{current}/@{attr_name}"
            if attr_path not in elements:
                elements[attr_path] = {
                    "name": f"@{attr_name}",
                    "path": attr_path,
                    "type": "string",
                    "repeating": False,
                    "is_repeating": False,
                    "optional": True,
                    "depth": path.count("/") + 1,
                    "is_attr": True,
                    "attributes": {},
                    "children": [],
                    "sample_value": attr_val[:80]
                }

        for child in node:
            walk(child, current)

    try:
        root = ET.fromstring(xml_content)
        walk(root)
    except ET.ParseError as e:
        return {"error": str(e), "elements": {}, "namespace": ""}

    return {
        "elements": elements,      # always a dict
        "namespace": namespace,
        "element_count": len(elements)
    }