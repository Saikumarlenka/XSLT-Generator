"""
EDIForge AI v4 -- Dual Schema Index
====================================
ROOT CAUSE FIX for logs:
  "ST -> Not found in canonical schema"
  "X12_00401_210 -> Not found in canonical schema"
  "ST01 -> Not found in canonical schema"

These are EDI *target* elements -- they belong to the X12 schema, NOT the
canonical schema.  The old pipeline called get_all_canonical_paths() and
then checked if EDI segment names existed in that set -- they never will.

This module maintains TWO completely separate indexes:
  canonical_index  -- paths from canonical XSD (source side, Invoice/Header/...)
  edi_index        -- paths from X12 XSD (target side, ST/ST01, B3/B302 ...)
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import Dict, List, Optional
import xml.etree.ElementTree as ET

XSD_NS   = "http://www.w3.org/2001/XMLSchema"
SCHEMAS_DIR = Path(__file__).parent.parent.parent / "schemas"

# -- Field-name synonyms for canonical matching ----------------------------
SYNONYMS: Dict[str, str] = {
    "bol": "billoflading", "billofladingno": "billoflading",
    "billofladingnum": "billoflading", "billofladingnumber": "billoflading",
    "carrierschac": "scac", "carrierscac": "scac", "scaccode": "scac",
    "stopno": "stopnumber", "stopnum": "stopnumber",
    "shipdate": "shipmentdate", "shippingdate": "shipmentdate",
    "pronum": "pronumber", "deliverydate": "delivereddate",
    "eta": "estimatedarrivaldate", "weight": "totalweight",
    "totalwt": "totalweight", "pieces": "totalpieces",
    "chargetype": "chargedescription", "chargedesc": "chargedescription",
    "amount": "chargeamount", "totalcharge": "chargeamount",
    "invnum": "invoicenumber", "invoiceno": "invoicenumber",
    "invdate": "invoicedate", "invnumber": "invoicenumber",
    "shipmentid": "shipmentidentificationnumber",
    "bolnumber": "billoflading", "pronumber": "pronumber",
}


def _norm(name: str) -> str:
    return re.sub(r"[\s_\-#./\\()\[\]]", "", name).lower()


# =============================================================================
# Canonical index (source side)
# =============================================================================

def build_canonical_index_from_schema(source_schema: Optional[dict]) -> Dict[str, str]:
    """Build {normalised_leaf: full_canonical_xpath} from a parsed schema dict."""
    if not source_schema:
        return {}
    elements = source_schema.get("elements", {})
    if isinstance(elements, list):
        elements = {e["path"]: e for e in elements if isinstance(e, dict) and "path" in e}
    index: Dict[str, str] = {}
    for path in elements:
        leaf = path.split("/")[-1].lstrip("@")
        key = _norm(leaf)
        if key not in index or path.count("/") < index[key].count("/"):
            index[key] = path
    for alias, canonical_key in SYNONYMS.items():
        if canonical_key in index and alias not in index:
            index[alias] = index[canonical_key]
    return index


def build_canonical_index_from_xsd(transaction_set: str) -> Dict[str, str]:
    """Build canonical index directly from XSD file on disk."""
    xsd_dir = SCHEMAS_DIR / "canonical" / transaction_set
    files = list(xsd_dir.glob("*.xsd")) if xsd_dir.exists() else []
    if not files:
        return {}
    content = files[0].read_text(encoding="utf-8", errors="replace")
    paths = _walk_xsd_paths(content)
    index: Dict[str, str] = {}
    for path in paths:
        leaf = path.split("/")[-1].lstrip("@")
        key = _norm(leaf)
        if key not in index or path.count("/") < index[key].count("/"):
            index[key] = path
    for alias, canonical_key in SYNONYMS.items():
        if canonical_key in index and alias not in index:
            index[alias] = index[canonical_key]
    return index


def resolve_canonical_field(field: str, index: Dict[str, str]) -> Optional[str]:
    """Exact match -> synonym -> prefix/suffix fuzzy match."""
    key = _norm(field)
    if key in index:
        return index[key]
    candidates = {k: v for k, v in index.items() if k.startswith(key) and len(key) >= 4}
    if candidates:
        return candidates[min(candidates, key=len)]
    candidates2 = {k: v for k, v in index.items() if key.startswith(k) and len(k) >= 4}
    if candidates2:
        return candidates2[max(candidates2, key=len)]
    return None


def get_all_canonical_paths(source_schema: Optional[dict]) -> List[str]:
    if not source_schema:
        return []
    elements = source_schema.get("elements", {})
    if isinstance(elements, list):
        return [e["path"] for e in elements if isinstance(e, dict) and "path" in e]
    return list(elements.keys())


# =============================================================================
# EDI index (target side)
# =============================================================================

def build_edi_index(transaction_set: str) -> Dict[str, str]:
    """Returns {EDI_element: path_in_X12_schema}  e.g. {"B302": "B3/B302"}."""
    xsd_path = SCHEMAS_DIR / "x12" / transaction_set
    files = list(xsd_path.glob("*.xsd")) if xsd_path.exists() else []
    if not files:
        return _hardcoded_edi_index(transaction_set)
    content = files[0].read_text(encoding="utf-8", errors="replace")
    paths = _walk_xsd_paths(content)
    index: Dict[str, str] = {}
    for path in paths:
        leaf = path.split("/")[-1].lstrip("@")
        if leaf and "Loop" not in leaf:
            index[leaf] = path
    return index if index else _hardcoded_edi_index(transaction_set)


def validate_edi_target(target: str, edi_index: Dict[str, str]) -> bool:
    tgt_clean = target.split(":")[-1] if ":" in target else target
    return tgt_clean in edi_index or target in edi_index


def get_all_edi_paths(transaction_set: str) -> List[str]:
    return list(build_edi_index(transaction_set).values())


# =============================================================================
# Loop detection from canonical XSD
# =============================================================================

def detect_repeating_nodes(transaction_set: str) -> List[Dict[str, str]]:
    """Find elements with maxOccurs > 1 in the canonical XSD."""
    xsd_dir = SCHEMAS_DIR / "canonical" / transaction_set
    files = list(xsd_dir.glob("*.xsd")) if xsd_dir.exists() else []
    if not files:
        return _hardcoded_loops(transaction_set)
    content = files[0].read_text(encoding="utf-8", errors="replace")
    return _find_repeating(content)


def _find_repeating(xsd_content: str) -> List[Dict[str, str]]:
    try:
        root = ET.fromstring(xsd_content)
    except ET.ParseError:
        return []
    ns = f"{{{XSD_NS}}}"
    results = []

    def walk(node, path=""):
        for child in node:
            tag = child.tag.replace(ns, "")
            name = child.get("name", "") or child.get("ref", "")
            max_occ = child.get("maxOccurs", "1")
            is_rep = (max_occ == "unbounded") or (max_occ.isdigit() and int(max_occ) > 1)
            if tag == "element" and name:
                cur = f"{path}/{name}" if path else name
                if is_rep:
                    results.append({"name": name, "xpath": cur})
                walk(child, cur)
            elif tag in ("complexType","sequence","choice","group",
                         "complexContent","simpleContent","extension","restriction"):
                walk(child, path)
    walk(root)
    return results


# =============================================================================
# Shared XSD walker
# =============================================================================

def _walk_xsd_paths(xsd_content: str) -> List[str]:
    try:
        root = ET.fromstring(xsd_content)
    except ET.ParseError:
        return []
    ns = f"{{{XSD_NS}}}"
    paths: List[str] = []

    def walk(node, path=""):
        for child in node:
            tag = child.tag.replace(ns, "")
            name = child.get("name", "") or child.get("ref", "")
            if tag == "element" and name:
                cur = f"{path}/{name}" if path else name
                paths.append(cur)
                walk(child, cur)
            elif tag == "attribute" and name:
                paths.append(f"{path}/@{name}" if path else f"@{name}")
            elif tag in ("complexType","sequence","choice","group",
                         "complexContent","simpleContent","extension","restriction"):
                walk(child, path)
    walk(root)
    return paths


# =============================================================================
# Hardcoded fallbacks when XSD is missing
# =============================================================================

def _hardcoded_edi_index(ts: str) -> Dict[str, str]:
    common = {"ST01":"ST/ST01","ST02":"ST/ST02","SE01":"SE/SE01","SE02":"SE/SE02"}
    by_ts = {
        "210": {**common,
            "B301":"B3/B301","B302":"B3/B302","B303":"B3/B303","B304":"B3/B304",
            "B305":"B3/B305","B306":"B3/B306","B307":"B3/B307","B308":"B3/B308",
            "B309":"B3/B309","B310":"B3/B310","B311":"B3/B311","B312":"B3/B312",
            "C201":"C2/C201","C202":"C2/C202","C203":"C2/C203",
            "C301":"C3/C301",
            "R301":"R3/R301","R302":"R3/R302","R303":"R3/R303","R304":"R3/R304",
            "R305":"R3/R305","R306":"R3/R306",
            "N101":"N1/N101","N102":"N1/N102","N103":"N1/N103","N104":"N1/N104",
            "N301":"N3/N301","N302":"N3/N302",
            "N401":"N4/N401","N402":"N4/N402","N403":"N4/N403","N404":"N4/N404",
            "N901":"N9/N901","N902":"N9/N902","N903":"N9/N903",
            "G621":"G62/G621","G622":"G62/G622",
            "LX01":"LX/LX01","L501":"L5/L501","L502":"L5/L502",
            "L001":"L0/L001","L004":"L0/L004",
            "L101":"L1/L101","L104":"L1/L104",
            "L301":"L3/L301","L305":"L3/L305",
        },
        "214": {**common,
            "B1001":"B10/B1001","B1002":"B10/B1002","B1003":"B10/B1003",
            "AT701":"AT7/AT701","AT702":"AT7/AT702","AT705":"AT7/AT705",
            "MS101":"MS1/MS101","MS102":"MS1/MS102",
            "N101":"N1/N101","N102":"N1/N102",
            "L1101":"L11/L1101","L1102":"L11/L1102",
        },
        "990": {**common,
            "W601":"W6/W601","W602":"W6/W602",
            "R401":"R4/R401","R402":"R4/R402",
            "K101":"K1/K101","K102":"K1/K102",
        },
        "204": {**common,
            "B101":"B1/B101","B102":"B1/B102","B103":"B1/B103",
            "S501":"S5/S501","S502":"S5/S502","S503":"S5/S503",
            "N101":"N1/N101","N102":"N1/N102",
            "L1101":"L11/L1101","L1102":"L11/L1102",
        },
    }
    return by_ts.get(ts, common)


def _hardcoded_loops(ts: str) -> List[Dict[str, str]]:
    by_ts = {
        "210": [
            {"name":"Party",     "xpath":"Header/PartyList/Party"},
            {"name":"LineItem",  "xpath":"Detail/LineItemList/LineItem"},
            {"name":"Equipment", "xpath":"Header/EquipmentList/Equipment"},
            {"name":"ReferenceInformation","xpath":"Header/ReferenceList/ReferenceInformation"},
        ],
        "214": [
            {"name":"Status",    "xpath":"Detail/StatusList/Status"},
            {"name":"Stop",      "xpath":"Detail/StopList/Stop"},
            {"name":"Reference", "xpath":"Detail/ReferenceList/Reference"},
        ],
        "990": [
            {"name":"Stop",      "xpath":"Detail/StopList/Stop"},
        ],
        "204": [
            {"name":"Stop",      "xpath":"Detail/StopList/Stop"},
            {"name":"Reference", "xpath":"Detail/ReferenceList/Reference"},
        ],
    }
    return by_ts.get(ts, [])