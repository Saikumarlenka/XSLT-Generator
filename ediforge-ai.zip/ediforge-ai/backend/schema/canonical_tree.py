"""EDIForge AI v2 -- Canonical Tree Builder."""
from __future__ import annotations
from typing import Dict, Optional


class CanonicalNode:
    def __init__(self, name: str, path: str = "", repeating: bool = False, is_attr: bool = False):
        self.name = name
        self.path = path
        self.repeating = repeating
        self.is_attr = is_attr
        self.children: Dict[str, "CanonicalNode"] = {}


def build_tree(source_schema) -> CanonicalNode:
    root = CanonicalNode("root", "")
    if not source_schema:
        return root
    elements = source_schema.get("elements", {})
    if isinstance(elements, list):
        elements = {e["path"]: e for e in elements if isinstance(e, dict) and "path" in e}
    for path, info in elements.items():
        parts = path.split("/")
        node = root
        for i, part in enumerate(parts):
            is_attr = part.startswith("@")
            clean = part.lstrip("@")
            if clean not in node.children:
                sub_path = "/".join(parts[: i + 1])
                sub_info = elements.get(sub_path, {})
                repeating = sub_info.get("repeating") or sub_info.get("is_repeating") or False
                node.children[clean] = CanonicalNode(name=clean, path=sub_path,
                                                      repeating=bool(repeating), is_attr=is_attr)
            node = node.children[clean]
    return root


def print_tree(node: CanonicalNode, indent: int = 0) -> str:
    lines = []
    prefix = "|   " * indent + "+-- "
    flag = " [REPEAT]" if node.repeating else ""
    attr = "@" if node.is_attr else ""
    lines.append(f"{prefix}{attr}{node.name}{flag}")
    for child in node.children.values():
        lines.append(print_tree(child, indent + 1))
    return "\n".join(lines)


def node_at_path(root: CanonicalNode, path: str) -> Optional[CanonicalNode]:
    node = root
    for part in path.split("/"):
        clean = part.lstrip("@")
        if clean not in node.children:
            return None
        node = node.children[clean]
    return node
