"""
EDIForge AI - Strict Path Resolution Engine (FIXED v2)
Resolves field names to canonical XPaths with context-segment preference.
"""
from __future__ import annotations
import re
from difflib import get_close_matches
from typing import Dict, List, Optional

_SYNONYMS = {
    "bol": "BillOfLading", "pro": "ProNumber", "pronumber": "ProNumber",
    "po": "PurchaseOrderNumber", "scac": "StandardCarrierAlphaCode",
    "loadid": "LoadId", "referenceid": "ReferenceId",
    "referencetype": "ReferenceType", "stoptype": "StopType",
    "statuscode": "StatusCode", "weight": "TotalWeight",
    "totalweight": "TotalWeight", "equipmentnumber": "EquipmentNumber",
    "invoicenumber": "InvoiceNumber", "invnum": "InvoiceNumber",
    "invoicedate": "InvoiceDate", "shipmentid": "ShipmentIdentificationNumber",
    "bolnumber": "BillOfLading", "carrierscac": "StandardCarrierAlphaCode",
    "netamountdue": "NetAmountDue", "totalcharges": "TotalCharges",
}


def _norm(s):
    return re.sub(r"[^a-z0-9]", "", s.lower())


def resolve_path(input_path, canonical_index, context_segment="", transaction_set=""):
    if not input_path:
        return None
    s = input_path.strip()
    if "/" in s or s.startswith("@"):
        return s
    key = _norm(s)
    if not key:
        return None
    if key in canonical_index:
        return _ctx(canonical_index[key], key, canonical_index, context_segment)
    syn = _SYNONYMS.get(key)
    if syn:
        sk = _norm(syn)
        if sk in canonical_index:
            return _ctx(canonical_index[sk], sk, canonical_index, context_segment)
    close = get_close_matches(key, list(canonical_index.keys()), n=3, cutoff=0.72)
    if close:
        ctx_hits = [c for c in close if context_segment.lower() in canonical_index[c].lower()]
        best = ctx_hits[0] if ctx_hits else close[0]
        return canonical_index[best]
    hits = [v for k, v in canonical_index.items() if len(key) >= 4 and (key in k or k in key)]
    if hits:
        ctx_hits = [h for h in hits if context_segment.lower() in h.lower()]
        return ctx_hits[0] if ctx_hits else hits[0]
    return None


def _ctx(found, key, index, context_segment):
    if not context_segment:
        return found
    all_hits = [v for k, v in index.items() if key in k or k in key]
    ctx_hits = [p for p in all_hits if context_segment.lower() in p.lower()]
    return ctx_hits[0] if ctx_hits else found


def resolve_all_mappings(mapping_rows, canonical_index, transaction_set=""):
    for row in mapping_rows:
        if row.get("_is_literal") or row.get("literal"):
            row["_resolved_source"] = None
            continue
        src   = (row.get("source") or "").strip()
        tgt   = (row.get("target") or "").strip()
        ctx_m = re.match(r"^([A-Z][A-Z0-9]{1,2})", tgt)
        context = ctx_m.group(1) if ctx_m else ""
        resolved = resolve_path(src, canonical_index, context, transaction_set)
        if resolved:
            row["source"] = resolved
            row["_resolved_source"] = resolved
        else:
            row["_resolved_source"] = None
    return mapping_rows


def validate_source_against_canonical(source_xpath, canonical_paths, canonical_index):
    if not source_xpath or not canonical_paths:
        return True
    if source_xpath in canonical_paths:
        return True
    clean_src = source_xpath.replace("s0:", "")
    if clean_src in canonical_paths:
        return True
    leaf = source_xpath.split("/")[-1].lstrip("@")
    if any(p.endswith("/" + leaf) or p.endswith("@" + leaf) for p in canonical_paths):
        return True
    if _norm(leaf) in canonical_index:
        return True
    parts = [p for p in source_xpath.split("/") if p and not p.startswith("s0:")]
    if len(parts) >= 2:
        last_two = "/".join(parts[-2:])
        if any(last_two in p for p in canonical_paths):
            return True
    return False



def validate_target_against_edi(target_elem, edi_index):
    if not target_elem or not edi_index:
        return True
    clean = target_elem.split(":")[-1] if ":" in target_elem else target_elem
    return clean in edi_index