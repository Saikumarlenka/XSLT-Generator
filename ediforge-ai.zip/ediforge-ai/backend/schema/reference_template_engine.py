"""
EDIForge AI v4 -- Reference Template Engine
============================================
Template-guided generation:
  - Without templates: AI guesses entire XSL structure  -> ~60% accuracy
  - With templates:    AI copies known loops/conditions  -> ~90%+ accuracy

Workflow:
  1. load training/base_maps/210_base.xsl (best existing map per transaction)
  2. extract all xsl:for-each loops
  3. extract all xsl:if conditions
  4. extract all hardcoded literal values
  5. extract source/target namespace
  6. build a prompt section that instructs the AI to copy the structure

auto_populate_base_maps() auto-selects from training/xsl_maps/ on first run.
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import Dict, List, Optional

BASE_MAPS_DIR = Path(__file__).parent.parent.parent / "training" / "base_maps"
MAPS_DIR      = Path(__file__).parent.parent.parent / "training" / "xsl_maps"

TRANSACTION_MAP_NAMES = {
    "210": ["210_base.xsl","210_base.xslt"],
    "214": ["214_base.xsl","214_base.xslt"],
    "990": ["990_base.xsl","990_base.xslt"],
    "204": ["204_base.xsl","204_base.xslt"],
}

_cache: Dict[str, dict] = {}


# =============================================================================
# Public API
# =============================================================================

def get_reference_template(transaction_set: str) -> Optional[dict]:
    if transaction_set in _cache:
        return _cache[transaction_set]
    path = _find_base_map(transaction_set)
    if not path:
        return None
    try:
        content = _read_xsl(path)
    except Exception:
        return None
    result = {
        "transaction_set": transaction_set,
        "loops":      _extract_loops(content),
        "conditions": _extract_conditions(content),
        "literals":   _extract_literals(content),
        "excerpts":   content[:6000],
        "source_ns":  _extract_source_ns(content),
        "target_ns":  _extract_target_ns(content),
    }
    _cache[transaction_set] = result
    return result


def get_base_map_section_for_prompt(transaction_set: str) -> str:
    """Return the prompt section to inject into AI generation call."""
    tmpl = get_reference_template(transaction_set)
    if not tmpl:
        return ""
    lines = [
        f"=== REFERENCE XSL MAP FOR {transaction_set} (structural guide -- USE as base, apply ALL customer mapping changes) ===",
        "This is a base reference map for this transaction set.",
        "USE the loop structure and namespace declarations as a starting point.",
        "CRITICALLY: Apply ALL changes specified in the MAPPING ROWS below. These are customer-specific requirements that OVERRIDE the reference map.",
        "Fields marked as struck-through or removed in the mapping document must be DELETED from output.",
        "Fields with different sources, literals, or rules must be UPDATED to match the mapping document exactly.",
        "",
    ]
    if tmpl["loops"]:
        lines.append("LOOPS IN REFERENCE MAP (preserve these xsl:for-each patterns):")
        for lp in tmpl["loops"]:
            lines.append(f"  xsl:for-each select=\"{lp['xpath']}\"  ->  EDI loop: {lp['edi_loop']}")
        lines.append("")
    if tmpl["conditions"]:
        lines.append("CONDITION PATTERNS (use xsl:if like these examples):")
        for cond in tmpl["conditions"][:12]:
            lines.append(f"  segment {cond['segment']}: xsl:if test=\"{cond['test']}\"")
        lines.append("")
    if tmpl["literals"]:
        lines.append("HARDCODED VALUES (these have no source -- output verbatim):")
        for lit in tmpl["literals"]:
            lines.append(f"  <{lit['element']}>{lit['value']}</{lit['element']}>")
        lines.append("")
    if tmpl["source_ns"]:
        lines.append(f"SOURCE NAMESPACE (use as xmlns:s0): {tmpl['source_ns']}")
    if tmpl["target_ns"]:
        lines.append(f"TARGET NAMESPACE (use as xmlns:ns0): {tmpl['target_ns']}")
    lines += ["", "=== REFERENCE MAP EXCERPT (first 6000 chars) ===", tmpl["excerpts"], "=== END REFERENCE ===", ""]
    return "\n".join(lines)


def list_available_base_maps() -> List[dict]:
    result = []
    for ts in TRANSACTION_MAP_NAMES:
        p = _find_base_map(ts)
        if p:
            try:
                content = _read_xsl(p)
            except Exception:
                content = ""
            loops = _extract_loops(content)
            result.append({
                "transaction_set":  ts,
                "filename":         p.name,
                "loops_detected":   len(loops),
                "loop_list":        [lp["edi_loop"] for lp in loops],
                "has_conditions":   bool(_extract_conditions(content)),
                "has_literals":     bool(_extract_literals(content)),
                "source_ns":        _extract_source_ns(content),
                "target_ns":        _extract_target_ns(content),
            })
    return result


def auto_populate_base_maps():
    """
    Auto-select best XSL map from training/xsl_maps/ for each transaction
    if training/base_maps/ doesn't already have one.
    Priority: most loops > keyword match > largest file.
    """
    if not MAPS_DIR.exists():
        return
    PATTERNS = {
        "210": ["210","invoice","inv"],
        "214": ["214","status","stat"],
        "990": ["990","tender","response"],
        "204": ["204","load"],
    }
    for ts, keywords in PATTERNS.items():
        dest = BASE_MAPS_DIR / f"{ts}_base.xsl"
        if dest.exists():
            continue
        candidates = []
        for f in MAPS_DIR.glob("*.xsl"):
            fname = f.name.lower()
            score = 0
            for kw in keywords:
                if kw in fname:
                    score += 10
            if score == 0:
                continue
            try:
                content = _read_xsl(f)
                score += len(re.findall(r"xsl:for-each", content)) * 2
                score += len(f.read_bytes())  // 10000
                candidates.append((score, f, content))
            except Exception:
                pass
        if candidates:
            candidates.sort(key=lambda x: x[0], reverse=True)
            _, best_file, best_content = candidates[0]
            BASE_MAPS_DIR.mkdir(parents=True, exist_ok=True)
            dest.write_text(best_content, encoding="utf-8")
            print(f"  [AutoPop] {ts}: selected {best_file.name} as base map")


# =============================================================================
# Internal helpers
# =============================================================================

def _find_base_map(ts: str) -> Optional[Path]:
    BASE_MAPS_DIR.mkdir(parents=True, exist_ok=True)
    for name in TRANSACTION_MAP_NAMES.get(ts, []):
        p = BASE_MAPS_DIR / name
        if p.exists():
            return p
    return None


def _read_xsl(path: Path) -> str:
    # Try UTF-16 first (BizTalk default), then UTF-8
    for enc in ("utf-16", "utf-8"):
        try:
            return path.read_text(encoding=enc, errors="replace")
        except Exception:
            continue
    return ""


def _extract_loops(content: str) -> List[Dict[str, str]]:
    loops = []
    seen = set()
    for m in re.finditer(r'xsl:for-each\s+select="([^"]+)"', content):
        xpath = m.group(1).strip()
        if xpath in seen:
            continue
        seen.add(xpath)
        loops.append({"xpath": xpath, "edi_loop": _guess_edi_loop(xpath)})
    return loops


def _guess_edi_loop(xpath: str) -> str:
    x = xpath.lower()
    if "party" in x:      return "N1Loop1"
    if "lineitem" in x:   return "LXLoop1"
    if "equipment" in x:  return "N7Loop1"
    if "reference" in x:  return "N9Loop1"
    if "status" in x:     return "AT7Loop1"
    if "stop" in x:       return "S5Loop1"
    if "charge" in x:     return "L1Loop1"
    return "Loop"


def _extract_conditions(content: str) -> List[Dict[str, str]]:
    conditions = []
    for m in re.finditer(
        r'<(?:ns0:)?([A-Z][A-Z0-9]{1,3})(?:\s[^>]*)?>(?:[^<]*<[^>]+>)*\s*<xsl:if\s+test="([^"]+)"',
        content
    ):
        seg, test = m.group(1), m.group(2)
        if seg not in ("xsl","Root","stylesheet"):
            conditions.append({"segment": seg, "test": test})
    return conditions[:30]


def _extract_literals(content: str) -> List[Dict[str, str]]:
    literals = []
    seen = set()
    for m in re.finditer(r'<([A-Z][A-Z0-9]{3,5})>([^<>{}\n]{1,40})</\1>', content):
        elem, val = m.group(1), m.group(2).strip()
        if val and elem not in seen and "xsl" not in val and "stylesheet" not in val:
            seen.add(elem)
            literals.append({"element": elem, "value": val})
    return literals


def _extract_source_ns(content: str) -> str:
    m = re.search(r'xmlns:s0="([^"]+)"', content)
    return m.group(1) if m else ""


def _extract_target_ns(content: str) -> str:
    m = re.search(r'xmlns:ns0="([^"]+)"', content)
    return m.group(1) if m else ""