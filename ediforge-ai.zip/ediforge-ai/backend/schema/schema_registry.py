"""EDIForge AI — Schema Registry"""
import xml.etree.ElementTree as ET
from pathlib import Path

SCHEMAS_DIR = Path(__file__).parent.parent.parent / "schemas"
XSD_NS = "http://www.w3.org/2001/XMLSchema"

SCHEMA_REGISTRY = {
    "210": {"name": "Motor Carrier Freight Details and Invoice", "path": "x12/210/X12_00401_210.xsd"},
    "214": {"name": "Transportation Carrier Shipment Status Message", "path": "x12/214/X12_00401_214.xsd"},
    "204": {"name": "Motor Carrier Load Tender", "path": "x12/204/X12_00401_204.xsd"},
    "990": {"name": "Response to a Load Tender", "path": "x12/990/X12_00401_990.xsd"},
}


def get_available_schemas():
    available = []
    for key, info in SCHEMA_REGISTRY.items():
        if (SCHEMAS_DIR / info["path"]).exists():
            available.append({"id": key, "name": info["name"], "transaction": key})
    return available


def load_schema(transaction_set: str) -> dict:
    if transaction_set not in SCHEMA_REGISTRY:
        return {"error": f"Schema {transaction_set} not found"}
    schema_path = SCHEMAS_DIR / SCHEMA_REGISTRY[transaction_set]["path"]
    if not schema_path.exists():
        return {"error": f"File not found: {schema_path}"}
    content = schema_path.read_bytes().decode("utf-8", errors="replace")
    return parse_biztalk_xsd(content, transaction_set)


def parse_biztalk_xsd(content: str, transaction_set: str = "") -> dict:
    try:
        root = ET.fromstring(content)
    except ET.ParseError as e:
        return {"error": str(e)}

    ns_prefix = f"{{{XSD_NS}}}"
    segments = {}
    loops = []
    element_map = {}

    def get_notes(node):
        for ann in node.findall(f"{ns_prefix}annotation"):
            for appinfo in ann.findall(f"{ns_prefix}appinfo"):
                for child in appinfo:
                    notes = child.get("notes", "")
                    if notes:
                        return notes
        return ""

    def walk(node, path="", depth=0):
        for child in node:
            tag = child.tag.replace(ns_prefix, "")
            name = child.get("name", "") or child.get("ref", "")
            min_occ = child.get("minOccurs", "1")
            max_occ = child.get("maxOccurs", "1")

            if tag == "element" and name:
                el_path = f"{path}/{name}" if path else name
                is_repeating = max_occ == "unbounded" or (max_occ.isdigit() and int(max_occ) > 1)
                notes = get_notes(child)

                element_map[el_path] = {
                    "name": name, "path": el_path, "notes": notes,
                    "required": min_occ != "0", "repeating": is_repeating,
                    "is_loop": "Loop" in name, "depth": depth
                }

                if "Loop" in name:
                    loops.append({
                        "name": name, "path": el_path,
                        "segment": name.replace("Loop1","").replace("Loop2","").replace("Loop","")
                    })

                seg = name.split("Loop")[0] if "Loop" in name else name
                if len(seg) <= 4 and seg.isupper() and "Loop" not in name:
                    if seg not in segments:
                        segments[seg] = {"name": seg, "notes": notes, "required": min_occ != "0", "elements": []}
                    ct = child.find(f"{ns_prefix}complexType")
                    if ct is not None:
                        seq = ct.find(f"{ns_prefix}sequence")
                        if seq is not None:
                            for el in seq.findall(f"{ns_prefix}element"):
                                el_name = el.get("name", "")
                                if el_name:
                                    segments[seg]["elements"].append({
                                        "id": el_name,
                                        "notes": get_notes(el),
                                        "required": el.get("minOccurs", "1") != "0"
                                    })

                walk(child, el_path, depth + 1)

            elif tag in ["complexType", "sequence", "choice", "all", "group",
                         "complexContent", "simpleContent", "extension", "restriction"]:
                walk(child, path, depth)

    walk(root)

    return {
        "transaction_set": transaction_set,
        "namespace": "http://schemas.microsoft.com/BizTalk/EDI/X12/2006",
        "segments": segments, "loops": loops, "element_map": element_map,
        "segment_count": len(segments), "loop_count": len(loops), "element_count": len(element_map)
    }


def get_schema_summary(transaction_set: str) -> str:
    schema = load_schema(transaction_set)
    if "error" in schema:
        return ""
    lines = [
        f"=== X12 {transaction_set} Standard EDI Schema ===",
        f"Namespace: {schema['namespace']}",
        f"Segments: {schema['segment_count']}  Loops: {schema['loop_count']}", ""
    ]
    if schema["loops"]:
        lines.append("LOOP STRUCTURE:")
        for loop in schema["loops"][:30]:
            lines.append(f"  {loop['name']} (segment: {loop['segment']})")
        lines.append("")
    lines.append("SEGMENTS AND ELEMENTS:")
    for seg_name, seg_info in list(schema["segments"].items())[:60]:
        req = "M" if seg_info["required"] else "O"
        notes = f" — {seg_info['notes']}" if seg_info["notes"] else ""
        lines.append(f"  {seg_name} [{req}]{notes}")
        for el in seg_info["elements"][:12]:
            el_req = "M" if el["required"] else "O"
            el_notes = f" ({el['notes'][:50]})" if el["notes"] else ""
            lines.append(f"    {el['id']} [{el_req}]{el_notes}")
    return "\n".join(lines)


def detect_transaction_from_mapping(text: str) -> str:
    for ts in ["210", "214", "204", "990", "850", "856", "810", "997"]:
        if ts in text:
            return ts
    tl = text.lower()
    if any(k in tl for k in ["invoice", "freight invoice", "carrier invoice"]): return "210"
    if any(k in tl for k in ["shipment status", "tracking"]): return "214"
    if any(k in tl for k in ["load tender", "motor carrier load"]): return "204"
    if any(k in tl for k in ["response to", "tender response"]): return "990"
    return ""
# =============================================================================
# EDIForge AI v4 -- Canonical info + namespace shims
# V4_REGISTRY_SHIMS
# =============================================================================

def get_canonical_info(source_schema: dict) -> str:
    try:
        from backend.generator.xslt_generator import get_canonical_info as _gci
        return _gci(source_schema)
    except Exception:
        if not source_schema: return "CANONICAL SCHEMA: Not provided."
        elements = source_schema.get("elements", {})
        count = len(elements) if isinstance(elements, dict) else len(elements)
        ns = source_schema.get("namespace", source_schema.get("target_namespace",""))
        return f"Canonical schema: {count} paths. Namespace: {ns}"


def get_full_namespace_block(source_schema: dict, transaction_set: str) -> str:
    source_ns = ""
    target_ns = ""
    if source_schema:
        source_ns = source_schema.get("namespace","") or source_schema.get("target_namespace","")
    try:
        from backend.schema.reference_template_engine import get_reference_template
        tmpl = get_reference_template(transaction_set)
        if tmpl:
            if not source_ns and tmpl.get("source_ns"): source_ns = tmpl["source_ns"]
            if not target_ns and tmpl.get("target_ns"): target_ns = tmpl["target_ns"]
    except Exception:
        pass
    lines = ['xmlns:xsl="http://www.w3.org/1999/XSL/Transform"',
             'xmlns:msxsl="urn:schemas-microsoft-com:xslt"',
             'xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var"',
             'xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp"']
    if source_ns: lines.append(f'xmlns:s0="{source_ns}"')
    if target_ns: lines.append(f'xmlns:ns0="{target_ns}"')
    return "\n  ".join(lines)
