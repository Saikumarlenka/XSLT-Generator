"""EDIForge AI - Core AI Engine v3. Universal canonical-to-EDI XSLT generation."""
import os, json, re
from dotenv import load_dotenv
load_dotenv()

MAX_FIX_RETRIES = int(os.getenv("MAX_FIX_RETRIES", 3))

def get_client(provider=None):
    provider = provider or os.getenv("AI_PROVIDER", "openrouter")
    if provider == "openrouter":
        from openai import OpenAI
        return "openrouter", OpenAI(
            api_key=os.getenv("OPENROUTER_API_KEY"),
            base_url="https://openrouter.ai/api/v1",
            default_headers={"HTTP-Referer":"https://ediforge.ai","X-Title":"EDIForge AI"}
        )
    elif provider == "groq":
        from openai import OpenAI
        return "groq", OpenAI(api_key=os.getenv("GROQ_API_KEY"), base_url="https://api.groq.com/openai/v1")
    elif provider == "gemini":
        from google import genai
        return "gemini", genai.Client(api_key=os.getenv("GEMINI_API_KEY"))
    elif provider == "openai":
        from openai import OpenAI
        return "openai", OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    raise ValueError(f"Unknown provider: {provider}")

def call_ai(prompt, system_prompt="", use_fallback=False, model_override=None):
    pname = os.getenv("FALLBACK_PROVIDER","groq") if use_fallback else os.getenv("AI_PROVIDER","openrouter")
    try:
        provider, client = get_client(pname)
        if provider == "gemini":
            r = client.models.generate_content(
                model=model_override or os.getenv("AI_MODEL","deepseek/deepseek-chat-v3-0324:free"),
                contents=f"{system_prompt}\n\n{prompt}"
            )
            return r.text
        if model_override:
            model = model_override
        elif use_fallback:
            model = os.getenv("FALLBACK_MODEL","llama-3.3-70b-versatile")
        else:
            model = os.getenv("AI_MODEL","deepseek/deepseek-chat-v3-0324:free")
        r = client.chat.completions.create(
            model=model, max_tokens=8000,
            messages=[{"role":"system","content":system_prompt},{"role":"user","content":prompt}]
        )
        return r.choices[0].message.content
    except Exception as e:
        if not use_fallback:
            print(f"Primary AI failed ({e}), switching to fallback...")
            try:
                return call_ai(prompt, system_prompt, use_fallback=True, model_override=None)
            except Exception as fallback_err:
                raise RuntimeError(f"Both primary and fallback AI failed. Primary: {e}. Fallback: {fallback_err}")
        raise

def clean_xslt(raw):
    raw = raw.strip()
    if "```" in raw:
        raw = "\n".join(l for l in raw.split("\n") if not l.strip().startswith("```")).strip()
    if not raw.startswith("<") and "<xsl:stylesheet" in raw:
        raw = raw[raw.find("<xsl:stylesheet"):]
    elif not raw.startswith("<") and "<?xml" in raw:
        raw = raw[raw.find("<?xml"):]
    # Keep XML prolog if present - file is written as UTF-8
    # lxml validation reads from string (UTF-8 in memory) so prolog is stripped only for validation
    return raw

def clean_json(raw):
    raw = re.sub(r"```json\s*","",raw.strip())
    raw = re.sub(r"```\s*","",raw)
    try: return json.loads(raw)
    except:
        m = re.search(r'\{.*\}', raw, re.DOTALL)
        if m:
            try: return json.loads(m.group())
            except: pass
        return {}

XSLT_SYSTEM = """You are EDIForge AI - an expert EDI/XSLT developer specialising in BizTalk Server canonical-to-EDI transformations.

========================================
NAMESPACE RULES (CRITICAL)
========================================

NEVER hardcode client-specific namespace URIs.
ALWAYS use the namespaces provided in the prompt under SOURCE NAMESPACE and TARGET NAMESPACE.
Namespaces change per client and per transaction set - always read them from the prompt.

Standard BizTalk namespaces to ALWAYS include:
  xmlns:msxsl="urn:schemas-microsoft-com:xslt"
  xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var"
  xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp"
  exclude-result-prefixes="msxsl var s0 userCSharp"

========================================
MANDATORY OUTPUT FORMAT
========================================

ALWAYS start with the XML declaration: <?xml version="1.0" encoding="UTF-8"?>
Always include: <xsl:output omit-xml-declaration="yes" method="xml" version="1.0" />
Always include these variables after xsl:output:
  <xsl:variable name="vLowercaseChars_CONST" select="'abcdefghijklmnopqrstuvwxyz'"/>
  <xsl:variable name="vUppercaseChars_CONST" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'"/>

========================================
BIZTALK TWO-TEMPLATE PATTERN (always use)
========================================

TEMPLATE 1 - dispatcher (use actual source root element with s0: prefix):
  <xsl:template match="/">
    <xsl:apply-templates select="/s0:RootElement"/>
  </xsl:template>

TEMPLATE 2 - main map (wrap ALL EDI output in ns0: root element):
  <xsl:template match="/s0:RootElement">
    <ns0:X12_00401_NNN>
      ... all segments ...
    </ns0:X12_00401_NNN>
  </xsl:template>

========================================
SEGMENT NAMESPACE PREFIX RULES (CRITICAL)
========================================

ALWAYS use ns0: prefix on EDI loop/segment wrapper elements:
  ns0:B3, ns0:C2, ns0:C3, ns0:N9, ns0:G62
  ns0:N1Loop1, ns0:N1, ns0:N3, ns0:N4
  ns0:N7Loop1, ns0:N7
  ns0:LXLoop1, ns0:LX, ns0:L5, ns0:L0, ns0:L1, ns0:L7, ns0:L3
  ns0:B10, ns0:L11, ns0:AT7Loop1, ns0:AT7, ns0:MS1, ns0:MS2
  ns0:AT8, ns0:L11_3, ns0:K1_2, ns0:SE, ns0:S5Loop1

NO ns0: prefix on:
  ST (always plain <ST> with no namespace)
  Child data elements: ST01, B302, N101, B1001, AT701 etc.

R3 and K1: ALWAYS output as XML comments only, never as live elements.

========================================
CANONICAL XPATH RULES (CRITICAL)
========================================

Source canonical XML uses XML ATTRIBUTES - not child text nodes.
CORRECT:  select="Header/BeginningSegment/@InvoiceNumber"
WRONG:    select="Header/InvoiceNumber"
WRONG:    select="InvoiceNumber/text()"

For namespace-safe absolute XPath (date variables and global references):
  /*[local-name()='Root']/*[local-name()='Header']/*[local-name()='Segment']/@*[local-name()='Field']

Declare ALL date variables TOGETHER at the TOP of their segment block BEFORE any xsl:if:
  <xsl:variable name="MyDate" select="/*[local-name()='Root']/.../@*[local-name()='Date']"/>

Date format (ISO to YYYYMMDD):
  <xsl:value-of select="concat(substring($Date,1,4),substring($Date,6,2),substring($Date,9,2))"/>

Time format (to HHMM):
  <xsl:value-of select="concat(substring($DateTime,12,2),substring($DateTime,15,2))"/>

========================================
SAFE ELEMENT MAPPING (apply to EVERY element)
========================================

Every output element MUST be wrapped in xsl:if.

Simple attribute:
<xsl:if test="@Field != ''">
  <EL01><xsl:value-of select="@Field"/></EL01>
</xsl:if>

Text field with cleaning:
<xsl:if test="@Field != ''">
  <EL01><xsl:call-template name="CleanAlphaField">
    <xsl:with-param name="inputText" select="@Field"/>
    <xsl:with-param name="maxLength" select="30"/>
  </xsl:call-template></EL01>
</xsl:if>

Numeric:
<xsl:if test="@Amount > 0">
  <EL07><xsl:value-of select="translate(@Amount,'.','')"/></EL07>
</xsl:if>

N1 party loops - THREE separate xsl:for-each (not one combined loop).
N3 and N4 are SIBLINGS of N1 inside N1Loop1 - NOT nested inside N1.

N7 loop - always use count variable guard:
<xsl:variable name="NumberOfN7" select="count(path/to/Equipment[@Field != ''])"/>
<xsl:if test="$NumberOfN7 > 0">
  <ns0:N7Loop1>
    <xsl:for-each select="path/to/Equipment">
      <ns0:N7>...</ns0:N7>
    </xsl:for-each>
  </ns0:N7Loop1>
</xsl:if>

SE segment - always last:
<SE>
  <xsl:if test="@TransactionSetIdentifierCode != ''"><SE01><xsl:value-of select="@TransactionSetIdentifierCode"/></SE01></xsl:if>
  <xsl:if test="@TransactionSetControlNumber != ''"><SE02><xsl:value-of select="@TransactionSetControlNumber"/></SE02></xsl:if>
</SE>

========================================
REUSABLE TEMPLATES (always include)
========================================

<xsl:template name="CleanAlphaField">
  <xsl:param name="inputText"/>
  <xsl:param name="maxLength"/>
  <xsl:variable name="singleQuote" select='"&apos;"'/>
  <xsl:variable name="doubleQuote" select="'&quot;'"/>
  <xsl:variable name="vAllowedSymbolsPart1" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}?/#'"/>
  <xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
  <xsl:variable name="vCleanedText" select="translate($inputText,translate($inputText, $vAllowedSymbols, ''),'')"/>
  <xsl:value-of select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
</xsl:template>

<xsl:template name="SetDefaultIfEmpty">
  <xsl:param name="pNode"/>
  <xsl:param name="pDefaultValue"/>
  <xsl:if test="$pNode"><xsl:value-of select="$pNode"/></xsl:if>
  <xsl:if test="not($pNode)"><xsl:value-of select="$pDefaultValue"/></xsl:if>
</xsl:template>

<xsl:template name="ValueLookup">
  <xsl:param name="ValueToConvert"/>
  <xsl:param name="LookupTable"/>
  <xsl:variable name="Result" select="msxsl:node-set($LookupTable)/map/entry[@key=$ValueToConvert]"/>
  <xsl:choose>
    <xsl:when test="$Result != ''"><xsl:value-of select="$Result"/></xsl:when>
    <xsl:otherwise><xsl:value-of select="$ValueToConvert"/></xsl:otherwise>
  </xsl:choose>
</xsl:template>

========================================
BIZTALK-SPECIFIC RULES (CRITICAL)
========================================

msxsl:node-set() usage — ONLY for value lookup tables:
  <xsl:variable name="MyLookup">
    <map><entry key="Pick">SF</entry><entry key="Drop">ST</entry></map>
  </xsl:variable>
  <xsl:value-of select="msxsl:node-set($MyLookup)/map/entry[@key=$ValueToConvert]"/>

Date/time extraction from ISO datetime attribute:
  Date YYYYMMDD: concat(substring(@statusdatetime,1,4),substring(@statusdatetime,6,2),substring(@statusdatetime,9,2))
  Time HHMM:     concat(substring(@statusdatetime,12,2),substring(@statusdatetime,15,2))

Child text node access: use /text() NOT just element name:
  CORRECT: select="LoadId/text()"
  WRONG:   select="LoadId"

Attribute access: always use @attributeName:
  CORRECT: select="@referenceId"
  WRONG:   select="referenceId"

EVERY output data element MUST use CleanAlphaField for string fields:
  <xsl:if test="@fieldName != ''">
    <ELEM01>
      <xsl:call-template name="CleanAlphaField">
        <xsl:with-param name="inputText" select="@fieldName"/>
        <xsl:with-param name="maxLength" select="30"/>
      </xsl:call-template>
    </ELEM01>
  </xsl:if>

Numeric fields use xsl:value-of directly (no CleanAlphaField):
  <xsl:if test="@amount != '' and @amount != '0'">
    <ELEM07><xsl:value-of select="@amount"/></ELEM07>
  </xsl:if>

Output ONLY valid XSLT - no markdown, no text outside XML comments."""

FIX_SYSTEM = """You are an expert XSLT debugger specialising in BizTalk EDI maps.
Fix ALL errors in the provided XSLT.
Ensure every element is wrapped in safe xsl:if checks.
ALWAYS start with: <?xml version="1.0" encoding="UTF-8"?>
Output ONLY the complete fixed XSLT."""

ANALYSIS_SYSTEM = "You are an expert EDI mapping analyst. Return structured JSON only. No markdown, no fences."



