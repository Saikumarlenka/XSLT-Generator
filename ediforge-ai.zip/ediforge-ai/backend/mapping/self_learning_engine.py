"""
EDIForge AI v4 -- Self-Learning Mapping Engine
===============================================
Extracts from every XSL map in training/xsl_maps/:
  mappings   {target_element: canonical_xpath}
  loops      {loop_xpath: edi_loop_name}
  transforms {source_xpath: transform_type}
  conditions [{test}]
  literals   {element: value}

Stores per-transaction in training/knowledge/<ts>_learned.json.
On next generation run, known mappings are reused before asking the AI.

Resolution order (smart):
  1. Learned knowledge base   (exact learned mappings)
  2. Mapping document rows    (what the user uploaded)
  3. Canonical schema matching (path_matching_engine)
  4. AI assistance             (last resort)
"""
from __future__ import annotations
import re, json
from pathlib import Path
from typing import Dict, List, Optional

KNOWLEDGE_DIR = Path(__file__).parent.parent.parent / "training" / "knowledge"
MAPS_DIR      = Path(__file__).parent.parent.parent / "training" / "xsl_maps"


def _read_xsl(path: Path) -> str:
    for enc in ("utf-16","utf-8"):
        try: return path.read_text(encoding=enc, errors="replace")
        except Exception: pass
    return ""


def _detect_ts(name: str) -> str:
    for ts in ["210","214","990","204"]:
        if ts in name: return ts
    return ""


def learn_from_xsl_file(xsl_path: Path, transaction_set: str = "") -> dict:
    content = _read_xsl(xsl_path)
    if not content: return {}
    if not transaction_set:
        transaction_set = _detect_ts(xsl_path.name)
    return {
        "transaction_set": transaction_set,
        "filename":  xsl_path.name,
        "mappings":  _extract_mappings(content),
        "loops":     _extract_loops(content),
        "transforms":_extract_transforms(content),
        "conditions":_extract_conditions(content),
        "literals":  _extract_literals(content),
    }


def _extract_mappings(content: str) -> Dict[str, str]:
    """<ELEM><xsl:value-of select="xpath"/></ELEM> -> {ELEM: xpath}"""
    mappings = {}
    for m in re.finditer(
        r'<([A-Z][A-Z0-9]{1,5})>\s*<xsl:value-of\s+select="([^"]+)"', content
    ):
        elem, xpath = m.group(1), m.group(2).strip()
        if elem not in ("xsl","Root","stylesheet") and xpath:
            mappings[elem] = xpath
    # Also catch call-template inputText= patterns
    for m in re.finditer(
        r'<([A-Z][A-Z0-9]{1,5})>.*?xsl:with-param[^"]*"inputText"\s+select="([^"]+)"',
        content, re.DOTALL
    ):
        elem, xpath = m.group(1), m.group(2).strip()
        if elem not in ("xsl","Root","stylesheet") and xpath:
            mappings[elem] = xpath
    return mappings


def _extract_loops(content: str) -> Dict[str, str]:
    loops = {}
    x = content.lower()
    for m in re.finditer(r'xsl:for-each\s+select="([^"]+)"', content):
        xpath = m.group(1).strip()
        xl = xpath.lower()
        if "party"     in xl: edi = "N1Loop1"
        elif "lineitem" in xl: edi = "LXLoop1"
        elif "equipment" in xl: edi = "N7Loop1"
        elif "reference" in xl: edi = "N9Loop1"
        elif "status"   in xl: edi = "AT7Loop1"
        elif "stop"     in xl: edi = "S5Loop1"
        else: edi = "Loop"
        loops[xpath] = edi
    return loops


def _extract_transforms(content: str) -> Dict[str, str]:
    t = {}
    for m in re.finditer(r'concat\(substring\((\$?[\w/@\[\]*.\-]+),1,4\),substring\(\1,6,2\)', content):
        t[m.group(1)] = "date_yyyymmdd"
    for m in re.finditer(r"translate\((\$?[\w/@\[\]*.\-]+),['\"][.,]['\"]", content):
        t[m.group(1)] = "decimal"
    return t


def _extract_conditions(content: str) -> List[dict]:
    conds, seen = [], set()
    for m in re.finditer(r'<xsl:if\s+test="([^"]+)"', content):
        test = m.group(1)
        if test not in seen:
            seen.add(test)
            conds.append({"test": test})
    return conds[:30]


def _extract_literals(content: str) -> Dict[str, str]:
    lits = {}
    for m in re.finditer(r'<([A-Z][A-Z0-9]{3,5})>([^<>{}\n]{1,30})</\1>', content):
        elem, val = m.group(1), m.group(2).strip()
        if val and "xsl" not in val:
            lits[elem] = val
    return lits


def learn_all_maps(force: bool = False) -> dict:
    KNOWLEDGE_DIR.mkdir(parents=True, exist_ok=True)
    all_maps = list(MAPS_DIR.glob("**/*.xsl")) + list(MAPS_DIR.glob("**/*.xslt"))
    if not all_maps:
        return {"maps_processed": 0}
    by_ts: Dict[str, dict] = {}
    for xsl_path in all_maps:
        try:
            learned = learn_from_xsl_file(xsl_path)
            ts = learned.get("transaction_set","unknown")
            if ts not in by_ts:
                by_ts[ts] = {"mappings":{},"loops":{},"transforms":{},"literals":{}}
            by_ts[ts]["mappings"].update(learned.get("mappings",{}))
            by_ts[ts]["loops"].update(learned.get("loops",{}))
            by_ts[ts]["transforms"].update(learned.get("transforms",{}))
            by_ts[ts]["literals"].update(learned.get("literals",{}))
        except Exception:
            pass
    for ts, data in by_ts.items():
        out = KNOWLEDGE_DIR / f"{ts}_learned.json"
        out.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return {
        "maps_processed":  len(all_maps),
        "transaction_sets": list(by_ts.keys()),
        "total_mappings":  sum(len(v["mappings"]) for v in by_ts.values()),
    }


def lookup_learned_mapping(edi_element: str, transaction_set: str) -> Optional[str]:
    kb = KNOWLEDGE_DIR / f"{transaction_set}_learned.json"
    if not kb.exists(): return None
    try:
        return json.loads(kb.read_text(encoding="utf-8")).get("mappings",{}).get(edi_element)
    except Exception:
        return None


def lookup_learned_loop(canonical_xpath: str, transaction_set: str) -> Optional[str]:
    kb = KNOWLEDGE_DIR / f"{transaction_set}_learned.json"
    if not kb.exists(): return None
    try:
        return json.loads(kb.read_text(encoding="utf-8")).get("loops",{}).get(canonical_xpath)
    except Exception:
        return None