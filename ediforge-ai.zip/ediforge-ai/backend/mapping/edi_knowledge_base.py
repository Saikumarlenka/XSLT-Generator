"""
EDIForge AI v5 — EDI Knowledge Base
Static semantic understanding of EDI 210/204/214/850 segments.
"""

EDI_SEGMENT_FIELDS = {
    "B3": {
        "B301": "InvoiceType", "B302": "InvoiceNumber",
        "B303": "ShipmentIdentificationNumber", "B304": "WeightUnitCode",
        "B305": "ShipmentMethodOfPayment", "B306": "Date",
        "B307": "NetAmountDue", "B308": "CorrectionIndicator",
        "B309": "DeliveryDate", "B310": "DateTimeQualifier",
        "B311": "StandardCarrierAlphaCode", "B312": "TariffServiceCode",
        "B313": "TransportationTerms",
    },
    "N9": {
        "N901": "ReferenceIdentificationQualifier", "N902": "ReferenceIdentification",
        "N903": "FreeFormDescription", "N904": "Date",
        "N905": "Time", "N906": "TimeCode",
    },
    "G62": {
        "G621": "DateTimeQualifier", "G622": "Date",
        "G623": "TimeCode", "G624": "Time", "G625": "TimeCode",
    },
    "N1": {
        "N101": "EntityIdentifierCode", "N102": "Name",
        "N103": "IdentificationCodeQualifier", "N104": "IdentificationCode",
        "N105": "EntityRelationshipCode", "N106": "EntityIdentifierCode",
    },
    "N2": {"N201": "Name", "N202": "Name"},
    "N3": {"N301": "AddressInformation", "N302": "AddressInformation"},
    "N4": {
        "N401": "CityName", "N402": "StateOrProvinceCode",
        "N403": "PostalCode", "N404": "CountryCode",
        "N405": "LocationQualifier", "N406": "LocationIdentifier",
        "N407": "CountrySubdivisionCode",
    },
    "LX": {"LX01": "AssignedNumber"},
    "L5": {
        "L501": "LadingLineItemNumber", "L502": "LadingDescription",
        "L503": "CommodityCode", "L504": "CommodityCodeQualifier",
        "L505": "PackagingCode", "L506": "MarksAndNumbers",
    },
    "L0": {
        "L001": "LadingLineItemNumber", "L002": "BilledRatedAsQuantity",
        "L003": "BilledRatedAsQualifier", "L004": "Weight",
        "L005": "WeightQualifier", "L006": "Volume",
        "L007": "VolumeUnitQualifier", "L008": "LadingQuantity",
        "L009": "PackagingFormCode", "L011": "WeightUnitCode",
    },
    "L1": {
        "L101": "LadingLineItemNumber", "L102": "FreightRate",
        "L103": "RateValueQualifier", "L104": "Charge",
        "L105": "Advances", "L106": "PrepaidAmount",
        "L107": "RateCombinationPointCode", "L108": "SpecialChargeOrAllowanceCode",
        "L109": "RateClassCode", "L110": "EntitlementCode",
        "L111": "ChargeMethodOfPayment", "L112": "SpecialChargeDescription",
    },
    "L3": {
        "L301": "Weight", "L302": "WeightQualifier",
        "L303": "FreightRate", "L304": "RateValueQualifier",
        "L305": "Charge", "L306": "Advances",
        "L307": "PrepaidAmount", "L308": "SpecialChargeOrAllowanceCode",
        "L309": "Volume", "L310": "VolumeUnitQualifier",
        "L311": "LadingQuantity", "L312": "WeightUnitCode",
    },
    "L7": {
        "L701": "LadingLineItemNumber", "L702": "TariffAgencyCode",
        "L703": "TariffNumber", "L704": "TariffSection",
        "L705": "TariffItemNumber", "L707": "FreightClassCode",
        "L710": "Date", "L711": "RateBasisNumber",
    },
    "B10": {
        "B1001": "ReferenceIdentification", "B1002": "ShipmentIdentificationNumber",
        "B1003": "StandardCarrierAlphaCode", "B1004": "InquiryRequestNumber",
    },
    "AT7": {
        "AT701": "ShipmentStatusCode", "AT702": "ShipmentStatusReasonCode",
        "AT703": "ShipmentAppointmentStatusCode", "AT704": "ShipmentAppointmentReasonCode",
        "AT705": "Date", "AT706": "Time", "AT707": "TimeCode",
    },
    "MS1": {"MS101": "CityName", "MS102": "StateOrProvinceCode", "MS103": "CountryCode"},
    "MS2": {
        "MS201": "StandardCarrierAlphaCode", "MS202": "EquipmentNumber",
        "MS203": "EquipmentDescriptionCode", "MS204": "EquipmentNumberCheckDigit",
    },
    "AT8": {
        "AT801": "WeightQualifier", "AT802": "WeightUnitCode", "AT803": "Weight",
        "AT804": "LadingQuantity", "AT805": "LadingQuantity",
        "AT806": "Volume", "AT807": "VolumeUnitQualifier",
    },
}

EDI_LOOP_SEMANTICS = {
    "N1Loop":  {"collection": "PartyList",     "item": "Party",      "key_field": "EntityIdentifierCode"},
    "LXLoop":  {"collection": "LineItemList",  "item": "LineItem",   "key_field": "AssignedNumber"},
    "S5Loop":  {"collection": "StopList",      "item": "Stop",       "key_field": "StopSequenceNumber"},
    "AT7Loop": {"collection": "StatusList",    "item": "Status",     "key_field": "ShipmentStatusCode"},
    "N9Loop":  {"collection": "ReferenceList", "item": "Reference",  "key_field": "ReferenceIdentificationQualifier"},
    "L1Loop":  {"collection": "ChargeList",    "item": "Charge",     "key_field": "SpecialChargeOrAllowanceCode"},
    "N7Loop":  {"collection": "EquipmentList", "item": "Equipment",  "key_field": "EquipmentNumber"},
    "HLLoop":  {"collection": "HierarchicalList", "item": "Hierarchical", "key_field": "HierarchicalIDNumber"},
}

DATE_FORMAT_RULES = {
    "Date":         "concat(substring($v,1,4),substring($v,6,2),substring($v,9,2))",
    "InvoiceDate":  "concat(substring($v,1,4),substring($v,6,2),substring($v,9,2))",
    "DeliveryDate": "concat(substring($v,1,4),substring($v,6,2),substring($v,9,2))",
    "PickupDate":   "concat(substring($v,1,4),substring($v,6,2),substring($v,9,2))",
    "ShipDate":     "concat(substring($v,1,4),substring($v,6,2),substring($v,9,2))",
    "Time":         "concat(substring($v,12,2),substring($v,15,2))",
    "DateTime":     "concat(substring($v,1,4),substring($v,6,2),substring($v,9,2))",
}

OMIT_CONDITIONS = {
    "SpecialChargeOrAllowanceCode": ["LHS"],
}


def lookup_segment_field(segment: str, element_code: str) -> str:
    seg = EDI_SEGMENT_FIELDS.get(segment.upper(), {})
    return seg.get(element_code.upper(), "")


def lookup_loop_semantics(loop_name: str) -> dict:
    for key, val in EDI_LOOP_SEMANTICS.items():
        if key.lower() in loop_name.lower():
            return val
    return {}


def get_date_format_xsl(field_name: str, var_name: str) -> str:
    expr = DATE_FORMAT_RULES.get(field_name)
    if expr:
        return expr.replace("$v", f"${var_name}")
    return f"${var_name}"


def get_omit_condition(field_name: str) -> list:
    return OMIT_CONDITIONS.get(field_name, [])


def enrich_mapping_with_semantics(mapping_row: dict) -> dict:
    m = dict(mapping_row)
    src = m.get("source", "")
    if not m.get("canonical_field") and src:
        parts = src.strip("/").split("/")
        if len(parts) >= 2:
            segment = parts[0].upper()
            element = parts[-1].upper()
            field = lookup_segment_field(segment, element)
            if field:
                m["canonical_field"] = field
    return m

# =============================================================================
# EDIForge AI v4 additions
# =============================================================================

EDI_MANDATORY_SEGMENTS = {
    "210": ["ST","B3","C2","SE"],
    "214": ["ST","B10","SE"],
    "990": ["ST","W6","SE"],
    "204": ["ST","B1","SE"],
}

# C2 hardcoded values per Sonoco 210 map (and most 210 maps)
C2_HARDCODED_DEFAULTS = {
    "C201": "R",
    "C202": "25",
    "C203": "TFP-001",
}

# R3 segment is always commented out in 210 maps (not transmitted)
R3_IS_COMMENT_ONLY = True

N1_QUALIFIER_MAP = {
    "BT": "Bill-To Party",  "SH": "Shipper",
    "CN": "Consignee",      "CA": "Carrier",
    "OB": "Ordered-By",     "SF": "Ship-From",
    "ST": "Ship-To",        "BY": "Buying Party",
}

TRANSFORM_RULE_LABELS = {
    "date_yyyymmdd":   "ISO date YYYY-MM-DD -> YYYYMMDD",
    "date_mmddyyyy":   "ISO date YYYY-MM-DD -> MMDDYYYY",
    "time_hhmm":       "ISO datetime -> HHMM",
    "decimal_no_comma":"Remove comma from decimal",
    "decimal_integer": "Remove decimal point (integer only)",
    "upper":           "Convert to uppercase",
    "clean_alpha":     "CleanAlphaField template (max 30 chars)",
}


def get_mandatory_segments(transaction_set: str) -> list:
    return EDI_MANDATORY_SEGMENTS.get(transaction_set, [])


def get_n1_qualifier(code: str) -> str:
    return N1_QUALIFIER_MAP.get(code.upper(), code)
