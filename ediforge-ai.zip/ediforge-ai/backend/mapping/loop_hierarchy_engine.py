"""
EDIForge AI v5 -- Loop Hierarchy Engine
========================================
Enforces parent-child loop nesting, repeat counts, qualifier-specific loops.
N1 -> [N2,N3,N4,N9]  |  LX -> [L5,L0,L1,L7]  |  S5 -> [L11,G62,AT8,N1,N9]
"""
from __future__ import annotations
import re
from typing import Dict, List, Optional

LOOP_HIERARCHY: Dict[str, dict] = {
    "N1Loop1":  {"children": ["N1","N2","N3","N4","N9"],   "max_repeat": 10,
                 "canonical_collection": "PartyList",      "canonical_item": "Party",
                 "qualifier_attr": "Name/@EntityIdentifierCode",
                 "common_qualifiers": ["BT","SH","CN","SF","ST","CA","SO"]},
    "LXLoop1":  {"children": ["LX","L5","L0","L1","L7","L11"], "max_repeat": 999,
                 "canonical_collection": "LineItemList",   "canonical_item": "LineItem",
                 "qualifier_attr": None, "common_qualifiers": []},
    "N9Loop1":  {"children": ["N9","MSG"],                 "max_repeat": 300,
                 "canonical_collection": "ReferenceList",  "canonical_item": "ReferenceInformation",
                 "qualifier_attr": "@EDICode",
                 "common_qualifiers": ["BM","PO","OI","FD","PID"]},
    "N7Loop1":  {"children": ["N7","N8","M7","NA","GA"],   "max_repeat": 10,
                 "canonical_collection": "EquipmentList",  "canonical_item": "Equipment",
                 "qualifier_attr": None, "common_qualifiers": []},
    "S5Loop1":  {"children": ["S5","L11","G62","LAD","AT8","N1","N9"], "max_repeat": 999,
                 "canonical_collection": "StopList",       "canonical_item": "StopOffDetails",
                 "qualifier_attr": "@StopReasonCode",
                 "common_qualifiers": ["Pick","Drop"]},
    "L1Loop1":  {"children": ["L1"],                       "max_repeat": 999,
                 "canonical_collection": "ChargeList",     "canonical_item": "RateAndCharges",
                 "qualifier_attr": None, "common_qualifiers": []},
    "AT7Loop1": {"children": ["AT7","MS1","MS2"],          "max_repeat": 10,
                 "canonical_collection": "StatusList",     "canonical_item": "StatusDetail",
                 "qualifier_attr": None, "common_qualifiers": []},
}

_DEFAULT_LOOPS = {
    "210": {"N9Loop1": "/s0:Invoice/Header/ReferenceList/ReferenceInformation[@EDICode != '']",
            "N1Loop1": "Header/PartyList/Party",
            "N7Loop1": "Header/EquipmentList/Equipment",
            "LXLoop1": "Detail/LineItemList/LineItem"},
    "214": {"N9Loop1": "Header/ReferenceList/ReferenceInformation",
            "N1Loop1": "Header/PartyList/Party",
            "AT7Loop1": "Detail/StatusList/StatusDetail",
            "S5Loop1": "Detail/StopList/StopOffDetails"},
    "204": {"N9Loop1": "Header/ReferenceList/ReferenceInformation",
            "N1Loop1": "Header/PartyList/Party",
            "S5Loop1": "Detail/StopList/StopOffDetails",
            "LXLoop1": "Detail/LineItemList/LineItem"},
    "990": {"N1Loop1": "Header/PartyList/Party"},
}


def build_loop_model(mappings: List[dict], transaction_set: str,
                     learned_loops: Optional[Dict] = None) -> List[dict]:
    result: Dict[str, str] = {}
    for m in mappings:
        _add_loop_from_xpath(m.get("source","") or "", result)
    for xpath, loop_name in (learned_loops or {}).items():
        result.setdefault(loop_name, xpath)
    for ln, xpath in _DEFAULT_LOOPS.get(transaction_set, {}).items():
        result.setdefault(ln, xpath)
    order  = ["N9Loop1","N1Loop1","N7Loop1","LXLoop1","L1Loop1","S5Loop1","AT7Loop1"]
    models = []
    for loop_name, for_each in result.items():
        spec = LOOP_HIERARCHY.get(loop_name, {})
        models.append({"loop_name": loop_name, "for_each": for_each,
                       "children": spec.get("children",[]),
                       "max_repeat": spec.get("max_repeat",1),
                       "qualifiers": _extract_qualifiers(loop_name, mappings),
                       "has_data": True})
    models.sort(key=lambda x: order.index(x["loop_name"]) if x["loop_name"] in order else 99)
    return models


def _add_loop_from_xpath(src: str, result: Dict[str, str]):
    s = src.lower()
    if "partylist" in s or "party" in s:     result.setdefault("N1Loop1", _heuristic_xpath(src,"N1Loop1"))
    if "lineitem"  in s:                     result.setdefault("LXLoop1", _heuristic_xpath(src,"LXLoop1"))
    if "referencelist" in s:                 result.setdefault("N9Loop1", _heuristic_xpath(src,"N9Loop1"))
    if "equipment" in s:                     result.setdefault("N7Loop1", _heuristic_xpath(src,"N7Loop1"))
    if "stoplist"  in s or "stopoffdetail" in s: result.setdefault("S5Loop1", _heuristic_xpath(src,"S5Loop1"))
    if "rateandcharge" in s or "chargelist" in s: result.setdefault("L1Loop1", _heuristic_xpath(src,"L1Loop1"))


def _heuristic_xpath(src: str, loop_name: str) -> str:
    spec    = LOOP_HIERARCHY.get(loop_name, {})
    collection = spec.get("canonical_collection","")
    item       = spec.get("canonical_item","")
    m = re.search(rf'((?:[\w]+/)*{collection}/{item}(?:\[.*?\])?)', src, re.IGNORECASE)
    if m: return m.group(1)
    parts = src.split("/")
    for i, p in enumerate(parts):
        if collection.lower() in p.lower(): return "/".join(parts[:i+2])
    return f"{collection}/{item}" if collection and item else src.split("/")[0]


def _extract_qualifiers(loop_name: str, mappings: List[dict]) -> List[str]:
    spec     = LOOP_HIERARCHY.get(loop_name, {})
    qual_attr = spec.get("qualifier_attr","")
    if not qual_attr: return []
    found = set()
    for m in mappings:
        for match in re.finditer(r"@\w+='([^']+)'", m.get("source","") or ""):
            found.add(match.group(1))
    return sorted(found) if found else spec.get("common_qualifiers",[])


# ---- Qualifier Engine integration (FIX 02) ----
try:
    from backend.engine.qualifier_engine import QualifierEngine as _QE
    _qe = _QE()
except ImportError:
    _qe = None


def get_qualified_loop_xpath(loop_name: str, qualifier: str,
                              transaction_set: str = "210") -> str:
    """Return qualifier-filtered xsl:for-each select= for a named loop."""
    from backend.engine.transaction_rules import get_loop_xpaths
    base = get_loop_xpaths(transaction_set).get(loop_name, "")
    if not base or not qualifier or not _qe:
        return base
    segment = loop_name.replace("Loop1", "").replace("Loop", "")
    return _qe.apply(segment, qualifier, base)
# ---- end qualifier integration ----


# ===========================================================
# FIX 06 â€” Schema-driven loop enforcement
# ===========================================================

def enforce_loops_for_transaction(
    loop_map: dict,
    transaction_set: str,
    mappings: list,
) -> dict:
    """
    Merge detected loops with schema-required loops for the transaction set.
    Returns complete loop_map with all required loops present.

    Priority: user mappings > learned > schema defaults > fallback
    """
    from backend.engine.transaction_rules import get_loop_xpaths, get_loops

    required_loops  = get_loops(transaction_set)
    default_xpaths  = get_loop_xpaths(transaction_set)
    result          = dict(default_xpaths)   # start with schema defaults
    result.update(loop_map)                  # override with detected

    # Add any required loops that are still missing
    for loop_name in required_loops:
        if loop_name not in result and loop_name in default_xpaths:
            result[loop_name] = default_xpaths[loop_name]

    # Auto-detect loops from mapping source paths
    for m in mappings:
        src = (m.get("source") or "").strip()
        for lname, lxpath in _DEFAULT_LOOPS.get(transaction_set, {}).items():
            collection = lxpath.split("/")[-1].split("[")[0].lower()
            if collection and collection in src.lower():
                if lname not in result:
                    result[lname] = lxpath

    return result


def validate_loop_nesting(xslt: str, transaction_set: str) -> dict:
    """
    Validate that the generated XSLT contains required loops.
    Returns {"valid": bool, "missing": [...], "found": [...]}.
    """
    from backend.engine.transaction_rules import get_loops
    required = get_loops(transaction_set)
    missing  = []
    found    = []
    for loop in required:
        base = loop.replace("Loop1", "").replace("Loop", "")
        if base.lower() in xslt.lower() and "for-each" in xslt:
            found.append(loop)
        else:
            missing.append(loop)
    return {
        "valid":   len(missing) == 0,
        "missing": missing,
        "found":   found,
    }


def get_loop_children(loop_name: str) -> list:
    """Return expected child segments for a loop."""
    info = LOOP_HIERARCHY.get(loop_name, {})
    return info.get("children", [])


def sort_segments_by_order(mappings: list, transaction_set: str) -> list:
    """Sort mappings according to the EDI segment order for the transaction."""
    from backend.engine.transaction_rules import get_segment_order
    order = get_segment_order(transaction_set)

    def _key(m):
        import re
        tgt = m.get("target", "")
        seg_m = re.match(r'^([A-Z][A-Z0-9]{0,2})(?=\d{2})', tgt)
        if seg_m:
            seg = seg_m.group(1)
            try:
                return order.index(seg) * 1000
            except ValueError:
                pass
        return 9999

    return sorted(mappings, key=_key)

