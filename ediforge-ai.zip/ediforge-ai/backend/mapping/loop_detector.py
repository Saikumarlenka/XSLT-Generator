"""EDIForge AI v5 � EDI Loop Detector."""
from typing import Dict, List, Optional, Tuple

EDI_LOOP_REGISTRY: Dict[str, Tuple[str, str]] = {
    "LX":  ("LXLoop",   "LineItemList"),
    "N1":  ("N1Loop",   "PartyList"),
    "N9":  ("N9Loop",   "ReferenceList"),
    "L11": ("L11Loop",  "ReferenceList"),
    "AT8": ("AT8Loop",  "HandlingUnitList"),
    "S5":  ("S5Loop",   "StopList"),
    "L5":  ("L5Loop",   "ChargeList"),
    "L0":  ("L0Loop",   "ChargeList"),
    "L1":  ("L1Loop",   "ChargeList"),
    "L7":  ("L7Loop",   "TariffList"),
    "AT7": ("AT7Loop",  "StatusList"),
    "AT5": ("AT5Loop",  "StopStatusList"),
    "MS1": ("MS1Loop",  "LocationList"),
    "HL":  ("HLLoop",   "HierarchicalList"),
    "SN1": ("SN1Loop",  "LineItemList"),
    "PO1": ("PO1Loop",  "LineItemList"),
    "SCH": ("SCHLoop",  "ScheduleList"),
    "N7":  ("N7Loop",   "EquipmentList"),
    "K1":  ("K1Loop",   "NoteList"),
}

CANONICAL_PARENT_TO_LOOP: Dict[str, str] = {
    v[1]: v[0] for v in EDI_LOOP_REGISTRY.values()
}


def detect_loop_for_source(source_path: str) -> Optional[Tuple[str, str]]:
    if not source_path:
        return None
    segment = source_path.split("/")[0].split(".")[0].upper()
    return EDI_LOOP_REGISTRY.get(segment)


def detect_loops_in_mappings(mappings: List[dict]) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for m in mappings:
        src = (m.get("source") or "")
        tgt = (m.get("target") or "")
        loop_info = detect_loop_for_source(src)
        if loop_info:
            loop_name, canonical_collection = loop_info
            result[canonical_collection] = loop_name
            parts = tgt.split("/")
            for p in parts:
                leaf = p.lstrip("@")
                if leaf and len(leaf) > 2:
                    try:
                        from backend.mapping.edi_knowledge_base import EDI_LOOP_SEMANTICS
                        sem = EDI_LOOP_SEMANTICS.get(loop_name, {})
                        if sem.get("item") and sem["item"].lower() in leaf.lower():
                            result[leaf] = loop_name
                    except ImportError:
                        pass
    return result


def get_loop_for_canonical_element(element_name: str) -> Optional[str]:
    return CANONICAL_PARENT_TO_LOOP.get(element_name)


def build_loop_xsl_guard(loop_name: str, canonical_collection: str, source_ns: str = "") -> str:
    try:
        from backend.mapping.edi_knowledge_base import EDI_LOOP_SEMANTICS
        sem = EDI_LOOP_SEMANTICS.get(loop_name, {})
        item = sem.get("item", "Item")
    except ImportError:
        item = "Item"
    prefix = "s0:" if source_ns else ""
    ns_path = f"{prefix}{canonical_collection}/{prefix}{item}"
    count_var = f"Number_Of_{item}"
    return (
        f'<xsl:variable name="{count_var}" select="count({ns_path}[. != \'\'])"/>\n'
        f'<xsl:if test="${count_var} &gt; 0">\n'
        f'  <ns0:{loop_name}1>\n'
        f'    <xsl:for-each select="{ns_path}">'
    )


def close_loop_xsl_guard(loop_name: str, item: str = "Item") -> str:
    return (
        f'    </xsl:for-each>\n'
        f'  </ns0:{loop_name}1>\n'
        f'</xsl:if>'
    )


# ---- FIX 06: transaction-aware loop retrieval ----
def get_all_loops_for_transaction(transaction_set: str) -> dict:
    """
    Return the complete loop_map for a transaction set,
    combining LOOP_REGISTRY defaults with schema rules.
    """
    try:
        from backend.engine.transaction_rules import get_loop_xpaths
        return get_loop_xpaths(transaction_set)
    except ImportError:
        return {}
# ---- end FIX 06 ----


