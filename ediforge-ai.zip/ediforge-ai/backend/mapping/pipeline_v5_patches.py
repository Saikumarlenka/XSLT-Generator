﻿"""
EDIForge AI v5 -- Pipeline Patches
Monkey-patches MapGenerationPipeline.run with:
  v5.1 Field Intelligence Store enrichment
  v5.2 Deterministic generator (base-map-first)
  v5.3 Loop hierarchy model
  v5.7 XSLT validation
Import this module at app startup AFTER pipeline.py is imported.
"""
from __future__ import annotations
import re
from typing import List, Dict, Optional

_bootstrapped = False


def _clear_990_caches():
    try:
        from backend.generator import deterministic_generator as _dg
        _dg._base_map_cache.pop("990", None)
    except Exception:
        pass
    try:
        from backend.schema import reference_template_engine as _rte
        _rte._cache.pop("990", None)
    except Exception:
        pass


_clear_990_caches()


def _bootstrap_once():
    global _bootstrapped
    if _bootstrapped: return
    _bootstrapped = True
    try:
        from backend.learning.field_intelligence_store import bootstrap_all_transaction_sets
        from pathlib import Path
        store_dir = Path(__file__).parent.parent.parent / "training" / "knowledge"
        existing  = list(store_dir.glob("*_field_intelligence.json"))
        if not existing:
            result = bootstrap_all_transaction_sets()
            print(f"  [v5 Bootstrap] {result.get('total',0)} fields learned across {result.get('transaction_sets',[])}")
        else:
            print(f"  [v5] Intelligence stores: {[p.name for p in existing]}")
    except Exception as e:
        print(f"  [v5 Bootstrap] Skipped: {e}")


def _v5_run(self, mapping_rows, raw_mapping_text="", source_schema=None,
             source_ns="", target_format="", transaction_set="",
             use_ai_for_pairs=True, use_ai_scaffold=True) -> dict:
    _bootstrap_once()
    log: List[str] = ["[v5 Pipeline] Running enhanced pipeline"]

    result = self._v4_run(mapping_rows, raw_mapping_text, source_schema,
                          source_ns, target_format, transaction_set,
                          use_ai_for_pairs, use_ai_scaffold)

    ts             = result.get("transaction_set") or transaction_set or ""
    valid_mappings = result.get("valid_mappings", [])
    loop_map       = result.get("loop_map", {})

    # v5.1 -- Field Intelligence Store
    if ts:
        try:
            from backend.learning.field_intelligence_store import get_store
            store   = get_store(ts)
            before  = sum(1 for m in valid_mappings if m.get("source"))
            valid_mappings = store.enrich_mappings(valid_mappings)
            after   = sum(1 for m in valid_mappings if m.get("source"))
            log.append(f"v5.1 Field Intelligence: +{after-before} sources ({after}/{len(valid_mappings)} filled)")
            for m in valid_mappings:
                if m.get("target") and m.get("source") and not m.get("_is_literal"):
                    leaf = re.sub(r"^ns0:","",m["target"].split("/")[-1]).lstrip("@")
                    store.learn(leaf, m["source"], confidence=0.9)
        except Exception as e:
            log.append(f"v5.1 Field Intelligence skipped: {e}")

    # v5.1b -- Reference Learning Patterns (FIX 13)
    if ts:
        try:
            from backend.engine.reference_learning import apply_learned_patterns
            before = sum(1 for m in valid_mappings if m.get("source"))
            valid_mappings = apply_learned_patterns(valid_mappings, ts)
            after  = sum(1 for m in valid_mappings if m.get("source"))
            log.append(f"v5.1b Reference Patterns: +{after-before} XPaths from learned patterns")
        except Exception as e:
            log.append(f"v5.1b Reference Patterns skipped: {e}")

    # v5.3 -- Loop Hierarchy Engine
    if ts:
        try:
            from backend.mapping.loop_hierarchy_engine import build_loop_model
            loop_model = build_loop_model(valid_mappings, ts, loop_map)
            for spec in loop_model:
                loop_map[spec["loop_name"]] = spec["for_each"]
            log.append(f"v5.3 Loop Hierarchy: {[s['loop_name'] for s in loop_model]}")
        except Exception as e:
            log.append(f"v5.3 Loop Hierarchy skipped: {e}")

    # v5.2 -- Deterministic Generator (base-map-first)
    xslt, used_base_map = result.get("xslt",""), False
    if ts:
        try:
            from backend.generator.deterministic_generator import DeterministicXSLTGenerator
            gen = DeterministicXSLTGenerator(ts)
            if gen.has_base_map():
                det_xslt = gen.generate(valid_mappings, source_schema, source_ns, target_format, loop_map)
                if det_xslt and len(det_xslt) > 500:
                    xslt, used_base_map = det_xslt, True
                    log.append("v5.2 Deterministic Generator: used base map (HIGH ACCURACY)")
        except Exception as e:
            log.append(f"v5.2 Deterministic Generator skipped: {e}")
    if not used_base_map:
        log.append("v5.2 Deterministic Generator: no base map, keeping v4 XSLT")

    # v5.7 -- Validation
    xslt_errors: List[str] = []
    if ts and xslt:
        try:
            from backend.generator.deterministic_generator import validate_xslt_structure
            xslt_errors = validate_xslt_structure(xslt, ts)
            log.append(f"v5.7 Validation: {'PASSED' if not xslt_errors else str(xslt_errors)}")
        except Exception as e:
            log.append(f"v5.7 Validation skipped: {e}")

    # Recalculate accuracy
    total  = len([m for m in valid_mappings if m.get("target")])
    filled = sum(1 for m in valid_mappings
                 if m.get("source") or m.get("literal") or m.get("_is_literal"))
    pct    = round(100 * filled / max(total,1), 1)

    result["xslt"]           = xslt
    result["loop_map"]       = loop_map
    result["valid_mappings"] = valid_mappings
    result["used_base_map"]  = used_base_map
    result["xslt_errors"]    = xslt_errors
    result["pipeline_log"]   = result.get("pipeline_log",[]) + log
    result["accuracy"]["accuracy_pct"]   = pct
    result["accuracy"]["filled_sources"] = filled
    result["accuracy"]["total_targets"]  = total
    log.append(f"v5 Final Accuracy: {pct}% ({filled}/{total})")
    return result


def _apply_patches():
    try:
        from backend.mapping.pipeline import MapGenerationPipeline
        if not hasattr(MapGenerationPipeline, "_v4_run"):
            MapGenerationPipeline._v4_run = MapGenerationPipeline.run
            MapGenerationPipeline.run     = _v5_run
            print("  [v5 Patches] Applied to MapGenerationPipeline.run")
    except Exception as e:
        print(f"  [v5 Patches] Could not apply: {e}")


_apply_patches()


ALL_TRANSACTION_SETS = ["210","214","990","204"]


def run_pipeline_for_transaction(transaction_set: str, mapping_rows, raw_mapping_text="",
                                  source_schema=None, source_ns="", target_format="",
                                  use_ai_for_pairs=True, use_ai_scaffold=True) -> dict:
    from backend.mapping.pipeline import MapGenerationPipeline
    return MapGenerationPipeline().run(
        mapping_rows=mapping_rows, raw_mapping_text=raw_mapping_text,
        source_schema=source_schema, source_ns=source_ns, target_format=target_format,
        transaction_set=transaction_set, use_ai_for_pairs=use_ai_for_pairs,
        use_ai_scaffold=use_ai_scaffold,
    )

