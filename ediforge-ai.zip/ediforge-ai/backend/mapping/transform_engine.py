"""
EDIForge AI - Transform Engine (FIXED v2)
Builds XSLT value expressions and condition tests for all transform types.
"""
from __future__ import annotations
from typing import Optional


def build_xslt_expression(xpath, transform=None, max_len=None):
    if not xpath:
        return ""
    t = (transform or "").lower().strip()
    if t in ("date_yyyymmdd", "date"):
        expr = "concat(substring(%s,1,4),substring(%s,6,2),substring(%s,9,2))" % (xpath, xpath, xpath)
        return '<xsl:value-of select="%s"/>' % expr
    if t == "date_mmddyyyy":
        expr = "concat(substring(%s,6,2),substring(%s,9,2),substring(%s,1,4))" % (xpath, xpath, xpath)
        return '<xsl:value-of select="%s"/>' % expr
    if t in ("decimal_no_comma", "remove_comma"):
        return "<xsl:value-of select=\"translate(%s, ',', '')\"/>" % xpath
    if t == "decimal_nodot":
        return "<xsl:value-of select=\"translate(%s, '.', '')\"/>" % xpath
    if t == "upper":
        return ("<xsl:value-of select=\"translate(%s,"
                "'abcdefghijklmnopqrstuvwxyz',"
                "'ABCDEFGHIJKLMNOPQRSTUVWXYZ')\"/>" % xpath)
    if t == "clean_alpha":
        ml = max_len or 50
        return ('<xsl:call-template name="CleanAlphaField">'
                '<xsl:with-param name="inputText" select="%s"/>'
                '<xsl:with-param name="maxLength" select="%d"/>'
                '</xsl:call-template>' % (xpath, ml))
    return '<xsl:value-of select="%s"/>' % xpath


def build_condition(xpath, transform=None):
    if not xpath:
        return "false()"
    t = (transform or "").lower().strip()
    if t in ("date_yyyymmdd", "date", "date_mmddyyyy"):
        return "string-length(%s) &gt;= 8" % xpath
    if t in ("decimal_no_comma", "remove_comma", "decimal_nodot"):
        return "string-length(%s) &gt;= 1" % xpath
    return "%s != ''" % xpath