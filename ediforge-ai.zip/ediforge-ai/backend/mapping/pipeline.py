﻿"""
EDIForge AI v4 -- Map Generation Pipeline
==========================================
13-step pipeline wiring all accuracy improvements:

Step 1:  Build dual schema indexes (canonical + EDI)
Step 2:  Auto-populate base maps; load reference template
Step 3:  Extend mapping rows (condition/literal/transform fields)
Step 4:  Resolve source field names to canonical XPaths
Step 5:  Learning engine enrichment (KB lookup + pattern matching)
Step 6:  Chunked AI extraction (20 rows/call -- FIXES 413 error)
Step 7:  Merge + deduplicate all mappings
Step 8:  Dual-schema consistency check (FIXES "ST not found" error)
Step 9:  Filter valid mappings
Step 10: Loop detection from XSD + existing maps + reference template
Step 11: AI XSLT generation with reference template injected
Step 12: Deterministic fallback (handles literals/transforms/loops)
Step 13: Accuracy report + self-learning update
"""
from __future__ import annotations
import json, re, sys, os
from typing import List, Optional, Dict
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from backend.schema.canonical_index import build_canonical_index, get_all_canonical_paths
from backend.schema.dual_schema_index import (
    build_canonical_index_from_schema, build_canonical_index_from_xsd,
    build_edi_index, detect_repeating_nodes,
    get_all_canonical_paths as _dual_get_can_paths,
)
from backend.schema.path_matching_engine import resolve_mapping_pairs
from backend.schema.reference_template_engine import (
    get_reference_template, get_base_map_section_for_prompt, auto_populate_base_maps,
)
from backend.mapping.field_normalizer import normalize_field, best_match
from backend.mapping.loop_detector import detect_loops_in_mappings
from backend.mapping.consistency_checker import check_consistency, filter_valid_mappings
from backend.mapping.self_learning_engine import lookup_learned_mapping, learn_all_maps
from backend.learning.learning_engine import LearningEngine
from backend.parser.mapping_doc_parser import build_transform_xpath


from backend.engine.base_map_validator import validate_base_map
from backend.engine.transaction_rules import get_rules as _get_txn_rules

from backend.engine.deterministic_generator import build_deterministic_xslt as _new_det_gen

from backend.mapping.loop_hierarchy_engine import enforce_loops_for_transaction, sort_segments_by_order

from backend.engine.output_validator import full_validate as _full_validate
from backend.engine.field_learning_store import learn_field_mappings, enrich_mappings_from_store
from backend.engine.condition_engine import auto_wrap_condition
from backend.engine.value_mapping_engine import ValueMappingEngine as _VME
_vme_instance = _VME()
_learner = LearningEngine()
AI_CHUNK_SIZE = int(os.getenv("AI_CHUNK_SIZE", "20"))


# =============================================================================
# Helpers
# =============================================================================

def _canonical_guide(source_schema) -> str:
    if not source_schema:
        return ("=== CANONICAL SCHEMA: NOT PROVIDED ===\n"
                "WARNING: No canonical schema uploaded. Do NOT invent structure.\n")
    elements = source_schema.get("elements", {})
    if isinstance(elements, list):
        elements = {e["path"]: e for e in elements if isinstance(e, dict) and "path" in e}
    ns = source_schema.get("namespace","") or source_schema.get("target_namespace","")
    lines = ["=== CANONICAL SCHEMA (source side -- use ONLY these XPaths) ==="]
    if ns: lines.append(f"Namespace: {ns}")
    lines.append(f"Total paths: {len(elements)}")
    lines.append("")
    for path, info in elements.items():
        rep = "  [REPEATING -- use xsl:for-each]" if isinstance(info,dict) and (info.get("repeating") or info.get("is_repeating")) else ""
        lines.append(f"  {path}{rep}")
    lines.append("")
    lines.append("STRICT RULE: Source XPath MUST use @ for attributes.")
    lines.append("WRONG:   select=\"Header/InvoiceNumber\"")
    lines.append("CORRECT: select=\"Header/BeginningSegmentForCarriersInvoice/@InvoiceNumber\"")
    lines.append("STRICT RULE: s0: prefix = SOURCE (canonical).  ns0: prefix = TARGET (EDI).")
    return "\n".join(lines)


def _ai_extract_chunked(mapping_rows, raw_mapping_text, canonical_guide, transaction_set) -> List[dict]:
    """Send rows in chunks of AI_CHUNK_SIZE -- FIXES 413 token limit error."""
    try:
        from backend.core.ai_engine import call_ai, clean_json, ANALYSIS_SYSTEM
    except Exception:
        return []
    unresolved = [r for r in mapping_rows if r.get("source") and "/" not in r.get("source","")]
    if not unresolved:
        unresolved = mapping_rows[:60]
    chunks = [unresolved[i:i+AI_CHUNK_SIZE] for i in range(0, len(unresolved), AI_CHUNK_SIZE)]
    all_pairs: List[dict] = []
    for idx, chunk in enumerate(chunks):
        rows_text = ""
        for i, r in enumerate(chunk, 1):
            s = r.get("source",""); t = r.get("target",""); rule = r.get("rule","") or r.get("notes","")
            if s or t:
                rows_text += f"{i}. SOURCE: {s}  ->  TARGET: {t}"
                if rule: rows_text += f"  | Rule: {rule}"
                rows_text += "\n"
        prompt = (f"You are an EDI mapping engine for transaction {transaction_set or 'unknown'}.\n\n"
                  f"{canonical_guide[:3000]}\n\n"
                  f"=== MAPPING ROWS (chunk {idx+1}/{len(chunks)}) ===\n{rows_text}\n\n"
                  f"For each row find the EXACT canonical XPath for the SOURCE field.\n"
                  f"Return ONLY valid JSON: "
                  f"{{\"mappings\": [{{\"source\": \"full/canonical/@xpath\", \"target\": \"EDI_element\"}}]}}")
        try:
            raw = call_ai(prompt, ANALYSIS_SYSTEM)
            parsed = clean_json(raw)
            if isinstance(parsed, dict) and "mappings" in parsed:
                all_pairs.extend(parsed["mappings"])
        except Exception as e:
            print(f"  AI chunk {idx+1} failed: {e}")
    return all_pairs


def _deterministic_xslt(mappings, source_schema, source_ns, target_format,
                         transaction_set, loop_map) -> str:
    target_ns = ""
    if target_format:
        m = re.search(r'xmlns:ns0="([^"]+)"', target_format)
        if m: target_ns = m.group(1)
    ts_num = transaction_set or ""
    if not ts_num and target_format:
        m2 = re.search(r"(2[01][04]|850|856|810|997|990)", target_format)
        if m2: ts_num = m2.group(1)

    ns_decls = 'xmlns:xsl="http://www.w3.org/1999/XSL/Transform"'
    ns_decls += '\n  xmlns:msxsl="urn:schemas-microsoft-com:xslt"'
    ns_decls += '\n  xmlns:var="http://schemas.microsoft.com/BizTalk/2003/var"'
    ns_decls += '\n  xmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp"'
    if source_ns: ns_decls += f'\n  xmlns:s0="{source_ns}"'
    if target_ns: ns_decls += f'\n  xmlns:ns0="{target_ns}"'

    # Detect source root element
    root_elem_src = "Invoice"
    if source_schema:
        elements = source_schema.get("elements", {})
        if isinstance(elements, list):
            elements = {e["path"]: e for e in elements if isinstance(e, dict) and "path" in e}
        for path in list(elements.keys())[:5]:
            top = path.split("/")[0]
            if top and not top.startswith("@") and top[0].isupper():
                root_elem_src = top; break

    root_match = f"/s0:{root_elem_src}" if source_ns else f"/{root_elem_src}"
    root_out   = f"ns0:X12_00401_{ts_num}" if ts_num and target_ns else "Root"

    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        f'<xsl:stylesheet version="1.0" {ns_decls}',
        '  exclude-result-prefixes="msxsl var s0 userCSharp">',
        "",
        '  <xsl:output omit-xml-declaration="yes" method="xml" version="1.0"/>',
        "  <xsl:variable name=\"vLowercaseChars_CONST\" select=\"'abcdefghijklmnopqrstuvwxyz'\"/>",
        "  <xsl:variable name=\"vUppercaseChars_CONST\" select=\"'ABCDEFGHIJKLMNOPQRSTUVWXYZ'\"/>",
        "",
        f'  <xsl:template match="/">',
        f'    <xsl:apply-templates select="{root_match}"/>',
        "  </xsl:template>",
        "",
        f'  <xsl:template match="{root_match}">',
        f"    <{root_out}>",
        "",
        "      <!-- ST segment -->",
        "      <ST>",
        "        <ST01>210</ST01>",
        "        <ST02>0001</ST02>",
        "      </ST>",
        "",
    ]

    by_parent: Dict[str, List[dict]] = defaultdict(list)
    for m in mappings:
        tgt = m.get("target", "")
        parent = re.match(r"^([A-Z][A-Z0-9]{0,2})(?=\d{2})", tgt)
        parent_key = parent.group(1) if parent else tgt.split("/")[0]
        by_parent[parent_key].append(m)

    for parent, pmappings in sorted(by_parent.items()):
        if not parent or parent in ("ST","SE"): continue
        lines.append(f"      <!-- {parent} segment -->")
        lines.append(f"      <ns0:{parent}>")
        for m in sorted(pmappings, key=lambda x: x.get("target","")):
            tgt     = m.get("target","")
            src     = m.get("source","") or m.get("_resolved_source","") or ""
            literal = m.get("literal")
            transform = m.get("transform")
            condition = m.get("condition")
            leaf = re.sub(r"^ns0:","", tgt.split("/")[-1])
            if not leaf: continue
            pad = "        "
            if literal:
                lines.append(f"{pad}<{leaf}>{literal}</{leaf}>")
            elif src:
                val_expr  = build_transform_xpath(src, transform)
                cond_test = condition if condition else f"{src} != ''"
                lines.append(f"{pad}<xsl:if test=\"{cond_test}\">")
                lines.append(f"{pad}  <{leaf}>")
                lines.append(f"{pad}    {val_expr}")
                lines.append(f"{pad}  </{leaf}>")
                lines.append(f"{pad}</xsl:if>")
        lines.append(f"      </ns0:{parent}>")
        lines.append("")

    # Loops
    for loop_name, loop_xpath in loop_map.items():
        if any(k in loop_name for k in ("Loop","Party","Item","Stop","Status")):
            lines.append(f"      <!-- {loop_name} loop -->")
            lines.append(f'      <xsl:for-each select="{loop_xpath}">')
            lines.append(f'        <ns0:{loop_name}1>')
            lines.append(f'        </ns0:{loop_name}1>')
            lines.append(f'      </xsl:for-each>')
            lines.append("")

    lines += [
        "      <!-- SE segment -- always last -->",
        "      <SE>",
        "        <SE01/>",
        "        <SE02>0001</SE02>",
        "      </SE>",
        "",
        f"    </{root_out}>",
        "  </xsl:template>",
        "",
        "  <!-- CleanAlphaField template -->",
        '  <xsl:template name="CleanAlphaField">',
        '    <xsl:param name="inputText"/>',
        '    <xsl:param name="maxLength"/>',
        "    <xsl:variable name=\"cleaned\" select=\"translate($inputText,'~*:?|','     ')\"/>",
        '    <xsl:value-of select="substring(normalize-space($cleaned),1,$maxLength)"/>',
        "  </xsl:template>",
        "",
        "</xsl:stylesheet>",
    ]
    return "\n".join(l for l in lines if l is not None)


# =============================================================================
# Main Pipeline
# =============================================================================

class MapGenerationPipeline:

    def run(self, mapping_rows, raw_mapping_text="", source_schema=None,
            source_ns="", target_format="", transaction_set="",
            use_ai_for_pairs=True, use_ai_scaffold=True,
            customer_profile=None) -> dict:
        log: List[str] = []

        # Step 1: Dual schema indexes
        canonical_index = build_canonical_index_from_schema(source_schema) if source_schema else {}
        canonical_paths = _dual_get_can_paths(source_schema)
        if transaction_set and not canonical_index:
            canonical_index = build_canonical_index_from_xsd(transaction_set)
        edi_index = build_edi_index(transaction_set) if transaction_set else {}
        log.append(f"Step 1: Canonical index -- {len(canonical_index)} fields | EDI index -- {len(edi_index)} elements")

        # Step 2: Reference template
        try: auto_populate_base_maps()
        except Exception: pass
        ref_tmpl = get_reference_template(transaction_set) if transaction_set else None
        if ref_tmpl:
            log.append(f"Step 2: Reference template loaded for {transaction_set} -- "
                       f"{len(ref_tmpl['loops'])} loops, {len(ref_tmpl['conditions'])} conditions, "
                       f"{len(ref_tmpl['literals'])} literals")
        else:
            log.append("Step 2: No reference template (add base map to training/base_maps/)")

        # Step 3: Extend mapping rows
        for row in mapping_rows:
            for field in ("literal","condition","transform","_is_literal"):
                if field not in row:
                    row[field] = None if field != "_is_literal" else False
            if "value_map" not in row:
                row["value_map"] = None
            if "value_map" not in row:
                row["value_map"] = None
            if "value_map" not in row:
                row["value_map"] = None

        # Step 4: Resolve source fields -> canonical XPaths
        resolved = resolve_mapping_pairs(mapping_rows, canonical_index, transaction_set)
        for m in resolved:
            if not m.get("_resolved_source") and m.get("source") and "/" not in m.get("source",""):
                hit = best_match(m["source"], canonical_index)
                if hit: m["source"] = hit; m["_resolved_source"] = hit
        # FIX 05: enrich from field-level learning store BEFORE AI (reduces AI calls)
        if transaction_set:
            resolved, _pre_fl = enrich_mappings_from_store(resolved, transaction_set)
            if _pre_fl > 0:
                log.append(f"Step 4-pre: Field store pre-filled {_pre_fl} sources before AI")
        log.append(f"Step 4: Resolved {sum(1 for r in resolved if r.get('_resolved_source') or '/' in (r.get('source') or ''))}/{len(resolved)} sources to XPaths")

        # Step 4b: Strict path resolver (dual-schema validation)
        try:
            from backend.schema.strict_path_resolver import resolve_all_mappings as _strict_resolve
            resolved = _strict_resolve(resolved, canonical_index, transaction_set)
            _ok = sum(1 for r in resolved if r.get("_resolved_source") or "/" in (r.get("source") or ""))
            log.append("Step 4b: Strict resolver -> %d/%d have valid XPaths" % (_ok, len(resolved)))
        except Exception as _spe:
            log.append("Step 4b: Strict resolver skipped - %s" % str(_spe))

        # Step 5: Learning engine enrichment
        # HALLUCINATION GUARD: never enrich rows that are hardcoded literals
        resolved = _learner.enrich_mappings(
            [m for m in resolved if not m.get("_is_literal") and not m.get("literal")]
        ) + [m for m in resolved if m.get("_is_literal") or m.get("literal")]
        learned_count = 0
        for m in resolved:
            if not m.get("source") and m.get("target") and transaction_set and not m.get("literal"):
                xpath = lookup_learned_mapping(m["target"], transaction_set)
                if xpath:
                    m["source"] = xpath; m["_learned"] = True; learned_count += 1
        # FIX 07: also enrich from field-level learning store
        if transaction_set:
            resolved, _fl_count = enrich_mappings_from_store(resolved, transaction_set)
            learned_count += _fl_count
        log.append(f"Step 5: Learning engine enriched {learned_count} empty sources")

        # Step 6: Chunked AI extraction (FIXES 413 error)
        ai_pairs: List[dict] = []
        if use_ai_for_pairs:
            try:
                guide = _canonical_guide(source_schema)
                ai_pairs = _ai_extract_chunked(resolved, raw_mapping_text, guide, transaction_set)
                log.append("Step 6: AI extracted %d pairs" % len(ai_pairs))
            except Exception as e:
                _em = str(e)
                if "openai" not in _em.lower() and "anthropic" not in _em.lower():
                    log.append("Step 6: AI extraction skipped -- %s" % _em)
                else:
                    log.append("Step 6: AI not configured -- deterministic mode active")
        else:
            log.append("Step 6: AI extraction disabled")

        # Step 7: Merge + deduplicate
        all_targets: Dict[str, dict] = {m.get("target"): m for m in resolved if m.get("target")}
        for ap in ai_pairs:
            if ap.get("target") and ap["target"] not in all_targets:
                all_targets[ap["target"]] = ap
        # Literals always win; value_map rows beat plain rows
        for m in resolved:
            if m.get("_is_literal") or m.get("literal"):
                all_targets[m.get("target","")] = m
            elif m.get("value_map") and not (all_targets.get(m.get("target","")) or {}).get("value_map"):
                all_targets[m.get("target","")] = m
        merged = list(all_targets.values())
        log.append(f"Step 7: Merged -- {len(merged)} unique target mappings")

        # Step 8: Dual-schema consistency check
        check = check_consistency(merged,
                                  canonical_paths=canonical_paths if source_schema else None,
                                  edi_index=edi_index,
                                  transaction_set=transaction_set)
        log.append(f"Step 8: Consistency -- {check['valid_count']}/{check['total_count']} valid, "
                   f"{len(check['duplicate_targets'])} duplicates, "
                   f"{len(check.get('invalid_targets',[]))} invalid targets, "
                   f"{len(check.get('invalid_sources',[]))} invalid sources")
        for w in check.get("warnings",[]): log.append(f"  {w}")

        # Step 9: Filter - protect literals and EDI-control rows
        if source_schema and canonical_paths:
            literal_rows  = [m for m in merged if m.get("_is_literal") or m.get("literal")]
            content_rows  = [m for m in merged if not m.get("_is_literal") and not m.get("literal")]
            filtered_rows = filter_valid_mappings(content_rows, canonical_paths, edi_index)
            valid_mappings = filtered_rows + literal_rows
            log.append("Step 9: %d mappings pass schema validation (%d literals always kept)"
                        % (len(valid_mappings), len(literal_rows)))
        else:
            valid_mappings = merged

        # FIX 09: Optimize conditions before generation
        try:
            from backend.engine.condition_optimizer import optimize_conditions
            valid_mappings = optimize_conditions(valid_mappings)
            log.append("Step 9b: Condition optimizer applied â€ no blind condition dumping")
        except Exception as _ce:
            log.append(f"Step 9b: Condition optimizer skipped â€ {_ce}")

        # Step 10: Loop detection
        loop_map = detect_loops_in_mappings(valid_mappings)
        if transaction_set:
            for lp in detect_repeating_nodes(transaction_set):
                if lp["name"] not in loop_map:
                    loop_map[lp["name"]] = lp["xpath"]
        if ref_tmpl:
            for lp in ref_tmpl.get("loops",[]):
                if lp["edi_loop"] not in loop_map:
                    loop_map[lp["edi_loop"]] = lp["xpath"]
        # FIX 06: enforce schema-required loops + sort mappings
        loop_map = enforce_loops_for_transaction(loop_map, transaction_set, valid_mappings)
        valid_mappings = sort_segments_by_order(valid_mappings, transaction_set)
        # FIX 06: enforce qualifier-specific XPaths on all mappings
        try:
            from backend.engine.qualifier_enforcer import enforce_qualifiers, enforce_qualifiers_on_loop_map
            valid_mappings = enforce_qualifiers(valid_mappings, transaction_set)
            loop_map = enforce_qualifiers_on_loop_map(loop_map, transaction_set)
            log.append("Step 10b: Qualifier enforcement applied to mappings and loop_map")
        except Exception as _qe:
            log.append(f"Step 10b: Qualifier enforcement skipped â€ {_qe}")
        log.append(f"Step 10: Loop detection (enforced) -- {len(loop_map)} loops: {list(loop_map.keys())}")

        # Step 11: AI XSLT with reference template injected
        xslt = ""
        if use_ai_scaffold:
            try:
                from backend.generator.xslt_generator import build_universal_prompt
                from backend.schema.schema_registry import detect_transaction_from_mapping, get_schema_summary
                from backend.core.ai_engine import call_ai, clean_xslt, XSLT_SYSTEM
                if not transaction_set and raw_mapping_text:
                    transaction_set = detect_transaction_from_mapping(raw_mapping_text)
                edi_schema_text = get_schema_summary(transaction_set) if transaction_set else ""
                base_map_section = get_base_map_section_for_prompt(transaction_set) if transaction_set else ""
                prompt = build_universal_prompt(
                    mapping_rows=valid_mappings, source_schema=source_schema,
                    raw_mapping_text=raw_mapping_text, source_ns=source_ns,
                    target_format=target_format, edi_schema_text=edi_schema_text,
                    transaction_set=transaction_set,
                )
                injection = _canonical_guide(source_schema) + "\n"
                if base_map_section: injection += base_map_section + "\n"
                prompt = injection + prompt
                xslt = clean_xslt(call_ai(prompt, XSLT_SYSTEM))
                log.append("Step 11: AI XSLT generated with canonical guide + reference template injected")
            except Exception as e:
                log.append(f"Step 11: AI scaffold failed -- {e}, using deterministic fallback")
                xslt = ""

        # Step 12: Deterministic fallback
        if not xslt:
            # FIX 04: transaction-aware deterministic generator
            xslt = _new_det_gen(
                mappings=valid_mappings,
                transaction_set=transaction_set,
                source_schema=source_schema,
                source_ns=source_ns,
                target_ns="",
                loop_map=loop_map,
            )
            # Legacy fallback kept for safety
            if not xslt:
                xslt = _deterministic_xslt(valid_mappings, source_schema, source_ns,
                                       target_format, transaction_set, loop_map)
            log.append("Step 12: Deterministic XSLT generated")

        # Step 12b: Self-healing validation loop
        if xslt and transaction_set:
            try:
                from backend.engine.self_healing_pipeline import self_healing_generate
                flat_index = {}
                if source_schema:
                    import re as _re2
                    elements = source_schema.get("elements", {})
                    if isinstance(elements, list):
                        elements = {e["path"]: e for e in elements if isinstance(e, dict) and "path" in e}
                    for path in elements.keys():
                        leaf = path.split("/")[-1].lstrip("@")
                        key = _re2.sub(r"[^a-z0-9]", "", leaf.lower())
                        if key: flat_index.setdefault(key, path)
                heal = self_healing_generate(
                    xslt=xslt,
                    transaction_set=transaction_set,
                    canonical_index=flat_index,
                    sample_xml=None,
                )
                xslt = heal.get("xslt", xslt)
                for hl in heal.get("heal_log", []):
                    log.append(f"  Heal: {hl}")
                log.append(f"Step 12b: Self-healing done â€ valid={heal.get('valid')}, attempts={heal.get('attempts')}")
            except ImportError:
                log.append("Step 12b: self_healing_pipeline not found â€ skipped")
            except Exception as _heal_err:
                log.append(f"Step 12b: Self-healing error â€ {_heal_err}")

        # Step 13: Accuracy report + self-learning
        accuracy = {
            "valid":               check["valid_count"],
            "total":               check["total_count"],
            "invalid_sources":     len(check.get("invalid_sources",[])),
            "invalid_targets":     len(check.get("invalid_targets",[])),
            "duplicates":          len(check["duplicate_targets"]),
            "learned_enrichments": learned_count,
            "loops_detected":      len(loop_map),
            "accuracy_pct":        check["accuracy_pct"],
        }
        log.append(f"Step 13: Accuracy -- {accuracy['accuracy_pct']}% ({accuracy['valid']}/{accuracy['total']} valid)")

        # FIX 07: Run full XSLT validation (syntax + structure)
        try:
            from backend.engine.output_validator import full_validate as _fv
            val_report = _fv(xslt, transaction_set)
            if not val_report["valid"]:
                for err in val_report["all_errors"]:
                    if err:
                        log.append(f"  XSLT Error: {err}")
            for warn in val_report.get("all_warnings", []):
                log.append(f"  XSLT Warning: {warn}")
            log.append(f"Step 13b: XSLT validation â€ valid={val_report['valid']}, "
                       f"syntax={val_report['syntax'].get('valid')}")
        except Exception as _ve:
            log.append(f"Step 13b: XSLT validation skipped -- {{_ve}}")
        try: _learner.learn_from_validated_map(valid_mappings)
        except Exception: pass

        return {
            "xslt":               xslt,
            "accuracy":           accuracy,
            "pipeline_log":       log,
            "consistency_report": check,
            "loop_map":           loop_map,
            "valid_mappings":     valid_mappings,
            "transaction_set":    transaction_set,
            "reference_template": ref_tmpl is not None,
            "customer_profile":   customer_profile,
            "xslt_errors":        [],
        }

# ---- EDIForge v4 accuracy patch: UTF-8 output + base map copy ----
import importlib as _il

def _patched_generate(mappings, transaction_set="210", canonical_schema=None,
                      x12_schema=None, log_lines=None):
    """Wrapper that calls the fixed generator and returns UTF-8 string."""
    try:
        gen_mod = _il.import_module("backend.generator.xslt_generator")
        xsl = gen_mod.generate_xslt(
            mappings=mappings,
            transaction_set=transaction_set,
            customer_profile=customer_profile,
            canonical_schema=canonical_schema,
            x12_schema=x12_schema,
            log_lines=log_lines,
        )
        # Return as string -- the API layer converts to bytes
        return xsl
    except Exception as e:
        if log_lines is not None:
            log_lines.append(f"Patched generator failed: {e}")
        raise

# Monkey-patch if old generate_xslt exists in this module scope
try:
    generate_xslt = _patched_generate
except Exception:
    pass
# ---- end accuracy patch ----




