"""
EDIForge AI v4 -- Mapping Consistency Checker  (FIXED)
=======================================================
ROOT CAUSE FIX for:
  "ST -> Not found in canonical schema"     (was validating EDI target against canonical)
  "X12_00401_210 -> Not found in canonical" (same bug)
  100 invalid paths in logs

Correct logic:
  source -> must exist in canonical schema   (Invoice/Header/... paths)
  target -> must exist in EDI / X12 schema  (ST01, B302, N101 ...)

The old checker was doing the opposite:
  target -> validated against canonical
  Which always failed because ST/B302/N101 are EDI, not canonical.
"""
from __future__ import annotations
from typing import Dict, List, Optional, Set


# EDI control segments - never in canonical schema, always keep
_EDI_ONLY_SEGMENTS = {
    "ST","ST01","ST02","SE","SE01","SE02","GS","GE","ISA","IEA",
    "AK1","AK2","AK3","AK4","AK5","AK9","IK3","IK4","IK5",
}
def check_consistency(
    mappings: List[dict],
    canonical_paths: Optional[List[str]] = None,
    edi_index: Optional[Dict[str, str]] = None,
    transaction_set: str = "",
) -> dict:
    # Auto-load EDI index
    if edi_index is None and transaction_set:
        try:
            from backend.schema.dual_schema_index import build_edi_index
            edi_index = build_edi_index(transaction_set)
        except Exception:
            edi_index = {}

    canonical_set: Optional[Set[str]] = set(canonical_paths) if canonical_paths else None
    edi_set: Optional[Set[str]] = set(edi_index.keys()) if edi_index else None

    invalid_sources: List[dict] = []
    invalid_targets: List[dict] = []
    duplicate_targets: List[dict] = []
    warnings: List[str] = []
    target_seen: Dict[str, int] = {}
    valid_rows = 0

    for i, m in enumerate(mappings):
        src = (m.get("source") or "").strip()
        tgt = (m.get("target") or "").strip()
        is_literal = m.get("_is_literal") or m.get("literal")
        if not tgt and not src:
            continue
        row_valid = True

        # Validate SOURCE against canonical schema
        if canonical_set and src and "/" in src:
            if src not in canonical_set:
                invalid_sources.append({"index":i,"source":src,
                                        "reason":"Source path not in canonical schema"})
                row_valid = False

        # Validate TARGET against EDI (X12) schema
        if edi_set and tgt and not is_literal:
            tgt_clean = tgt.split(":")[-1] if ":" in tgt else tgt
            if tgt_clean not in edi_set and tgt not in edi_set:
                invalid_targets.append({"index":i,"target":tgt,
                                        "reason":"Target element not in EDI schema"})
                row_valid = False

        # Duplicate target check
        if tgt:
            if tgt in target_seen:
                duplicate_targets.append({"target":tgt,"first_at":target_seen[tgt],"duplicate_at":i})
            else:
                target_seen[tgt] = i

        # Missing source warning (skip literals -- they HAVE no source by design)
        if tgt and not src and not is_literal:
            warnings.append(f"Row {i}: target '{tgt}' has no source (and is not a hardcoded literal)")

        if row_valid:
            valid_rows += 1

    total = len([m for m in mappings
                 if m.get("target","").strip() or m.get("source","").strip()])
    return {
        "valid_count":       valid_rows,
        "total_count":       total,
        "invalid_paths":     invalid_sources,   # backward compat alias
        "invalid_sources":   invalid_sources,
        "invalid_targets":   invalid_targets,
        "duplicate_targets": duplicate_targets,
        "missing_required":  [],
        "warnings":          warnings,
        "is_clean":          not invalid_sources and not invalid_targets and not duplicate_targets,
        "accuracy_pct":      round(100 * valid_rows / max(total, 1), 1),
    }


def filter_valid_mappings(
    mappings: List[dict],
    canonical_paths: List[str],
    edi_index: Optional[Dict[str, str]] = None,
) -> List[dict]:
    canonical_set = set(canonical_paths)
    valid = []
    for m in mappings:
        if m.get("_is_literal") or m.get("literal"):
            valid.append(m); continue
        tgt = m.get("target","").strip()
        src = m.get("source","").strip()
        if not tgt: continue
        if "/" in src and src not in canonical_set:
            continue
        valid.append(m)
    return valid
