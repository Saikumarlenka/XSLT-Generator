"""EDIForge AI v2 -- Field Normalizer."""
import re
from typing import Optional

ABBREVIATIONS = {
    r"\bbol\b": "billoflading",
    r"\bscac\b": "scac",
    r"\bpro\b": "pronumber",
    r"\bpro#\b": "pronumber",
    r"\bwt\b": "weight",
    r"\bqty\b": "quantity",
    r"\bdlv\b": "deliverydate",
    r"\beta\b": "estimatedarrivaldate",
    r"\bpcs\b": "pieces",
    r"\bamt\b": "amount",
    r"\bref\b": "referencenumber",
    r"\bpo\b": "purchaseordernumber",
}


def normalize_field(name: str) -> str:
    if not name:
        return ""
    text = name.strip().lower()
    for pattern, replacement in ABBREVIATIONS.items():
        text = re.sub(pattern, replacement, text)
    text = re.sub(r"[\s_\-#./\\()\[\]]", "", text)
    text = re.sub(r"(no|num|number)$", "", text)
    return text


def best_match(field: str, canonical_index: dict) -> Optional[str]:
    key = normalize_field(field)
    if not key:
        return None
    if key in canonical_index:
        return canonical_index[key]
    candidates = {k: v for k, v in canonical_index.items() if key.startswith(k) and len(k) >= 4}
    if candidates:
        return candidates[max(candidates, key=len)]
    candidates2 = {k: v for k, v in canonical_index.items() if k.startswith(key) and len(key) >= 4}
    if candidates2:
        return candidates2[min(candidates2, key=len)]
    return None
