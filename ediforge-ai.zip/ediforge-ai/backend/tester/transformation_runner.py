"""
EDIForge AI - Transformation Test Engine (FIXED v2)
Runs sample canonical XML through generated XSLT and validates EDI output.
"""
import sys, os, re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))


def run_transformation(xslt_content, xml_content):
    try:
        from lxml import etree
    except ImportError:
        return {"success": False,
                "error": "lxml not installed - run: pip install lxml", "output": ""}
    try:
        xslt_clean = re.sub(r"<[?]xml[^?]*[?]>", "", xslt_content, count=1).strip()
        xslt_root  = etree.fromstring(xslt_clean.encode("utf-8"))
        transform  = etree.XSLT(xslt_root)
    except Exception as e:
        return {"success": False, "error": "XSLT load error: %s" % e, "output": ""}
    try:
        xml_root = etree.fromstring(xml_content.encode("utf-8"))
    except Exception as e:
        return {"success": False, "error": "Sample XML parse error: %s" % e, "output": ""}
    try:
        result      = transform(xml_root)
        output      = str(result)
        xslt_errors = [str(e) for e in transform.error_log]
        return {"success": True, "output": output,
                "output_lines": len(output.splitlines()),
                "xslt_warnings": xslt_errors, "error": None}
    except etree.XSLTApplyError as e:
        return {"success": False, "error": "Transformation error: %s" % e, "output": ""}
    except Exception as e:
        return {"success": False, "error": str(e), "output": ""}


def validate_edi_output(output, transaction_set="", expected_segments=None):
    _REQUIRED = {
        "210": ["ST","B3","SE"], "214": ["ST","B10","SE"],
        "204": ["ST","B2","SE"], "990": ["ST","B1","SE"],
        "940": ["ST","W05","SE"],
    }
    issues = []
    segments_found = list(dict.fromkeys(
        re.findall(r"<(?:ns0:)?([A-Z][A-Z0-9]{1,4})\b", output)))
    required = expected_segments or _REQUIRED.get(transaction_set, ["ST","SE"])
    missing  = [s for s in required if s not in segments_found]
    if missing:
        issues.append("Missing required segments: %s" % missing)
    empty = re.findall(r"<([A-Z][A-Z0-9]{2,4})(?:/>|></[A-Z][A-Z0-9]{2,4}>)", output)
    if empty:
        issues.append("Empty elements: %s" % list(dict.fromkeys(empty)))
    return {"segment_count": len(segments_found), "segments_found": segments_found,
            "missing": missing, "empty_elements": empty,
            "issues": issues, "valid": len(issues) == 0}


def run_and_validate(xslt_content, xml_content, transaction_set=""):
    tr = run_transformation(xslt_content, xml_content)
    validation = {"valid": False, "issues": ["Transformation failed"]}
    if tr["success"]:
        validation = validate_edi_output(tr["output"], transaction_set=transaction_set)
    return {
        "transform":  tr,
        "validation": validation,
        "passed":     tr["success"] and validation["valid"],
        "summary": ("Transform: %s | EDI Valid: %s" % (
            "OK" if tr["success"] else "FAIL",
            "YES" if validation["valid"] else ("NO - " + "; ".join(validation["issues"]))
        )),
    }