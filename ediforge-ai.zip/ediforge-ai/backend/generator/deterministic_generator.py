﻿"""
EDIForge AI - deterministic_generator redirect
The real implementation lives in backend/engine/deterministic_generator.py
This file is kept only so existing imports don't crash.
"""
from backend.engine.deterministic_generator import (
    build_deterministic_xslt,
    _build_header,
    _build_helper_templates,
    _build_st_segment,
    _build_se_segment,
    _build_segment,
    _build_loop,
)

from backend.generator._det_gen_class import DeterministicXSLTGenerator, validate_xslt_structure

__all__ = [
    "build_deterministic_xslt",
    "DeterministicXSLTGenerator",
    "validate_xslt_structure",
]
