﻿"""
EDIForge AI v5 -- DeterministicXSLTGenerator class
BASE MAP FIRST: structure from base map, only XPath values replaced.
"""
from __future__ import annotations
import re, sys
from pathlib import Path
from typing import Dict, List, Optional

try:
    from lxml import etree as _etree; LXML_OK = True
except ImportError:
    LXML_OK = False

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

BASE_MAPS_DIR = Path(__file__).parent.parent.parent / "training" / "base_maps"
XSL_MAPS_DIR  = Path(__file__).parent.parent.parent / "training" / "xsl_maps"
_base_map_cache: Dict[str, str] = {}


def load_base_map(transaction_set: str) -> Optional[str]:
    if transaction_set in _base_map_cache:
        return _base_map_cache[transaction_set]
    for name in (f"{transaction_set}_base.xsl", f"{transaction_set}_base.xslt"):
        p = BASE_MAPS_DIR / name
        if p.exists():
            content = _decode_xsl(p)
            _base_map_cache[transaction_set] = content
            return content
    candidates = [f for f in XSL_MAPS_DIR.glob("*.xsl") if transaction_set in f.name]
    if candidates:
        best = max(candidates, key=lambda p: p.stat().st_size)
        content = _decode_xsl(best)
        _base_map_cache[transaction_set] = content
        return content
    return None


def _decode_xsl(path: Path) -> str:
    for enc in ("utf-16", "utf-8-sig", "utf-8"):
        try:
            return path.read_text(encoding=enc, errors="replace")
        except Exception:
            pass
    return path.read_text(errors="replace")


class DeterministicXSLTGenerator:
    def __init__(self, transaction_set: str):
        self.transaction_set = transaction_set
        self.base_xslt       = load_base_map(transaction_set)

    def has_base_map(self) -> bool:
        return self.base_xslt is not None

    def generate(self, mappings: List[dict], source_schema=None,
                 source_ns: str = "", target_format: str = "",
                 loop_map: Optional[Dict] = None) -> str:
        loop_map = loop_map or {}
        if self.base_xslt:
            return self._apply_to_template(mappings)
        return self._build_from_scratch(mappings, source_schema, source_ns, target_format, loop_map)

    def _apply_to_template(self, mappings: List[dict]) -> str:
        result = self.base_xslt
        mapping_lookup: Dict[str, str] = {}
        literal_lookup: Dict[str, str] = {}

        for m in mappings:
            tgt  = m.get("target", "").strip()
            src  = m.get("source", "") or m.get("_resolved_source", "") or ""
            leaf = re.sub(r"^ns0:", "", tgt.split("/")[-1]).lstrip("@")
            if m.get("literal"):
                literal_lookup[leaf] = str(m["literal"])
            elif src:
                mapping_lookup[leaf] = src.strip()

        def _replace_value_of(match):
            elem, old_select = match.group(1), match.group(2)
            if elem in literal_lookup:
                return f'<{elem}>{literal_lookup[elem]}</{elem}>'
            if elem in mapping_lookup:
                return match.group(0).replace(f'select="{old_select}"',
                                              f'select="{mapping_lookup[elem]}"')
            return match.group(0)

        result = re.sub(
            r'<([A-Z][A-Z0-9]{1,5})>\s*<xsl:value-of\s+select="([^"]+)"',
            _replace_value_of, result
        )

        def _replace_call_template(match):
            elem, old_select = match.group(1), match.group(2)
            if elem in mapping_lookup:
                return match.group(0).replace(
                    f'select="{old_select}"',
                    f'select="{mapping_lookup[elem]}"'
                )
            return match.group(0)

        result = re.sub(
            r'<([A-Z][A-Z0-9]{1,5})>\s*<xsl:call-template[^>]*>.*?'
            r'<xsl:with-param name="inputText"\s+select="([^"]+)"',
            _replace_call_template, result, flags=re.DOTALL
        )

        try:
            from backend.engine.transaction_rules import get_loop_xpaths
            loop_xpaths = get_loop_xpaths(self.transaction_set)
            for loop_name, correct_xpath in loop_xpaths.items():
                edi_elem = loop_name.replace("Loop1", "").replace("Loop", "")
                pattern = re.compile(
                    rf'(<xsl:for-each\s+select=")([^"]+)(">\\s*(?:<[^>]*>\\s*)*<ns0:{edi_elem})',
                    re.DOTALL
                )
                result = pattern.sub(lambda m: m.group(1) + correct_xpath + m.group(3), result)
        except Exception:
            pass

        return result

    def _build_from_scratch(self, mappings, source_schema, source_ns, target_format, loop_map) -> str:
        try:
            from backend.engine.deterministic_generator import build_deterministic_xslt
            return build_deterministic_xslt(
                mappings=mappings,
                transaction_set=self.transaction_set,
                source_schema=source_schema,
                source_ns=source_ns,
                loop_map=loop_map,
            )
        except Exception as e:
            return f"<!-- DeterministicXSLTGenerator fallback failed: {e} -->"


REQUIRED_SEGMENTS_BY_TS: Dict[str, List[str]] = {
    "210": ["ST", "B3", "SE"],
    "214": ["ST", "B10", "SE"],
    "990": ["ST", "B1", "SE"],
    "204": ["ST", "B2", "SE"],
}


def validate_xslt_structure(xslt: str, transaction_set: str) -> List[str]:
    errors: List[str] = []
    if not xslt or len(xslt) < 100:
        errors.append("XSLT is empty or too short")
        return errors
    if "xsl:stylesheet" not in xslt:
        errors.append("Missing <xsl:stylesheet>")
    for seg in REQUIRED_SEGMENTS_BY_TS.get(transaction_set, ["ST", "SE"]):
        if not re.search(rf'<(?:ns0:)?{seg}\b', xslt):
            errors.append(f"Missing required segment: {seg}")
    if "xmlns:xsl=" not in xslt:
        errors.append("Missing XSL namespace declaration")
    if LXML_OK:
        try:
            test = xslt
            if test.startswith("<?xml"):
                test = test[test.find("?>")+2:].strip()
            _etree.fromstring(test.encode("utf-8"))
        except Exception as e:
            errors.append(f"XML parse error: {e}")
    return errors
