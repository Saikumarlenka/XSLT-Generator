"""
EDIForge AI v4 -- XSLT Generator  (ACCURACY FIX)

Fixes applied vs previous version:
  1.  Reads actual namespace URIs from base map (ns0:, s0:)
  2.  Outputs UTF-8 to match converted training maps
  3.  Correct root element from base map (ns0:X12_00401_210 etc.)
  4.  s0: prefix on template match + apply-templates
  5.  xsl:variable declarations for date fields inside B3
  6.  C2/R3/G62 output as hardcoded literal XML, not as XPath expressions
  7.  N9 loop: for-each over ReferenceList with (@EDICode=BM or PO) filter
  8.  N1 loops: 3 separate loops with party-code-specific N101 hardcoding
  9.  LXLoop1 with full nested content (LX, L5, L0-conditional, L1-conditional)
  10. L108 xsl:choose/when logic (405->FUE, LHS->omit, else passthrough)
  11. L3 loop with translate(TotalCharges, comma removal)
  12. G62 two instances (qualifier 10 pickup, 35 delivery)
  13. SE uses TransactionSetheader/@TransactionSetIdentifierCode
  14. All helper templates copied from base map
  15. "Node Name" and other invalid element names filtered out
"""
import os, re, sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

try:
    from schema.base_map_registry import get_base_map_metadata, get_reference_excerpt
except ImportError:
    get_base_map_metadata = None
    get_reference_excerpt = None

try:
    from schema.dual_schema_index import build_dual_index
except ImportError:
    build_dual_index = None

try:
    from core.ai_engine import call_ai
except ImportError:
    call_ai = None


# ---- Qualifier Engine import (FIX 02) ----
try:
    from backend.engine.qualifier_engine import build_n1_party_loops, qualify_xpath
    _QUALIFIER_ENGINE_AVAILABLE = True
except ImportError:
    _QUALIFIER_ENGINE_AVAILABLE = False
    def qualify_xpath(segment, qualifier, base, position=None): return base
    def build_n1_party_loops(quals): return [{"qualifier": q, "xpath": q, "comment": q} for q in quals]
# ---- end qualifier import ----


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _safe_element_name(name):
    """Remove invalid characters from XML element names."""
    name = str(name).strip()
    # Remove spaces and anything not allowed in XML names
    name = re.sub(r'[^a-zA-Z0-9_:.\-]', '_', name)
    if not name or name[0].isdigit():
        name = "_" + name
    return name


def _indent(xml, spaces=3):
    prefix = "\t" * spaces
    return "\n".join(prefix + line for line in xml.splitlines())


def _date_var(var_name, field_name):
    """Generate xsl:variable declaration for a date field using local-name() traversal."""
    return (
        f'\t\t\t\t<xsl:variable name="{var_name}" '
        f'select="/*[local-name()=\'Invoice\']/*[local-name()=\'Header\']'
        f'/*[local-name()=\'BeginningSegmentForCarriersInvoice\']'
        f'/@*[local-name()=\'{field_name}\']" />'
    )


def _format_date(var):
    """XPath concat() for YYYYMMDD from ISO date variable."""
    return (
        f"concat(substring(${var}, 1, 4), "
        f"substring(${var}, 6, 2), "
        f"substring(${var}, 9, 2))"
    )


# ---------------------------------------------------------------------------
# Section builders
# ---------------------------------------------------------------------------

def _build_stylesheet_open(meta, transaction_set):
    """Build the <xsl:stylesheet ...> opening tag with correct namespaces."""
    ns0_uri = (meta or {}).get("ns0_uri") or f"http://Echo.BSSR.Schemas.EDI.X12_00401.EDI{transaction_set}/v1.0"
    s0_uri  = (meta or {}).get("s0_uri")  or "http://Echo.BSSR.Internal.Canonical.Invoice"
    return f'''<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
\txmlns:msxsl="urn:schemas-microsoft-com:xslt"
\txmlns:var="http://schemas.microsoft.com/BizTalk/2003/var"
\texclude-result-prefixes="msxsl var s0 userCSharp"
\tversion="1.0"
\txmlns:ns0="{ns0_uri}"
\txmlns:s0="{s0_uri}"
\txmlns:userCSharp="http://schemas.microsoft.com/BizTalk/2003/userCSharp">'''


def _build_b3_section(mappings):
    """Build the B3 segment with date variables and correct full XPaths."""
    date_vars = "\n".join([
        _date_var("InvoiceDate",   "InvoiceDate"),
        _date_var("DeliveryDate",  "DeliveryDate"),
        _date_var("BillingDate",   "BillingDate"),
        _date_var("PickupDate",    "PickupDate"),
    ])

    def _val(field, xpath, transform=None, clean=False, maxlen=None):
        if transform == "date":
            expr = _format_date(field)
            var  = field
            return f'''\t\t\t\t<xsl:if test="${var} != '' ">
\t\t\t\t\t<{field}>
\t\t\t\t\t\t<xsl:value-of select="{expr}" />
\t\t\t\t\t</{field}>
\t\t\t\t</xsl:if>'''
        if clean:
            return f'''\t\t\t\t<xsl:if test="{xpath} != ''">
\t\t\t\t\t<{field}>
\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="{xpath}" />
\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="{maxlen or 22}" />
\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t</{field}>
\t\t\t\t</xsl:if>'''
        if transform == "translate_comma":
            return f'''\t\t\t\t<xsl:if test="string-length({xpath}) > 2">
\t\t\t\t\t<{field}>
\t\t\t\t\t\t<xsl:value-of select="translate({xpath}, \',\', \'\')" />
\t\t\t\t\t</{field}>
\t\t\t\t</xsl:if>'''
        return f'''\t\t\t\t<xsl:if test="{xpath} != '' ">
\t\t\t\t\t<{field}>
\t\t\t\t\t\t<xsl:value-of select="{xpath}" />
\t\t\t\t\t</{field}>
\t\t\t\t</xsl:if>'''

    base = "Header/BeginningSegmentForCarriersInvoice"
    return f'''\t\t\t<ns0:B3>
\t\t\t\t<!-- B301 not mapped by default -->
{_val("B302", f"{base}/@InvoiceNumber", clean=True, maxlen=22)}
{_val("B303", f"{base}/@ShipmentIdentificationNumber", clean=True, maxlen=30)}
{_val("B304", f"{base}/@ShipmentMethodOfPayment")}
{_val("B305", f"{base}/@WeightUnitCode")}
{date_vars}
{_val("B306", "InvoiceDate", transform="date")}
\t\t\t\t<xsl:if test="{base}/@NetAmountDue != '' ">
\t\t\t\t\t<B307>
\t\t\t\t\t\t<xsl:value-of select="translate({base}/@NetAmountDue, \'.\', \'\')" />
\t\t\t\t\t</B307>
\t\t\t\t</xsl:if>
\t\t\t\t<!-- B308 not mapped by default -->
{_val("B309", "DeliveryDate", transform="date")}
{_val("B310", f"{base}/@DateTimeQualifier")}
{_val("B311", f"{base}/@StandardCarrierAlphaCode")}
{_val("B312", "PickupDate", transform="date")}
\t\t\t\t<!-- B313, B314 not mapped by default -->
\t\t\t</ns0:B3>'''


def _build_c2_literal():
    return '''\t\t\t<ns0:C2>
\t\t\t\t<C201>R</C201>
\t\t\t\t<C202>25</C202>
\t\t\t\t<C203>TFP-001</C203>
\t\t\t</ns0:C2>'''


def _build_c3_section():
    return '''\t\t\t<xsl:if test="Header/Currency/@BillingCurrencyCode != '' ">
\t\t\t\t<ns0:C3>
\t\t\t\t\t<C301>
\t\t\t\t\t\t<xsl:value-of select="Header/Currency/@BillingCurrencyCode" />
\t\t\t\t\t</C301>
\t\t\t\t</ns0:C3>
\t\t\t</xsl:if>'''


def _build_n9_loop():
    ref_xpath = "/*[local-name()='Invoice']/*[local-name()='Header']/*[local-name()='ReferenceList']/*[local-name()='ReferenceInformation']"
    return f'''\t\t\t<xsl:for-each select="{ref_xpath}">
\t\t\t\t<xsl:if test="(@EDICode=\'BM\' or @EDICode=\'PO\') and @ReferenceInformation != \' \' ">
\t\t\t\t\t<ns0:N9>
\t\t\t\t\t\t<N901>
\t\t\t\t\t\t\t<xsl:value-of select="@EDICode" />
\t\t\t\t\t\t</N901>
\t\t\t\t\t\t<N902>
\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="@ReferenceInformation" />
\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="30" />
\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t</N902>
\t\t\t\t\t</ns0:N9>
\t\t\t\t</xsl:if>
\t\t\t</xsl:for-each>'''


def _build_g62_sections():
    """Two G62 segments: qualifier 10=pickup, 35=delivery."""
    return '''\t\t\t<xsl:variable name="PickupDate2" select="/*[local-name()=\'Invoice\']/*[local-name()=\'Header\']/*[local-name()=\'BeginningSegmentForCarriersInvoice\']/@*[local-name()=\'PickupDate\']" />
\t\t\t<xsl:variable name="DeliveryDate2" select="/*[local-name()=\'Invoice\']/*[local-name()=\'Header\']/*[local-name()=\'BeginningSegmentForCarriersInvoice\']/@*[local-name()=\'DeliveryDate\']" />
\t\t\t<ns0:G62>
\t\t\t\t<G6201>10</G6201>
\t\t\t\t<G6202>
\t\t\t\t\t<xsl:value-of select="concat(substring($PickupDate2, 1, 4), substring($PickupDate2, 6, 2), substring($PickupDate2, 9, 2))" />
\t\t\t\t</G6202>
\t\t\t</ns0:G62>
\t\t\t<ns0:G62>
\t\t\t\t<G6201>35</G6201>
\t\t\t\t<G6202>
\t\t\t\t\t<xsl:value-of select="concat(substring($DeliveryDate2, 1, 4), substring($DeliveryDate2, 6, 2), substring($DeliveryDate2, 9, 2))" />
\t\t\t\t</G6202>
\t\t\t</ns0:G62>'''


def _build_n1_loops():
    """Three N1 loops per the original map pattern."""
    def _party_loop(filter_code, n101_hardcode, label):
        n101_val = f"<N101>{n101_hardcode}</N101>" if n101_hardcode else '''<N101>
\t\t\t\t\t\t\t<xsl:value-of select="Name/@EntityIdentifierCode" />
\t\t\t\t\t\t</N101>'''
        if not n101_hardcode:
            n101_val = '''\t\t\t\t\t\t<N101>
\t\t\t\t\t\t\t<xsl:value-of select="Name/@EntityIdentifierCode" />
\t\t\t\t\t\t</N101>'''
        else:
            n101_val = f'\t\t\t\t\t\t<N101>{n101_hardcode}</N101>'

        return f'''\t\t\t<!-- {label} -->
\t\t\t<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode=\'{filter_code}\'][1]">
\t\t\t\t<ns0:N1Loop1>
\t\t\t\t\t<ns0:N1>
{n101_val}
\t\t\t\t\t\t<N102>
\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="Name/@Name" />
\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="60" />
\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t</N102>
\t\t\t\t\t</ns0:N1>
\t\t\t\t\t<xsl:if test="(AddressInformation/@AddressInformationLine1 != \'\') or (AddressInformation/@AddressInformationLine2 != \'\') ">
\t\t\t\t\t\t<ns0:N3>
\t\t\t\t\t\t\t<xsl:if test="AddressInformation/@AddressInformationLine1 != \'\'">
\t\t\t\t\t\t\t\t<N301>
\t\t\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1" />
\t\t\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="55" />
\t\t\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t\t\t</N301>
\t\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t\t\t<xsl:if test="AddressInformation/@AddressInformationLine2 != \'\'">
\t\t\t\t\t\t\t\t<N302>
\t\t\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2" />
\t\t\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="55" />
\t\t\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t\t\t</N302>
\t\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t\t</ns0:N3>
\t\t\t\t\t</xsl:if>
\t\t\t\t\t<xsl:if test="(GeographicLocation/@CityName != \'\') or (GeographicLocation/@StateOrProvinceCode != \'\') or (GeographicLocation/@PostalCode != \'\')">
\t\t\t\t\t\t<ns0:N4>
\t\t\t\t\t\t\t<xsl:if test="GeographicLocation/@CityName != \'\'">
\t\t\t\t\t\t\t\t<N401>
\t\t\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="GeographicLocation/@CityName" />
\t\t\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="55" />
\t\t\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t\t\t</N401>
\t\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t\t\t<xsl:if test="GeographicLocation/@StateOrProvinceCode != \'\'">
\t\t\t\t\t\t\t\t<N402>
\t\t\t\t\t\t\t\t\t<xsl:value-of select="GeographicLocation/@StateOrProvinceCode" />
\t\t\t\t\t\t\t\t</N402>
\t\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t\t\t<xsl:if test="GeographicLocation/@PostalCode != \'\'">
\t\t\t\t\t\t\t\t<N403>
\t\t\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="GeographicLocation/@PostalCode" />
\t\t\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="55" />
\t\t\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t\t\t</N403>
\t\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t\t\t<xsl:if test="GeographicLocation/@CountryCode != \'\'">
\t\t\t\t\t\t\t\t<N404>
\t\t\t\t\t\t\t\t\t<xsl:value-of select="GeographicLocation/@CountryCode" />
\t\t\t\t\t\t\t\t</N404>
\t\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t\t</ns0:N4>
\t\t\t\t\t</xsl:if>
\t\t\t\t</ns0:N1Loop1>
\t\t\t</xsl:for-each>'''

    # BT -> use EntityIdentifierCode as-is
    bt_loop = f'''\t\t\t<!-- Bill-To party -->
\t\t\t<xsl:for-each select="Header/PartyList/Party[Name/@EntityIdentifierCode=\'BT\']">
\t\t\t\t<ns0:N1Loop1>
\t\t\t\t\t<ns0:N1>
\t\t\t\t\t\t<N101>
\t\t\t\t\t\t\t<xsl:value-of select="Name/@EntityIdentifierCode" />
\t\t\t\t\t\t</N101>
\t\t\t\t\t\t<N102>
\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="Name/@Name" />
\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="60" />
\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t</N102>
\t\t\t\t\t</ns0:N1>
\t\t\t\t\t<xsl:if test="(AddressInformation/@AddressInformationLine1 != \'\') or (AddressInformation/@AddressInformationLine2 != \'\') ">
\t\t\t\t\t\t<ns0:N3>
\t\t\t\t\t\t\t<xsl:if test="AddressInformation/@AddressInformationLine1 != \'\'"><N301><xsl:call-template name="CleanAlphaField"><xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine1" /><xsl:with-param name="maxLength" select="55" /></xsl:call-template></N301></xsl:if>
\t\t\t\t\t\t\t<xsl:if test="AddressInformation/@AddressInformationLine2 != \'\'"><N302><xsl:call-template name="CleanAlphaField"><xsl:with-param name="inputText" select="AddressInformation/@AddressInformationLine2" /><xsl:with-param name="maxLength" select="55" /></xsl:call-template></N302></xsl:if>
\t\t\t\t\t\t</ns0:N3>
\t\t\t\t\t</xsl:if>
\t\t\t\t\t<xsl:if test="(GeographicLocation/@CityName != \'\') or (GeographicLocation/@StateOrProvinceCode != \'\') or (GeographicLocation/@PostalCode != \'\')">
\t\t\t\t\t\t<ns0:N4>
\t\t\t\t\t\t\t<xsl:if test="GeographicLocation/@CityName != \'\'"><N401><xsl:call-template name="CleanAlphaField"><xsl:with-param name="inputText" select="GeographicLocation/@CityName" /><xsl:with-param name="maxLength" select="55" /></xsl:call-template></N401></xsl:if>
\t\t\t\t\t\t\t<xsl:if test="GeographicLocation/@StateOrProvinceCode != \'\'"><N402><xsl:value-of select="GeographicLocation/@StateOrProvinceCode" /></N402></xsl:if>
\t\t\t\t\t\t\t<xsl:if test="GeographicLocation/@PostalCode != \'\'"><N403><xsl:call-template name="CleanAlphaField"><xsl:with-param name="inputText" select="GeographicLocation/@PostalCode" /><xsl:with-param name="maxLength" select="55" /></xsl:call-template></N403></xsl:if>
\t\t\t\t\t\t\t<xsl:if test="GeographicLocation/@CountryCode != \'\'"><N404><xsl:value-of select="GeographicLocation/@CountryCode" /></N404></xsl:if>
\t\t\t\t\t\t</ns0:N4>
\t\t\t\t\t</xsl:if>
\t\t\t\t</ns0:N1Loop1>
\t\t\t</xsl:for-each>'''

    sh_loop = _party_loop("SH", "SF", "Ship-From party (SH->SF)")
    cn_loop = _party_loop("CN", "ST", "Consignee/Ship-To party (CN->ST)")

    return f"{bt_loop}\n{sh_loop}\n{cn_loop}"


def _build_n7_loop():
    return '''\t\t\t<xsl:variable name="NumberOfN7" select="count(Header/EquipmentList/Equipment[@EquipmentNumber != \'\'])"/>
\t\t\t<xsl:if test="$NumberOfN7 > 0">
\t\t\t\t<ns0:N7Loop1>
\t\t\t\t\t<xsl:for-each select="Header/EquipmentList/Equipment">
\t\t\t\t\t\t<ns0:N7>
\t\t\t\t\t\t\t<xsl:if test="@EquipmentNumber != \'\'"><N702><xsl:value-of select="@EquipmentNumber" /></N702></xsl:if>
\t\t\t\t\t\t\t<xsl:if test="@EquipmentDescriptionCode != \'\'"><N711><xsl:value-of select="@EquipmentDescriptionCode" /></N711></xsl:if>
\t\t\t\t\t\t\t<xsl:if test="@EquipmentDescriptionCode != \'\'"><N715><xsl:value-of select="@EquipmentLength" /></N715></xsl:if>
\t\t\t\t\t\t</ns0:N7>
\t\t\t\t\t</xsl:for-each>
\t\t\t\t</ns0:N7Loop1>
\t\t\t</xsl:if>'''


def _build_lx_loop():
    """Full LXLoop1 with LX, L5, L0 (conditional on LHS), L1, choose/when for L108."""
    return '''\t\t\t<xsl:for-each select="Detail/LineItemList/LineItem">
\t\t\t\t<ns0:LXLoop1>
\t\t\t\t\t<ns0:LX>
\t\t\t\t\t\t<LX01><xsl:value-of select="position()"/></LX01>
\t\t\t\t\t</ns0:LX>
\t\t\t\t\t<ns0:L5>
\t\t\t\t\t\t<L501><xsl:value-of select="position()"/></L501>
\t\t\t\t\t\t<xsl:if test="DescriptionMarksAndNumbers/@LadingDescription != \'\'">
\t\t\t\t\t\t\t<L502>
\t\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="DescriptionMarksAndNumbers/@LadingDescription" />
\t\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="50" />
\t\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t\t</L502>
\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t</ns0:L5>
\t\t\t\t\t<!-- L0 only when SpecialChargeOrAllowanceCode = LHS -->
\t\t\t\t\t<xsl:if test="RateAndCharges/@SpecialChargeOrAllowanceCode = \'LHS\'">
\t\t\t\t\t\t<ns0:L0>
\t\t\t\t\t\t\t<L001><xsl:value-of select="position()"/></L001>
\t\t\t\t\t\t\t<xsl:if test="LineItemQuantityAndWeight/@BilledRatedAsQuantity != \'\'"><L002><xsl:value-of select="LineItemQuantityAndWeight/@BilledRatedAsQuantity" /></L002></xsl:if>
\t\t\t\t\t\t\t<xsl:if test="LineItemQuantityAndWeight/@BilledRatedAsQualifier != \'\'"><L003><xsl:value-of select="LineItemQuantityAndWeight/@BilledRatedAsQualifier" /></L003></xsl:if>
\t\t\t\t\t\t\t<xsl:if test="//Summary/TotalWeightAndCharges/@Weight != \'\'">
\t\t\t\t\t\t\t\t<L004><xsl:value-of select="//Summary/TotalWeightAndCharges/@Weight" /></L004>
\t\t\t\t\t\t\t\t<L005>L</L005>
\t\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t\t\t<xsl:if test="//Summary/TotalWeightAndCharges/@LadingQuantity != \'\'">
\t\t\t\t\t\t\t\t<L008><xsl:value-of select="//Summary/TotalWeightAndCharges/@LadingQuantity" /></L008>
\t\t\t\t\t\t\t\t<L009>PLT</L009>
\t\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t\t\t<xsl:if test="LineItemQuantityAndWeight/@WeightUnitCode != \'\'"><L011><xsl:value-of select="LineItemQuantityAndWeight/@WeightUnitCode" /></L011></xsl:if>
\t\t\t\t\t\t</ns0:L0>
\t\t\t\t\t</xsl:if>
\t\t\t\t\t<!-- L1 rate and charges -->
\t\t\t\t\t<xsl:if test="RateAndCharges/@FreightRate != \'\' or RateAndCharges/@Charge != \'\' or RateAndCharges/@SpecialChargeOrAllowanceCode != \'\'">
\t\t\t\t\t\t<ns0:L1>
\t\t\t\t\t\t\t<L101><xsl:value-of select="position()" /></L101>
\t\t\t\t\t\t\t<xsl:if test="RateAndCharges/@FreightRate != \'\'"><L102><xsl:value-of select="RateAndCharges/@FreightRate" /></L102></xsl:if>
\t\t\t\t\t\t\t<xsl:if test="RateAndCharges/@RateValueQualifier != \'\'"><L103><xsl:value-of select="RateAndCharges/@RateValueQualifier" /></L103></xsl:if>
\t\t\t\t\t\t\t<xsl:if test="RateAndCharges/@Charge != \'\'"><L104><xsl:value-of select="RateAndCharges/@Charge" /></L104></xsl:if>
\t\t\t\t\t\t\t<!-- L108: 405->FUE, LHS->omit, else passthrough -->
\t\t\t\t\t\t\t<xsl:choose>
\t\t\t\t\t\t\t\t<xsl:when test="RateAndCharges/@SpecialChargeOrAllowanceCode = \'405\'">
\t\t\t\t\t\t\t\t\t<L108>FUE</L108>
\t\t\t\t\t\t\t\t</xsl:when>
\t\t\t\t\t\t\t\t<xsl:otherwise>
\t\t\t\t\t\t\t\t\t<xsl:if test="RateAndCharges/@SpecialChargeOrAllowanceCode != \'\' and RateAndCharges/@SpecialChargeOrAllowanceCode != \'LHS\'">
\t\t\t\t\t\t\t\t\t\t<L108><xsl:value-of select="RateAndCharges/@SpecialChargeOrAllowanceCode" /></L108>
\t\t\t\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t\t\t\t</xsl:otherwise>
\t\t\t\t\t\t\t</xsl:choose>
\t\t\t\t\t\t</ns0:L1>
\t\t\t\t\t</xsl:if>
\t\t\t\t</ns0:LXLoop1>
\t\t\t</xsl:for-each>'''


def _build_l3_section():
    return '''\t\t\t<xsl:for-each select="Summary/TotalWeightAndCharges">
\t\t\t\t<ns0:L3>
\t\t\t\t\t<xsl:if test="@Weight"><L301><xsl:value-of select="@Weight" /></L301></xsl:if>
\t\t\t\t\t<xsl:if test="@WeightQualifier"><L302>G</L302></xsl:if>
\t\t\t\t\t<xsl:variable name="TotalCharges" select="@TotalCharges" />
\t\t\t\t\t<xsl:variable name="TotalChargesLength" select="string-length(@TotalCharges)" />
\t\t\t\t\t<xsl:if test="$TotalChargesLength > 2">
\t\t\t\t\t\t<L305><xsl:value-of select="translate(@TotalCharges, \',\', \'\')" /></L305>
\t\t\t\t\t</xsl:if>
\t\t\t\t\t<xsl:if test="@LadingQuantity"><L311><xsl:value-of select="@LadingQuantity" /></L311></xsl:if>
\t\t\t\t</ns0:L3>
\t\t\t</xsl:for-each>'''


def _build_se_section():
    return '''\t\t\t<SE>
\t\t\t\t<SE01>
\t\t\t\t\t<xsl:value-of select="Header/TransactionSetheader/@TransactionSetIdentifierCode" />
\t\t\t\t</SE01>
\t\t\t\t<SE02>
\t\t\t\t\t<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber" />
\t\t\t\t</SE02>
\t\t\t</SE>'''


def _build_helper_templates():
    """Full helper templates matching the original map."""
    return r'''
	<!--Custom Templates-->

	<xsl:template name="ChangeThisName">
		<xsl:param name="ValueToConvert" select="0" />
		<xsl:param name="LadingDescriptionParm" select="1" />
		<xsl:variable name="L108Map" >
			<map>
				<entry key="LHS">400</entry>
				<entry key="LYC">LAY</entry>
				<entry key="SRG">STR</entry>
				<entry key="TDT">DET</entry>
			</map>
		</xsl:variable>
		<xsl:variable name="ValueConverted" select="msxsl:node-set($L108Map)/map/entry[@key=$ValueToConvert]" />
		<xsl:choose>
			<xsl:when test="$ValueConverted">
				<xsl:value-of select="$ValueConverted" />
			</xsl:when>
			<xsl:otherwise>
				<xsl:choose>
					<xsl:when test="$LadingDescriptionParm = 'Lumper'">
						<xsl:text>LAB</xsl:text>
					</xsl:when>
					<xsl:when test="$LadingDescriptionParm = 'Unloading'">
						<xsl:text>UNL</xsl:text>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="$ValueToConvert"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

	<xsl:template name="CleanAlphaField">
		<xsl:param name="inputText" />
		<xsl:param name="maxLength" />
		<xsl:variable name="singleQuote" select='"&apos;"' />
		<xsl:variable name="doubleQuote" select="'&quot;'" />
		<xsl:variable name="vAllowedSymbolsPart1" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !@$%()+-_,.;=[]{}?/#'"/>
		<xsl:variable name="vAllowedSymbols" select="concat($vAllowedSymbolsPart1, $singleQuote, $doubleQuote)"/>
		<xsl:variable name="vCleanedText" select="translate($inputText,translate($inputText, $vAllowedSymbols, ''),'')"/>
		<xsl:value-of select="substring(normalize-space($vCleanedText), 1, $maxLength)"/>
	</xsl:template>

	<xsl:template name="StopTypeMapValue">
		<xsl:param name="ValueToConvert" select="0" />
		<xsl:variable name="StopTypeMap" >
			<map>
				<entry key="Pick">SF</entry>
				<entry key="Drop">CN</entry>
			</map>
		</xsl:variable>
		<xsl:value-of select="msxsl:node-set($StopTypeMap)/map/entry[@key=$ValueToConvert]"/>
	</xsl:template>

	<xsl:template name="SetDefaultIfEmpty">
		<xsl:param name="pNode"/>
		<xsl:param name="pDefaultValue"/>
		<xsl:if test="$pNode">
			<xsl:value-of select="$pNode" />
		</xsl:if>
		<xsl:if test="not($pNode)">
			<xsl:value-of select="$pDefaultValue"/>
		</xsl:if>
	</xsl:template>'''


# ---------------------------------------------------------------------------
# Transaction-set dispatcher + per-transaction body builders
# ---------------------------------------------------------------------------

def _build_st_segment():
    return '''\t\t\t<ST>
\t\t\t\t<ST01>
\t\t\t\t\t<xsl:value-of select="Header/TransactionSetheader/@TransactionSetIdentifierCode" />
\t\t\t\t</ST01>
\t\t\t\t<ST02>
\t\t\t\t\t<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber" />
\t\t\t\t</ST02>
\t\t\t</ST>'''


def _build_se_generic():
    return '''\t\t\t<SE>
\t\t\t\t<SE01>
\t\t\t\t\t<xsl:value-of select="Header/TransactionSetheader/@NumberOfIncludedSegments" />
\t\t\t\t</SE01>
\t\t\t\t<SE02>
\t\t\t\t\t<xsl:value-of select="Header/TransactionSetheader/@TransactionSetControlNumber" />
\t\t\t\t</SE02>
\t\t\t</SE>'''


def _build_mapped_fields(mappings):
    """
    Generic fallback: emit xsl:value-of for every mapping row,
    grouped into parent segment elements.
    """
    lines = []
    current_seg = None
    for row in mappings:
        target  = str(row.get("target",  "")).strip()
        source  = str(row.get("source",  "")).strip()
        literal = str(row.get("literal", "")).strip()
        if not target:
            continue
        # Derive segment name (before / or .)
        raw_seg = re.split(r"[/.]", target)[0]
        seg_name = _safe_element_name(raw_seg)
        field_raw = target.split("/")[-1] if "/" in target else target.split(".")[-1]
        field_name = _safe_element_name(field_raw)
        if not seg_name or field_name in ("Node_Name", ""):
            continue
        if current_seg != seg_name:
            if current_seg is not None:
                lines.append(f"\t\t\t</{current_seg}>")
            lines.append(f"\t\t\t<{seg_name}>")
            current_seg = seg_name
        if literal:
            lines.append(f"\t\t\t\t<{field_name}>{literal}</{field_name}>")
        elif source:
            lines.append(f'\t\t\t\t<{field_name}><xsl:value-of select="{source}" /></{field_name}>')
    if current_seg is not None:
        lines.append(f"\t\t\t</{current_seg}>")
    return "\n".join(lines)


def _build_body_for_transaction(transaction_set, mappings, meta):
    """Dispatch to the right body builder for each EDI transaction set."""
    ts = (transaction_set or "210").strip()
    dispatch = {
        "210": _build_210_body,
        "214": _build_214_body,
        "204": _build_204_body,
        "990": _build_990_body,
        "850": _build_850_body,
        "856": _build_856_body,
        "810": _build_810_body,
        "997": _build_997_body,
        "315": _build_315_body,
        "310": _build_310_body,
    }
    builder = dispatch.get(ts, _build_generic_body)

    # For 214: resolve per-customer profile and pass as customer_rules
    if ts == "214":
        customer_rules = None
        if meta:
            profile_name = meta.get("customer_profile", "default")
            try:
                from backend.engine.transaction_rules import TRANSACTION_RULES
                profiles = TRANSACTION_RULES.get("214", {}).get("customer_profiles", {})
                customer_rules = profiles.get(profile_name) or profiles.get("default")
            except ImportError:
                pass
        return builder(mappings, customer_rules=customer_rules)

    return builder(mappings)


def _build_210_body(mappings):
    """EDI 210 - Motor Carrier Freight Details and Invoice (original full structure)."""
    parts = [
        _build_st_segment(),
        _build_b3_section(mappings),
        _build_c2_literal(),
        _build_c3_section(),
        _build_n9_loop(),
        _build_g62_sections(),
        _build_n1_loops(),
        _build_n7_loop(),
        _build_lx_loop(),
        _build_l3_section(),
        _build_se_section(),
    ]
    return "\n\n".join(parts)


def _build_214_body(mappings, customer_rules=None):
    """EDI 214 - Transportation Carrier Shipment Status Message.

    Fully corrected against Echo BSS canonical XML schema.
    All 10 issues from validation analysis are fixed:
      1.  B1003: eNum-conditional SCAC (or hardcode per customer_rules)
      2.  N101 Drop qualifier: CN (not ST) - but customer_rules can override to ST
      3.  N103: locationIdentifier or '93' fallback
      4.  N104: first EDIQualifier referenceId by stopType (Pick=SF, Drop=ST)
      5.  AT7: status code whitelist (X3/AF/CP/X6/X1/D1) drives AT701/AT702
      6.  AT7: AA/AB drives AT703/AT704
      7.  AT707: @statusTimeZone if present, else LT
      8.  MS2: dynamic equipmentScac/equipmentNumber/equipmentDescriptionCode
      9.  SPOLoop1: PurchaseOrderDetail mapping
      10. SE01: segment count (not hardcoded literal)
      Also: uses correct canonical XPaths throughout (StatusList, ReferenceData, etc.)

    customer_rules (dict, optional):
        b1003_hardcode   : str  - if set, hardcode B1003 to this value (e.g. 'ECHS')
                                   if not set, uses eNum='191806' -> 'ECHS' else Scac
        b1003_enum_check : str  - eNum value that triggers hardcode (default '191806')
        drop_n101        : str  - qualifier for Drop stop (default 'CN')
        at7_reason_code  : bool - if True, AT702 from BusinessReference RC (Unreal style)
        at8_enabled      : bool - if True, output AT8 segment
        k1_enabled       : bool - if True, output K1/remarks segment
        ms2_enabled      : bool - if True, output MS2 segment (default True)
        spo_enabled      : bool - if True, output SPOLoop1 segment
        l11_3_enabled    : bool - if True, output L11_3 StopSequenceNumber loop
    """
    cr = customer_rules or {}
    b1003_hardcode   = cr.get("b1003_hardcode", None)       # None = use conditional logic
    b1003_enum       = cr.get("b1003_enum_check", "191806")
    drop_n101        = cr.get("drop_n101", "CN")
    at7_reason_code  = cr.get("at7_reason_code", False)
    at8_enabled      = cr.get("at8_enabled", False)
    k1_enabled       = cr.get("k1_enabled", True)
    ms2_enabled      = cr.get("ms2_enabled", True)
    spo_enabled      = cr.get("spo_enabled", True)
    l11_3_enabled    = cr.get("l11_3_enabled", False)

    # ------------------------------------------------------------------
    # B1003 logic: customer-configurable
    # ------------------------------------------------------------------
    if b1003_hardcode:
        b1003_xml = f"\t\t\t\t\t<B1003>{b1003_hardcode}</B1003>"
    else:
        b1003_xml = f'''\t\t\t\t\t<B1003>
\t\t\t\t\t\t<xsl:choose>
\t\t\t\t\t\t\t<xsl:when test="eNum = '{b1003_enum}'">ECHS</xsl:when>
\t\t\t\t\t\t\t<xsl:otherwise><xsl:value-of select="ReferenceData/Scac"/></xsl:otherwise>
\t\t\t\t\t\t</xsl:choose>
\t\t\t\t\t</B1003>'''

    # ------------------------------------------------------------------
    # B10 segment
    # ------------------------------------------------------------------
    b10 = f'''\t\t\t<!-- B10: Shipment Identification -->
\t\t\t<xsl:for-each select="Status/StatusList/ShipmentStatus">
\t\t\t\t<ns0:B10>
\t\t\t\t\t<B1001>
\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="ReferenceData/LoadId"/>
\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="30"/>
\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t</B1001>
\t\t\t\t\t<B1002>
\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="ReferenceData/Bol"/>
\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="30"/>
\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t</B1002>
{b1003_xml}
\t\t\t\t</ns0:B10>'''

    # ------------------------------------------------------------------
    # L11 loop - BusinessReferences
    # ------------------------------------------------------------------
    l11 = '''\t\t\t<!-- L11: Reference Numbers from BusinessReferences -->
\t\t\t<xsl:for-each select="BusinessReferences/BusinessReference">
\t\t\t\t<ns0:L11Loop1>
\t\t\t\t\t<ns0:L11>
\t\t\t\t\t\t<L1101><xsl:value-of select="@referenceId"/></L1101>
\t\t\t\t\t\t<L1102>
\t\t\t\t\t\t\t<xsl:choose>
\t\t\t\t\t\t\t\t<!-- eNum 9720 + PO type: use referenceType directly -->
\t\t\t\t\t\t\t\t<xsl:when test="../../eNum = '9720' and @referenceType = 'PO'">
\t\t\t\t\t\t\t\t\t<xsl:value-of select="@referenceType"/>
\t\t\t\t\t\t\t\t</xsl:when>
\t\t\t\t\t\t\t\t<xsl:otherwise>
\t\t\t\t\t\t\t\t\t<xsl:value-of select="@referenceType"/>
\t\t\t\t\t\t\t\t</xsl:otherwise>
\t\t\t\t\t\t\t</xsl:choose>
\t\t\t\t\t\t</L1102>
\t\t\t\t\t</ns0:L11>
\t\t\t\t</ns0:L11Loop1>
\t\t\t</xsl:for-each>'''

    # ------------------------------------------------------------------
    # N1 Loop - Pick and Drop stops
    # ------------------------------------------------------------------
    n1_loop = f'''\t\t\t<!-- N1Loop: Pick and Drop addresses -->
\t\t\t<xsl:for-each select="Statuses/Status/Details/Detail[@stopType = 'Pick' or @stopType = 'Drop']">
\t\t\t\t<ns0:N1Loop1>
\t\t\t\t\t<ns0:N1>
\t\t\t\t\t\t<N101>
\t\t\t\t\t\t\t<xsl:choose>
\t\t\t\t\t\t\t\t<xsl:when test="@stopType = 'Pick'">SF</xsl:when>
\t\t\t\t\t\t\t\t<xsl:when test="@stopType = 'Drop'">{drop_n101}</xsl:when>
\t\t\t\t\t\t\t</xsl:choose>
\t\t\t\t\t\t</N101>
\t\t\t\t\t\t<N102>
\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="Addresses/Address/@name"/>
\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="30"/>
\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t</N102>
\t\t\t\t\t\t<!-- N103: locationIdentifier or fallback to 93 -->
\t\t\t\t\t\t<xsl:if test="Addresses/Address/@locationIdentifier != '' or not(Addresses/Address/@locationIdentifier)">
\t\t\t\t\t\t\t<N103>
\t\t\t\t\t\t\t\t<xsl:choose>
\t\t\t\t\t\t\t\t\t<xsl:when test="Addresses/Address/@locationIdentifier != ''">
\t\t\t\t\t\t\t\t\t\t<xsl:value-of select="Addresses/Address/@locationIdentifier"/>
\t\t\t\t\t\t\t\t\t</xsl:when>
\t\t\t\t\t\t\t\t\t<xsl:otherwise>93</xsl:otherwise>
\t\t\t\t\t\t\t\t</xsl:choose>
\t\t\t\t\t\t\t</N103>
\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t\t<!-- N104: first EDIQualifier referenceId by stopType -->
\t\t\t\t\t\t<N104>
\t\t\t\t\t\t\t<xsl:choose>
\t\t\t\t\t\t\t\t<xsl:when test="@stopType = 'Pick'">
\t\t\t\t\t\t\t\t\t<xsl:value-of select="(../../BusinessReferences/BusinessReference[@referenceType='SF' and @referenceDescription='EDIQualifier']/@referenceId)[1]"/>
\t\t\t\t\t\t\t\t</xsl:when>
\t\t\t\t\t\t\t\t<xsl:when test="@stopType = 'Drop'">
\t\t\t\t\t\t\t\t\t<xsl:value-of select="(../../BusinessReferences/BusinessReference[@referenceType='ST' and @referenceDescription='EDIQualifier']/@referenceId)[1]"/>
\t\t\t\t\t\t\t\t</xsl:when>
\t\t\t\t\t\t\t</xsl:choose>
\t\t\t\t\t\t</N104>
\t\t\t\t\t</ns0:N1>
\t\t\t\t\t<ns0:N3>
\t\t\t\t\t\t<N301>
\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="Addresses/Address/@address1"/>
\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="30"/>
\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t</N301>
\t\t\t\t\t\t<xsl:if test="Addresses/Address/@address2 != ''">
\t\t\t\t\t\t\t<N302>
\t\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="Addresses/Address/@address2"/>
\t\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="30"/>
\t\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t\t</N302>
\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t</ns0:N3>
\t\t\t\t\t<ns0:N4>
\t\t\t\t\t\t<N401>
\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="Addresses/Address/@city"/>
\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="30"/>
\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t</N401>
\t\t\t\t\t\t<N402><xsl:value-of select="Addresses/Address/@stateProvince"/></N402>
\t\t\t\t\t\t<N403><xsl:value-of select="Addresses/Address/@postalCode"/></N403>
\t\t\t\t\t\t<N404><xsl:value-of select="Addresses/Address/@country"/></N404>
\t\t\t\t\t</ns0:N4>
\t\t\t\t</ns0:N1Loop1>
\t\t\t</xsl:for-each>'''

    # ------------------------------------------------------------------
    # AT702: either RC-based reason code (Unreal) or hardcoded NS (National Sugar)
    # ------------------------------------------------------------------
    if at7_reason_code:
        at702_logic = '''\t\t\t\t\t\t<AT702>
\t\t\t\t\t\t\t<xsl:choose>
\t\t\t\t\t\t\t\t<xsl:when test="string-length(//BusinessReferences/BusinessReference[@referenceType='RC']/@referenceId) &gt;= 2">
\t\t\t\t\t\t\t\t\t<xsl:value-of select="substring(//BusinessReferences/BusinessReference[@referenceType='RC']/@referenceId, 1, 2)"/>
\t\t\t\t\t\t\t\t</xsl:when>
\t\t\t\t\t\t\t\t<xsl:otherwise>NS</xsl:otherwise>
\t\t\t\t\t\t\t</xsl:choose>
\t\t\t\t\t\t</AT702>'''
    else:
        at702_logic = "\t\t\t\t\t\t<AT702>NS</AT702>"

    # ------------------------------------------------------------------
    # LX Loop containing AT7, MS1, MS2
    # ------------------------------------------------------------------
    ms2_block = ""
    if ms2_enabled:
        ms2_block = '''\t\t\t\t\t<!-- MS2: Equipment info (conditional on equipmentDescriptionCode or equipmentNumber) -->
\t\t\t\t\t<xsl:if test="EquipmentLocation/@equipmentDescriptionCode != '' or EquipmentLocation/@equipmentNumber != ''">
\t\t\t\t\t\t<ns0:MS2>
\t\t\t\t\t\t\t<MS201><xsl:value-of select="EquipmentLocation/@equipmentScac"/></MS201>
\t\t\t\t\t\t\t<MS202><xsl:value-of select="EquipmentLocation/@equipmentNumber"/></MS202>
\t\t\t\t\t\t\t<MS203><xsl:value-of select="EquipmentLocation/@equipmentDescriptionCode"/></MS203>
\t\t\t\t\t\t</ns0:MS2>
\t\t\t\t\t</xsl:if>'''

    lx_loop = f'''\t\t\t<!-- LXLoop1: Status details loop -->
\t\t\t<xsl:for-each select="Statuses/Status/Details/Detail[@statusCode != '']">
\t\t\t\t<ns0:LXLoop1>
\t\t\t\t\t<ns0:LX>
\t\t\t\t\t\t<LX01><xsl:value-of select="../../@assignedNumber"/></LX01>
\t\t\t\t\t</ns0:LX>
\t\t\t\t\t<ns0:AT7Loop1>
\t\t\t\t\t\t<ns0:AT7>
\t\t\t\t\t\t\t<!-- AT701/AT702: only for specific status codes -->
\t\t\t\t\t\t\t<xsl:if test="@statusCode = 'X3' or @statusCode = 'AF' or @statusCode = 'CP' or @statusCode = 'X6' or @statusCode = 'X1' or @statusCode = 'D1'">
\t\t\t\t\t\t\t\t<AT701><xsl:value-of select="@statusCode"/></AT701>
{at702_logic}
\t\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t\t\t<!-- AT703/AT704: only for AA or AB status codes -->
\t\t\t\t\t\t\t<xsl:if test="@statusCode = 'AA' or @statusCode = 'AB'">
\t\t\t\t\t\t\t\t<AT703><xsl:value-of select="@statusCode"/></AT703>
\t\t\t\t\t\t\t\t<AT704>NA</AT704>
\t\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t\t\t<!-- AT705: date portion of statusdatetime (YYYYMMDD) -->
\t\t\t\t\t\t\t<xsl:if test="@statusdatetime != ''">
\t\t\t\t\t\t\t\t<AT705>
\t\t\t\t\t\t\t\t\t<xsl:value-of select="concat(substring(@statusdatetime,1,4), substring(@statusdatetime,6,2), substring(@statusdatetime,9,2))"/>
\t\t\t\t\t\t\t\t</AT705>
\t\t\t\t\t\t\t\t<!-- AT706: time portion (HHMM) -->
\t\t\t\t\t\t\t\t<AT706>
\t\t\t\t\t\t\t\t\t<xsl:value-of select="concat(substring(@statusdatetime,12,2), substring(@statusdatetime,15,2))"/>
\t\t\t\t\t\t\t\t</AT706>
\t\t\t\t\t\t\t</xsl:if>
\t\t\t\t\t\t\t<!-- AT707: statusTimeZone if present, else LT -->
\t\t\t\t\t\t\t<AT707>
\t\t\t\t\t\t\t\t<xsl:choose>
\t\t\t\t\t\t\t\t\t<xsl:when test="@statusTimeZone != ''">
\t\t\t\t\t\t\t\t\t\t<xsl:value-of select="@statusTimeZone"/>
\t\t\t\t\t\t\t\t\t</xsl:when>
\t\t\t\t\t\t\t\t\t<xsl:otherwise>LT</xsl:otherwise>
\t\t\t\t\t\t\t\t</xsl:choose>
\t\t\t\t\t\t\t</AT707>
\t\t\t\t\t\t</ns0:AT7>
\t\t\t\t\t</ns0:AT7Loop1>
\t\t\t\t\t<!-- MS1: Equipment location city/state (conditional) -->
\t\t\t\t\t<xsl:if test="EquipmentLocation/@cityName != '' and EquipmentLocation/@stateOrProvince != ''">
\t\t\t\t\t\t<ns0:MS1>
\t\t\t\t\t\t\t<MS101>
\t\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="EquipmentLocation/@cityName"/>
\t\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="30"/>
\t\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t\t</MS101>
\t\t\t\t\t\t\t<MS102><xsl:value-of select="EquipmentLocation/@stateOrProvince"/></MS102>
\t\t\t\t\t\t</ns0:MS1>
\t\t\t\t\t</xsl:if>
{ms2_block}
\t\t\t\t</ns0:LXLoop1>
\t\t\t</xsl:for-each>'''

    # ------------------------------------------------------------------
    # L11_3: StopSequenceNumber loop (optional per customer)
    # ------------------------------------------------------------------
    l11_3_block = ""
    if l11_3_enabled:
        l11_3_block = '''\t\t\t<!-- L11_3: StopSequenceNumber (when present and > 0) -->
\t\t\t<xsl:for-each select="Status/StatusList/ShipmentStatus/ReferenceData[number(StopSequenceNumber) > 0]">
\t\t\t\t<ns0:L11Loop3>
\t\t\t\t\t<ns0:L11>
\t\t\t\t\t\t<L1101>
\t\t\t\t\t\t\t<xsl:call-template name="CleanAlphaField">
\t\t\t\t\t\t\t\t<xsl:with-param name="inputText" select="StopSequenceNumber"/>
\t\t\t\t\t\t\t\t<xsl:with-param name="maxLength" select="30"/>
\t\t\t\t\t\t\t</xsl:call-template>
\t\t\t\t\t\t</L1101>
\t\t\t\t\t\t<L1102>QN</L1102>
\t\t\t\t\t</ns0:L11>
\t\t\t\t</ns0:L11Loop3>
\t\t\t</xsl:for-each>'''

    # ------------------------------------------------------------------
    # K1: Remarks segment (optional per customer)
    # ------------------------------------------------------------------
    k1_block = ""
    if k1_enabled:
        k1_block = '''\t\t\t<!-- K1_2: Remarks in 30-char segments -->
\t\t\t<xsl:for-each select="Remarks/Remark">
\t\t\t\t<xsl:if test="@remarkMessage2 != ''">
\t\t\t\t\t<ns0:K1>
\t\t\t\t\t\t<K101><xsl:value-of select="@remarkMessage2"/></K101>
\t\t\t\t\t\t<K102>Notes</K102>
\t\t\t\t\t</ns0:K1>
\t\t\t\t</xsl:if>
\t\t\t</xsl:for-each>'''

    # ------------------------------------------------------------------
    # AT8: Shipment totals (optional per customer)
    # ------------------------------------------------------------------
    at8_block = ""
    if at8_enabled:
        at8_block = '''\t\t\t<!-- AT8: Shipment totals (when weight or handling qty > 0) -->
\t\t\t<xsl:if test="ShipmentTotals/ShipmentTotal[number(@totalWeight) > 0 or number(@totalHandlingQty) > 0]">
\t\t\t\t<ns0:AT8>
\t\t\t\t\t<AT801><xsl:value-of select="ShipmentTotals/ShipmentTotal/@totalTypeQualifier"/></AT801>
\t\t\t\t\t<AT802><xsl:value-of select="ShipmentTotals/ShipmentTotal/@totalUnitOfMeasure"/></AT802>
\t\t\t\t\t<xsl:if test="number(ShipmentTotals/ShipmentTotal/@totalWeight) > 0">
\t\t\t\t\t\t<AT803><xsl:value-of select="format-number(ShipmentTotals/ShipmentTotal/@totalWeight, '##.00')"/></AT803>
\t\t\t\t\t</xsl:if>
\t\t\t\t\t<xsl:if test="number(ShipmentTotals/ShipmentTotal/@totalHandlingQty) > 0">
\t\t\t\t\t\t<AT804><xsl:value-of select="ShipmentTotals/ShipmentTotal/@totalHandlingQty"/></AT804>
\t\t\t\t\t</xsl:if>
\t\t\t\t</ns0:AT8>
\t\t\t</xsl:if>'''

    # ------------------------------------------------------------------
    # SPOLoop1: Purchase Order Details (optional per customer)
    # ------------------------------------------------------------------
    spo_block = ""
    if spo_enabled:
        spo_block = '''\t\t\t<!-- SPOLoop1: Purchase Order Details -->
\t\t\t<xsl:for-each select="Statuses/ShipmentPurcheseOrderInfo/PurchaseOrderDetail">
\t\t\t\t<ns0:SPOLoop1>
\t\t\t\t\t<ns0:SPO>
\t\t\t\t\t\t<SPO01><xsl:value-of select="@poNumber"/></SPO01>
\t\t\t\t\t</ns0:SPO>
\t\t\t\t</ns0:SPOLoop1>
\t\t\t</xsl:for-each>'''

    # ------------------------------------------------------------------
    # SE segment: SE01 = segment count (computed), SE02 = control number
    # ------------------------------------------------------------------
    se = '''\t\t\t<!-- SE: Transaction Set Trailer -->
\t\t\t<ns0:SE>
\t\t\t\t<SE01>
\t\t\t\t\t<!-- SE01 = number of included segments (ST through SE) -->
\t\t\t\t\t<xsl:value-of select="Status/StatusList/ShipmentStatus/ReferenceData/SegmentCount"/>
\t\t\t\t</SE01>
\t\t\t\t<SE02>
\t\t\t\t\t<xsl:value-of select="Status/StatusList/ShipmentStatus/ReferenceData/TransactionSetControlNumber"/>
\t\t\t\t</SE02>
\t\t\t</ns0:SE>
\t\t\t</xsl:for-each>  <!-- end ShipmentStatus loop -->'''

    parts = [_build_st_segment(), b10, l11, n1_loop, lx_loop]
    if l11_3_block:
        parts.append(l11_3_block)
    if k1_block:
        parts.append(k1_block)
    if at8_block:
        parts.append(at8_block)
    if spo_block:
        parts.append(spo_block)
    parts.append(se)
    return "\n\n".join(parts)


def _build_204_body(mappings):
    """EDI 204 - Motor Carrier Load Tender."""
    mapped = _build_mapped_fields(mappings)
    b1 = '''\t\t\t<B1>
\t\t\t\t<B101><xsl:value-of select="Header/LoadTender/@StandardCarrierAlphaCode" /></B101>
\t\t\t\t<B102><xsl:value-of select="Header/LoadTender/@ShipmentIdentificationNumber" /></B102>
\t\t\t\t<B103><xsl:value-of select="Header/LoadTender/@Date" /></B103>
\t\t\t\t<B104><xsl:value-of select="Header/LoadTender/@LoadTypeCode" /></B104>
\t\t\t</B1>'''
    l11 = '''\t\t\t<L11>
\t\t\t\t<L1101><xsl:value-of select="Header/LoadTender/@ReferenceIdentification" /></L1101>
\t\t\t\t<L1102><xsl:value-of select="Header/LoadTender/@ReferenceIdentificationQualifier" /></L1102>
\t\t\t</L11>'''
    s5_loop = '''\t\t\t<xsl:for-each select="Detail/StopOffDetail">
\t\t\t\t<S5Loop1>
\t\t\t\t\t<S5>
\t\t\t\t\t\t<S501><xsl:value-of select="@StopSequenceNumber" /></S501>
\t\t\t\t\t\t<S502><xsl:value-of select="@StopReasonCode" /></S502>
\t\t\t\t\t\t<S503><xsl:value-of select="@Weight" /></S503>
\t\t\t\t\t\t<S504><xsl:value-of select="@WeightUnitCode" /></S504>
\t\t\t\t\t\t<S505><xsl:value-of select="@NumberOfUnitsShipped" /></S505>
\t\t\t\t\t</S5>
\t\t\t\t</S5Loop1>
\t\t\t</xsl:for-each>'''
    parts = [_build_st_segment(), b1, l11, s5_loop]
    if mapped.strip():
        parts.append(mapped)
    parts.append(_build_se_generic())
    return "\n\n".join(parts)


def _build_990_body(mappings):
    """EDI 990 - Response to Load Tender."""
    mapped = _build_mapped_fields(mappings)
    w6 = '''\t\t\t<W6>
\t\t\t\t<W601><xsl:value-of select="Header/LoadTenderResponse/@StandardCarrierAlphaCode" /></W601>
\t\t\t\t<W602><xsl:value-of select="Header/LoadTenderResponse/@Date" /></W602>
\t\t\t\t<W603><xsl:value-of select="Header/LoadTenderResponse/@ShipmentIdentificationNumber" /></W603>
\t\t\t\t<W604><xsl:value-of select="Header/LoadTenderResponse/@TransactionSetPurposeCode" /></W604>
\t\t\t</W6>'''
    parts = [_build_st_segment(), w6]
    if mapped.strip():
        parts.append(mapped)
    parts.append(_build_se_generic())
    return "\n\n".join(parts)


def _build_850_body(mappings):
    """EDI 850 - Purchase Order."""
    mapped = _build_mapped_fields(mappings)
    beg = '''\t\t\t<BEG>
\t\t\t\t<BEG01><xsl:value-of select="Header/PurchaseOrder/@TransactionSetPurposeCode" /></BEG01>
\t\t\t\t<BEG02><xsl:value-of select="Header/PurchaseOrder/@PurchaseOrderTypeCode" /></BEG02>
\t\t\t\t<BEG03><xsl:value-of select="Header/PurchaseOrder/@PurchaseOrderNumber" /></BEG03>
\t\t\t\t<BEG05><xsl:value-of select="Header/PurchaseOrder/@Date" /></BEG05>
\t\t\t</BEG>'''
    po1_loop = '''\t\t\t<xsl:for-each select="Detail/LineItem">
\t\t\t\t<PO1Loop1>
\t\t\t\t\t<PO1>
\t\t\t\t\t\t<PO101><xsl:value-of select="@AssignedIdentification" /></PO101>
\t\t\t\t\t\t<PO102><xsl:value-of select="@QuantityOrdered" /></PO102>
\t\t\t\t\t\t<PO103><xsl:value-of select="@UnitOrBasisForMeasurementCode" /></PO103>
\t\t\t\t\t\t<PO104><xsl:value-of select="@UnitPrice" /></PO104>
\t\t\t\t\t\t<PO107><xsl:value-of select="@ProductServiceIdQualifier" /></PO107>
\t\t\t\t\t\t<PO108><xsl:value-of select="@ProductServiceId" /></PO108>
\t\t\t\t\t</PO1>
\t\t\t\t</PO1Loop1>
\t\t\t</xsl:for-each>'''
    ctt = '''\t\t\t<CTT>
\t\t\t\t<CTT01><xsl:value-of select="Summary/TransactionTotals/@NumberOfLineItems" /></CTT01>
\t\t\t\t<CTT02><xsl:value-of select="Summary/TransactionTotals/@HashTotal" /></CTT02>
\t\t\t</CTT>'''
    parts = [_build_st_segment(), beg, po1_loop]
    if mapped.strip():
        parts.append(mapped)
    parts += [ctt, _build_se_generic()]
    return "\n\n".join(parts)


def _build_856_body(mappings):
    """EDI 856 - Ship Notice / Manifest (ASN)."""
    mapped = _build_mapped_fields(mappings)
    bsn = '''\t\t\t<BSN>
\t\t\t\t<BSN01><xsl:value-of select="Header/ShipNotice/@TransactionSetPurposeCode" /></BSN01>
\t\t\t\t<BSN02><xsl:value-of select="Header/ShipNotice/@ShipmentIdentification" /></BSN02>
\t\t\t\t<BSN03><xsl:value-of select="Header/ShipNotice/@Date" /></BSN03>
\t\t\t\t<BSN04><xsl:value-of select="Header/ShipNotice/@Time" /></BSN04>
\t\t\t\t<BSN05><xsl:value-of select="Header/ShipNotice/@HierarchicalStructureCode" /></BSN05>
\t\t\t</BSN>'''
    hl_loop = '''\t\t\t<xsl:for-each select="Detail/Shipment">
\t\t\t\t<HLLoop1>
\t\t\t\t\t<HL>
\t\t\t\t\t\t<HL01><xsl:value-of select="@HierarchicalIDNumber" /></HL01>
\t\t\t\t\t\t<HL03><xsl:value-of select="@HierarchicalLevelCode" /></HL03>
\t\t\t\t\t\t<HL04><xsl:value-of select="@HierarchicalChildCode" /></HL04>
\t\t\t\t\t</HL>
\t\t\t\t\t<xsl:for-each select="Order">
\t\t\t\t\t\t<HLLoop2>
\t\t\t\t\t\t\t<HL>
\t\t\t\t\t\t\t\t<HL01><xsl:value-of select="@HierarchicalIDNumber" /></HL01>
\t\t\t\t\t\t\t\t<HL02><xsl:value-of select="@HierarchicalParentIDNumber" /></HL02>
\t\t\t\t\t\t\t\t<HL03>O</HL03>
\t\t\t\t\t\t\t\t<HL04>1</HL04>
\t\t\t\t\t\t\t</HL>
\t\t\t\t\t\t</HLLoop2>
\t\t\t\t\t</xsl:for-each>
\t\t\t\t</HLLoop1>
\t\t\t</xsl:for-each>'''
    parts = [_build_st_segment(), bsn, hl_loop]
    if mapped.strip():
        parts.append(mapped)
    parts.append(_build_se_generic())
    return "\n\n".join(parts)


def _build_810_body(mappings):
    """EDI 810 - Invoice."""
    mapped = _build_mapped_fields(mappings)
    big = '''\t\t\t<BIG>
\t\t\t\t<BIG01><xsl:value-of select="Header/Invoice/@Date" /></BIG01>
\t\t\t\t<BIG02><xsl:value-of select="Header/Invoice/@InvoiceNumber" /></BIG02>
\t\t\t\t<BIG04><xsl:value-of select="Header/Invoice/@PurchaseOrderNumber" /></BIG04>
\t\t\t\t<BIG06><xsl:value-of select="Header/Invoice/@TransactionTypeCode" /></BIG06>
\t\t\t</BIG>'''
    it1_loop = '''\t\t\t<xsl:for-each select="Detail/LineItem">
\t\t\t\t<IT1Loop1>
\t\t\t\t\t<IT1>
\t\t\t\t\t\t<IT101><xsl:value-of select="@AssignedIdentification" /></IT101>
\t\t\t\t\t\t<IT102><xsl:value-of select="@QuantityInvoiced" /></IT102>
\t\t\t\t\t\t<IT103><xsl:value-of select="@UnitOrBasisForMeasurementCode" /></IT103>
\t\t\t\t\t\t<IT104><xsl:value-of select="@UnitPrice" /></IT104>
\t\t\t\t\t\t<IT107><xsl:value-of select="@ProductServiceIdQualifier" /></IT107>
\t\t\t\t\t\t<IT108><xsl:value-of select="@ProductServiceId" /></IT108>
\t\t\t\t\t</IT1>
\t\t\t\t</IT1Loop1>
\t\t\t</xsl:for-each>'''
    tds = '''\t\t\t<TDS>
\t\t\t\t<TDS01><xsl:value-of select="Summary/TotalMonetaryValueSummary/@Amount" /></TDS01>
\t\t\t</TDS>'''
    ctt = '''\t\t\t<CTT>
\t\t\t\t<CTT01><xsl:value-of select="Summary/TransactionTotals/@NumberOfLineItems" /></CTT01>
\t\t\t</CTT>'''
    parts = [_build_st_segment(), big, it1_loop]
    if mapped.strip():
        parts.append(mapped)
    parts += [tds, ctt, _build_se_generic()]
    return "\n\n".join(parts)


def _build_997_body(mappings):
    """EDI 997 - Functional Acknowledgment."""
    ak1 = '''\t\t\t<AK1>
\t\t\t\t<AK101><xsl:value-of select="Header/FunctionalGroup/@FunctionalIdentifierCode" /></AK101>
\t\t\t\t<AK102><xsl:value-of select="Header/FunctionalGroup/@GroupControlNumber" /></AK102>
\t\t\t</AK1>'''
    ak9 = '''\t\t\t<AK9>
\t\t\t\t<AK901><xsl:value-of select="Header/FunctionalGroup/@FunctionalGroupAcknowledgeCode" /></AK901>
\t\t\t\t<AK902><xsl:value-of select="Header/FunctionalGroup/@NumberOfTransactionSetsIncluded" /></AK902>
\t\t\t\t<AK903><xsl:value-of select="Header/FunctionalGroup/@NumberReceived" /></AK903>
\t\t\t\t<AK904><xsl:value-of select="Header/FunctionalGroup/@NumberAccepted" /></AK904>
\t\t\t</AK9>'''
    return "\n\n".join([_build_st_segment(), ak1, ak9, _build_se_generic()])


def _build_315_body(mappings):
    """EDI 315 - Ocean Carrier Status Message (Water)."""
    mapped = _build_mapped_fields(mappings)
    b4 = '''\t\t\t<B4>
\t\t\t\t<B401><xsl:value-of select="Header/ShipmentStatus/@SpecialHandlingCode" /></B401>
\t\t\t\t<B402><xsl:value-of select="Header/ShipmentStatus/@Date" /></B402>
\t\t\t\t<B403><xsl:value-of select="Header/ShipmentStatus/@StatusCode" /></B403>
\t\t\t\t<B404><xsl:value-of select="Header/ShipmentStatus/@ContainerNumber" /></B404>
\t\t\t\t<B409><xsl:value-of select="Header/ShipmentStatus/@BillOfLadingNumber" /></B409>
\t\t\t</B4>'''
    parts = [_build_st_segment(), b4]
    if mapped.strip():
        parts.append(mapped)
    parts.append(_build_se_generic())
    return "\n\n".join(parts)


def _build_310_body(mappings):
    """EDI 310 - Freight Receipt and Invoice (Ocean)."""
    mapped = _build_mapped_fields(mappings)
    b3b = '''\t\t\t<B3B>
\t\t\t\t<B3B01><xsl:value-of select="Header/Invoice/@InvoiceNumber" /></B3B01>
\t\t\t\t<B3B02><xsl:value-of select="Header/Invoice/@ShipmentMethodOfPayment" /></B3B02>
\t\t\t\t<B3B03><xsl:value-of select="Header/Invoice/@Date" /></B3B03>
\t\t\t\t<B3B06><xsl:value-of select="Header/Invoice/@Amount" /></B3B06>
\t\t\t</B3B>'''
    parts = [_build_st_segment(), b3b]
    if mapped.strip():
        parts.append(mapped)
    parts.append(_build_se_generic())
    return "\n\n".join(parts)


def _build_generic_body(mappings):
    """Fallback for any transaction set not explicitly handled."""
    mapped = _build_mapped_fields(mappings)
    parts = [_build_st_segment()]
    if mapped.strip():
        parts.append(mapped)
    parts.append(_build_se_generic())
    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# Main public function
# ---------------------------------------------------------------------------

def build_universal_prompt(mapping_rows, source_schema, raw_mapping_text,
                            source_ns, target_format, edi_schema_text,
                            transaction_set, **kwargs):
    """Build AI prompt for XSLT generation."""
    from backend.core.ai_engine import XSLT_SYSTEM
    rows_text = ""
    for i, r in enumerate(mapping_rows[:60], 1):
        s = r.get("source", "") or ""
        t = r.get("target", "") or ""
        rule = r.get("rule", "") or r.get("notes", "") or ""
        lit = r.get("literal", "") or ""
        if t:
            rows_text += f"{i}. SOURCE: {s}  ->  TARGET: {t}"
            if lit: rows_text += f"  [LITERAL: {lit}]"
            if rule: rows_text += f"  | Rule: {rule}"
            rows_text += "\n"

    prompt = f"""Generate a complete BizTalk XSLT map for EDI {transaction_set or '210'}.

SOURCE NAMESPACE: {source_ns}
TARGET FORMAT SAMPLE:
{(target_format or '')[:500]}

EDI SCHEMA:
{(edi_schema_text or '')[:1000]}

MAPPING ROWS ({len(mapping_rows)} total):
{rows_text}

Output ONLY valid XSLT starting with <?xml version="1.0" encoding="UTF-8"?>
Follow the BizTalk two-template pattern exactly as shown in your system prompt."""
    return prompt


def generate_xslt(mappings, transaction_set="210", canonical_schema=None,
                   x12_schema=None, log_lines=None, customer_profile=None):
    """
    Generate a complete, structurally correct XSLT map.

    Args:
        mappings: list of dicts with keys: target, source, literal, transform, condition
        transaction_set: "210", "214", "990", etc.
        canonical_schema: path to canonical XSD (unused in structure, used for AI)
        x12_schema: path to X12 XSD
        log_lines: list to append log messages to

    Returns:
        str: Complete XSLT content (UTF-8 string for BizTalk)
    """
    if log_lines is None:
        log_lines = []

    # Load base map metadata
    meta = None
    if get_base_map_metadata:
        meta = get_base_map_metadata(transaction_set)
        if meta:
            log_lines.append(f"Generator: loaded base map metadata for {transaction_set}")
        else:
            log_lines.append(f"Generator: no base map found for {transaction_set}, using defaults")

    # Build stylesheet header
    stylesheet_open = _build_stylesheet_open(meta, transaction_set)
    root_elem = (meta or {}).get("root_element") or f"ns0:X12_00401_{transaction_set}"

    # Assemble body — dispatches per transaction set
    if customer_profile and meta is not None:
        meta["customer_profile"] = customer_profile
    elif customer_profile:
        meta = {"customer_profile": customer_profile}
    body = _build_body_for_transaction(transaction_set or "210", mappings, meta)

    # Use transaction-specific source root from rules (FIX: was hardcoded to s0:Invoice)
    from backend.engine.transaction_rules import get_rules as _get_ts_rules
    source_root_el = _get_ts_rules(transaction_set or "210").get("source_root", "s0:Invoice").lstrip("s0:")

    xsl = f'''<?xml version="1.0" encoding="UTF-8"?>
{stylesheet_open}

\t<xsl:variable name="vLowercaseChars_CONST" select="'abcdefghijklmnopqrstuvwxyz'"/>
\t<xsl:variable name="vUppercaseChars_CONST" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'"/>

\t<xsl:output omit-xml-declaration="yes" method="xml" version="1.0" />

\t<xsl:template match="/">
		<xsl:apply-templates select="/s0:{source_root_el}" />
\t</xsl:template>

	<xsl:template match="/s0:{source_root_el}">
\t\t<{root_elem}>

{body}

\t\t</{root_elem}>
\t</xsl:template>
{_build_helper_templates()}

</xsl:stylesheet>'''

    log_lines.append(f"Generator: deterministic XSLT built ({len(xsl.splitlines())} lines)")
    return xsl


def save_xslt_utf16(xsl_content, output_path):
    """
    Save XSLT as UTF-8.
    
    """
    import codecs
    with codecs.open(output_path, "w", encoding="UTF-8") as f:
        f.write(xsl_content)


def get_xslt_bytes_utf16(xsl_content):
    """Return UTF-8 encoded bytes for HTTP response."""
    return xsl_content.encode("utf-8")

# ---------------------------------------------------------------------------
# Modify XSLT (Post-processing / AI refinement layer)
# ---------------------------------------------------------------------------

def modify_xslt(xslt_content, rules=None):
    """
    Enhance or modify generated XSLT dynamically.

    This acts as a post-processing layer where:
    - AI corrections can be applied
    - Conditions can be injected
    - Partner-specific tweaks can be handled
    """

    if not xslt_content:
        return xslt_content

    rules = rules or {}

    try:
        # -------------------------------------------------------------------
        # Inject conditional wrappers
        # -------------------------------------------------------------------
        for cond in rules.get("conditions", []):
            target = cond.get("target")
            test = cond.get("test")

            if target and test and target in xslt_content:
                xslt_content = xslt_content.replace(
                    target,
                    f'<xsl:if test="{test}">{target}</xsl:if>'
                )

        # -------------------------------------------------------------------
        # Inject loops (basic support)
        # -------------------------------------------------------------------
        for loop in rules.get("loops", []):
            target = loop.get("target")
            select = loop.get("select")

            if target and select and target in xslt_content:
                xslt_content = xslt_content.replace(
                    target,
                    f'<xsl:for-each select="{select}">{target}</xsl:for-each>'
                )

        # -------------------------------------------------------------------
        # Future: AI refinement hook (safe)
        # -------------------------------------------------------------------
        try:
            from core.ai_engine import call_ai
            if call_ai and rules.get("use_ai"):
                xslt_content = call_ai(
                    "Improve this XSLT for correctness and EDI compliance:\n" + xslt_content
                )
        except Exception:
            # Silent fail — never break generation
            pass

    except Exception as e:
        print(f"[modify_xslt] Warning: {e}")

    return xslt_content

# ---------------------------------------------------------------------------
# analyze_mapping — called by /api/analyze endpoint in app.py
# ---------------------------------------------------------------------------

def analyze_mapping(raw_text: str, mapping_rows: list) -> dict:
    """
    Analyse a mapping document and return metadata about it.
    Called by the /api/analyze route.
    """
    result = {
        "total_rows": len(mapping_rows),
        "has_source": False,
        "has_target": False,
        "has_transforms": False,
        "has_conditions": False,
        "source_fields": [],
        "target_fields": [],
        "transforms_found": [],
        "sample_rows": [],
        "raw_length": len(raw_text),
        "keywords_found": [],
    }

    sources, targets, transforms = [], [], []
    for row in mapping_rows:
        src = row.get("source", "")
        tgt = row.get("target", "")
        tr  = row.get("transform", "")
        if src:
            sources.append(src)
        if tgt:
            targets.append(tgt)
        if tr:
            transforms.append(tr)
        if row.get("condition"):
            result["has_conditions"] = True

    result["has_source"]      = bool(sources)
    result["has_target"]      = bool(targets)
    result["has_transforms"]  = bool(transforms)
    result["source_fields"]   = sources[:20]
    result["target_fields"]   = targets[:20]
    result["transforms_found"]= list(set(transforms))[:10]
    result["sample_rows"]     = mapping_rows[:5]
    result["keywords_found"]  = [
        kw for kw in ["210", "214", "990", "204", "850", "856", "810", "997", "315", "310"]
        if kw in raw_text
    ]

    return result


# ---------------------------------------------------------------------------
# generate_xslt_with_registry — called by /api/generate endpoint in app.py
# ---------------------------------------------------------------------------

def generate_xslt_with_registry(
    mapping_rows,
    source_schema=None,
    raw_mapping_text="",
    source_ns="",
    target_format="",
    transaction_set="",
    customer_profile=None
):
    """
    High-level wrapper around generate_xslt that:
      - Auto-detects the transaction set when not supplied
      - Loads schema metadata from the registry
      - Returns (xslt_str, detected_transaction_set, schema_info)
    """
    log_lines = []

    # --- auto-detect transaction set if not provided ---
    detected_ts = (transaction_set or "").strip()
    if not detected_ts and raw_mapping_text:
        for ts_candidate in ["210", "214", "990", "204", "850", "856", "810", "997", "315", "310"]:
            if ts_candidate in raw_mapping_text:
                detected_ts = ts_candidate
                log_lines.append(f"Registry: auto-detected transaction set {detected_ts} from mapping text")
                break

    if not detected_ts:
        detected_ts = "210"
        log_lines.append("Registry: no transaction set detected, defaulting to 210")

    # --- load schema info from registry ---
    schema_info = {}
    if get_base_map_metadata:
        meta = get_base_map_metadata(detected_ts)
        if meta:
            schema_info = {
                "segment_count": len(meta.get("segments", [])),
                "loop_count":    len(meta.get("loops", [])),
                "loops":         meta.get("loops", []),
            }
            log_lines.append(f"Registry: loaded schema metadata for {detected_ts}")
        else:
            log_lines.append(f"Registry: no schema entry for {detected_ts}, proceeding with defaults")

    # --- generate XSLT ---
    xslt = generate_xslt(
        mappings=mapping_rows,
        transaction_set=detected_ts,
        canonical_schema=source_schema,
        log_lines=log_lines,
        customer_profile=customer_profile,
    )

    for line in log_lines:
        print(line)

    return xslt, detected_ts, schema_info


