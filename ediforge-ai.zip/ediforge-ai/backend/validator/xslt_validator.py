import re
"""EDIForge AI — XSLT Validator. Validates syntax + runs lxml checks."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

def validate_xslt_syntax(xslt_content: str) -> dict:
    """Validate XSLT syntax using lxml."""
    try:
        from lxml import etree
    except ImportError:
        return {"valid": False, "error": "lxml not installed. Run: pip install lxml", "errors": []}

    errors = []

    # Check basic structure
    if not xslt_content.strip():
        return {"valid": False, "error": "Empty XSLT content", "errors": ["Empty content"]}

    if "<?xml" not in xslt_content:
        errors.append("Missing XML declaration (<?xml version='1.0'?>)")

    if "xsl:stylesheet" not in xslt_content:
        errors.append("Missing root xsl:stylesheet element")

    # Parse with lxml
    try:
        # Strip XML prolog before fromstring - lxml cannot handle encoding declaration in fromstring
        xslt_for_parse = re.sub(r'<[?]xml[^?]*[?]>', '', xslt_content, count=1).strip()
        root = etree.fromstring(xslt_for_parse.encode("utf-8"))
        xslt = etree.XSLT(root)
        return {
            "valid": True,
            "error": None,
            "errors": errors,
            "warnings": [],
            "template_count": len(root.findall(".//{http://www.w3.org/1999/XSL/Transform}template")),
            "for_each_count": len(root.findall(".//{http://www.w3.org/1999/XSL/Transform}for-each")),
            "choose_count": len(root.findall(".//{http://www.w3.org/1999/XSL/Transform}choose"))
        }
    except etree.XMLSyntaxError as e:
        return {"valid": False, "error": f"XML Syntax Error: {e}", "errors": [str(e)]}
    except etree.XSLTParseError as e:
        return {"valid": False, "error": f"XSLT Parse Error: {e}", "errors": [str(e)]}
    except Exception as e:
        return {"valid": False, "error": str(e), "errors": [str(e)]}


def auto_fix_xslt(xslt_content: str, max_retries: int = 3) -> dict:
    """Auto-fix XSLT by sending errors back to AI."""
    from backend.core.ai_engine import call_ai, clean_xslt, FIX_SYSTEM, MAX_FIX_RETRIES

    max_retries = min(max_retries, MAX_FIX_RETRIES)
    current_xslt = xslt_content
    fix_history = []

    for attempt in range(1, max_retries + 1):
        result = validate_xslt_syntax(current_xslt)

        if result["valid"]:
            return {
                "success": True,
                "xslt": current_xslt,
                "attempts": attempt - 1,
                "fix_history": fix_history,
                "validation": result
            }

        error = result["error"]
        print(f"  Fix attempt {attempt}/{max_retries}: {error}")

        prompt = f"""Fix this XSLT. It has the following error:

ERROR: {error}

BROKEN XSLT:
{current_xslt}

Return ONLY the complete fixed XSLT starting with <?xml version="1.0" encoding="UTF-8"?>"""

        try:
            fixed = call_ai(prompt, FIX_SYSTEM)
            fixed = clean_xslt(fixed)
            fix_history.append({"attempt": attempt, "error": error, "fixed": True})
            current_xslt = fixed
        except Exception as e:
            fix_history.append({"attempt": attempt, "error": error, "fixed": False, "ai_error": str(e)})

    # Final validation
    final_result = validate_xslt_syntax(current_xslt)
    return {
        "success": final_result["valid"],
        "xslt": current_xslt,
        "attempts": max_retries,
        "fix_history": fix_history,
        "validation": final_result
    }
