﻿"""
EDIForge AI - XSLT Quality Validator
Validates generated XSLT against patterns learned from training maps.
Called from app.py after generation.
"""
from __future__ import annotations
import re
from typing import List


def validate_generated_xslt(xslt: str, transaction_set: str) -> dict:
    """
    Run quality checks on a generated XSLT:
    1. Required EDI segments present
    2. No empty mandatory elements
    3. Loop structure correct
    4. CleanAlphaField helper present
    5. Namespace declarations correct
    Returns a quality report dict.
    """
    issues:   List[str] = []
    warnings: List[str] = []

    if not xslt or len(xslt) < 100:
        return {"passed": False, "summary": "XSLT is empty or too short",
                "issues": ["Empty XSLT"], "warnings": []}

    # 1. Required segments
    try:
        from backend.engine.transaction_rules import get_required_segments
        for seg in get_required_segments(transaction_set):
            if f"<{seg}" not in xslt and f"<ns0:{seg}" not in xslt:
                issues.append(f"Missing required segment: {seg}")
    except Exception:
        pass

    # 2. Namespace checks
    if "xmlns:xsl" not in xslt:
        issues.append("Missing XSL namespace declaration")
    if "xmlns:ns0" not in xslt:
        warnings.append("Missing ns0 namespace declaration")
    if "xmlns:s0" not in xslt:
        warnings.append("Missing s0 source namespace declaration")

    # 3. Helper templates
    if "CleanAlphaField" not in xslt:
        warnings.append("CleanAlphaField helper template missing")

    # 4. For-each balance
    opens  = len(re.findall(r"<xsl:for-each", xslt))
    closes = len(re.findall(r"</xsl:for-each>", xslt))
    if opens != closes:
        issues.append(f"Unbalanced xsl:for-each: {opens} open vs {closes} close")

    # 5. If balance
    opens_if  = len(re.findall(r"<xsl:if\b", xslt))
    closes_if = len(re.findall(r"</xsl:if>", xslt))
    if opens_if != closes_if:
        issues.append(f"Unbalanced xsl:if: {opens_if} open vs {closes_if} close")

    # 6. Compare with learned patterns
    try:
        from backend.engine.reference_learning import _load_patterns
        patterns = _load_patterns(transaction_set)
        learned_loops = patterns.get("loops", {})
        for loop_name, expected_xpath in learned_loops.items():
            if loop_name not in xslt:
                warnings.append(f"Learned loop {loop_name} not found in XSLT")
    except Exception:
        pass

    passed = len(issues) == 0
    summary = ("PASSED" if passed else f"FAILED ({len(issues)} issues)") + \
              (f" | {len(warnings)} warnings" if warnings else "")

    return {
        "passed":   passed,
        "summary":  summary,
        "issues":   issues,
        "warnings": warnings,
        "transaction_set": transaction_set,
    }
