"""EDIForge AI — Entry point"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from backend.api.app import app
from dotenv import load_dotenv
load_dotenv()

if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    print(f"""
╔═══════════════════════════════════════╗
║         EDIForge AI v2.0              ║
║   AI-Powered EDI Mapping Engine       ║
╠═══════════════════════════════════════╣
║  URL:      http://localhost:{port}       ║
║  Provider: {os.getenv('AI_PROVIDER','openrouter').upper():<28}║
║  Model:    {os.getenv('AI_MODEL','deepseek/deepseek-chat')[:28]:<28}║
╚═══════════════════════════════════════╝
    """)
    app.run(host="0.0.0.0", port=port, debug=os.getenv("FLASK_DEBUG","false")=="true")

# EDIForge AI v4 -- auto-learn on startup
try:
    from backend.schema.reference_template_engine import auto_populate_base_maps
    from backend.mapping.self_learning_engine import learn_all_maps
    print("[v4] Auto-populating base maps...")
    auto_populate_base_maps()
    print("[v4] Learning from existing XSL maps...")
    result = learn_all_maps()
    print(f"[v4] KB ready: {result.get('total_mappings',0)} mappings from "
          f"{result.get('maps_processed',0)} maps")
except Exception as e:
    print(f"[v4] Auto-learn skipped: {e}")

