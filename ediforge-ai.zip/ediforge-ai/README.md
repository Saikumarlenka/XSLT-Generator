# EDIForge AI — Production-Grade EDI Mapping Engine

AI-powered XSLT generator with automatic validation, auto-fix, and test engine.

## Features
- **Generate XSLT** from mapping docs (.docx, .pdf, .xlsx, .csv, .txt)
- **Schema Intelligence** — reads canonical XSD, infers from sample XML, parses EDI spec PDF
- **XSLT Validator** — lxml syntax checking
- **AI Auto-Fix** — sends errors back to AI (up to 3 retries)
- **Test Engine** — runs sample XML through XSLT and shows output
- **EDI Spec Parser** — reads implementation guide PDFs
- **Modify Existing** — update XSLT maps with change documents

## Quick Start

```bash
# 1. Clone and setup
cd ediforge-ai
pip install -r requirements.txt
cp .env.example .env
# Edit .env — add your OpenRouter API key

# 2. Get free API key
# OpenRouter: https://openrouter.ai → Sign up → Keys
# DeepSeek model is free via OpenRouter

# 3. Run
python run.py

# 4. Open browser
# http://localhost:5000
```

## AI Providers (.env)

| Provider | Key Variable | Best Model |
|---|---|---|
| OpenRouter (DeepSeek) | OPENROUTER_API_KEY | deepseek/deepseek-chat |
| Groq (fallback) | GROQ_API_KEY | llama-3.3-70b-versatile |
| Gemini | GEMINI_API_KEY | gemini-2.0-flash |

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | /api/generate | Generate XSLT from mapping doc + schemas |
| POST | /api/modify | Update existing XSLT with changes |
| POST | /api/validate | Validate XSLT syntax |
| POST | /api/fix | AI auto-fix invalid XSLT |
| POST | /api/test | Run transformation with sample XML |
| POST | /api/parse-spec | Parse EDI spec PDF |
| GET | /health | Server status |

## Project Structure

```
ediforge-ai/
├── backend/
│   ├── core/ai_engine.py        # AI engine (OpenRouter/Groq/Gemini)
│   ├── parser/doc_parser.py     # Document parser (.docx/.pdf/.xlsx/.csv)
│   ├── parser/pdf_parser.py     # EDI spec PDF parser
│   ├── schema/schema_reader.py  # XSD + XML schema analyzer
│   ├── generator/xslt_generator.py # XSLT generation + prompt builder
│   ├── validator/xslt_validator.py # lxml validation + AI auto-fix
│   ├── tester/transformation_runner.py # Test engine
│   └── api/app.py               # Flask API
├── frontend/index.html          # Web UI
├── schemas/                     # Store .xsd files here
├── mappings/                    # Store mapping docs here
├── samples/                     # Store sample XML files here
├── output/                      # Generated XSLT saved here
├── run.py                       # Entry point
├── requirements.txt
└── .env.example
```
